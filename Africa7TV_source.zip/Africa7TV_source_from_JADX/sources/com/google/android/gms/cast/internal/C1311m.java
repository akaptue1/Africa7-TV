package com.google.android.gms.cast.internal;

import com.google.android.gms.cast.C1260m;

/* renamed from: com.google.android.gms.cast.internal.m */
class C1311m implements Runnable {
    /* renamed from: a */
    final /* synthetic */ C1303g f6721a;
    /* renamed from: b */
    final /* synthetic */ String f6722b;
    /* renamed from: c */
    final /* synthetic */ String f6723c;
    /* renamed from: d */
    final /* synthetic */ C1307i f6724d;

    C1311m(C1307i c1307i, C1303g c1303g, String str, String str2) {
        this.f6724d = c1307i;
        this.f6721a = c1303g;
        this.f6722b = str;
        this.f6723c = str2;
    }

    public void run() {
        synchronized (this.f6721a.f6687i) {
            C1260m c1260m = (C1260m) this.f6721a.f6687i.get(this.f6722b);
        }
        if (c1260m != null) {
            c1260m.mo1536a(this.f6721a.f6685g, this.f6722b, this.f6723c);
            return;
        }
        C1303g.f6682a.m9644b("Discarded message for unknown namespace '%s'", this.f6722b);
    }
}
