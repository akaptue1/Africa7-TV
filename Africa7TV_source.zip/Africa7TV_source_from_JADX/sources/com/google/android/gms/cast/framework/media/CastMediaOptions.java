package com.google.android.gms.cast.framework.media;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.cast.internal.C1318w;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.p034a.C0830f;

public class CastMediaOptions extends AbstractSafeParcelable {
    public static final Creator<CastMediaOptions> CREATOR = new C1281w();
    /* renamed from: a */
    private static final C1318w f6545a = new C1318w("CastMediaOptions");
    /* renamed from: b */
    private final int f6546b;
    /* renamed from: c */
    private final String f6547c;
    /* renamed from: d */
    private final String f6548d;
    /* renamed from: e */
    private final C1257x f6549e;
    /* renamed from: f */
    private final NotificationOptions f6550f;

    CastMediaOptions(int i, String str, String str2, IBinder iBinder, NotificationOptions notificationOptions) {
        this.f6546b = i;
        this.f6547c = str;
        this.f6548d = str2;
        this.f6549e = C1258y.m9343a(iBinder);
        this.f6550f = notificationOptions;
    }

    /* renamed from: a */
    int m9270a() {
        return this.f6546b;
    }

    /* renamed from: b */
    public String m9271b() {
        return this.f6547c;
    }

    /* renamed from: c */
    public NotificationOptions m9272c() {
        return this.f6550f;
    }

    /* renamed from: d */
    public String m9273d() {
        return this.f6548d;
    }

    /* renamed from: e */
    public C1255a m9274e() {
        if (this.f6549e != null) {
            try {
                return (C1255a) C0830f.m6211a(this.f6549e.mo1535b());
            } catch (Throwable e) {
                f6545a.m9642a(e, "Unable to call %s on %s.", "getWrappedClientObject", C1257x.class.getSimpleName());
            }
        }
        return null;
    }

    /* renamed from: f */
    public IBinder m9275f() {
        return this.f6549e == null ? null : this.f6549e.asBinder();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1281w.m9439a(this, parcel, i);
    }
}
