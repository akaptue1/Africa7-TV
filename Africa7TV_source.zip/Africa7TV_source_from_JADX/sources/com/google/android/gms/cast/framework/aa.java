package com.google.android.gms.cast.framework;

import android.os.Bundle;
import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface aa extends IInterface {
    /* renamed from: a */
    Bundle mo1436a();

    /* renamed from: a */
    void mo1437a(C0827c c0827c);

    /* renamed from: a */
    void mo1438a(C1290u c1290u);

    /* renamed from: b */
    void mo1439b(C0827c c0827c);

    /* renamed from: b */
    void mo1440b(C1290u c1290u);

    /* renamed from: b */
    boolean mo1441b();

    /* renamed from: c */
    av mo1442c();

    /* renamed from: d */
    aj mo1443d();

    /* renamed from: e */
    void mo1444e();

    /* renamed from: f */
    C0827c mo1445f();
}
