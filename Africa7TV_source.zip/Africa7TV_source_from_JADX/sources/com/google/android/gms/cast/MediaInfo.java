package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.cast.internal.C1312n;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.bp;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.util.C1424m;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class MediaInfo extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Creator<MediaInfo> CREATOR = new C1333y();
    /* renamed from: a */
    String f6374a;
    /* renamed from: b */
    private final int f6375b;
    /* renamed from: c */
    private final String f6376c;
    /* renamed from: d */
    private int f6377d;
    /* renamed from: e */
    private String f6378e;
    /* renamed from: f */
    private MediaMetadata f6379f;
    /* renamed from: g */
    private long f6380g;
    /* renamed from: h */
    private List<MediaTrack> f6381h;
    /* renamed from: i */
    private TextTrackStyle f6382i;
    /* renamed from: j */
    private List<AdBreakInfo> f6383j;
    /* renamed from: k */
    private JSONObject f6384k;

    MediaInfo(int i, String str, int i2, String str2, MediaMetadata mediaMetadata, long j, List<MediaTrack> list, TextTrackStyle textTrackStyle, String str3, List<AdBreakInfo> list2) {
        this.f6375b = i;
        this.f6376c = str;
        this.f6377d = i2;
        this.f6378e = str2;
        this.f6379f = mediaMetadata;
        this.f6380g = j;
        this.f6381h = list;
        this.f6382i = textTrackStyle;
        this.f6374a = str3;
        if (this.f6374a != null) {
            try {
                this.f6384k = new JSONObject(this.f6374a);
            } catch (JSONException e) {
                this.f6384k = null;
                this.f6374a = null;
            }
        } else {
            this.f6384k = null;
        }
        this.f6383j = list2;
    }

    MediaInfo(JSONObject jSONObject) {
        this(1, jSONObject.getString("contentId"), -1, null, null, -1, null, null, null, null);
        String string = jSONObject.getString("streamType");
        if ("NONE".equals(string)) {
            this.f6377d = 0;
        } else if ("BUFFERED".equals(string)) {
            this.f6377d = 1;
        } else if ("LIVE".equals(string)) {
            this.f6377d = 2;
        } else {
            this.f6377d = -1;
        }
        this.f6378e = jSONObject.getString("contentType");
        if (jSONObject.has("metadata")) {
            JSONObject jSONObject2 = jSONObject.getJSONObject("metadata");
            this.f6379f = new MediaMetadata(jSONObject2.getInt("metadataType"));
            this.f6379f.m8899a(jSONObject2);
        }
        this.f6380g = -1;
        if (jSONObject.has("duration") && !jSONObject.isNull("duration")) {
            double optDouble = jSONObject.optDouble("duration", 0.0d);
            if (!(Double.isNaN(optDouble) || Double.isInfinite(optDouble))) {
                this.f6380g = C1312n.m9598a(optDouble);
            }
        }
        if (jSONObject.has("tracks")) {
            this.f6381h = new ArrayList();
            JSONArray jSONArray = jSONObject.getJSONArray("tracks");
            for (int i = 0; i < jSONArray.length(); i++) {
                this.f6381h.add(new MediaTrack(jSONArray.getJSONObject(i)));
            }
        } else {
            this.f6381h = null;
        }
        if (jSONObject.has("textTrackStyle")) {
            jSONObject2 = jSONObject.getJSONObject("textTrackStyle");
            TextTrackStyle textTrackStyle = new TextTrackStyle();
            textTrackStyle.m8955a(jSONObject2);
            this.f6382i = textTrackStyle;
        } else {
            this.f6382i = null;
        }
        this.f6384k = jSONObject.optJSONObject("customData");
    }

    /* renamed from: a */
    int m8882a() {
        return this.f6375b;
    }

    /* renamed from: a */
    public void m8883a(List<AdBreakInfo> list) {
        this.f6383j = list;
    }

    /* renamed from: b */
    public String m8884b() {
        return this.f6376c;
    }

    /* renamed from: c */
    public int m8885c() {
        return this.f6377d;
    }

    /* renamed from: d */
    public String m8886d() {
        return this.f6378e;
    }

    /* renamed from: e */
    public MediaMetadata m8887e() {
        return this.f6379f;
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaInfo)) {
            return false;
        }
        MediaInfo mediaInfo = (MediaInfo) obj;
        if ((this.f6384k == null) != (mediaInfo.f6384k == null)) {
            return false;
        }
        if (this.f6384k != null && mediaInfo.f6384k != null && !C1424m.m10351a(this.f6384k, mediaInfo.f6384k)) {
            return false;
        }
        if (!(C1312n.m9602a(this.f6376c, mediaInfo.f6376c) && this.f6377d == mediaInfo.f6377d && C1312n.m9602a(this.f6378e, mediaInfo.f6378e) && C1312n.m9602a(this.f6379f, mediaInfo.f6379f) && this.f6380g == mediaInfo.f6380g)) {
            z = false;
        }
        return z;
    }

    /* renamed from: f */
    public long m8888f() {
        return this.f6380g;
    }

    /* renamed from: g */
    public List<MediaTrack> m8889g() {
        return this.f6381h;
    }

    /* renamed from: h */
    public TextTrackStyle m8890h() {
        return this.f6382i;
    }

    public int hashCode() {
        return bp.m10107a(this.f6376c, Integer.valueOf(this.f6377d), this.f6378e, this.f6379f, Long.valueOf(this.f6380g), String.valueOf(this.f6384k));
    }

    /* renamed from: i */
    public List<AdBreakInfo> m8891i() {
        return this.f6383j;
    }

    /* renamed from: j */
    public JSONObject m8892j() {
        JSONObject jSONObject = new JSONObject();
        try {
            Object obj;
            jSONObject.put("contentId", this.f6376c);
            switch (this.f6377d) {
                case 1:
                    obj = "BUFFERED";
                    break;
                case 2:
                    obj = "LIVE";
                    break;
                default:
                    obj = "NONE";
                    break;
            }
            jSONObject.put("streamType", obj);
            if (this.f6378e != null) {
                jSONObject.put("contentType", this.f6378e);
            }
            if (this.f6379f != null) {
                jSONObject.put("metadata", this.f6379f.m8902d());
            }
            if (this.f6380g <= -1) {
                jSONObject.put("duration", JSONObject.NULL);
            } else {
                jSONObject.put("duration", C1312n.m9597a(this.f6380g));
            }
            if (this.f6381h != null) {
                JSONArray jSONArray = new JSONArray();
                for (MediaTrack i : this.f6381h) {
                    jSONArray.put(i.m8951i());
                }
                jSONObject.put("tracks", jSONArray);
            }
            if (this.f6382i != null) {
                jSONObject.put("textTrackStyle", this.f6382i.m8967m());
            }
            if (this.f6384k != null) {
                jSONObject.put("customData", this.f6384k);
            }
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i) {
        this.f6374a = this.f6384k == null ? null : this.f6384k.toString();
        C1333y.m9702a(this, parcel, i);
    }
}
