package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.bp;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class JoinOptions extends AbstractSafeParcelable {
    public static final Creator<JoinOptions> CREATOR = new C1331w();
    /* renamed from: a */
    private final int f6369a;
    /* renamed from: b */
    private int f6370b;

    public JoinOptions() {
        this(1, 0);
    }

    JoinOptions(int i, int i2) {
        this.f6369a = i;
        this.f6370b = i2;
    }

    /* renamed from: a */
    int m8877a() {
        return this.f6369a;
    }

    /* renamed from: b */
    public int m8878b() {
        return this.f6370b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof JoinOptions)) {
            return false;
        }
        return this.f6370b == ((JoinOptions) obj).f6370b;
    }

    public int hashCode() {
        return bp.m10107a(Integer.valueOf(this.f6370b));
    }

    public String toString() {
        String str;
        switch (this.f6370b) {
            case 0:
                str = "STRONG";
                break;
            case 2:
                str = "INVISIBLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        return String.format("joinOptions(connectionType=%s)", new Object[]{str});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1331w.m9696a(this, parcel, i);
    }
}
