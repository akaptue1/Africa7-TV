package com.google.android.gms.cast.framework.media;

import com.google.android.gms.common.api.C1223y;

/* renamed from: com.google.android.gms.cast.framework.media.m */
public interface C1272m extends C1223y {
}
