package com.google.android.gms.cast;

import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.cast.internal.C1317v;
import com.google.android.gms.common.api.C1138g;
import com.google.android.gms.common.api.C1344a;

/* renamed from: com.google.android.gms.cast.a */
public final class C1221a {
    /* renamed from: a */
    static final C1138g<C1303g, C1321j> f6445a = new C1222b();
    /* renamed from: b */
    public static final C1344a<C1321j> f6446b = new C1344a("Cast.API", f6445a, C1317v.f6727a);
    /* renamed from: c */
    public static final C1225d f6447c = new C1226e();
}
