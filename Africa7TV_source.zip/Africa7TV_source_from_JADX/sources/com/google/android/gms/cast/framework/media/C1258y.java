package com.google.android.gms.cast.framework.media;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.p034a.C0827c;

/* renamed from: com.google.android.gms.cast.framework.media.y */
public abstract class C1258y extends Binder implements C1257x {
    public C1258y() {
        attachInterface(this, "com.google.android.gms.cast.framework.media.IImagePicker");
    }

    /* renamed from: a */
    public static C1257x m9343a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.framework.media.IImagePicker");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof C1257x)) ? new C1282z(iBinder) : (C1257x) queryLocalInterface;
    }

    public IBinder asBinder() {
        return this;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        IBinder iBinder = null;
        WebImage a;
        switch (i) {
            case 1:
                parcel.enforceInterface("com.google.android.gms.cast.framework.media.IImagePicker");
                a = mo1533a(parcel.readInt() != 0 ? (MediaMetadata) MediaMetadata.CREATOR.createFromParcel(parcel) : null, parcel.readInt());
                parcel2.writeNoException();
                if (a != null) {
                    parcel2.writeInt(1);
                    a.writeToParcel(parcel2, 1);
                } else {
                    parcel2.writeInt(0);
                }
                return true;
            case 2:
                parcel.enforceInterface("com.google.android.gms.cast.framework.media.IImagePicker");
                C0827c b = mo1535b();
                parcel2.writeNoException();
                if (b != null) {
                    iBinder = b.asBinder();
                }
                parcel2.writeStrongBinder(iBinder);
                return true;
            case 3:
                parcel.enforceInterface("com.google.android.gms.cast.framework.media.IImagePicker");
                int a2 = mo1532a();
                parcel2.writeNoException();
                parcel2.writeInt(a2);
                return true;
            case 4:
                parcel.enforceInterface("com.google.android.gms.cast.framework.media.IImagePicker");
                a = mo1534a(parcel.readInt() != 0 ? (MediaMetadata) MediaMetadata.CREATOR.createFromParcel(parcel) : null, parcel.readInt() != 0 ? (ImageHints) ImageHints.CREATOR.createFromParcel(parcel) : null);
                parcel2.writeNoException();
                if (a != null) {
                    parcel2.writeInt(1);
                    a.writeToParcel(parcel2, 1);
                } else {
                    parcel2.writeInt(0);
                }
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.framework.media.IImagePicker");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
