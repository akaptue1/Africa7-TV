package com.google.android.gms.cast.framework.media;

import com.google.android.gms.common.api.Status;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.framework.media.u */
final class C1279u implements C1272m {
    /* renamed from: a */
    private final Status f6628a;
    /* renamed from: b */
    private final JSONObject f6629b;

    C1279u(Status status, JSONObject jSONObject) {
        this.f6628a = status;
        this.f6629b = jSONObject;
    }

    /* renamed from: e */
    public Status mo1546e() {
        return this.f6628a;
    }
}
