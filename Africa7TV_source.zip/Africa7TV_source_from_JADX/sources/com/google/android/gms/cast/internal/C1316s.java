package com.google.android.gms.cast.internal;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.cast.JoinOptions;
import com.google.android.gms.cast.LaunchOptions;

/* renamed from: com.google.android.gms.cast.internal.s */
class C1316s implements C1314q {
    /* renamed from: a */
    private IBinder f6726a;

    C1316s(IBinder iBinder) {
        this.f6726a = iBinder;
    }

    /* renamed from: a */
    public void mo1579a() {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            this.f6726a.transact(1, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1580a(double d, double d2, boolean z) {
        int i = 1;
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeDouble(d);
            obtain.writeDouble(d2);
            if (!z) {
                i = 0;
            }
            obtain.writeInt(i);
            this.f6726a.transact(7, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1581a(String str) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            this.f6726a.transact(5, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1582a(String str, LaunchOptions launchOptions) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            if (launchOptions != null) {
                obtain.writeInt(1);
                launchOptions.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f6726a.transact(13, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1583a(String str, String str2) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            obtain.writeString(str2);
            this.f6726a.transact(3, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1584a(String str, String str2, long j) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            obtain.writeString(str2);
            obtain.writeLong(j);
            this.f6726a.transact(9, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1585a(String str, String str2, long j, String str3) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            obtain.writeString(str2);
            obtain.writeLong(j);
            obtain.writeString(str3);
            this.f6726a.transact(15, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1586a(String str, String str2, JoinOptions joinOptions) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            obtain.writeString(str2);
            if (joinOptions != null) {
                obtain.writeInt(1);
                joinOptions.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f6726a.transact(14, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1587a(String str, boolean z) {
        int i = 1;
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            if (!z) {
                i = 0;
            }
            obtain.writeInt(i);
            this.f6726a.transact(2, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1588a(String str, byte[] bArr, long j) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            obtain.writeByteArray(bArr);
            obtain.writeLong(j);
            this.f6726a.transact(10, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1589a(boolean z, double d, boolean z2) {
        int i = 1;
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeInt(z ? 1 : 0);
            obtain.writeDouble(d);
            if (!z2) {
                i = 0;
            }
            obtain.writeInt(i);
            this.f6726a.transact(8, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public IBinder asBinder() {
        return this.f6726a;
    }

    /* renamed from: b */
    public void mo1590b() {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            this.f6726a.transact(4, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: b */
    public void mo1591b(String str) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            this.f6726a.transact(11, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: c */
    public void mo1592c() {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            this.f6726a.transact(6, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    /* renamed from: c */
    public void mo1593c(String str) {
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
            obtain.writeString(str);
            this.f6726a.transact(12, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }
}
