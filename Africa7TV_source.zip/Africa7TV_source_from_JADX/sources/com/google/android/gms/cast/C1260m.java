package com.google.android.gms.cast;

/* renamed from: com.google.android.gms.cast.m */
public interface C1260m {
    /* renamed from: a */
    void mo1536a(CastDevice castDevice, String str, String str2);
}
