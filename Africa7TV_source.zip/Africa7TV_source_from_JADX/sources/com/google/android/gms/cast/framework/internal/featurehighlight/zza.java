package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v4.view.C0231r;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import com.google.android.gms.C1433e;

public final class zza extends ViewGroup {
    /* renamed from: a */
    private final int[] f6532a = new int[2];
    /* renamed from: b */
    private final Rect f6533b = new Rect();
    /* renamed from: c */
    private final Rect f6534c = new Rect();
    /* renamed from: d */
    private final C1251f f6535d;
    /* renamed from: e */
    private final C1249d f6536e;
    /* renamed from: f */
    private C1246c f6537f;
    /* renamed from: g */
    private View f6538g;
    /* renamed from: h */
    private View f6539h;
    /* renamed from: i */
    private final C1250e f6540i;
    /* renamed from: j */
    private final C0231r f6541j;
    /* renamed from: k */
    private C0231r f6542k;
    /* renamed from: l */
    private C1248b f6543l;
    /* renamed from: m */
    private boolean f6544m;

    public zza(Context context) {
        super(context);
        setId(C1433e.cast_featurehighlight_view);
        setWillNotDraw(false);
        this.f6536e = new C1249d(context);
        this.f6536e.setCallback(this);
        this.f6535d = new C1251f(context);
        this.f6535d.setCallback(this);
        this.f6540i = new C1250e(this);
        this.f6541j = new C0231r(context, new C1247a(this));
        this.f6541j.m2403a(false);
        setVisibility(8);
    }

    /* renamed from: a */
    private void m9260a(int[] iArr, View view) {
        getLocationInWindow(iArr);
        int i = iArr[0];
        int i2 = iArr[1];
        view.getLocationInWindow(iArr);
        iArr[0] = iArr[0] - i;
        iArr[1] = iArr[1] - i2;
    }

    /* renamed from: a */
    private boolean m9261a(float f, float f2) {
        return this.f6534c.contains(Math.round(f), Math.round(f2));
    }

    /* renamed from: a */
    Drawable m9264a() {
        return null;
    }

    /* renamed from: b */
    View m9265b() {
        return this.f6537f.asView();
    }

    /* renamed from: c */
    C1251f m9266c() {
        return this.f6535d;
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof MarginLayoutParams;
    }

    /* renamed from: d */
    C1249d m9267d() {
        return this.f6536e;
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new MarginLayoutParams(-2, -2);
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new MarginLayoutParams(getContext(), attributeSet);
    }

    protected LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return new MarginLayoutParams(layoutParams);
    }

    protected void onDraw(Canvas canvas) {
        canvas.save();
        if (this.f6539h != null) {
            canvas.clipRect(this.f6534c);
        }
        this.f6535d.draw(canvas);
        this.f6536e.draw(canvas);
        if (this.f6538g != null) {
            if (this.f6538g.getParent() != null) {
                Bitmap createBitmap = Bitmap.createBitmap(this.f6538g.getWidth(), this.f6538g.getHeight(), Config.ARGB_8888);
                this.f6538g.draw(new Canvas(createBitmap));
                int a = this.f6535d.m9255a();
                int red = Color.red(a);
                int green = Color.green(a);
                int blue = Color.blue(a);
                for (a = 0; a < createBitmap.getHeight(); a++) {
                    for (int i = 0; i < createBitmap.getWidth(); i++) {
                        int pixel = createBitmap.getPixel(i, a);
                        if (Color.alpha(pixel) != 0) {
                            createBitmap.setPixel(i, a, Color.argb(Color.alpha(pixel), red, green, blue));
                        }
                    }
                }
                canvas.drawBitmap(createBitmap, (float) this.f6533b.left, (float) this.f6533b.top, null);
            }
            canvas.restore();
            return;
        }
        throw new IllegalStateException("Neither target view nor drawable was set");
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (this.f6538g == null) {
            throw new IllegalStateException("Target view must be set before layout");
        }
        if (this.f6538g.getParent() != null) {
            m9260a(this.f6532a, this.f6538g);
        }
        this.f6533b.set(this.f6532a[0], this.f6532a[1], this.f6532a[0] + this.f6538g.getWidth(), this.f6532a[1] + this.f6538g.getHeight());
        if (this.f6539h != null) {
            m9260a(this.f6532a, this.f6539h);
            this.f6534c.set(this.f6532a[0], this.f6532a[1], this.f6532a[0] + this.f6539h.getMeasuredWidth(), this.f6532a[1] + this.f6539h.getMeasuredHeight());
        } else {
            this.f6534c.set(i, i2, i3, i4);
        }
        this.f6535d.setBounds(this.f6534c);
        this.f6536e.setBounds(this.f6534c);
        this.f6540i.m9252a(this.f6533b, this.f6534c);
    }

    protected void onMeasure(int i, int i2) {
        setMeasuredDimension(resolveSize(MeasureSpec.getSize(i), i), resolveSize(MeasureSpec.getSize(i2), i2));
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f6544m = this.f6533b.contains((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        if (this.f6544m) {
            if (this.f6542k != null) {
                this.f6542k.m2404a(motionEvent);
                if (actionMasked == 1) {
                    motionEvent = MotionEvent.obtain(motionEvent);
                    motionEvent.setAction(3);
                }
            }
            if (this.f6538g.getParent() != null) {
                this.f6538g.onTouchEvent(motionEvent);
            }
        } else {
            this.f6541j.m2404a(motionEvent);
        }
        return true;
    }

    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f6535d || drawable == this.f6536e || drawable == null;
    }
}
