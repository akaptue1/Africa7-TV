package com.google.android.gms.cast.internal;

import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.cast.C1224c;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.cast.internal.h */
final class C1304h implements C1224c {
    /* renamed from: a */
    private final Status f6705a;
    /* renamed from: b */
    private final ApplicationMetadata f6706b;
    /* renamed from: c */
    private final String f6707c;
    /* renamed from: d */
    private final String f6708d;
    /* renamed from: e */
    private final boolean f6709e;

    public C1304h(Status status) {
        this(status, null, null, null, false);
    }

    public C1304h(Status status, ApplicationMetadata applicationMetadata, String str, String str2, boolean z) {
        this.f6705a = status;
        this.f6706b = applicationMetadata;
        this.f6707c = str;
        this.f6708d = str2;
        this.f6709e = z;
    }

    /* renamed from: a */
    public ApplicationMetadata mo1562a() {
        return this.f6706b;
    }

    /* renamed from: b */
    public String mo1563b() {
        return this.f6707c;
    }

    /* renamed from: c */
    public String mo1564c() {
        return this.f6708d;
    }

    /* renamed from: d */
    public boolean mo1565d() {
        return this.f6709e;
    }

    /* renamed from: e */
    public Status mo1546e() {
        return this.f6705a;
    }
}
