package com.google.android.gms.cast.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;

/* renamed from: com.google.android.gms.cast.internal.o */
public class C1313o implements Creator<DeviceStatus> {
    /* renamed from: a */
    static void m9605a(DeviceStatus deviceStatus, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, deviceStatus.m9493a());
        C1386c.m10196a(parcel, 2, deviceStatus.m9494b());
        C1386c.m10209a(parcel, 3, deviceStatus.m9495c());
        C1386c.m10198a(parcel, 4, deviceStatus.m9496d());
        C1386c.m10202a(parcel, 5, deviceStatus.m9498f(), i, false);
        C1386c.m10198a(parcel, 6, deviceStatus.m9497e());
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public DeviceStatus m9606a(Parcel parcel) {
        int i = 0;
        int b = C1384a.m10169b(parcel);
        double d = 0.0d;
        ApplicationMetadata applicationMetadata = null;
        int i2 = 0;
        boolean z = false;
        int i3 = 0;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i3 = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    d = C1384a.m10181k(parcel, a);
                    break;
                case 3:
                    z = C1384a.m10173c(parcel, a);
                    break;
                case 4:
                    i2 = C1384a.m10175e(parcel, a);
                    break;
                case 5:
                    applicationMetadata = (ApplicationMetadata) C1384a.m10166a(parcel, a, ApplicationMetadata.CREATOR);
                    break;
                case 6:
                    i = C1384a.m10175e(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new DeviceStatus(i3, d, z, i2, applicationMetadata, i);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public DeviceStatus[] m9607a(int i) {
        return new DeviceStatus[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9606a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9607a(i);
    }
}
