package com.google.android.gms.cast.framework.media;

import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.cast.internal.C1320z;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;
import java.io.IOException;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.framework.media.f */
class C1265f extends C1264r {
    /* renamed from: a */
    final /* synthetic */ JSONObject f6607a;
    /* renamed from: b */
    final /* synthetic */ C1261d f6608b;

    C1265f(C1261d c1261d, C1352q c1352q, JSONObject jSONObject) {
        this.f6608b = c1261d;
        this.f6607a = jSONObject;
        super(c1352q);
    }

    /* renamed from: a */
    protected void mo1541a(C1303g c1303g) {
        synchronized (this.f6608b.f6595b) {
            try {
                this.f6608b.f6597d.m9657a(this.e, 0, -1, null, -1, null, this.f6607a);
            } catch (IOException e) {
                m8763b((C1223y) (C1272m) mo1416b(new Status(2100)));
            } catch (C1320z e2) {
                m8763b((C1223y) (C1272m) mo1416b(new Status(2100)));
            }
        }
    }
}
