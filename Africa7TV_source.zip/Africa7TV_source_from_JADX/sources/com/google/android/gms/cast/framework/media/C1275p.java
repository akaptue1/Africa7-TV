package com.google.android.gms.cast.framework.media;

import com.google.android.gms.cast.internal.aa;
import com.google.android.gms.common.api.C1352q;
import java.io.IOException;

/* renamed from: com.google.android.gms.cast.framework.media.p */
class C1275p implements aa {
    /* renamed from: a */
    final /* synthetic */ C1261d f6620a;
    /* renamed from: b */
    private C1352q f6621b;
    /* renamed from: c */
    private long f6622c = 0;

    public C1275p(C1261d c1261d) {
        this.f6620a = c1261d;
    }

    /* renamed from: a */
    public long mo1542a() {
        long j = this.f6622c + 1;
        this.f6622c = j;
        return j;
    }

    /* renamed from: a */
    public void m9425a(C1352q c1352q) {
        this.f6621b = c1352q;
    }

    /* renamed from: a */
    public void mo1543a(String str, String str2, long j, String str3) {
        if (this.f6621b == null) {
            throw new IOException("No GoogleApiClient available");
        }
        for (C1271l e : this.f6620a.f6601h) {
            e.mo1981e();
        }
        this.f6620a.f6599f.mo1431a(this.f6621b, str, str2).mo1410a(new C1276q(this, j));
    }
}
