package com.google.android.gms.cast;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.common.api.C1138g;
import com.google.android.gms.common.api.C1242s;
import com.google.android.gms.common.api.C1243t;
import com.google.android.gms.common.internal.C1370c;
import com.google.android.gms.common.internal.C1393z;

/* renamed from: com.google.android.gms.cast.b */
final class C1222b extends C1138g<C1303g, C1321j> {
    C1222b() {
    }

    /* renamed from: a */
    public C1303g m8980a(Context context, Looper looper, C1393z c1393z, C1321j c1321j, C1242s c1242s, C1243t c1243t) {
        C1370c.m10113a((Object) c1321j, (Object) "Setting the API options is required.");
        return new C1303g(context, looper, c1393z, c1321j.f6758a, (long) c1321j.f6760c, c1321j.f6759b, c1242s, c1243t);
    }
}
