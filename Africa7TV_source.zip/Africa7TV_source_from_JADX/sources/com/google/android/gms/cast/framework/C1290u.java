package com.google.android.gms.cast.framework;

import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

/* renamed from: com.google.android.gms.cast.framework.u */
public interface C1290u extends IInterface {
    /* renamed from: a */
    int mo1550a();

    /* renamed from: b */
    C0827c mo1551b();

    /* renamed from: c */
    void mo1552c();

    /* renamed from: d */
    void mo1553d();
}
