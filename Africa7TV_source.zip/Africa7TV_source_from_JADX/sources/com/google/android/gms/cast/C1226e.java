package com.google.android.gms.cast;

import android.os.RemoteException;
import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.cast.internal.C1317v;
import com.google.android.gms.common.api.C1192u;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;
import java.io.IOException;

/* renamed from: com.google.android.gms.cast.e */
public final class C1226e implements C1225d {
    /* renamed from: a */
    public C1192u<Status> mo1429a(C1352q c1352q, String str) {
        return c1352q.mo2042a(new C1297i(this, c1352q, str));
    }

    /* renamed from: a */
    public C1192u<C1224c> mo1430a(C1352q c1352q, String str, LaunchOptions launchOptions) {
        return c1352q.mo2042a(new C1295g(this, c1352q, str, launchOptions));
    }

    /* renamed from: a */
    public C1192u<Status> mo1431a(C1352q c1352q, String str, String str2) {
        return c1352q.mo2042a(new C1229f(this, c1352q, str, str2));
    }

    /* renamed from: a */
    public C1192u<C1224c> m8996a(C1352q c1352q, String str, String str2, JoinOptions joinOptions) {
        return c1352q.mo2042a(new C1296h(this, c1352q, str, str2, joinOptions));
    }

    /* renamed from: a */
    public void mo1432a(C1352q c1352q, String str, C1260m c1260m) {
        try {
            ((C1303g) c1352q.mo2041a(C1317v.f6727a)).m9551a(str, c1260m);
        } catch (RemoteException e) {
            throw new IOException("service error");
        }
    }

    /* renamed from: b */
    public C1192u<C1224c> mo1433b(C1352q c1352q, String str, String str2) {
        return m8996a(c1352q, str, str2, null);
    }

    /* renamed from: b */
    public void mo1434b(C1352q c1352q, String str) {
        try {
            ((C1303g) c1352q.mo2041a(C1317v.f6727a)).m9549a(str);
        } catch (RemoteException e) {
            throw new IOException("service error");
        }
    }
}
