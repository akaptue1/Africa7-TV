package com.google.android.gms.cast.framework.media;

import com.google.android.gms.cast.internal.C1227b;
import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.cast.internal.ab;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.cast.framework.media.r */
abstract class C1264r extends C1227b<C1272m> {
    /* renamed from: e */
    ab f6606e = new C1277s(this);

    C1264r(C1352q c1352q) {
        super(c1352q);
    }

    /* renamed from: a */
    public C1272m m9398a(Status status) {
        return new C1278t(this, status);
    }

    /* renamed from: a */
    protected void mo1541a(C1303g c1303g) {
    }

    /* renamed from: b */
    public /* synthetic */ C1223y mo1416b(Status status) {
        return m9398a(status);
    }
}
