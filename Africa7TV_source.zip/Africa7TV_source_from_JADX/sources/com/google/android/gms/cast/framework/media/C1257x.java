package com.google.android.gms.cast.framework.media;

import android.os.IInterface;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.p034a.C0827c;

/* renamed from: com.google.android.gms.cast.framework.media.x */
public interface C1257x extends IInterface {
    /* renamed from: a */
    int mo1532a();

    /* renamed from: a */
    WebImage mo1533a(MediaMetadata mediaMetadata, int i);

    /* renamed from: a */
    WebImage mo1534a(MediaMetadata mediaMetadata, ImageHints imageHints);

    /* renamed from: b */
    C0827c mo1535b();
}
