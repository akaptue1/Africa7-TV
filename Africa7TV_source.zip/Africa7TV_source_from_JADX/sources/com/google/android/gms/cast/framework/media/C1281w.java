package com.google.android.gms.cast.framework.media;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;

/* renamed from: com.google.android.gms.cast.framework.media.w */
public class C1281w implements Creator<CastMediaOptions> {
    /* renamed from: a */
    static void m9439a(CastMediaOptions castMediaOptions, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, castMediaOptions.m9270a());
        C1386c.m10207a(parcel, 2, castMediaOptions.m9271b(), false);
        C1386c.m10207a(parcel, 3, castMediaOptions.m9273d(), false);
        C1386c.m10201a(parcel, 4, castMediaOptions.m9275f(), false);
        C1386c.m10202a(parcel, 5, castMediaOptions.m9272c(), i, false);
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public CastMediaOptions m9440a(Parcel parcel) {
        NotificationOptions notificationOptions = null;
        int b = C1384a.m10169b(parcel);
        int i = 0;
        IBinder iBinder = null;
        String str = null;
        String str2 = null;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    str2 = C1384a.m10183m(parcel, a);
                    break;
                case 3:
                    str = C1384a.m10183m(parcel, a);
                    break;
                case 4:
                    iBinder = C1384a.m10184n(parcel, a);
                    break;
                case 5:
                    notificationOptions = (NotificationOptions) C1384a.m10166a(parcel, a, NotificationOptions.CREATOR);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new CastMediaOptions(i, str2, str, iBinder, notificationOptions);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public CastMediaOptions[] m9441a(int i) {
        return new CastMediaOptions[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9440a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9441a(i);
    }
}
