package com.google.android.gms.cast.framework;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.p034a.C0827c;

public abstract class bc extends Binder implements bb {
    public bc() {
        attachInterface(this, "com.google.android.gms.cast.framework.ISessionProvider");
    }

    public IBinder asBinder() {
        return this;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        switch (i) {
            case 1:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionProvider");
                C0827c a = mo1547a(parcel.readString());
                parcel2.writeNoException();
                parcel2.writeStrongBinder(a != null ? a.asBinder() : null);
                return true;
            case 2:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionProvider");
                boolean a2 = mo1548a();
                parcel2.writeNoException();
                parcel2.writeInt(a2 ? 1 : 0);
                return true;
            case 3:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionProvider");
                String b = mo1549b();
                parcel2.writeNoException();
                parcel2.writeString(b);
                return true;
            case 4:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionProvider");
                parcel2.writeNoException();
                parcel2.writeInt(9877208);
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.framework.ISessionProvider");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
