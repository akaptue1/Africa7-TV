package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;

/* renamed from: com.google.android.gms.cast.x */
public class C1332x implements Creator<LaunchOptions> {
    /* renamed from: a */
    static void m9699a(LaunchOptions launchOptions, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, launchOptions.m8879a());
        C1386c.m10209a(parcel, 2, launchOptions.m8880b());
        C1386c.m10207a(parcel, 3, launchOptions.m8881c(), false);
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public LaunchOptions m9700a(Parcel parcel) {
        boolean z = false;
        int b = C1384a.m10169b(parcel);
        String str = null;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    z = C1384a.m10173c(parcel, a);
                    break;
                case 3:
                    str = C1384a.m10183m(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LaunchOptions(i, z, str);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public LaunchOptions[] m9701a(int i) {
        return new LaunchOptions[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9700a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9701a(i);
    }
}
