package com.google.android.gms.cast.framework;

import com.google.android.gms.cast.internal.C1318w;
import com.google.android.gms.p034a.C0827c;
import com.google.android.gms.p034a.C0830f;

/* renamed from: com.google.android.gms.cast.framework.o */
public class C1284o {
    /* renamed from: a */
    private static final C1318w f6637a = new C1318w("SessionManager");
    /* renamed from: b */
    private final av f6638b;

    public C1284o(av avVar) {
        this.f6638b = avVar;
    }

    /* renamed from: a */
    public C1232l m9452a() {
        try {
            return (C1232l) C0830f.m6211a(this.f6638b.mo1484a());
        } catch (Throwable e) {
            f6637a.m9642a(e, "Unable to call %s on %s.", "getWrappedCurrentSession", av.class.getSimpleName());
            return null;
        }
    }

    /* renamed from: a */
    public void m9453a(boolean z) {
        try {
            this.f6638b.mo1487a(true, z);
        } catch (Throwable e) {
            f6637a.m9642a(e, "Unable to call %s on %s.", "endCurrentSession", av.class.getSimpleName());
        }
    }

    /* renamed from: b */
    public C0827c m9454b() {
        try {
            return this.f6638b.mo1488b();
        } catch (Throwable e) {
            f6637a.m9642a(e, "Unable to call %s on %s.", "getWrappedThis", av.class.getSimpleName());
            return null;
        }
    }
}
