package com.google.android.gms.cast.framework.media;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import com.google.android.gms.cast.framework.C1230a;
import com.google.android.gms.cast.internal.C1318w;
import com.google.android.gms.internal.atq;
import com.google.android.gms.p034a.C0830f;

public class MediaNotificationService extends Service {
    /* renamed from: a */
    private static final C1318w f6555a = new C1318w("MediaNotificationService");
    /* renamed from: b */
    private aa f6556b;

    public IBinder onBind(Intent intent) {
        try {
            return this.f6556b.mo1529a(intent);
        } catch (Throwable e) {
            f6555a.m9642a(e, "Unable to call %s on %s.", "onBind", aa.class.getSimpleName());
            return null;
        }
    }

    public void onCreate() {
        this.f6556b = atq.m12327a((Service) this, C1230a.m9017a((Context) this).m9024d(), C0830f.m6210a(null), C1230a.m9017a((Context) this).m9019a().m9014g());
        try {
            this.f6556b.mo1530a();
        } catch (Throwable e) {
            f6555a.m9642a(e, "Unable to call %s on %s.", "onCreate", aa.class.getSimpleName());
        }
        super.onCreate();
    }

    public void onDestroy() {
        try {
            this.f6556b.mo1531b();
        } catch (Throwable e) {
            f6555a.m9642a(e, "Unable to call %s on %s.", "onDestroy", aa.class.getSimpleName());
        }
        super.onDestroy();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        int i3 = 1;
        try {
            i3 = this.f6556b.mo1528a(intent, i, i2);
        } catch (Throwable e) {
            f6555a.m9642a(e, "Unable to call %s on %s.", "onStartCommand", aa.class.getSimpleName());
        }
        return i3;
    }
}
