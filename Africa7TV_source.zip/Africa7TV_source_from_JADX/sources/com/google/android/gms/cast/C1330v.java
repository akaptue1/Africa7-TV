package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;
import java.util.List;

/* renamed from: com.google.android.gms.cast.v */
public class C1330v implements Creator<CastDevice> {
    /* renamed from: a */
    static void m9693a(CastDevice castDevice, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, castDevice.m8866a());
        C1386c.m10207a(parcel, 2, castDevice.m8868b(), false);
        C1386c.m10207a(parcel, 3, castDevice.f6357a, false);
        C1386c.m10207a(parcel, 4, castDevice.m8869c(), false);
        C1386c.m10207a(parcel, 5, castDevice.m8870d(), false);
        C1386c.m10207a(parcel, 6, castDevice.m8871e(), false);
        C1386c.m10198a(parcel, 7, castDevice.m8873g());
        C1386c.m10221c(parcel, 8, castDevice.m8874h(), false);
        C1386c.m10198a(parcel, 9, castDevice.m8875i());
        C1386c.m10198a(parcel, 10, castDevice.m8876j());
        C1386c.m10207a(parcel, 11, castDevice.m8872f(), false);
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public CastDevice m9694a(Parcel parcel) {
        int i = 0;
        String str = null;
        int b = C1384a.m10169b(parcel);
        int i2 = -1;
        List list = null;
        int i3 = 0;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        int i4 = 0;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i4 = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    str6 = C1384a.m10183m(parcel, a);
                    break;
                case 3:
                    str5 = C1384a.m10183m(parcel, a);
                    break;
                case 4:
                    str4 = C1384a.m10183m(parcel, a);
                    break;
                case 5:
                    str3 = C1384a.m10183m(parcel, a);
                    break;
                case 6:
                    str2 = C1384a.m10183m(parcel, a);
                    break;
                case 7:
                    i3 = C1384a.m10175e(parcel, a);
                    break;
                case 8:
                    list = C1384a.m10172c(parcel, a, WebImage.CREATOR);
                    break;
                case 9:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 10:
                    i2 = C1384a.m10175e(parcel, a);
                    break;
                case 11:
                    str = C1384a.m10183m(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new CastDevice(i4, str6, str5, str4, str3, str2, i3, list, i, i2, str);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public CastDevice[] m9695a(int i) {
        return new CastDevice[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9694a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9695a(i);
    }
}
