package com.google.android.gms.cast;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;
import java.util.List;

/* renamed from: com.google.android.gms.cast.z */
public class C1334z implements Creator<MediaMetadata> {
    /* renamed from: a */
    static void m9705a(MediaMetadata mediaMetadata, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, mediaMetadata.m8897a());
        C1386c.m10221c(parcel, 2, mediaMetadata.m8903e(), false);
        C1386c.m10200a(parcel, 3, mediaMetadata.f6387a, false);
        C1386c.m10198a(parcel, 4, mediaMetadata.m8900b());
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public MediaMetadata m9706a(Parcel parcel) {
        Bundle bundle = null;
        int i = 0;
        int b = C1384a.m10169b(parcel);
        List list = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i2 = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    list = C1384a.m10172c(parcel, a, WebImage.CREATOR);
                    break;
                case 3:
                    bundle = C1384a.m10185o(parcel, a);
                    break;
                case 4:
                    i = C1384a.m10175e(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new MediaMetadata(i2, list, bundle, i);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public MediaMetadata[] m9707a(int i) {
        return new MediaMetadata[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9706a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9707a(i);
    }
}
