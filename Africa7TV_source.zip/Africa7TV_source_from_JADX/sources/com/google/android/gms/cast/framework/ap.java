package com.google.android.gms.cast.framework;

import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface ap extends IInterface {
    /* renamed from: a */
    int mo1463a(Intent intent, int i, int i2);

    /* renamed from: a */
    IBinder mo1464a(Intent intent);

    /* renamed from: a */
    void mo1465a();

    /* renamed from: b */
    void mo1466b();

    /* renamed from: c */
    C0827c mo1467c();
}
