package com.google.android.gms.cast.internal;

import com.google.android.gms.common.util.C1415d;

public final class ac {
    /* renamed from: a */
    public static final Object f6664a = new Object();
    /* renamed from: g */
    private static final C1318w f6665g = new C1318w("RequestTracker");
    /* renamed from: b */
    private long f6666b;
    /* renamed from: c */
    private long f6667c = -1;
    /* renamed from: d */
    private long f6668d = 0;
    /* renamed from: e */
    private ab f6669e;
    /* renamed from: f */
    private final C1415d f6670f;

    public ac(C1415d c1415d, long j) {
        this.f6670f = c1415d;
        this.f6666b = j;
    }

    /* renamed from: c */
    private void m9502c() {
        this.f6667c = -1;
        this.f6669e = null;
        this.f6668d = 0;
    }

    /* renamed from: a */
    public void m9503a() {
        synchronized (f6664a) {
            if (this.f6667c != -1) {
                m9502c();
            }
        }
    }

    /* renamed from: a */
    public void m9504a(long j, ab abVar) {
        synchronized (f6664a) {
            ab abVar2 = this.f6669e;
            long j2 = this.f6667c;
            this.f6667c = j;
            this.f6669e = abVar;
            this.f6668d = this.f6670f.mo1681b();
        }
        if (abVar2 != null) {
            abVar2.mo1544a(j2);
        }
    }

    /* renamed from: a */
    public boolean m9505a(long j) {
        boolean z;
        synchronized (f6664a) {
            z = this.f6667c != -1 && this.f6667c == j;
        }
        return z;
    }

    /* renamed from: a */
    public boolean m9506a(long j, int i) {
        return m9507a(j, i, null);
    }

    /* renamed from: a */
    public boolean m9507a(long j, int i, Object obj) {
        boolean z = true;
        ab abVar = null;
        synchronized (f6664a) {
            if (this.f6667c == -1 || this.f6667c != j) {
                z = false;
            } else {
                f6665g.m9644b("request %d completed", Long.valueOf(this.f6667c));
                abVar = this.f6669e;
                m9502c();
            }
        }
        if (abVar != null) {
            abVar.mo1545a(j, i, obj);
        }
        return z;
    }

    /* renamed from: b */
    public boolean m9508b() {
        boolean z;
        synchronized (f6664a) {
            z = this.f6667c != -1;
        }
        return z;
    }

    /* renamed from: b */
    public boolean m9509b(long j, int i) {
        ab abVar;
        boolean z = true;
        long j2 = 0;
        synchronized (f6664a) {
            if (this.f6667c == -1 || j - this.f6668d < this.f6666b) {
                z = false;
                abVar = null;
            } else {
                f6665g.m9644b("request %d timed out", Long.valueOf(this.f6667c));
                j2 = this.f6667c;
                abVar = this.f6669e;
                m9502c();
            }
        }
        if (abVar != null) {
            abVar.mo1545a(j2, i, null);
        }
        return z;
    }
}
