package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;

public class aa implements Creator<MediaQueueItem> {
    /* renamed from: a */
    static void m8968a(MediaQueueItem mediaQueueItem, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, mediaQueueItem.m8905a());
        C1386c.m10202a(parcel, 2, mediaQueueItem.m8907b(), i, false);
        C1386c.m10198a(parcel, 3, mediaQueueItem.m8908c());
        C1386c.m10209a(parcel, 4, mediaQueueItem.m8909d());
        C1386c.m10196a(parcel, 5, mediaQueueItem.m8910e());
        C1386c.m10196a(parcel, 6, mediaQueueItem.m8911f());
        C1386c.m10196a(parcel, 7, mediaQueueItem.m8912g());
        C1386c.m10212a(parcel, 8, mediaQueueItem.m8913h(), false);
        C1386c.m10207a(parcel, 9, mediaQueueItem.f6391a, false);
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public MediaQueueItem m8969a(Parcel parcel) {
        int b = C1384a.m10169b(parcel);
        int i = 0;
        MediaInfo mediaInfo = null;
        int i2 = 0;
        boolean z = false;
        double d = 0.0d;
        double d2 = 0.0d;
        double d3 = 0.0d;
        long[] jArr = null;
        String str = null;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    mediaInfo = (MediaInfo) C1384a.m10166a(parcel, a, MediaInfo.CREATOR);
                    break;
                case 3:
                    i2 = C1384a.m10175e(parcel, a);
                    break;
                case 4:
                    z = C1384a.m10173c(parcel, a);
                    break;
                case 5:
                    d = C1384a.m10181k(parcel, a);
                    break;
                case 6:
                    d2 = C1384a.m10181k(parcel, a);
                    break;
                case 7:
                    d3 = C1384a.m10181k(parcel, a);
                    break;
                case 8:
                    jArr = C1384a.m10189s(parcel, a);
                    break;
                case 9:
                    str = C1384a.m10183m(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new MediaQueueItem(i, mediaInfo, i2, z, d, d2, d3, jArr, str);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public MediaQueueItem[] m8970a(int i) {
        return new MediaQueueItem[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m8969a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m8970a(i);
    }
}
