package com.google.android.gms.cast.framework;

/* renamed from: com.google.android.gms.cast.framework.j */
public interface C1252j {
}
