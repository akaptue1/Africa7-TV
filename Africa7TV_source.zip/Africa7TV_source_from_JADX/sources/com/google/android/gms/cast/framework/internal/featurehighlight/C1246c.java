package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.view.View;

/* renamed from: com.google.android.gms.cast.framework.internal.featurehighlight.c */
public interface C1246c {
    View asView();
}
