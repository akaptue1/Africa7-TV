package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;

/* renamed from: com.google.android.gms.cast.w */
public class C1331w implements Creator<JoinOptions> {
    /* renamed from: a */
    static void m9696a(JoinOptions joinOptions, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, joinOptions.m8877a());
        C1386c.m10198a(parcel, 2, joinOptions.m8878b());
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public JoinOptions m9697a(Parcel parcel) {
        int i = 0;
        int b = C1384a.m10169b(parcel);
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i2 = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    i = C1384a.m10175e(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new JoinOptions(i2, i);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public JoinOptions[] m9698a(int i) {
        return new JoinOptions[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9697a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9698a(i);
    }
}
