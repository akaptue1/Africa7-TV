package com.google.android.gms.cast.internal;

import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.cast.internal.p */
public abstract class C1228p extends C1227b<Status> {
    public C1228p(C1352q c1352q) {
        super(c1352q);
    }

    /* renamed from: a */
    public Status m9002a(Status status) {
        return status;
    }

    /* renamed from: a */
    public void mo1435a(C1303g c1303g) {
    }

    /* renamed from: b */
    public /* synthetic */ C1223y mo1416b(Status status) {
        return m9002a(status);
    }
}
