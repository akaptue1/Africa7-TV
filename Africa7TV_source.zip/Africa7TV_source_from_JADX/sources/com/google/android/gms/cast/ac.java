package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;

public class ac implements Creator<MediaTrack> {
    /* renamed from: a */
    static void m8974a(MediaTrack mediaTrack, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, mediaTrack.m8943a());
        C1386c.m10199a(parcel, 2, mediaTrack.m8944b());
        C1386c.m10198a(parcel, 3, mediaTrack.m8945c());
        C1386c.m10207a(parcel, 4, mediaTrack.m8946d(), false);
        C1386c.m10207a(parcel, 5, mediaTrack.m8947e(), false);
        C1386c.m10207a(parcel, 6, mediaTrack.m8948f(), false);
        C1386c.m10207a(parcel, 7, mediaTrack.m8949g(), false);
        C1386c.m10198a(parcel, 8, mediaTrack.m8950h());
        C1386c.m10207a(parcel, 9, mediaTrack.f6421a, false);
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public MediaTrack m8975a(Parcel parcel) {
        int i = 0;
        String str = null;
        int b = C1384a.m10169b(parcel);
        long j = 0;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i3 = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    j = C1384a.m10177g(parcel, a);
                    break;
                case 3:
                    i2 = C1384a.m10175e(parcel, a);
                    break;
                case 4:
                    str5 = C1384a.m10183m(parcel, a);
                    break;
                case 5:
                    str4 = C1384a.m10183m(parcel, a);
                    break;
                case 6:
                    str3 = C1384a.m10183m(parcel, a);
                    break;
                case 7:
                    str2 = C1384a.m10183m(parcel, a);
                    break;
                case 8:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 9:
                    str = C1384a.m10183m(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new MediaTrack(i3, j, i2, str5, str4, str3, str2, i, str);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public MediaTrack[] m8976a(int i) {
        return new MediaTrack[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m8975a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m8976a(i);
    }
}
