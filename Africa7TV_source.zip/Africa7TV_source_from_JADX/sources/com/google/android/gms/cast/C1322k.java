package com.google.android.gms.cast;

import com.google.android.gms.common.internal.C1370c;

/* renamed from: com.google.android.gms.cast.k */
public final class C1322k {
    /* renamed from: a */
    CastDevice f6761a;
    /* renamed from: b */
    C1240l f6762b;
    /* renamed from: c */
    private int f6763c = 0;

    public C1322k(CastDevice castDevice, C1240l c1240l) {
        C1370c.m10113a((Object) castDevice, (Object) "CastDevice parameter cannot be null");
        C1370c.m10113a((Object) c1240l, (Object) "CastListener parameter cannot be null");
        this.f6761a = castDevice;
        this.f6762b = c1240l;
    }

    /* renamed from: a */
    public C1321j m9673a() {
        return new C1321j();
    }
}
