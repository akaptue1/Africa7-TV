package com.google.android.gms.cast;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;
import java.util.List;

/* renamed from: com.google.android.gms.cast.u */
public class C1329u implements Creator<ApplicationMetadata> {
    /* renamed from: a */
    static void m9690a(ApplicationMetadata applicationMetadata, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, applicationMetadata.m8857a());
        C1386c.m10207a(parcel, 2, applicationMetadata.m8858b(), false);
        C1386c.m10207a(parcel, 3, applicationMetadata.m8859c(), false);
        C1386c.m10221c(parcel, 4, applicationMetadata.m8863g(), false);
        C1386c.m10219b(parcel, 5, applicationMetadata.m8860d(), false);
        C1386c.m10207a(parcel, 6, applicationMetadata.m8861e(), false);
        C1386c.m10202a(parcel, 7, applicationMetadata.m8862f(), i, false);
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public ApplicationMetadata m9691a(Parcel parcel) {
        Uri uri = null;
        int b = C1384a.m10169b(parcel);
        int i = 0;
        String str = null;
        List list = null;
        List list2 = null;
        String str2 = null;
        String str3 = null;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    str3 = C1384a.m10183m(parcel, a);
                    break;
                case 3:
                    str2 = C1384a.m10183m(parcel, a);
                    break;
                case 4:
                    list2 = C1384a.m10172c(parcel, a, WebImage.CREATOR);
                    break;
                case 5:
                    list = C1384a.m10192v(parcel, a);
                    break;
                case 6:
                    str = C1384a.m10183m(parcel, a);
                    break;
                case 7:
                    uri = (Uri) C1384a.m10166a(parcel, a, Uri.CREATOR);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ApplicationMetadata(i, str3, str2, list2, list, str, uri);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public ApplicationMetadata[] m9692a(int i) {
        return new ApplicationMetadata[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9691a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9692a(i);
    }
}
