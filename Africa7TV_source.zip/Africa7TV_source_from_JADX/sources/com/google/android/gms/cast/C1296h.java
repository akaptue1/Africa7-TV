package com.google.android.gms.cast;

import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.internal.avz;

/* renamed from: com.google.android.gms.cast.h */
class C1296h extends C1294n {
    /* renamed from: a */
    final /* synthetic */ String f6650a;
    /* renamed from: b */
    final /* synthetic */ String f6651b;
    /* renamed from: c */
    final /* synthetic */ JoinOptions f6652c;
    /* renamed from: d */
    final /* synthetic */ C1226e f6653d;

    C1296h(C1226e c1226e, C1352q c1352q, String str, String str2, JoinOptions joinOptions) {
        this.f6653d = c1226e;
        this.f6650a = str;
        this.f6651b = str2;
        this.f6652c = joinOptions;
        super(c1352q);
    }

    /* renamed from: a */
    public void mo1554a(C1303g c1303g) {
        try {
            c1303g.m9553a(this.f6650a, this.f6651b, this.f6652c, (avz) this);
        } catch (IllegalStateException e) {
            m9000a(2001);
        }
    }
}
