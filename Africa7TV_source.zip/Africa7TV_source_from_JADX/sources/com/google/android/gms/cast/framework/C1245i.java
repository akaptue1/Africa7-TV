package com.google.android.gms.cast.framework;

/* renamed from: com.google.android.gms.cast.framework.i */
public interface C1245i {
}
