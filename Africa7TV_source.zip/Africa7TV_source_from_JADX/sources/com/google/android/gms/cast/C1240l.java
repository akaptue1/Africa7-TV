package com.google.android.gms.cast;

/* renamed from: com.google.android.gms.cast.l */
public class C1240l {
    /* renamed from: a */
    public void mo1518a() {
    }

    /* renamed from: a */
    public void mo1519a(int i) {
    }

    /* renamed from: a */
    public void mo1520a(ApplicationMetadata applicationMetadata) {
    }

    /* renamed from: b */
    public void mo1521b() {
    }

    /* renamed from: b */
    public void mo1522b(int i) {
    }

    /* renamed from: c */
    public void mo1523c(int i) {
    }
}
