package com.google.android.gms.cast.framework;

import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface bb extends IInterface {
    /* renamed from: a */
    C0827c mo1547a(String str);

    /* renamed from: a */
    boolean mo1548a();

    /* renamed from: b */
    String mo1549b();
}
