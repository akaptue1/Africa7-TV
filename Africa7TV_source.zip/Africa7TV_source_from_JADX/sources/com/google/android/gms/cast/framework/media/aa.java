package com.google.android.gms.cast.framework.media;

import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;

public interface aa extends IInterface {
    /* renamed from: a */
    int mo1528a(Intent intent, int i, int i2);

    /* renamed from: a */
    IBinder mo1529a(Intent intent);

    /* renamed from: a */
    void mo1530a();

    /* renamed from: b */
    void mo1531b();
}
