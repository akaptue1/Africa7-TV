package com.google.android.gms.cast.framework.internal.featurehighlight;

/* renamed from: com.google.android.gms.cast.framework.internal.featurehighlight.b */
public interface C1248b {
    /* renamed from: a */
    void m9243a();
}
