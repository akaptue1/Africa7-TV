package com.google.android.gms.cast.framework.media;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class NotificationOptions extends AbstractSafeParcelable {
    public static final Creator<NotificationOptions> CREATOR = new ae();
    /* renamed from: a */
    private static final List<String> f6557a = Arrays.asList(new String[]{"com.google.android.gms.cast.framework.action.TOGGLE_PLAYBACK", "com.google.android.gms.cast.framework.action.STOP_CASTING"});
    /* renamed from: b */
    private static final int[] f6558b = new int[]{0, 1};
    /* renamed from: A */
    private final int f6559A;
    /* renamed from: B */
    private final int f6560B;
    /* renamed from: C */
    private final int f6561C;
    /* renamed from: D */
    private final int f6562D;
    /* renamed from: E */
    private final int f6563E;
    /* renamed from: F */
    private final int f6564F;
    /* renamed from: G */
    private final int f6565G;
    /* renamed from: H */
    private final int f6566H;
    /* renamed from: c */
    private final int f6567c;
    /* renamed from: d */
    private final List<String> f6568d;
    /* renamed from: e */
    private final int[] f6569e;
    /* renamed from: f */
    private final long f6570f;
    /* renamed from: g */
    private final String f6571g;
    /* renamed from: h */
    private final int f6572h;
    /* renamed from: i */
    private final int f6573i;
    /* renamed from: j */
    private final int f6574j;
    /* renamed from: k */
    private final int f6575k;
    /* renamed from: l */
    private final int f6576l;
    /* renamed from: m */
    private final int f6577m;
    /* renamed from: n */
    private final int f6578n;
    /* renamed from: o */
    private final int f6579o;
    /* renamed from: p */
    private final int f6580p;
    /* renamed from: q */
    private final int f6581q;
    /* renamed from: r */
    private final int f6582r;
    /* renamed from: s */
    private final int f6583s;
    /* renamed from: t */
    private final int f6584t;
    /* renamed from: u */
    private final int f6585u;
    /* renamed from: v */
    private final int f6586v;
    /* renamed from: w */
    private final int f6587w;
    /* renamed from: x */
    private final int f6588x;
    /* renamed from: y */
    private final int f6589y;
    /* renamed from: z */
    private final int f6590z;

    public NotificationOptions(int i, List<String> list, int[] iArr, long j, String str, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19, int i20, int i21, int i22, int i23, int i24, int i25, int i26, int i27, int i28) {
        this.f6567c = i;
        if (list != null) {
            this.f6568d = new ArrayList(list);
        } else {
            this.f6568d = null;
        }
        if (iArr != null) {
            this.f6569e = Arrays.copyOf(iArr, iArr.length);
        } else {
            this.f6569e = null;
        }
        this.f6570f = j;
        this.f6571g = str;
        this.f6572h = i2;
        this.f6573i = i3;
        this.f6574j = i4;
        this.f6575k = i5;
        this.f6576l = i6;
        this.f6577m = i7;
        this.f6578n = i8;
        this.f6579o = i9;
        this.f6580p = i10;
        this.f6581q = i11;
        this.f6582r = i12;
        this.f6583s = i13;
        this.f6584t = i14;
        this.f6585u = i15;
        this.f6586v = i16;
        this.f6587w = i17;
        this.f6588x = i18;
        this.f6589y = i19;
        this.f6590z = i20;
        this.f6559A = i21;
        this.f6560B = i22;
        this.f6561C = i23;
        this.f6562D = i24;
        this.f6563E = i25;
        this.f6564F = i26;
        this.f6565G = i27;
        this.f6566H = i28;
    }

    /* renamed from: A */
    public int m9290A() {
        return this.f6561C;
    }

    /* renamed from: B */
    public int m9291B() {
        return this.f6562D;
    }

    /* renamed from: C */
    public int m9292C() {
        return this.f6563E;
    }

    /* renamed from: D */
    public int m9293D() {
        return this.f6564F;
    }

    /* renamed from: E */
    public int m9294E() {
        return this.f6565G;
    }

    /* renamed from: F */
    public int m9295F() {
        return this.f6566H;
    }

    /* renamed from: a */
    int m9296a() {
        return this.f6567c;
    }

    /* renamed from: b */
    public List<String> m9297b() {
        return this.f6568d;
    }

    /* renamed from: c */
    public int[] m9298c() {
        return Arrays.copyOf(this.f6569e, this.f6569e.length);
    }

    /* renamed from: d */
    public long m9299d() {
        return this.f6570f;
    }

    /* renamed from: e */
    public String m9300e() {
        return this.f6571g;
    }

    /* renamed from: f */
    public int m9301f() {
        return this.f6572h;
    }

    /* renamed from: g */
    public int m9302g() {
        return this.f6573i;
    }

    /* renamed from: h */
    public int m9303h() {
        return this.f6574j;
    }

    /* renamed from: i */
    public int m9304i() {
        return this.f6575k;
    }

    /* renamed from: j */
    public int m9305j() {
        return this.f6576l;
    }

    /* renamed from: k */
    public int m9306k() {
        return this.f6577m;
    }

    /* renamed from: l */
    public int m9307l() {
        return this.f6578n;
    }

    /* renamed from: m */
    public int m9308m() {
        return this.f6579o;
    }

    /* renamed from: n */
    public int m9309n() {
        return this.f6580p;
    }

    /* renamed from: o */
    public int m9310o() {
        return this.f6581q;
    }

    /* renamed from: p */
    public int m9311p() {
        return this.f6582r;
    }

    /* renamed from: q */
    public int m9312q() {
        return this.f6583s;
    }

    /* renamed from: r */
    public int m9313r() {
        return this.f6584t;
    }

    /* renamed from: s */
    public int m9314s() {
        return this.f6585u;
    }

    /* renamed from: t */
    public int m9315t() {
        return this.f6586v;
    }

    /* renamed from: u */
    public int m9316u() {
        return this.f6587w;
    }

    /* renamed from: v */
    public int m9317v() {
        return this.f6588x;
    }

    /* renamed from: w */
    public int m9318w() {
        return this.f6589y;
    }

    public void writeToParcel(Parcel parcel, int i) {
        ae.m9336a(this, parcel, i);
    }

    /* renamed from: x */
    public int m9319x() {
        return this.f6590z;
    }

    /* renamed from: y */
    public int m9320y() {
        return this.f6559A;
    }

    /* renamed from: z */
    public int m9321z() {
        return this.f6560B;
    }
}
