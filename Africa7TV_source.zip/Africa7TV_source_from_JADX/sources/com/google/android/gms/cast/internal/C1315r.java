package com.google.android.gms.cast.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.cast.JoinOptions;
import com.google.android.gms.cast.LaunchOptions;

/* renamed from: com.google.android.gms.cast.internal.r */
public abstract class C1315r extends Binder implements C1314q {
    /* renamed from: a */
    public static C1314q m9623a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.internal.ICastDeviceController");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof C1314q)) ? new C1316s(iBinder) : (C1314q) queryLocalInterface;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        boolean z = false;
        switch (i) {
            case 1:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1579a();
                return true;
            case 2:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                String readString = parcel.readString();
                if (parcel.readInt() != 0) {
                    z = true;
                }
                mo1587a(readString, z);
                return true;
            case 3:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1583a(parcel.readString(), parcel.readString());
                return true;
            case 4:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1590b();
                return true;
            case 5:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1581a(parcel.readString());
                return true;
            case 6:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1592c();
                return true;
            case 7:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1580a(parcel.readDouble(), parcel.readDouble(), parcel.readInt() != 0);
                return true;
            case 8:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                boolean z2 = parcel.readInt() != 0;
                double readDouble = parcel.readDouble();
                if (parcel.readInt() != 0) {
                    z = true;
                }
                mo1589a(z2, readDouble, z);
                return true;
            case 9:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1584a(parcel.readString(), parcel.readString(), parcel.readLong());
                return true;
            case 10:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1588a(parcel.readString(), parcel.createByteArray(), parcel.readLong());
                return true;
            case 11:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1591b(parcel.readString());
                return true;
            case 12:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1593c(parcel.readString());
                return true;
            case 13:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1582a(parcel.readString(), parcel.readInt() != 0 ? (LaunchOptions) LaunchOptions.CREATOR.createFromParcel(parcel) : null);
                return true;
            case 14:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1586a(parcel.readString(), parcel.readString(), parcel.readInt() != 0 ? (JoinOptions) JoinOptions.CREATOR.createFromParcel(parcel) : null);
                return true;
            case 15:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
                mo1585a(parcel.readString(), parcel.readString(), parcel.readLong(), parcel.readString());
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.internal.ICastDeviceController");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
