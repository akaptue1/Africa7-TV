package com.google.android.gms.cast.framework;

import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface ag extends IInterface {
    /* renamed from: a */
    int mo1452a();

    /* renamed from: a */
    void mo1453a(int i);

    /* renamed from: b */
    C0827c mo1454b();
}
