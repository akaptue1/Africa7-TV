package com.google.android.gms.cast.framework.media;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.view.KeyEvent;
import com.google.android.gms.cast.framework.C1230a;
import com.google.android.gms.cast.framework.C1232l;
import com.google.android.gms.cast.framework.C1233c;
import com.google.android.gms.cast.framework.C1284o;

public class MediaIntentReceiver extends BroadcastReceiver {
    /* renamed from: a */
    private void m9280a(C1233c c1233c) {
        C1261d b = m9282b(c1233c);
        if (b != null) {
            b.m9385p();
        }
    }

    /* renamed from: a */
    private void m9281a(C1233c c1233c, long j) {
        if (j != 0) {
            C1261d b = m9282b(c1233c);
            if (b != null && !b.m9379j() && !b.m9387r()) {
                b.m9361a(b.m9372d() + j);
            }
        }
    }

    /* renamed from: b */
    private C1261d m9282b(C1233c c1233c) {
        return (c1233c == null || !c1233c.m9189e()) ? null : c1233c.m9204a();
    }

    /* renamed from: a */
    protected void m9283a(C1232l c1232l) {
        if (c1232l instanceof C1233c) {
            m9280a((C1233c) c1232l);
        }
    }

    /* renamed from: a */
    protected void m9284a(C1232l c1232l, long j) {
        if (c1232l instanceof C1233c) {
            m9281a((C1233c) c1232l, j);
        }
    }

    /* renamed from: a */
    protected void m9285a(C1232l c1232l, Intent intent) {
        if ((c1232l instanceof C1233c) && intent.hasExtra("android.intent.extra.KEY_EVENT")) {
            KeyEvent keyEvent = (KeyEvent) intent.getExtras().get("android.intent.extra.KEY_EVENT");
            if (keyEvent != null && keyEvent.getAction() == 0 && keyEvent.getKeyCode() == 85) {
                m9280a((C1233c) c1232l);
            }
        }
    }

    /* renamed from: a */
    protected void m9286a(String str, Intent intent) {
    }

    /* renamed from: b */
    protected void m9287b(C1232l c1232l) {
        if (c1232l instanceof C1233c) {
            C1261d b = m9282b((C1233c) c1232l);
            if (b != null && !b.m9387r()) {
                b.m9373d(null);
            }
        }
    }

    /* renamed from: b */
    protected void m9288b(C1232l c1232l, long j) {
        if (c1232l instanceof C1233c) {
            m9281a((C1233c) c1232l, -j);
        }
    }

    /* renamed from: c */
    protected void m9289c(C1232l c1232l) {
        if (c1232l instanceof C1233c) {
            C1261d b = m9282b((C1233c) c1232l);
            if (b != null && !b.m9387r()) {
                b.m9371c(null);
            }
        }
    }

    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action != null) {
            C1284o b = C1230a.m9017a(context).m9021b();
            boolean z = true;
            switch (action.hashCode()) {
                case -1699820260:
                    if (action.equals("com.google.android.gms.cast.framework.action.REWIND")) {
                        z = true;
                        break;
                    }
                    break;
                case -945151566:
                    if (action.equals("com.google.android.gms.cast.framework.action.SKIP_NEXT")) {
                        z = true;
                        break;
                    }
                    break;
                case -945080078:
                    if (action.equals("com.google.android.gms.cast.framework.action.SKIP_PREV")) {
                        z = true;
                        break;
                    }
                    break;
                case -668151673:
                    if (action.equals("com.google.android.gms.cast.framework.action.STOP_CASTING")) {
                        z = true;
                        break;
                    }
                    break;
                case -124479363:
                    if (action.equals("com.google.android.gms.cast.framework.action.DISCONNECT")) {
                        z = true;
                        break;
                    }
                    break;
                case 235550565:
                    if (action.equals("com.google.android.gms.cast.framework.action.TOGGLE_PLAYBACK")) {
                        z = false;
                        break;
                    }
                    break;
                case 1362116196:
                    if (action.equals("com.google.android.gms.cast.framework.action.FORWARD")) {
                        z = true;
                        break;
                    }
                    break;
                case 1997055314:
                    if (action.equals("android.intent.action.MEDIA_BUTTON")) {
                        z = true;
                        break;
                    }
                    break;
            }
            switch (z) {
                case false:
                    m9283a(b.m9452a());
                    return;
                case true:
                    m9287b(b.m9452a());
                    return;
                case true:
                    m9289c(b.m9452a());
                    return;
                case true:
                    m9284a(b.m9452a(), intent.getLongExtra("googlecast-extra_skip_step_ms", 0));
                    return;
                case true:
                    m9288b(b.m9452a(), intent.getLongExtra("googlecast-extra_skip_step_ms", 0));
                    return;
                case true:
                    b.m9453a(true);
                    return;
                case true:
                    b.m9453a(false);
                    return;
                case true:
                    m9285a(b.m9452a(), intent);
                    return;
                default:
                    m9286a(action, intent);
                    return;
            }
        }
    }
}
