package com.google.android.gms.cast.framework;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.Context;
import android.os.Bundle;

@TargetApi(14)
/* renamed from: com.google.android.gms.cast.framework.b */
class C1231b implements ActivityLifecycleCallbacks {
    /* renamed from: a */
    private Context f6479a;

    public C1231b(Context context) {
        this.f6479a = context.getApplicationContext();
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityPaused(Activity activity) {
        C1230a.m9017a(this.f6479a).m9022b(activity);
    }

    public void onActivityResumed(Activity activity) {
        C1230a.m9017a(this.f6479a).m9020a(activity);
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity) {
    }

    public void onActivityStopped(Activity activity) {
    }
}
