package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;

public class ad implements Creator<TextTrackStyle> {
    /* renamed from: a */
    static void m8977a(TextTrackStyle textTrackStyle, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, textTrackStyle.m8954a());
        C1386c.m10197a(parcel, 2, textTrackStyle.m8956b());
        C1386c.m10198a(parcel, 3, textTrackStyle.m8957c());
        C1386c.m10198a(parcel, 4, textTrackStyle.m8958d());
        C1386c.m10198a(parcel, 5, textTrackStyle.m8959e());
        C1386c.m10198a(parcel, 6, textTrackStyle.m8960f());
        C1386c.m10198a(parcel, 7, textTrackStyle.m8961g());
        C1386c.m10198a(parcel, 8, textTrackStyle.m8962h());
        C1386c.m10198a(parcel, 9, textTrackStyle.m8963i());
        C1386c.m10207a(parcel, 10, textTrackStyle.m8964j(), false);
        C1386c.m10198a(parcel, 11, textTrackStyle.m8965k());
        C1386c.m10198a(parcel, 12, textTrackStyle.m8966l());
        C1386c.m10207a(parcel, 13, textTrackStyle.f6431a, false);
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public TextTrackStyle m8978a(Parcel parcel) {
        int b = C1384a.m10169b(parcel);
        int i = 0;
        float f = 0.0f;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        String str = null;
        int i9 = 0;
        int i10 = 0;
        String str2 = null;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    f = C1384a.m10179i(parcel, a);
                    break;
                case 3:
                    i2 = C1384a.m10175e(parcel, a);
                    break;
                case 4:
                    i3 = C1384a.m10175e(parcel, a);
                    break;
                case 5:
                    i4 = C1384a.m10175e(parcel, a);
                    break;
                case 6:
                    i5 = C1384a.m10175e(parcel, a);
                    break;
                case 7:
                    i6 = C1384a.m10175e(parcel, a);
                    break;
                case 8:
                    i7 = C1384a.m10175e(parcel, a);
                    break;
                case 9:
                    i8 = C1384a.m10175e(parcel, a);
                    break;
                case 10:
                    str = C1384a.m10183m(parcel, a);
                    break;
                case 11:
                    i9 = C1384a.m10175e(parcel, a);
                    break;
                case 12:
                    i10 = C1384a.m10175e(parcel, a);
                    break;
                case 13:
                    str2 = C1384a.m10183m(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new TextTrackStyle(i, f, i2, i3, i4, i5, i6, i7, i8, str, i9, i10, str2);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public TextTrackStyle[] m8979a(int i) {
        return new TextTrackStyle[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m8978a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m8979a(i);
    }
}
