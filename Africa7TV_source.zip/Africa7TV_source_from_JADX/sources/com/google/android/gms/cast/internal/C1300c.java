package com.google.android.gms.cast.internal;

import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.common.util.C1415d;

/* renamed from: com.google.android.gms.cast.internal.c */
public abstract class C1300c extends C1299f {
    /* renamed from: a */
    protected final Handler f6674a = new Handler(Looper.getMainLooper());
    /* renamed from: b */
    protected final C1415d f6675b;
    /* renamed from: c */
    protected final long f6676c;
    /* renamed from: d */
    protected final Runnable f6677d;
    /* renamed from: e */
    protected boolean f6678e;

    public C1300c(String str, C1415d c1415d, String str2, String str3, long j) {
        super(str, str2, str3);
        this.f6675b = c1415d;
        this.f6677d = new C1302e();
        this.f6676c = j;
        m9519a(false);
    }

    /* renamed from: a */
    public void mo1555a() {
        m9519a(false);
    }

    /* renamed from: a */
    protected final void m9519a(boolean z) {
        if (this.f6678e != z) {
            this.f6678e = z;
            if (z) {
                this.f6674a.postDelayed(this.f6677d, this.f6676c);
            } else {
                this.f6674a.removeCallbacks(this.f6677d);
            }
        }
    }

    /* renamed from: a */
    protected abstract boolean mo1595a(long j);
}
