package com.google.android.gms.cast.framework;

import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface aj extends IInterface {
    /* renamed from: a */
    void mo1455a();

    /* renamed from: a */
    void mo1456a(am amVar);

    /* renamed from: b */
    void mo1457b();

    /* renamed from: b */
    void mo1458b(am amVar);

    /* renamed from: c */
    C0827c mo1459c();
}
