package com.google.android.gms.cast.framework;

import com.google.android.gms.p034a.C0827c;

/* renamed from: com.google.android.gms.cast.framework.r */
class C1287r extends bc {
    /* renamed from: a */
    final /* synthetic */ C1285p f6642a;

    private C1287r(C1285p c1285p) {
        this.f6642a = c1285p;
    }

    /* renamed from: a */
    public C0827c mo1547a(String str) {
        C1232l a = this.f6642a.mo1947a(str);
        return a == null ? null : a.m9191g();
    }

    /* renamed from: a */
    public boolean mo1548a() {
        return this.f6642a.mo1948c();
    }

    /* renamed from: b */
    public String mo1549b() {
        return this.f6642a.m9457b();
    }
}
