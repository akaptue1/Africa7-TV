package com.google.android.gms.cast;

import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.cast.q */
class C1325q {
    /* renamed from: a */
    private final Map<String, String> f6766a = new HashMap();
    /* renamed from: b */
    private final Map<String, String> f6767b = new HashMap();
    /* renamed from: c */
    private final Map<String, Integer> f6768c = new HashMap();

    /* renamed from: a */
    public C1325q m9682a(String str, String str2, int i) {
        this.f6766a.put(str, str2);
        this.f6767b.put(str2, str);
        this.f6768c.put(str, Integer.valueOf(i));
        return this;
    }

    /* renamed from: a */
    public String m9683a(String str) {
        return (String) this.f6766a.get(str);
    }

    /* renamed from: b */
    public String m9684b(String str) {
        return (String) this.f6767b.get(str);
    }

    /* renamed from: c */
    public int m9685c(String str) {
        Integer num = (Integer) this.f6768c.get(str);
        return num != null ? num.intValue() : 0;
    }
}
