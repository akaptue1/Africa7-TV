package com.google.android.gms.cast.framework;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.common.ConnectionResult;

public abstract class ae extends Binder implements ad {
    /* renamed from: a */
    public static ad m9052a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.framework.ICastSession");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof ad)) ? new af(iBinder) : (ad) queryLocalInterface;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        boolean z = false;
        ApplicationMetadata applicationMetadata = null;
        switch (i) {
            case 1:
                Bundle bundle;
                parcel.enforceInterface("com.google.android.gms.cast.framework.ICastSession");
                if (parcel.readInt() != 0) {
                    bundle = (Bundle) Bundle.CREATOR.createFromParcel(parcel);
                }
                mo1447a(bundle);
                parcel2.writeNoException();
                return true;
            case 2:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ICastSession");
                mo1446a(parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 3:
                ConnectionResult connectionResult;
                parcel.enforceInterface("com.google.android.gms.cast.framework.ICastSession");
                if (parcel.readInt() != 0) {
                    connectionResult = (ConnectionResult) ConnectionResult.CREATOR.createFromParcel(parcel);
                }
                mo1449a(connectionResult);
                parcel2.writeNoException();
                return true;
            case 4:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ICastSession");
                if (parcel.readInt() != 0) {
                    applicationMetadata = (ApplicationMetadata) ApplicationMetadata.CREATOR.createFromParcel(parcel);
                }
                String readString = parcel.readString();
                String readString2 = parcel.readString();
                if (parcel.readInt() != 0) {
                    z = true;
                }
                mo1448a(applicationMetadata, readString, readString2, z);
                parcel2.writeNoException();
                return true;
            case 5:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ICastSession");
                mo1451b(parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 6:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ICastSession");
                if (parcel.readInt() != 0) {
                    z = true;
                }
                mo1450a(z, parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.framework.ICastSession");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
