package com.google.android.gms.cast.framework;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.cast.LaunchOptions;
import com.google.android.gms.cast.framework.media.CastMediaOptions;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;
import java.util.List;

/* renamed from: com.google.android.gms.cast.framework.s */
public class C1288s implements Creator<CastOptions> {
    /* renamed from: a */
    static void m9463a(CastOptions castOptions, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, castOptions.m9008a());
        C1386c.m10207a(parcel, 2, castOptions.m9009b(), false);
        C1386c.m10219b(parcel, 3, castOptions.m9010c(), false);
        C1386c.m10209a(parcel, 4, castOptions.m9011d());
        C1386c.m10202a(parcel, 5, castOptions.m9012e(), i, false);
        C1386c.m10209a(parcel, 6, castOptions.m9013f());
        C1386c.m10202a(parcel, 7, castOptions.m9014g(), i, false);
        C1386c.m10209a(parcel, 8, castOptions.m9015h());
        C1386c.m10196a(parcel, 9, castOptions.m9016i());
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public CastOptions m9464a(Parcel parcel) {
        CastMediaOptions castMediaOptions = null;
        boolean z = false;
        int b = C1384a.m10169b(parcel);
        double d = 0.0d;
        boolean z2 = false;
        LaunchOptions launchOptions = null;
        boolean z3 = false;
        List list = null;
        String str = null;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    str = C1384a.m10183m(parcel, a);
                    break;
                case 3:
                    list = C1384a.m10192v(parcel, a);
                    break;
                case 4:
                    z3 = C1384a.m10173c(parcel, a);
                    break;
                case 5:
                    launchOptions = (LaunchOptions) C1384a.m10166a(parcel, a, LaunchOptions.CREATOR);
                    break;
                case 6:
                    z2 = C1384a.m10173c(parcel, a);
                    break;
                case 7:
                    castMediaOptions = (CastMediaOptions) C1384a.m10166a(parcel, a, CastMediaOptions.CREATOR);
                    break;
                case 8:
                    z = C1384a.m10173c(parcel, a);
                    break;
                case 9:
                    d = C1384a.m10181k(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new CastOptions(i, str, list, z3, launchOptions, z2, castMediaOptions, z, d);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public CastOptions[] m9465a(int i) {
        return new CastOptions[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9464a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9465a(i);
    }
}
