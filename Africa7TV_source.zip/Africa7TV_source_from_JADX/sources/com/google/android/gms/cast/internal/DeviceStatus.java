package com.google.android.gms.cast.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.common.internal.bp;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class DeviceStatus extends AbstractSafeParcelable {
    public static final Creator<DeviceStatus> CREATOR = new C1313o();
    /* renamed from: a */
    private final int f6658a;
    /* renamed from: b */
    private double f6659b;
    /* renamed from: c */
    private boolean f6660c;
    /* renamed from: d */
    private int f6661d;
    /* renamed from: e */
    private ApplicationMetadata f6662e;
    /* renamed from: f */
    private int f6663f;

    public DeviceStatus() {
        this(3, Double.NaN, false, -1, null, -1);
    }

    DeviceStatus(int i, double d, boolean z, int i2, ApplicationMetadata applicationMetadata, int i3) {
        this.f6658a = i;
        this.f6659b = d;
        this.f6660c = z;
        this.f6661d = i2;
        this.f6662e = applicationMetadata;
        this.f6663f = i3;
    }

    /* renamed from: a */
    public int m9493a() {
        return this.f6658a;
    }

    /* renamed from: b */
    public double m9494b() {
        return this.f6659b;
    }

    /* renamed from: c */
    public boolean m9495c() {
        return this.f6660c;
    }

    /* renamed from: d */
    public int m9496d() {
        return this.f6661d;
    }

    /* renamed from: e */
    public int m9497e() {
        return this.f6663f;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof DeviceStatus)) {
            return false;
        }
        DeviceStatus deviceStatus = (DeviceStatus) obj;
        return this.f6659b == deviceStatus.f6659b && this.f6660c == deviceStatus.f6660c && this.f6661d == deviceStatus.f6661d && C1312n.m9602a(this.f6662e, deviceStatus.f6662e) && this.f6663f == deviceStatus.f6663f;
    }

    /* renamed from: f */
    public ApplicationMetadata m9498f() {
        return this.f6662e;
    }

    public int hashCode() {
        return bp.m10107a(Double.valueOf(this.f6659b), Boolean.valueOf(this.f6660c), Integer.valueOf(this.f6661d), this.f6662e, Integer.valueOf(this.f6663f));
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1313o.m9605a(this, parcel, i);
    }
}
