package com.google.android.gms.cast.framework.media;

import com.google.android.gms.cast.internal.ab;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.Status;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.framework.media.s */
class C1277s implements ab {
    /* renamed from: a */
    final /* synthetic */ C1264r f6625a;

    C1277s(C1264r c1264r) {
        this.f6625a = c1264r;
    }

    /* renamed from: a */
    public void mo1544a(long j) {
        this.f6625a.m8763b((C1223y) (C1272m) this.f6625a.mo1416b(new Status(2103)));
    }

    /* renamed from: a */
    public void mo1545a(long j, int i, Object obj) {
        this.f6625a.m8763b(new C1279u(new Status(i), obj instanceof JSONObject ? (JSONObject) obj : null));
    }
}
