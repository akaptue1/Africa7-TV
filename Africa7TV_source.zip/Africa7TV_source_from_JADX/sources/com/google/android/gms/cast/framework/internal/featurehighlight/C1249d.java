package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import com.google.android.gms.C1220c;
import com.google.android.gms.C1434f;

/* renamed from: com.google.android.gms.cast.framework.internal.featurehighlight.d */
class C1249d extends Drawable {
    /* renamed from: a */
    private final Paint f6504a = new Paint();
    /* renamed from: b */
    private final Paint f6505b = new Paint();
    /* renamed from: c */
    private final Rect f6506c = new Rect();
    /* renamed from: d */
    private final int f6507d;
    /* renamed from: e */
    private final int f6508e;
    /* renamed from: f */
    private float f6509f;
    /* renamed from: g */
    private float f6510g = 1.0f;
    /* renamed from: h */
    private float f6511h;
    /* renamed from: i */
    private float f6512i;

    public C1249d(Context context) {
        Resources resources = context.getResources();
        this.f6507d = resources.getDimensionPixelSize(C1220c.cast_libraries_material_featurehighlight_inner_radius);
        this.f6508e = resources.getInteger(C1434f.cast_libraries_material_featurehighlight_pulse_base_alpha);
        this.f6504a.setAntiAlias(true);
        this.f6504a.setStyle(Style.FILL);
        this.f6505b.setAntiAlias(true);
        this.f6505b.setStyle(Style.FILL);
        m9244a(-1);
    }

    /* renamed from: a */
    public void m9244a(int i) {
        this.f6504a.setColor(i);
        this.f6505b.setColor(i);
        invalidateSelf();
    }

    /* renamed from: a */
    public void m9245a(Rect rect) {
        this.f6506c.set(rect);
        this.f6511h = this.f6506c.exactCenterX();
        this.f6512i = this.f6506c.exactCenterY();
        this.f6509f = Math.max((float) this.f6507d, Math.max(((float) this.f6506c.width()) / 2.0f, ((float) this.f6506c.height()) / 2.0f));
        invalidateSelf();
    }

    public void draw(Canvas canvas) {
        int i = (0.0f > 0.0f ? 1 : (0.0f == 0.0f ? 0 : -1));
        canvas.drawCircle(this.f6511h, this.f6512i, this.f6509f * this.f6510g, this.f6504a);
    }

    public int getOpacity() {
        return -3;
    }

    public void setAlpha(int i) {
        this.f6504a.setAlpha(i);
        invalidateSelf();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f6504a.setColorFilter(colorFilter);
        invalidateSelf();
    }
}
