package com.google.android.gms.cast.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import com.facebook.internal.NativeProtocol;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.cast.C1224c;
import com.google.android.gms.cast.C1240l;
import com.google.android.gms.cast.C1260m;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.cast.JoinOptions;
import com.google.android.gms.cast.LaunchOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C1242s;
import com.google.android.gms.common.api.C1243t;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.BinderWrapper;
import com.google.android.gms.common.internal.C1393z;
import com.google.android.gms.common.internal.ag;
import com.google.android.gms.internal.avz;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/* renamed from: com.google.android.gms.cast.internal.g */
public class C1303g extends ag<C1314q> {
    /* renamed from: B */
    private static final Object f6680B = new Object();
    /* renamed from: C */
    private static final Object f6681C = new Object();
    /* renamed from: a */
    private static final C1318w f6682a = new C1318w("CastClientImpl");
    /* renamed from: A */
    private avz<Status> f6683A;
    /* renamed from: f */
    private ApplicationMetadata f6684f;
    /* renamed from: g */
    private final CastDevice f6685g;
    /* renamed from: h */
    private final C1240l f6686h;
    /* renamed from: i */
    private final Map<String, C1260m> f6687i = new HashMap();
    /* renamed from: j */
    private final long f6688j;
    /* renamed from: k */
    private C1307i f6689k;
    /* renamed from: l */
    private String f6690l;
    /* renamed from: m */
    private boolean f6691m;
    /* renamed from: n */
    private boolean f6692n;
    /* renamed from: o */
    private boolean f6693o;
    /* renamed from: p */
    private boolean f6694p;
    /* renamed from: q */
    private double f6695q;
    /* renamed from: r */
    private int f6696r;
    /* renamed from: s */
    private int f6697s;
    /* renamed from: t */
    private final AtomicLong f6698t = new AtomicLong(0);
    /* renamed from: u */
    private String f6699u;
    /* renamed from: v */
    private String f6700v;
    /* renamed from: w */
    private Bundle f6701w;
    /* renamed from: x */
    private final Map<Long, avz<Status>> f6702x = new HashMap();
    /* renamed from: y */
    private C1314q f6703y;
    /* renamed from: z */
    private avz<C1224c> f6704z;

    public C1303g(Context context, Looper looper, C1393z c1393z, CastDevice castDevice, long j, C1240l c1240l, C1242s c1242s, C1243t c1243t) {
        super(context, looper, 10, c1393z, c1242s, c1243t);
        this.f6685g = castDevice;
        this.f6686h = c1240l;
        this.f6688j = j;
        m9521D();
    }

    /* renamed from: D */
    private void m9521D() {
        this.f6694p = false;
        this.f6696r = -1;
        this.f6697s = -1;
        this.f6684f = null;
        this.f6690l = null;
        this.f6695q = 0.0d;
        this.f6691m = false;
    }

    /* renamed from: E */
    private void m9522E() {
        f6682a.m9644b("removing all MessageReceivedCallbacks", new Object[0]);
        synchronized (this.f6687i) {
            this.f6687i.clear();
        }
    }

    /* renamed from: a */
    private void m9526a(ApplicationStatus applicationStatus) {
        boolean z;
        String b = applicationStatus.m9492b();
        if (C1312n.m9602a(b, this.f6690l)) {
            z = false;
        } else {
            this.f6690l = b;
            z = true;
        }
        f6682a.m9644b("hasChanged=%b, mFirstApplicationStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(this.f6692n));
        if (this.f6686h != null && (z || this.f6692n)) {
            this.f6686h.mo1518a();
        }
        this.f6692n = false;
    }

    /* renamed from: a */
    private void m9527a(DeviceStatus deviceStatus) {
        boolean z;
        ApplicationMetadata f = deviceStatus.m9498f();
        if (!C1312n.m9602a(f, this.f6684f)) {
            this.f6684f = f;
            this.f6686h.mo1520a(this.f6684f);
        }
        double b = deviceStatus.m9494b();
        if (Double.isNaN(b) || Math.abs(b - this.f6695q) <= 1.0E-7d) {
            z = false;
        } else {
            this.f6695q = b;
            z = true;
        }
        boolean c = deviceStatus.m9495c();
        if (c != this.f6691m) {
            this.f6691m = c;
            z = true;
        }
        f6682a.m9644b("hasVolumeChanged=%b, mFirstDeviceStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(this.f6693o));
        if (this.f6686h != null && (z || this.f6693o)) {
            this.f6686h.mo1521b();
        }
        int d = deviceStatus.m9496d();
        if (d != this.f6696r) {
            this.f6696r = d;
            z = true;
        } else {
            z = false;
        }
        f6682a.m9644b("hasActiveInputChanged=%b, mFirstDeviceStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(this.f6693o));
        if (this.f6686h != null && (z || this.f6693o)) {
            this.f6686h.mo1522b(this.f6696r);
        }
        d = deviceStatus.m9497e();
        if (d != this.f6697s) {
            this.f6697s = d;
            z = true;
        } else {
            z = false;
        }
        f6682a.m9644b("hasStandbyStateChanged=%b, mFirstDeviceStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(this.f6693o));
        if (this.f6686h != null && (z || this.f6693o)) {
            this.f6686h.mo1523c(this.f6697s);
        }
        this.f6693o = false;
    }

    /* renamed from: a */
    private void m9531a(avz<C1224c> avz) {
        synchronized (f6680B) {
            if (this.f6704z != null) {
                this.f6704z.mo1412a(new C1304h(new Status(2002)));
            }
            this.f6704z = avz;
        }
    }

    /* renamed from: b */
    private void m9535b(avz<Status> avz) {
        synchronized (f6681C) {
            if (this.f6683A != null) {
                avz.mo1412a(new Status(2001));
                return;
            }
            this.f6683A = avz;
        }
    }

    /* renamed from: a */
    protected C1314q m9545a(IBinder iBinder) {
        return C1315r.m9623a(iBinder);
    }

    /* renamed from: a */
    protected String mo1160a() {
        return "com.google.android.gms.cast.service.BIND_CAST_DEVICE_CONTROLLER_SERVICE";
    }

    /* renamed from: a */
    protected void mo1556a(int i, IBinder iBinder, Bundle bundle, int i2) {
        f6682a.m9644b("in onPostInitHandler; statusCode=%d", Integer.valueOf(i));
        if (i == 0 || i == 1001) {
            this.f6694p = true;
            this.f6692n = true;
            this.f6693o = true;
        } else {
            this.f6694p = false;
        }
        if (i == 1001) {
            this.f6701w = new Bundle();
            this.f6701w.putBoolean("com.google.android.gms.cast.EXTRA_APP_NO_LONGER_RUNNING", true);
            i = 0;
        }
        super.mo1556a(i, iBinder, bundle, i2);
    }

    /* renamed from: a */
    public void mo1557a(ConnectionResult connectionResult) {
        super.mo1557a(connectionResult);
        m9522E();
    }

    /* renamed from: a */
    public void m9549a(String str) {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("Channel namespace cannot be null or empty");
        }
        synchronized (this.f6687i) {
            C1260m c1260m = (C1260m) this.f6687i.remove(str);
        }
        if (c1260m != null) {
            try {
                mo1560h().mo1593c(str);
            } catch (Throwable e) {
                f6682a.m9642a(e, "Error unregistering namespace (%s): %s", str, e.getMessage());
            }
        }
    }

    /* renamed from: a */
    public void m9550a(String str, LaunchOptions launchOptions, avz<C1224c> avz) {
        m9531a((avz) avz);
        mo1560h().mo1582a(str, launchOptions);
    }

    /* renamed from: a */
    public void m9551a(String str, C1260m c1260m) {
        C1312n.m9600a(str);
        m9549a(str);
        if (c1260m != null) {
            synchronized (this.f6687i) {
                this.f6687i.put(str, c1260m);
            }
            mo1560h().mo1591b(str);
        }
    }

    /* renamed from: a */
    public void m9552a(String str, avz<Status> avz) {
        m9535b((avz) avz);
        mo1560h().mo1581a(str);
    }

    /* renamed from: a */
    public void m9553a(String str, String str2, JoinOptions joinOptions, avz<C1224c> avz) {
        m9531a((avz) avz);
        if (joinOptions == null) {
            joinOptions = new JoinOptions();
        }
        mo1560h().mo1586a(str, str2, joinOptions);
    }

    /* renamed from: a */
    public void m9554a(String str, String str2, avz<Status> avz) {
        if (TextUtils.isEmpty(str2)) {
            throw new IllegalArgumentException("The message payload cannot be null or empty");
        } else if (str2.length() > NativeProtocol.MESSAGE_GET_ACCESS_TOKEN_REQUEST) {
            throw new IllegalArgumentException("Message exceeds maximum size");
        } else {
            C1312n.m9600a(str);
            mo1561i();
            long incrementAndGet = this.f6698t.incrementAndGet();
            try {
                this.f6702x.put(Long.valueOf(incrementAndGet), avz);
                mo1560h().mo1584a(str, str2, incrementAndGet);
            } catch (Throwable th) {
                this.f6702x.remove(Long.valueOf(incrementAndGet));
            }
        }
    }

    /* renamed from: b */
    protected /* synthetic */ IInterface mo1161b(IBinder iBinder) {
        return m9545a(iBinder);
    }

    /* renamed from: b */
    protected String mo1162b() {
        return "com.google.android.gms.cast.internal.ICastDeviceController";
    }

    /* renamed from: c */
    protected Bundle mo1390c() {
        Bundle bundle = new Bundle();
        f6682a.m9644b("getRemoteService(): mLastApplicationId=%s, mLastSessionId=%s", this.f6699u, this.f6700v);
        this.f6685g.m8867a(bundle);
        bundle.putLong("com.google.android.gms.cast.EXTRA_CAST_FLAGS", this.f6688j);
        this.f6689k = new C1307i(this);
        bundle.putParcelable("listener", new BinderWrapper(this.f6689k.asBinder()));
        if (this.f6699u != null) {
            bundle.putString("last_application_id", this.f6699u);
            if (this.f6700v != null) {
                bundle.putString("last_session_id", this.f6700v);
            }
        }
        return bundle;
    }

    /* renamed from: f */
    public void mo1558f() {
        Throwable e;
        f6682a.m9644b("disconnect(); ServiceListener=%s, isConnected=%b", this.f6689k, Boolean.valueOf(m6728m()));
        C1307i c1307i = this.f6689k;
        this.f6689k = null;
        if (c1307i == null || c1307i.m9582a() == null) {
            f6682a.m9644b("already disposed, so short-circuiting", new Object[0]);
            return;
        }
        m9522E();
        try {
            mo1560h().mo1579a();
            super.mo1558f();
        } catch (RemoteException e2) {
            e = e2;
            try {
                f6682a.m9642a(e, "Error while disconnecting the controller interface: %s", e.getMessage());
            } finally {
                super.mo1558f();
            }
        } catch (IllegalStateException e3) {
            e = e3;
            f6682a.m9642a(e, "Error while disconnecting the controller interface: %s", e.getMessage());
        }
    }

    /* renamed from: g */
    public Bundle mo1559g() {
        if (this.f6701w == null) {
            return super.mo1559g();
        }
        Bundle bundle = this.f6701w;
        this.f6701w = null;
        return bundle;
    }

    /* renamed from: h */
    C1314q mo1560h() {
        return null == null ? (C1314q) super.m6741z() : this.f6703y;
    }

    /* renamed from: i */
    void mo1561i() {
        if (!this.f6694p || this.f6689k == null || this.f6689k.m9593b()) {
            throw new IllegalStateException("Not connected to a device");
        }
    }
}
