package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;
import java.util.List;

public class ab implements Creator<MediaStatus> {
    /* renamed from: a */
    static void m8971a(MediaStatus mediaStatus, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, mediaStatus.m8920a());
        C1386c.m10202a(parcel, 2, mediaStatus.m8931f(), i, false);
        C1386c.m10199a(parcel, 3, mediaStatus.m8925b());
        C1386c.m10198a(parcel, 4, mediaStatus.m8936k());
        C1386c.m10196a(parcel, 5, mediaStatus.m8930e());
        C1386c.m10198a(parcel, 6, mediaStatus.m8927c());
        C1386c.m10198a(parcel, 7, mediaStatus.m8929d());
        C1386c.m10199a(parcel, 8, mediaStatus.m8932g());
        C1386c.m10199a(parcel, 9, mediaStatus.f6401a);
        C1386c.m10196a(parcel, 10, mediaStatus.m8933h());
        C1386c.m10209a(parcel, 11, mediaStatus.m8934i());
        C1386c.m10212a(parcel, 12, mediaStatus.m8935j(), false);
        C1386c.m10198a(parcel, 13, mediaStatus.m8937l());
        C1386c.m10198a(parcel, 14, mediaStatus.m8938m());
        C1386c.m10207a(parcel, 15, mediaStatus.f6402b, false);
        C1386c.m10198a(parcel, 16, mediaStatus.f6403c);
        C1386c.m10221c(parcel, 17, mediaStatus.f6404d, false);
        C1386c.m10209a(parcel, 18, mediaStatus.m8941p());
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public MediaStatus m8972a(Parcel parcel) {
        int b = C1384a.m10169b(parcel);
        int i = 0;
        MediaInfo mediaInfo = null;
        long j = 0;
        int i2 = 0;
        double d = 0.0d;
        int i3 = 0;
        int i4 = 0;
        long j2 = 0;
        long j3 = 0;
        double d2 = 0.0d;
        boolean z = false;
        long[] jArr = null;
        int i5 = 0;
        int i6 = 0;
        String str = null;
        int i7 = 0;
        List list = null;
        boolean z2 = false;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    mediaInfo = (MediaInfo) C1384a.m10166a(parcel, a, MediaInfo.CREATOR);
                    break;
                case 3:
                    j = C1384a.m10177g(parcel, a);
                    break;
                case 4:
                    i2 = C1384a.m10175e(parcel, a);
                    break;
                case 5:
                    d = C1384a.m10181k(parcel, a);
                    break;
                case 6:
                    i3 = C1384a.m10175e(parcel, a);
                    break;
                case 7:
                    i4 = C1384a.m10175e(parcel, a);
                    break;
                case 8:
                    j2 = C1384a.m10177g(parcel, a);
                    break;
                case 9:
                    j3 = C1384a.m10177g(parcel, a);
                    break;
                case 10:
                    d2 = C1384a.m10181k(parcel, a);
                    break;
                case 11:
                    z = C1384a.m10173c(parcel, a);
                    break;
                case 12:
                    jArr = C1384a.m10189s(parcel, a);
                    break;
                case 13:
                    i5 = C1384a.m10175e(parcel, a);
                    break;
                case 14:
                    i6 = C1384a.m10175e(parcel, a);
                    break;
                case 15:
                    str = C1384a.m10183m(parcel, a);
                    break;
                case 16:
                    i7 = C1384a.m10175e(parcel, a);
                    break;
                case 17:
                    list = C1384a.m10172c(parcel, a, MediaQueueItem.CREATOR);
                    break;
                case 18:
                    z2 = C1384a.m10173c(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new MediaStatus(i, mediaInfo, j, i2, d, i3, i4, j2, j3, d2, z, jArr, i5, i6, str, i7, list, z2);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public MediaStatus[] m8973a(int i) {
        return new MediaStatus[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m8972a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m8973a(i);
    }
}
