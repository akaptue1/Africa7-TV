package com.google.android.gms.cast.framework;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.cast.internal.C1318w;
import com.google.android.gms.internal.atq;
import com.google.android.gms.p034a.C0827c;

/* renamed from: com.google.android.gms.cast.framework.l */
public abstract class C1232l {
    /* renamed from: a */
    private static final C1318w f6482a = new C1318w("Session");
    /* renamed from: b */
    private final as f6483b;
    /* renamed from: c */
    private final C1283n f6484c = new C1283n();

    protected C1232l(Context context, String str, String str2) {
        this.f6483b = atq.m12326a(context, str, str2, this.f6484c);
    }

    /* renamed from: a */
    protected final void m9182a(int i) {
        try {
            this.f6483b.mo1469a(i);
        } catch (Throwable e) {
            f6482a.m9642a(e, "Unable to call %s on %s.", "notifyFailedToStartSession", as.class.getSimpleName());
        }
    }

    /* renamed from: a */
    protected abstract void mo1508a(Bundle bundle);

    /* renamed from: a */
    protected abstract void mo1509a(boolean z);

    /* renamed from: b */
    protected final void m9185b(int i) {
        try {
            this.f6483b.mo1473b(i);
        } catch (Throwable e) {
            f6482a.m9642a(e, "Unable to call %s on %s.", "notifySessionEnded", as.class.getSimpleName());
        }
    }

    /* renamed from: b */
    protected abstract void mo1510b(Bundle bundle);

    /* renamed from: c */
    public long mo1511c() {
        return 0;
    }

    /* renamed from: c */
    protected final void m9188c(int i) {
        try {
            this.f6483b.mo1475c(i);
        } catch (Throwable e) {
            f6482a.m9642a(e, "Unable to call %s on %s.", "notifyFailedToResumeSession", as.class.getSimpleName());
        }
    }

    /* renamed from: e */
    public boolean m9189e() {
        boolean z = false;
        try {
            z = this.f6483b.mo1478e();
        } catch (Throwable e) {
            f6482a.m9642a(e, "Unable to call %s on %s.", "isConnected", as.class.getSimpleName());
        }
        return z;
    }

    /* renamed from: f */
    public boolean m9190f() {
        boolean z = false;
        try {
            z = this.f6483b.mo1482i();
        } catch (Throwable e) {
            f6482a.m9642a(e, "Unable to call %s on %s.", "isResuming", as.class.getSimpleName());
        }
        return z;
    }

    /* renamed from: g */
    public final C0827c m9191g() {
        try {
            return this.f6483b.mo1468a();
        } catch (Throwable e) {
            f6482a.m9642a(e, "Unable to call %s on %s.", "getWrappedObject", as.class.getSimpleName());
            return null;
        }
    }
}
