package com.google.android.gms.cast.framework.media;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.p034a.C0827c;
import com.google.android.gms.p034a.C0828d;

/* renamed from: com.google.android.gms.cast.framework.media.z */
class C1282z implements C1257x {
    /* renamed from: a */
    private IBinder f6635a;

    C1282z(IBinder iBinder) {
        this.f6635a = iBinder;
    }

    /* renamed from: a */
    public int mo1532a() {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.media.IImagePicker");
            this.f6635a.transact(3, obtain, obtain2, 0);
            obtain2.readException();
            int readInt = obtain2.readInt();
            return readInt;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public WebImage mo1533a(MediaMetadata mediaMetadata, int i) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.media.IImagePicker");
            if (mediaMetadata != null) {
                obtain.writeInt(1);
                mediaMetadata.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            obtain.writeInt(i);
            this.f6635a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
            WebImage webImage = obtain2.readInt() != 0 ? (WebImage) WebImage.CREATOR.createFromParcel(obtain2) : null;
            obtain2.recycle();
            obtain.recycle();
            return webImage;
        } catch (Throwable th) {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public WebImage mo1534a(MediaMetadata mediaMetadata, ImageHints imageHints) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.media.IImagePicker");
            if (mediaMetadata != null) {
                obtain.writeInt(1);
                mediaMetadata.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            if (imageHints != null) {
                obtain.writeInt(1);
                imageHints.writeToParcel(obtain, 0);
            } else {
                obtain.writeInt(0);
            }
            this.f6635a.transact(4, obtain, obtain2, 0);
            obtain2.readException();
            WebImage webImage = obtain2.readInt() != 0 ? (WebImage) WebImage.CREATOR.createFromParcel(obtain2) : null;
            obtain2.recycle();
            obtain.recycle();
            return webImage;
        } catch (Throwable th) {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    public IBinder asBinder() {
        return this.f6635a;
    }

    /* renamed from: b */
    public C0827c mo1535b() {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.media.IImagePicker");
            this.f6635a.transact(2, obtain, obtain2, 0);
            obtain2.readException();
            C0827c a = C0828d.m6209a(obtain2.readStrongBinder());
            return a;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }
}
