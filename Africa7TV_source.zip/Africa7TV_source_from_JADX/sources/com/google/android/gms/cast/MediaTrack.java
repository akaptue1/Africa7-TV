package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.facebook.internal.NativeProtocol;
import com.google.android.gms.cast.internal.C1312n;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.bp;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.util.C1424m;
import org.json.JSONException;
import org.json.JSONObject;

public final class MediaTrack extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Creator<MediaTrack> CREATOR = new ac();
    /* renamed from: a */
    String f6421a;
    /* renamed from: b */
    private final int f6422b;
    /* renamed from: c */
    private long f6423c;
    /* renamed from: d */
    private int f6424d;
    /* renamed from: e */
    private String f6425e;
    /* renamed from: f */
    private String f6426f;
    /* renamed from: g */
    private String f6427g;
    /* renamed from: h */
    private String f6428h;
    /* renamed from: i */
    private int f6429i;
    /* renamed from: j */
    private JSONObject f6430j;

    MediaTrack(int i, long j, int i2, String str, String str2, String str3, String str4, int i3, String str5) {
        this.f6422b = i;
        this.f6423c = j;
        this.f6424d = i2;
        this.f6425e = str;
        this.f6426f = str2;
        this.f6427g = str3;
        this.f6428h = str4;
        this.f6429i = i3;
        this.f6421a = str5;
        if (this.f6421a != null) {
            try {
                this.f6430j = new JSONObject(this.f6421a);
                return;
            } catch (JSONException e) {
                this.f6430j = null;
                this.f6421a = null;
                return;
            }
        }
        this.f6430j = null;
    }

    MediaTrack(JSONObject jSONObject) {
        this(1, 0, 0, null, null, null, null, -1, null);
        m8942a(jSONObject);
    }

    /* renamed from: a */
    private void m8942a(JSONObject jSONObject) {
        this.f6423c = jSONObject.getLong("trackId");
        String string = jSONObject.getString("type");
        if ("TEXT".equals(string)) {
            this.f6424d = 1;
        } else if ("AUDIO".equals(string)) {
            this.f6424d = 2;
        } else if (NativeProtocol.METHOD_ARGS_VIDEO.equals(string)) {
            this.f6424d = 3;
        } else {
            String str = "invalid type: ";
            string = String.valueOf(string);
            throw new JSONException(string.length() != 0 ? str.concat(string) : new String(str));
        }
        this.f6425e = jSONObject.optString("trackContentId", null);
        this.f6426f = jSONObject.optString("trackContentType", null);
        this.f6427g = jSONObject.optString("name", null);
        this.f6428h = jSONObject.optString("language", null);
        if (jSONObject.has("subtype")) {
            string = jSONObject.getString("subtype");
            if ("SUBTITLES".equals(string)) {
                this.f6429i = 1;
            } else if ("CAPTIONS".equals(string)) {
                this.f6429i = 2;
            } else if ("DESCRIPTIONS".equals(string)) {
                this.f6429i = 3;
            } else if ("CHAPTERS".equals(string)) {
                this.f6429i = 4;
            } else if ("METADATA".equals(string)) {
                this.f6429i = 5;
            } else {
                str = "invalid subtype: ";
                string = String.valueOf(string);
                throw new JSONException(string.length() != 0 ? str.concat(string) : new String(str));
            }
        }
        this.f6429i = 0;
        this.f6430j = jSONObject.optJSONObject("customData");
    }

    /* renamed from: a */
    int m8943a() {
        return this.f6422b;
    }

    /* renamed from: b */
    public long m8944b() {
        return this.f6423c;
    }

    /* renamed from: c */
    public int m8945c() {
        return this.f6424d;
    }

    /* renamed from: d */
    public String m8946d() {
        return this.f6425e;
    }

    /* renamed from: e */
    public String m8947e() {
        return this.f6426f;
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaTrack)) {
            return false;
        }
        MediaTrack mediaTrack = (MediaTrack) obj;
        if ((this.f6430j == null) != (mediaTrack.f6430j == null)) {
            return false;
        }
        if (this.f6430j != null && mediaTrack.f6430j != null && !C1424m.m10351a(this.f6430j, mediaTrack.f6430j)) {
            return false;
        }
        if (!(this.f6423c == mediaTrack.f6423c && this.f6424d == mediaTrack.f6424d && C1312n.m9602a(this.f6425e, mediaTrack.f6425e) && C1312n.m9602a(this.f6426f, mediaTrack.f6426f) && C1312n.m9602a(this.f6427g, mediaTrack.f6427g) && C1312n.m9602a(this.f6428h, mediaTrack.f6428h) && this.f6429i == mediaTrack.f6429i)) {
            z = false;
        }
        return z;
    }

    /* renamed from: f */
    public String m8948f() {
        return this.f6427g;
    }

    /* renamed from: g */
    public String m8949g() {
        return this.f6428h;
    }

    /* renamed from: h */
    public int m8950h() {
        return this.f6429i;
    }

    public int hashCode() {
        return bp.m10107a(Long.valueOf(this.f6423c), Integer.valueOf(this.f6424d), this.f6425e, this.f6426f, this.f6427g, this.f6428h, Integer.valueOf(this.f6429i), this.f6430j);
    }

    /* renamed from: i */
    public JSONObject m8951i() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("trackId", this.f6423c);
            switch (this.f6424d) {
                case 1:
                    jSONObject.put("type", "TEXT");
                    break;
                case 2:
                    jSONObject.put("type", "AUDIO");
                    break;
                case 3:
                    jSONObject.put("type", NativeProtocol.METHOD_ARGS_VIDEO);
                    break;
            }
            if (this.f6425e != null) {
                jSONObject.put("trackContentId", this.f6425e);
            }
            if (this.f6426f != null) {
                jSONObject.put("trackContentType", this.f6426f);
            }
            if (this.f6427g != null) {
                jSONObject.put("name", this.f6427g);
            }
            if (!TextUtils.isEmpty(this.f6428h)) {
                jSONObject.put("language", this.f6428h);
            }
            switch (this.f6429i) {
                case 1:
                    jSONObject.put("subtype", "SUBTITLES");
                    break;
                case 2:
                    jSONObject.put("subtype", "CAPTIONS");
                    break;
                case 3:
                    jSONObject.put("subtype", "DESCRIPTIONS");
                    break;
                case 4:
                    jSONObject.put("subtype", "CHAPTERS");
                    break;
                case 5:
                    jSONObject.put("subtype", "METADATA");
                    break;
            }
            if (this.f6430j != null) {
                jSONObject.put("customData", this.f6430j);
            }
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i) {
        this.f6421a = this.f6430j == null ? null : this.f6430j.toString();
        ac.m8974a(this, parcel, i);
    }
}
