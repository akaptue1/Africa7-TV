package com.google.android.gms.cast.internal;

import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.internal.C1370c;
import java.util.Locale;

/* renamed from: com.google.android.gms.cast.internal.w */
public class C1318w {
    /* renamed from: b */
    private static boolean f6733b = false;
    /* renamed from: a */
    protected final String f6734a;
    /* renamed from: c */
    private final boolean f6735c;
    /* renamed from: d */
    private boolean f6736d;
    /* renamed from: e */
    private boolean f6737e;
    /* renamed from: f */
    private String f6738f;

    public C1318w(String str) {
        this(str, C1318w.m9639c());
    }

    public C1318w(String str, boolean z) {
        C1370c.m10115a(str, (Object) "The log tag cannot be null or empty.");
        this.f6734a = str;
        this.f6735c = str.length() <= 23;
        this.f6736d = z;
        this.f6737e = false;
    }

    /* renamed from: c */
    public static boolean m9639c() {
        return false;
    }

    /* renamed from: a */
    public void m9640a(String str) {
        String str2;
        if (TextUtils.isEmpty(str)) {
            str2 = null;
        } else {
            str2 = String.format("[%s] ", new Object[]{str});
        }
        this.f6738f = str2;
    }

    /* renamed from: a */
    public void m9641a(String str, Object... objArr) {
        if (m9646b()) {
            Log.v(this.f6734a, m9649e(str, objArr));
        }
    }

    /* renamed from: a */
    public void m9642a(Throwable th, String str, Object... objArr) {
        if (m9643a()) {
            Log.d(this.f6734a, m9649e(str, objArr), th);
        }
    }

    /* renamed from: a */
    public boolean m9643a() {
        return this.f6736d || (this.f6735c && Log.isLoggable(this.f6734a, 3));
    }

    /* renamed from: b */
    public void m9644b(String str, Object... objArr) {
        if (m9643a()) {
            Log.d(this.f6734a, m9649e(str, objArr));
        }
    }

    /* renamed from: b */
    public void m9645b(Throwable th, String str, Object... objArr) {
        Log.e(this.f6734a, m9649e(str, objArr), th);
    }

    /* renamed from: b */
    public boolean m9646b() {
        return false;
    }

    /* renamed from: c */
    public void m9647c(String str, Object... objArr) {
        Log.i(this.f6734a, m9649e(str, objArr));
    }

    /* renamed from: d */
    public void m9648d(String str, Object... objArr) {
        Log.w(this.f6734a, m9649e(str, objArr));
    }

    /* renamed from: e */
    protected String m9649e(String str, Object... objArr) {
        if (objArr.length != 0) {
            str = String.format(Locale.ROOT, str, objArr);
        }
        if (TextUtils.isEmpty(this.f6738f)) {
            return str;
        }
        String valueOf = String.valueOf(this.f6738f);
        String valueOf2 = String.valueOf(str);
        return valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf);
    }
}
