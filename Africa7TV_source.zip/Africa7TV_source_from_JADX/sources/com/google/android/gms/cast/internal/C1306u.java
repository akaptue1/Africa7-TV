package com.google.android.gms.cast.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.cast.ApplicationMetadata;

/* renamed from: com.google.android.gms.cast.internal.u */
public abstract class C1306u extends Binder implements C1305t {
    public C1306u() {
        attachInterface(this, "com.google.android.gms.cast.internal.ICastDeviceControllerListener");
    }

    public IBinder asBinder() {
        return this;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        boolean z = false;
        DeviceStatus deviceStatus = null;
        switch (i) {
            case 1:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                mo1566a(parcel.readInt());
                return true;
            case 2:
                ApplicationMetadata applicationMetadata;
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                if (parcel.readInt() != 0) {
                    applicationMetadata = (ApplicationMetadata) ApplicationMetadata.CREATOR.createFromParcel(parcel);
                }
                String readString = parcel.readString();
                String readString2 = parcel.readString();
                if (parcel.readInt() != 0) {
                    z = true;
                }
                mo1567a(applicationMetadata, readString, readString2, z);
                return true;
            case 3:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                mo1575b(parcel.readInt());
                return true;
            case 4:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                String readString3 = parcel.readString();
                double readDouble = parcel.readDouble();
                if (parcel.readInt() != 0) {
                    z = true;
                }
                mo1570a(readString3, readDouble, z);
                return true;
            case 5:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                mo1573a(parcel.readString(), parcel.readString());
                return true;
            case 6:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                mo1574a(parcel.readString(), parcel.createByteArray());
                return true;
            case 7:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                mo1577d(parcel.readInt());
                return true;
            case 8:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                mo1576c(parcel.readInt());
                return true;
            case 9:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                mo1578e(parcel.readInt());
                return true;
            case 10:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                mo1572a(parcel.readString(), parcel.readLong(), parcel.readInt());
                return true;
            case 11:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                mo1571a(parcel.readString(), parcel.readLong());
                return true;
            case 12:
                ApplicationStatus applicationStatus;
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                if (parcel.readInt() != 0) {
                    applicationStatus = (ApplicationStatus) ApplicationStatus.CREATOR.createFromParcel(parcel);
                }
                mo1568a(applicationStatus);
                return true;
            case 13:
                parcel.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                if (parcel.readInt() != 0) {
                    deviceStatus = (DeviceStatus) DeviceStatus.CREATOR.createFromParcel(parcel);
                }
                mo1569a(deviceStatus);
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
