package com.google.android.gms.cast.framework;

import com.google.android.gms.cast.LaunchOptions;

/* renamed from: com.google.android.gms.cast.framework.f */
class C1239f extends C1238y {
    /* renamed from: a */
    final /* synthetic */ C1233c f6498a;

    private C1239f(C1233c c1233c) {
        this.f6498a = c1233c;
    }

    /* renamed from: a */
    public int mo1513a() {
        return 9877208;
    }

    /* renamed from: a */
    public void mo1514a(int i) {
        this.f6498a.m9201d(i);
    }

    /* renamed from: a */
    public void mo1515a(String str) {
        this.f6498a.f6489e.mo1429a(this.f6498a.f6492h, str);
    }

    /* renamed from: a */
    public void mo1516a(String str, LaunchOptions launchOptions) {
        this.f6498a.f6489e.mo1430a(this.f6498a.f6492h, str, launchOptions).mo1410a(new C1236e(this.f6498a, "launchApplication"));
    }

    /* renamed from: a */
    public void mo1517a(String str, String str2) {
        this.f6498a.f6489e.mo1433b(this.f6498a.f6492h, str, str2).mo1410a(new C1236e(this.f6498a, "joinApplication"));
    }
}
