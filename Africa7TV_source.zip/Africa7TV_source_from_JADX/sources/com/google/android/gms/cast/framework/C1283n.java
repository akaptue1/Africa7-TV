package com.google.android.gms.cast.framework;

import android.os.Bundle;
import com.google.android.gms.p034a.C0827c;
import com.google.android.gms.p034a.C0830f;

/* renamed from: com.google.android.gms.cast.framework.n */
class C1283n extends be {
    /* renamed from: a */
    final /* synthetic */ C1232l f6636a;

    private C1283n(C1232l c1232l) {
        this.f6636a = c1232l;
    }

    /* renamed from: a */
    public int mo1502a() {
        return 9877208;
    }

    /* renamed from: a */
    public void mo1503a(Bundle bundle) {
        this.f6636a.mo1508a(bundle);
    }

    /* renamed from: a */
    public void mo1504a(boolean z) {
        this.f6636a.mo1509a(z);
    }

    /* renamed from: b */
    public C0827c mo1505b() {
        return C0830f.m6210a(this.f6636a);
    }

    /* renamed from: b */
    public void mo1506b(Bundle bundle) {
        this.f6636a.mo1510b(bundle);
    }

    /* renamed from: c */
    public long mo1507c() {
        return this.f6636a.mo1511c();
    }
}
