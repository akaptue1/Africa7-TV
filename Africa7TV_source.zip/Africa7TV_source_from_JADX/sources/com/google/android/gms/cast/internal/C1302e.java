package com.google.android.gms.cast.internal;

/* renamed from: com.google.android.gms.cast.internal.e */
class C1302e implements Runnable {
    /* renamed from: a */
    final /* synthetic */ C1300c f6679a;

    private C1302e(C1300c c1300c) {
        this.f6679a = c1300c;
    }

    public void run() {
        this.f6679a.f6678e = false;
        this.f6679a.m9519a(this.f6679a.mo1595a(this.f6679a.f6675b.mo1681b()));
    }
}
