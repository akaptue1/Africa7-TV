package com.google.android.gms.cast.framework;

import com.google.android.gms.cast.C1224c;
import com.google.android.gms.cast.framework.media.C1261d;
import com.google.android.gms.cast.internal.C1319x;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1235z;

/* renamed from: com.google.android.gms.cast.framework.e */
class C1236e implements C1235z<C1224c> {
    /* renamed from: a */
    String f6496a;
    /* renamed from: b */
    final /* synthetic */ C1233c f6497b;

    C1236e(C1233c c1233c, String str) {
        this.f6497b = c1233c;
        this.f6496a = str;
    }

    /* renamed from: a */
    public void m9211a(C1224c c1224c) {
        this.f6497b.f6495k = c1224c;
        try {
            if (c1224c.mo1546e().m9761c()) {
                C1233c.f6485a.m9644b("%s() -> success result", this.f6496a);
                this.f6497b.f6493i = new C1261d(new C1319x(null), this.f6497b.f6489e);
                try {
                    this.f6497b.f6493i.m9366a(this.f6497b.f6492h);
                    this.f6497b.f6493i.m9370c();
                    this.f6497b.f6491g.m12438a(this.f6497b.f6493i, this.f6497b.m9207b());
                } catch (Throwable e) {
                    C1233c.f6485a.m9645b(e, "Exception when setting GoogleApiClient.", new Object[0]);
                    this.f6497b.f6493i = null;
                }
                this.f6497b.f6488d.mo1448a(c1224c.mo1562a(), c1224c.mo1563b(), c1224c.mo1564c(), c1224c.mo1565d());
                return;
            }
            C1233c.f6485a.m9644b("%s() -> failure result", this.f6496a);
            this.f6497b.f6488d.mo1451b(c1224c.mo1546e().m9762d());
        } catch (Throwable e2) {
            C1233c.f6485a.m9642a(e2, "Unable to call %s on %s.", "methods", ad.class.getSimpleName());
        }
    }

    /* renamed from: a */
    public /* synthetic */ void mo1512a(C1223y c1223y) {
        m9211a((C1224c) c1223y);
    }
}
