package com.google.android.gms.cast.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.bp;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ApplicationStatus extends AbstractSafeParcelable {
    public static final Creator<ApplicationStatus> CREATOR = new C1298a();
    /* renamed from: a */
    private final int f6656a;
    /* renamed from: b */
    private String f6657b;

    public ApplicationStatus() {
        this(1, null);
    }

    ApplicationStatus(int i, String str) {
        this.f6656a = i;
        this.f6657b = str;
    }

    /* renamed from: a */
    public int m9491a() {
        return this.f6656a;
    }

    /* renamed from: b */
    public String m9492b() {
        return this.f6657b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ApplicationStatus)) {
            return false;
        }
        return C1312n.m9602a(this.f6657b, ((ApplicationStatus) obj).f6657b);
    }

    public int hashCode() {
        return bp.m10107a(this.f6657b);
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1298a.m9499a(this, parcel, i);
    }
}
