package com.google.android.gms.cast.framework;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.p034a.C0827c;

public abstract class be extends Binder implements bd {
    public be() {
        attachInterface(this, "com.google.android.gms.cast.framework.ISessionProxy");
    }

    /* renamed from: a */
    public static bd m9175a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.framework.ISessionProxy");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof bd)) ? new bf(iBinder) : (bd) queryLocalInterface;
    }

    public IBinder asBinder() {
        return this;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        Bundle bundle = null;
        switch (i) {
            case 1:
                IBinder asBinder;
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionProxy");
                C0827c b = mo1505b();
                parcel2.writeNoException();
                if (b != null) {
                    asBinder = b.asBinder();
                }
                parcel2.writeStrongBinder(asBinder);
                return true;
            case 2:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionProxy");
                if (parcel.readInt() != 0) {
                    bundle = (Bundle) Bundle.CREATOR.createFromParcel(parcel);
                }
                mo1503a(bundle);
                parcel2.writeNoException();
                return true;
            case 3:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionProxy");
                if (parcel.readInt() != 0) {
                    bundle = (Bundle) Bundle.CREATOR.createFromParcel(parcel);
                }
                mo1506b(bundle);
                parcel2.writeNoException();
                return true;
            case 4:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionProxy");
                mo1504a(parcel.readInt() != 0);
                parcel2.writeNoException();
                return true;
            case 5:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionProxy");
                long c = mo1507c();
                parcel2.writeNoException();
                parcel2.writeLong(c);
                return true;
            case 6:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionProxy");
                int a = mo1502a();
                parcel2.writeNoException();
                parcel2.writeInt(a);
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.framework.ISessionProxy");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
