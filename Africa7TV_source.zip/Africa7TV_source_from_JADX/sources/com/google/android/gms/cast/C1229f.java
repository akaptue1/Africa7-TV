package com.google.android.gms.cast;

import com.google.android.gms.cast.internal.C1228p;
import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.internal.avz;

/* renamed from: com.google.android.gms.cast.f */
class C1229f extends C1228p {
    /* renamed from: a */
    final /* synthetic */ String f6448a;
    /* renamed from: b */
    final /* synthetic */ String f6449b;
    /* renamed from: c */
    final /* synthetic */ C1226e f6450c;

    C1229f(C1226e c1226e, C1352q c1352q, String str, String str2) {
        this.f6450c = c1226e;
        this.f6448a = str;
        this.f6449b = str2;
        super(c1352q);
    }

    /* renamed from: a */
    public void mo1435a(C1303g c1303g) {
        try {
            c1303g.m9554a(this.f6448a, this.f6449b, (avz) this);
            return;
        } catch (IllegalArgumentException e) {
        } catch (IllegalStateException e2) {
        }
        m9000a(2001);
    }
}
