package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.MarginLayoutParams;
import com.google.android.gms.C1220c;
import com.google.android.gms.internal.gu;

/* renamed from: com.google.android.gms.cast.framework.internal.featurehighlight.e */
class C1250e {
    /* renamed from: a */
    private final Rect f6513a = new Rect();
    /* renamed from: b */
    private final int f6514b;
    /* renamed from: c */
    private final int f6515c;
    /* renamed from: d */
    private final int f6516d;
    /* renamed from: e */
    private final int f6517e;
    /* renamed from: f */
    private final zza f6518f;

    C1250e(zza zza) {
        this.f6518f = (zza) gu.m13936a(zza);
        Resources resources = zza.getResources();
        this.f6514b = resources.getDimensionPixelSize(C1220c.cast_libraries_material_featurehighlight_inner_radius);
        this.f6515c = resources.getDimensionPixelOffset(C1220c.cast_libraries_material_featurehighlight_inner_margin);
        this.f6516d = resources.getDimensionPixelSize(C1220c.cast_libraries_material_featurehighlight_text_max_width);
        this.f6517e = resources.getDimensionPixelSize(C1220c.cast_libraries_material_featurehighlight_text_horizontal_offset);
    }

    /* renamed from: a */
    private int m9246a(Rect rect) {
        Drawable a = this.f6518f.m9264a();
        return Math.max(this.f6514b * 2, a != null ? a.getBounds().height() : rect.height());
    }

    /* renamed from: a */
    private int m9247a(View view, int i, int i2, int i3, int i4) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        int i5 = i3 / 2;
        int i6 = (i4 - i <= i2 - i4 ? 1 : null) != null ? (i4 - i5) + this.f6517e : (i4 - i5) - this.f6517e;
        return i6 - marginLayoutParams.leftMargin < i ? i + marginLayoutParams.leftMargin : (i6 + i3) + marginLayoutParams.rightMargin > i2 ? (i2 - i3) - marginLayoutParams.rightMargin : i6;
    }

    /* renamed from: a */
    private void m9248a(View view, int i, int i2) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        view.measure(MeasureSpec.makeMeasureSpec(Math.min((i - marginLayoutParams.leftMargin) - marginLayoutParams.rightMargin, this.f6516d), 1073741824), MeasureSpec.makeMeasureSpec(i2, Integer.MIN_VALUE));
    }

    /* renamed from: a */
    private void m9249a(View view, Rect rect) {
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
    }

    /* renamed from: b */
    private void m9250b(View view, int i, int i2) {
        view.layout(i, i2, view.getMeasuredWidth() + i, view.getMeasuredHeight() + i2);
    }

    /* renamed from: c */
    private void m9251c(View view, int i, int i2) {
        view.layout(i, i2 - view.getMeasuredHeight(), view.getMeasuredWidth() + i, i2);
    }

    /* renamed from: a */
    void m9252a(Rect rect, Rect rect2) {
        int i = 0;
        View b = this.f6518f.m9265b();
        if (rect.isEmpty() || rect2.isEmpty()) {
            b.layout(0, 0, 0, 0);
        } else {
            int centerY = rect.centerY();
            int centerX = rect.centerX();
            if (centerY < rect2.centerY()) {
                i = 1;
            }
            int a = m9246a(rect);
            int i2 = this.f6515c + ((a / 2) + centerY);
            if (i != 0) {
                m9248a(b, rect2.width(), rect2.bottom - i2);
                m9250b(b, m9247a(b, rect2.left, rect2.right, b.getMeasuredWidth(), centerX), i2);
            } else {
                i2 = (centerY - (a / 2)) - this.f6515c;
                m9248a(b, rect2.width(), i2 - rect2.top);
                m9251c(b, m9247a(b, rect2.left, rect2.right, b.getMeasuredWidth(), centerX), i2);
            }
        }
        m9249a(b, this.f6513a);
        this.f6518f.m9266c().m9257a(rect, this.f6513a);
        this.f6518f.m9267d().m9245a(rect);
    }
}
