package com.google.android.gms.cast.framework.media;

import com.google.android.gms.cast.AdBreakInfo;
import com.google.android.gms.cast.MediaStatus;
import java.util.List;

/* renamed from: com.google.android.gms.cast.framework.media.n */
public interface C1273n {
    /* renamed from: a */
    boolean m9419a(MediaStatus mediaStatus);

    /* renamed from: b */
    List<AdBreakInfo> m9420b(MediaStatus mediaStatus);
}
