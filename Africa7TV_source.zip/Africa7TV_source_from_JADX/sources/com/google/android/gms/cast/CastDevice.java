package com.google.android.gms.cast;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.cast.internal.C1312n;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CastDevice extends AbstractSafeParcelable implements ReflectedParcelable {
    public static final Creator<CastDevice> CREATOR = new C1330v();
    /* renamed from: a */
    String f6357a;
    /* renamed from: b */
    private final int f6358b;
    /* renamed from: c */
    private String f6359c;
    /* renamed from: d */
    private Inet4Address f6360d;
    /* renamed from: e */
    private String f6361e;
    /* renamed from: f */
    private String f6362f;
    /* renamed from: g */
    private String f6363g;
    /* renamed from: h */
    private int f6364h;
    /* renamed from: i */
    private List<WebImage> f6365i;
    /* renamed from: j */
    private int f6366j;
    /* renamed from: k */
    private int f6367k;
    /* renamed from: l */
    private String f6368l;

    CastDevice(int i, String str, String str2, String str3, String str4, String str5, int i2, List<WebImage> list, int i3, int i4, String str6) {
        List arrayList;
        this.f6358b = i;
        this.f6359c = m8864a(str);
        this.f6357a = m8864a(str2);
        if (!TextUtils.isEmpty(this.f6357a)) {
            try {
                InetAddress byName = InetAddress.getByName(this.f6357a);
                if (byName instanceof Inet4Address) {
                    this.f6360d = (Inet4Address) byName;
                }
            } catch (UnknownHostException e) {
                String str7 = this.f6357a;
                String valueOf = String.valueOf(e.getMessage());
                Log.i("CastDevice", new StringBuilder((String.valueOf(str7).length() + 48) + String.valueOf(valueOf).length()).append("Unable to convert host address (").append(str7).append(") to ipaddress: ").append(valueOf).toString());
            }
        }
        this.f6361e = m8864a(str3);
        this.f6362f = m8864a(str4);
        this.f6363g = m8864a(str5);
        this.f6364h = i2;
        if (list == null) {
            arrayList = new ArrayList();
        }
        this.f6365i = arrayList;
        this.f6366j = i3;
        this.f6367k = i4;
        this.f6368l = m8864a(str6);
    }

    /* renamed from: a */
    private static String m8864a(String str) {
        return str == null ? "" : str;
    }

    /* renamed from: b */
    public static CastDevice m8865b(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        bundle.setClassLoader(CastDevice.class.getClassLoader());
        return (CastDevice) bundle.getParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE");
    }

    /* renamed from: a */
    public int m8866a() {
        return this.f6358b;
    }

    /* renamed from: a */
    public void m8867a(Bundle bundle) {
        if (bundle != null) {
            bundle.putParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE", this);
        }
    }

    /* renamed from: b */
    public String m8868b() {
        return this.f6359c;
    }

    /* renamed from: c */
    public String m8869c() {
        return this.f6361e;
    }

    /* renamed from: d */
    public String m8870d() {
        return this.f6362f;
    }

    /* renamed from: e */
    public String m8871e() {
        return this.f6363g;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof CastDevice)) {
            return false;
        }
        CastDevice castDevice = (CastDevice) obj;
        return this.f6359c == null ? castDevice.f6359c == null : C1312n.m9602a(this.f6359c, castDevice.f6359c) && C1312n.m9602a(this.f6360d, castDevice.f6360d) && C1312n.m9602a(this.f6362f, castDevice.f6362f) && C1312n.m9602a(this.f6361e, castDevice.f6361e) && C1312n.m9602a(this.f6363g, castDevice.f6363g) && this.f6364h == castDevice.f6364h && C1312n.m9602a(this.f6365i, castDevice.f6365i) && this.f6366j == castDevice.f6366j && this.f6367k == castDevice.f6367k && C1312n.m9602a(this.f6368l, castDevice.f6368l);
    }

    /* renamed from: f */
    public String m8872f() {
        return this.f6368l;
    }

    /* renamed from: g */
    public int m8873g() {
        return this.f6364h;
    }

    /* renamed from: h */
    public List<WebImage> m8874h() {
        return Collections.unmodifiableList(this.f6365i);
    }

    public int hashCode() {
        return this.f6359c == null ? 0 : this.f6359c.hashCode();
    }

    /* renamed from: i */
    public int m8875i() {
        return this.f6366j;
    }

    /* renamed from: j */
    public int m8876j() {
        return this.f6367k;
    }

    public String toString() {
        return String.format("\"%s\" (%s)", new Object[]{this.f6361e, this.f6359c});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1330v.m9693a(this, parcel, i);
    }
}
