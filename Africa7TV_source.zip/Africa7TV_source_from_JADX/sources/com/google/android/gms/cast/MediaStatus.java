package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.SparseArray;
import com.google.android.gms.cast.internal.C1312n;
import com.google.android.gms.common.internal.bp;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.util.C1424m;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class MediaStatus extends AbstractSafeParcelable {
    public static final Creator<MediaStatus> CREATOR = new ab();
    /* renamed from: a */
    long f6401a;
    /* renamed from: b */
    String f6402b;
    /* renamed from: c */
    int f6403c;
    /* renamed from: d */
    final ArrayList<MediaQueueItem> f6404d;
    /* renamed from: e */
    private final int f6405e;
    /* renamed from: f */
    private MediaInfo f6406f;
    /* renamed from: g */
    private long f6407g;
    /* renamed from: h */
    private int f6408h;
    /* renamed from: i */
    private double f6409i;
    /* renamed from: j */
    private int f6410j;
    /* renamed from: k */
    private int f6411k;
    /* renamed from: l */
    private long f6412l;
    /* renamed from: m */
    private double f6413m;
    /* renamed from: n */
    private boolean f6414n;
    /* renamed from: o */
    private long[] f6415o;
    /* renamed from: p */
    private int f6416p;
    /* renamed from: q */
    private int f6417q;
    /* renamed from: r */
    private JSONObject f6418r;
    /* renamed from: s */
    private boolean f6419s;
    /* renamed from: t */
    private final SparseArray<Integer> f6420t;

    MediaStatus(int i, MediaInfo mediaInfo, long j, int i2, double d, int i3, int i4, long j2, long j3, double d2, boolean z, long[] jArr, int i5, int i6, String str, int i7, List<MediaQueueItem> list, boolean z2) {
        this.f6404d = new ArrayList();
        this.f6420t = new SparseArray();
        this.f6405e = i;
        this.f6406f = mediaInfo;
        this.f6407g = j;
        this.f6408h = i2;
        this.f6409i = d;
        this.f6410j = i3;
        this.f6411k = i4;
        this.f6412l = j2;
        this.f6401a = j3;
        this.f6413m = d2;
        this.f6414n = z;
        this.f6415o = jArr;
        this.f6416p = i5;
        this.f6417q = i6;
        this.f6402b = str;
        if (this.f6402b != null) {
            try {
                this.f6418r = new JSONObject(this.f6402b);
            } catch (JSONException e) {
                this.f6418r = null;
                this.f6402b = null;
            }
        } else {
            this.f6418r = null;
        }
        this.f6403c = i7;
        if (!(list == null || list.isEmpty())) {
            m8916a((MediaQueueItem[]) list.toArray(new MediaQueueItem[list.size()]));
        }
        this.f6419s = z2;
    }

    public MediaStatus(JSONObject jSONObject) {
        this(1, null, 0, 0, 0.0d, 0, 0, 0, 0, 0.0d, false, null, 0, 0, null, 0, null, false);
        m8921a(jSONObject, 0);
    }

    /* renamed from: a */
    private void m8916a(MediaQueueItem[] mediaQueueItemArr) {
        this.f6404d.clear();
        this.f6420t.clear();
        for (int i = 0; i < mediaQueueItemArr.length; i++) {
            MediaQueueItem mediaQueueItem = mediaQueueItemArr[i];
            this.f6404d.add(mediaQueueItem);
            this.f6420t.put(mediaQueueItem.m8908c(), Integer.valueOf(i));
        }
    }

    /* renamed from: a */
    private boolean m8917a(int i, int i2, int i3, int i4) {
        if (i != 1) {
            return false;
        }
        switch (i2) {
            case 1:
            case 3:
                return i3 == 0;
            case 2:
                return i4 != 2;
            default:
                return true;
        }
    }

    /* renamed from: a */
    private boolean m8918a(MediaStatus mediaStatus) {
        return this.f6418r == null || mediaStatus.f6418r == null || C1424m.m10351a(this.f6418r, mediaStatus.f6418r);
    }

    /* renamed from: q */
    private void m8919q() {
        this.f6403c = 0;
        this.f6404d.clear();
        this.f6420t.clear();
    }

    /* renamed from: a */
    int m8920a() {
        return this.f6405e;
    }

    /* renamed from: a */
    public int m8921a(JSONObject jSONObject, int i) {
        int i2;
        int i3;
        double d;
        long a;
        long[] jArr;
        int i4 = 2;
        int i5 = 1;
        long j = jSONObject.getLong("mediaSessionId");
        if (j != this.f6407g) {
            this.f6407g = j;
            i2 = 1;
        } else {
            i2 = 0;
        }
        if (jSONObject.has("playerState")) {
            String string = jSONObject.getString("playerState");
            i3 = string.equals("IDLE") ? 1 : string.equals("PLAYING") ? 2 : string.equals("PAUSED") ? 3 : string.equals("BUFFERING") ? 4 : 0;
            if (i3 != this.f6410j) {
                this.f6410j = i3;
                i2 |= 2;
            }
            if (i3 == 1 && jSONObject.has("idleReason")) {
                string = jSONObject.getString("idleReason");
                if (!string.equals("CANCELLED")) {
                    i4 = string.equals("INTERRUPTED") ? 3 : string.equals("FINISHED") ? 1 : string.equals("ERROR") ? 4 : 0;
                }
                if (i4 != this.f6411k) {
                    this.f6411k = i4;
                    i2 |= 2;
                }
            }
        }
        if (jSONObject.has("playbackRate")) {
            d = jSONObject.getDouble("playbackRate");
            if (this.f6409i != d) {
                this.f6409i = d;
                i2 |= 2;
            }
        }
        if (jSONObject.has("currentTime") && (i & 2) == 0) {
            a = C1312n.m9598a(jSONObject.getDouble("currentTime"));
            if (a != this.f6412l) {
                this.f6412l = a;
                i2 |= 2;
            }
        }
        if (jSONObject.has("supportedMediaCommands")) {
            a = jSONObject.getLong("supportedMediaCommands");
            if (a != this.f6401a) {
                this.f6401a = a;
                i2 |= 2;
            }
        }
        if (jSONObject.has("volume") && (i & 1) == 0) {
            JSONObject jSONObject2 = jSONObject.getJSONObject("volume");
            d = jSONObject2.getDouble("level");
            if (d != this.f6413m) {
                this.f6413m = d;
                i2 |= 2;
            }
            boolean z = jSONObject2.getBoolean("muted");
            if (z != this.f6414n) {
                this.f6414n = z;
                i2 |= 2;
            }
        }
        if (jSONObject.has("activeTrackIds")) {
            JSONArray jSONArray = jSONObject.getJSONArray("activeTrackIds");
            int length = jSONArray.length();
            long[] jArr2 = new long[length];
            for (i4 = 0; i4 < length; i4++) {
                jArr2[i4] = jSONArray.getLong(i4);
            }
            if (this.f6415o != null && this.f6415o.length == length) {
                for (i4 = 0; i4 < length; i4++) {
                    if (this.f6415o[i4] != jArr2[i4]) {
                        break;
                    }
                }
                i5 = 0;
            }
            if (i5 != 0) {
                this.f6415o = jArr2;
            }
            long[] jArr3 = jArr2;
            i3 = i5;
            jArr = jArr3;
        } else if (this.f6415o != null) {
            i3 = 1;
            jArr = null;
        } else {
            jArr = null;
            i3 = 0;
        }
        if (i3 != 0) {
            this.f6415o = jArr;
            i2 |= 2;
        }
        if (jSONObject.has("customData")) {
            this.f6418r = jSONObject.getJSONObject("customData");
            this.f6402b = null;
            i2 |= 2;
        }
        if (jSONObject.has("media")) {
            JSONObject jSONObject3 = jSONObject.getJSONObject("media");
            this.f6406f = new MediaInfo(jSONObject3);
            i2 |= 2;
            if (jSONObject3.has("metadata")) {
                i2 |= 4;
            }
        }
        if (jSONObject.has("currentItemId")) {
            i5 = jSONObject.getInt("currentItemId");
            if (this.f6408h != i5) {
                this.f6408h = i5;
                i2 |= 2;
            }
        }
        i5 = jSONObject.optInt("preloadedItemId", 0);
        if (this.f6417q != i5) {
            this.f6417q = i5;
            i2 |= 16;
        }
        i5 = jSONObject.optInt("loadingItemId", 0);
        if (this.f6416p != i5) {
            this.f6416p = i5;
            i2 |= 2;
        }
        if (!m8917a(this.f6410j, this.f6411k, this.f6416p, this.f6406f == null ? -1 : this.f6406f.m8885c())) {
            return m8924a(jSONObject) ? i2 | 8 : i2;
        } else {
            this.f6408h = 0;
            this.f6416p = 0;
            this.f6417q = 0;
            if (this.f6404d.isEmpty()) {
                return i2;
            }
            m8919q();
            return i2 | 8;
        }
    }

    /* renamed from: a */
    public MediaQueueItem m8922a(int i) {
        return m8926b(i);
    }

    /* renamed from: a */
    public void m8923a(boolean z) {
        this.f6419s = z;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    boolean m8924a(org.json.JSONObject r11) {
        /*
        r10 = this;
        r3 = 3;
        r0 = 2;
        r1 = 0;
        r2 = 1;
        r4 = "repeatMode";
        r4 = r11.has(r4);
        if (r4 == 0) goto L_0x00ef;
    L_0x000c:
        r4 = r10.f6403c;
        r5 = "repeatMode";
        r6 = r11.getString(r5);
        r5 = -1;
        r7 = r6.hashCode();
        switch(r7) {
            case -1118317585: goto L_0x0073;
            case -962896020: goto L_0x0069;
            case 1645938909: goto L_0x005f;
            case 1645952171: goto L_0x0055;
            default: goto L_0x001c;
        };
    L_0x001c:
        switch(r5) {
            case 0: goto L_0x007d;
            case 1: goto L_0x007f;
            case 2: goto L_0x0020;
            case 3: goto L_0x0081;
            default: goto L_0x001f;
        };
    L_0x001f:
        r0 = r4;
    L_0x0020:
        r3 = r10.f6403c;
        if (r3 == r0) goto L_0x00ef;
    L_0x0024:
        r10.f6403c = r0;
        r0 = r2;
    L_0x0027:
        r3 = "items";
        r3 = r11.has(r3);
        if (r3 == 0) goto L_0x00ed;
    L_0x002f:
        r3 = "items";
        r4 = r11.getJSONArray(r3);
        r5 = r4.length();
        r6 = new android.util.SparseArray;
        r6.<init>();
        r3 = r1;
    L_0x003f:
        if (r3 >= r5) goto L_0x0083;
    L_0x0041:
        r7 = r4.getJSONObject(r3);
        r8 = "itemId";
        r7 = r7.getInt(r8);
        r7 = java.lang.Integer.valueOf(r7);
        r6.put(r3, r7);
        r3 = r3 + 1;
        goto L_0x003f;
    L_0x0055:
        r7 = "REPEAT_OFF";
        r6 = r6.equals(r7);
        if (r6 == 0) goto L_0x001c;
    L_0x005d:
        r5 = r1;
        goto L_0x001c;
    L_0x005f:
        r7 = "REPEAT_ALL";
        r6 = r6.equals(r7);
        if (r6 == 0) goto L_0x001c;
    L_0x0067:
        r5 = r2;
        goto L_0x001c;
    L_0x0069:
        r7 = "REPEAT_SINGLE";
        r6 = r6.equals(r7);
        if (r6 == 0) goto L_0x001c;
    L_0x0071:
        r5 = r0;
        goto L_0x001c;
    L_0x0073:
        r7 = "REPEAT_ALL_AND_SHUFFLE";
        r6 = r6.equals(r7);
        if (r6 == 0) goto L_0x001c;
    L_0x007b:
        r5 = r3;
        goto L_0x001c;
    L_0x007d:
        r0 = r1;
        goto L_0x0020;
    L_0x007f:
        r0 = r2;
        goto L_0x0020;
    L_0x0081:
        r0 = r3;
        goto L_0x0020;
    L_0x0083:
        r7 = new com.google.android.gms.cast.MediaQueueItem[r5];
        r3 = r1;
        r1 = r0;
    L_0x0087:
        if (r3 >= r5) goto L_0x00dd;
    L_0x0089:
        r0 = r6.get(r3);
        r0 = (java.lang.Integer) r0;
        r8 = r4.getJSONObject(r3);
        r9 = r0.intValue();
        r9 = r10.m8926b(r9);
        if (r9 == 0) goto L_0x00b8;
    L_0x009d:
        r8 = r9.m8906a(r8);
        r1 = r1 | r8;
        r7[r3] = r9;
        r0 = r0.intValue();
        r0 = r10.m8928c(r0);
        r0 = r0.intValue();
        if (r3 == r0) goto L_0x00eb;
    L_0x00b2:
        r0 = r2;
    L_0x00b3:
        r1 = r3 + 1;
        r3 = r1;
        r1 = r0;
        goto L_0x0087;
    L_0x00b8:
        r0 = r0.intValue();
        r1 = r10.f6408h;
        if (r0 != r1) goto L_0x00d4;
    L_0x00c0:
        r0 = new com.google.android.gms.cast.s;
        r1 = r10.f6406f;
        r0.<init>(r1);
        r0 = r0.m9686a();
        r7[r3] = r0;
        r0 = r7[r3];
        r0.m8906a(r8);
        r0 = r2;
        goto L_0x00b3;
    L_0x00d4:
        r0 = new com.google.android.gms.cast.MediaQueueItem;
        r0.<init>(r8);
        r7[r3] = r0;
        r0 = r2;
        goto L_0x00b3;
    L_0x00dd:
        r0 = r10.f6404d;
        r0 = r0.size();
        if (r0 == r5) goto L_0x00e9;
    L_0x00e5:
        r10.m8916a(r7);
    L_0x00e8:
        return r2;
    L_0x00e9:
        r2 = r1;
        goto L_0x00e5;
    L_0x00eb:
        r0 = r1;
        goto L_0x00b3;
    L_0x00ed:
        r2 = r0;
        goto L_0x00e8;
    L_0x00ef:
        r0 = r1;
        goto L_0x0027;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.MediaStatus.a(org.json.JSONObject):boolean");
    }

    /* renamed from: b */
    public long m8925b() {
        return this.f6407g;
    }

    /* renamed from: b */
    public MediaQueueItem m8926b(int i) {
        Integer num = (Integer) this.f6420t.get(i);
        return num == null ? null : (MediaQueueItem) this.f6404d.get(num.intValue());
    }

    /* renamed from: c */
    public int m8927c() {
        return this.f6410j;
    }

    /* renamed from: c */
    public Integer m8928c(int i) {
        return (Integer) this.f6420t.get(i);
    }

    /* renamed from: d */
    public int m8929d() {
        return this.f6411k;
    }

    /* renamed from: e */
    public double m8930e() {
        return this.f6409i;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaStatus)) {
            return false;
        }
        MediaStatus mediaStatus = (MediaStatus) obj;
        return (this.f6418r == null) != (mediaStatus.f6418r == null) ? false : this.f6407g == mediaStatus.f6407g && this.f6408h == mediaStatus.f6408h && this.f6409i == mediaStatus.f6409i && this.f6410j == mediaStatus.f6410j && this.f6411k == mediaStatus.f6411k && this.f6412l == mediaStatus.f6412l && this.f6413m == mediaStatus.f6413m && this.f6414n == mediaStatus.f6414n && this.f6416p == mediaStatus.f6416p && this.f6417q == mediaStatus.f6417q && this.f6403c == mediaStatus.f6403c && Arrays.equals(this.f6415o, mediaStatus.f6415o) && C1312n.m9602a(Long.valueOf(this.f6401a), Long.valueOf(mediaStatus.f6401a)) && C1312n.m9602a(this.f6404d, mediaStatus.f6404d) && C1312n.m9602a(this.f6406f, mediaStatus.f6406f) && m8918a(mediaStatus) && this.f6419s == mediaStatus.m8941p();
    }

    /* renamed from: f */
    public MediaInfo m8931f() {
        return this.f6406f;
    }

    /* renamed from: g */
    public long m8932g() {
        return this.f6412l;
    }

    /* renamed from: h */
    public double m8933h() {
        return this.f6413m;
    }

    public int hashCode() {
        return bp.m10107a(this.f6406f, Long.valueOf(this.f6407g), Integer.valueOf(this.f6408h), Double.valueOf(this.f6409i), Integer.valueOf(this.f6410j), Integer.valueOf(this.f6411k), Long.valueOf(this.f6412l), Long.valueOf(this.f6401a), Double.valueOf(this.f6413m), Boolean.valueOf(this.f6414n), Integer.valueOf(Arrays.hashCode(this.f6415o)), Integer.valueOf(this.f6416p), Integer.valueOf(this.f6417q), this.f6418r, Integer.valueOf(this.f6403c), this.f6404d, Boolean.valueOf(this.f6419s));
    }

    /* renamed from: i */
    public boolean m8934i() {
        return this.f6414n;
    }

    /* renamed from: j */
    public long[] m8935j() {
        return this.f6415o;
    }

    /* renamed from: k */
    public int m8936k() {
        return this.f6408h;
    }

    /* renamed from: l */
    public int m8937l() {
        return this.f6416p;
    }

    /* renamed from: m */
    public int m8938m() {
        return this.f6417q;
    }

    /* renamed from: n */
    public int m8939n() {
        return this.f6403c;
    }

    /* renamed from: o */
    public int m8940o() {
        return this.f6404d.size();
    }

    /* renamed from: p */
    public boolean m8941p() {
        return this.f6419s;
    }

    public void writeToParcel(Parcel parcel, int i) {
        this.f6402b = this.f6418r == null ? null : this.f6418r.toString();
        ab.m8971a(this, parcel, i);
    }
}
