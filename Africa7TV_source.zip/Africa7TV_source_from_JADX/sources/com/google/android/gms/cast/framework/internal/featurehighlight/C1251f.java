package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v4.p002b.C0107a;
import android.util.TypedValue;
import com.google.android.gms.C1219b;
import com.google.android.gms.C1220c;
import com.google.android.gms.common.util.C1426o;
import com.google.android.gms.internal.gt;

/* renamed from: com.google.android.gms.cast.framework.internal.featurehighlight.f */
class C1251f extends Drawable {
    /* renamed from: a */
    private final int f6519a;
    /* renamed from: b */
    private final int f6520b;
    /* renamed from: c */
    private final int f6521c;
    /* renamed from: d */
    private final Rect f6522d = new Rect();
    /* renamed from: e */
    private final Rect f6523e = new Rect();
    /* renamed from: f */
    private final Paint f6524f = new Paint();
    /* renamed from: g */
    private float f6525g;
    /* renamed from: h */
    private float f6526h = 1.0f;
    /* renamed from: i */
    private float f6527i;
    /* renamed from: j */
    private float f6528j;
    /* renamed from: k */
    private float f6529k = 0.0f;
    /* renamed from: l */
    private float f6530l = 0.0f;
    /* renamed from: m */
    private int f6531m = 244;

    public C1251f(Context context) {
        if (C1426o.m10361i()) {
            m9256a(C1251f.m9254a(context));
        } else {
            m9256a(context.getResources().getColor(C1219b.f6345xfbd34f47));
        }
        this.f6524f.setAntiAlias(true);
        this.f6524f.setStyle(Style.FILL);
        Resources resources = context.getResources();
        this.f6519a = resources.getDimensionPixelSize(C1220c.cast_libraries_material_featurehighlight_center_threshold);
        this.f6520b = resources.getDimensionPixelSize(C1220c.f6347xd1678993);
        this.f6521c = resources.getDimensionPixelSize(C1220c.cast_libraries_material_featurehighlight_outer_padding);
    }

    /* renamed from: a */
    private float m9253a(float f, float f2, Rect rect) {
        return (float) Math.ceil((double) gt.m13934a(f, f2, (float) rect.left, (float) rect.top, (float) rect.right, (float) rect.bottom));
    }

    @TargetApi(21)
    /* renamed from: a */
    private static int m9254a(Context context) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(16843827, typedValue, true);
        return C0107a.m720c(typedValue.data, 244);
    }

    /* renamed from: a */
    public int m9255a() {
        return this.f6524f.getColor();
    }

    /* renamed from: a */
    public void m9256a(int i) {
        this.f6524f.setColor(i);
        this.f6531m = this.f6524f.getAlpha();
        invalidateSelf();
    }

    /* renamed from: a */
    public void m9257a(Rect rect, Rect rect2) {
        this.f6522d.set(rect);
        this.f6523e.set(rect2);
        float exactCenterX = rect.exactCenterX();
        float exactCenterY = rect.exactCenterY();
        Rect bounds = getBounds();
        if (Math.min(exactCenterY - ((float) bounds.top), ((float) bounds.bottom) - exactCenterY) < ((float) this.f6519a)) {
            this.f6527i = exactCenterX;
            this.f6528j = exactCenterY;
        } else {
            this.f6527i = ((exactCenterX > bounds.exactCenterX() ? 1 : (exactCenterX == bounds.exactCenterX() ? 0 : -1)) <= 0 ? 1 : null) != null ? rect2.exactCenterX() + ((float) this.f6520b) : rect2.exactCenterX() - ((float) this.f6520b);
            this.f6528j = rect2.exactCenterY();
        }
        this.f6525g = ((float) this.f6521c) + Math.max(m9253a(this.f6527i, this.f6528j, rect), m9253a(this.f6527i, this.f6528j, rect2));
        invalidateSelf();
    }

    /* renamed from: a */
    public boolean m9258a(float f, float f2) {
        return gt.m13935b(f, f2, this.f6527i, this.f6528j) < this.f6525g;
    }

    public void draw(Canvas canvas) {
        canvas.drawCircle(this.f6527i + 0.0f, this.f6528j + 0.0f, this.f6525g * this.f6526h, this.f6524f);
    }

    public int getAlpha() {
        return this.f6524f.getAlpha();
    }

    public int getOpacity() {
        return -3;
    }

    public void setAlpha(int i) {
        this.f6524f.setAlpha(i);
        invalidateSelf();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f6524f.setColorFilter(colorFilter);
        invalidateSelf();
    }
}
