package com.google.android.gms.cast.framework.media;

import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.cast.C1225d;
import com.google.android.gms.cast.C1260m;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaQueueItem;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.cast.internal.C1319x;
import com.google.android.gms.common.api.C1192u;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C1370c;
import com.google.android.gms.internal.avy;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.framework.media.d */
public class C1261d implements C1260m {
    /* renamed from: a */
    public static final String f6594a = C1319x.f6739g;
    /* renamed from: b */
    private final Object f6595b = new Object();
    /* renamed from: c */
    private final Handler f6596c = new Handler(Looper.getMainLooper());
    /* renamed from: d */
    private final C1319x f6597d;
    /* renamed from: e */
    private final C1275p f6598e = new C1275p(this);
    /* renamed from: f */
    private final C1225d f6599f;
    /* renamed from: g */
    private C1352q f6600g;
    /* renamed from: h */
    private final List<C1271l> f6601h = new CopyOnWriteArrayList();
    /* renamed from: i */
    private final Map<C1274o, C1280v> f6602i = new ConcurrentHashMap();
    /* renamed from: j */
    private final Map<Long, C1280v> f6603j = new ConcurrentHashMap();
    /* renamed from: k */
    private C1273n f6604k;

    public C1261d(C1319x c1319x, C1225d c1225d) {
        this.f6599f = c1225d;
        this.f6597d = (C1319x) C1370c.m10112a((Object) c1319x);
        this.f6597d.m9662a(new C1263e(this));
        this.f6597d.m9512a(this.f6598e);
    }

    /* renamed from: a */
    private C1264r m9349a(C1264r c1264r) {
        try {
            this.f6600g.mo2042a((avy) c1264r);
        } catch (IllegalStateException e) {
            c1264r.m8763b((C1223y) (C1272m) c1264r.mo1416b(new Status(2100)));
        } catch (Throwable th) {
        }
        return c1264r;
    }

    /* renamed from: a */
    private void m9351a(Set<C1274o> set) {
        if (!m9382m() && !m9381l()) {
            Set<C1274o> hashSet = new HashSet(set);
            if (m9380k()) {
                for (C1274o a : hashSet) {
                    a.m9421a(m9372d(), m9374e());
                }
            } else if (m9383n()) {
                MediaQueueItem o = m9384o();
                if (o != null && o.m8907b() != null) {
                    for (C1274o a2 : hashSet) {
                        a2.m9421a(0, o.m8907b().m8888f());
                    }
                }
            } else {
                for (C1274o a22 : hashSet) {
                    a22.m9421a(0, 0);
                }
            }
        }
    }

    /* renamed from: t */
    private void m9358t() {
        if (this.f6600g == null) {
            throw new IllegalStateException("No connection");
        }
    }

    /* renamed from: u */
    private void m9359u() {
        for (C1280v c1280v : this.f6603j.values()) {
            if (m9386q() && !c1280v.m9438c()) {
                c1280v.m9436a();
            } else if (!m9386q() && c1280v.m9438c()) {
                c1280v.m9437b();
            }
            if (c1280v.m9438c() && (m9382m() || m9381l() || m9383n())) {
                m9351a(c1280v.f6631b);
            }
        }
    }

    /* renamed from: a */
    public C1192u<C1272m> m9360a() {
        return m9363a(null);
    }

    /* renamed from: a */
    public C1192u<C1272m> m9361a(long j) {
        return m9362a(j, 0, null);
    }

    /* renamed from: a */
    public C1192u<C1272m> m9362a(long j, int i, JSONObject jSONObject) {
        m9358t();
        return m9349a(new C1269j(this, this.f6600g, j, i, jSONObject));
    }

    /* renamed from: a */
    public C1192u<C1272m> m9363a(JSONObject jSONObject) {
        m9358t();
        return m9349a(new C1267h(this, this.f6600g, jSONObject));
    }

    /* renamed from: a */
    public void mo1536a(CastDevice castDevice, String str, String str2) {
        this.f6597d.mo1596b(str2);
    }

    /* renamed from: a */
    public void m9365a(C1271l c1271l) {
        if (c1271l != null) {
            this.f6601h.add(c1271l);
        }
    }

    /* renamed from: a */
    public void m9366a(C1352q c1352q) {
        if (this.f6600g != c1352q) {
            if (this.f6600g != null) {
                this.f6597d.mo1555a();
                this.f6599f.mo1434b(this.f6600g, m9388s());
                this.f6598e.m9425a(null);
                this.f6596c.removeCallbacksAndMessages(null);
            }
            this.f6600g = c1352q;
            if (this.f6600g != null) {
                this.f6599f.mo1432a(this.f6600g, m9388s(), (C1260m) this);
                this.f6598e.m9425a(this.f6600g);
            }
        }
    }

    /* renamed from: b */
    public C1192u<C1272m> m9367b() {
        return m9368b(null);
    }

    /* renamed from: b */
    public C1192u<C1272m> m9368b(JSONObject jSONObject) {
        m9358t();
        return m9349a(new C1268i(this, this.f6600g, jSONObject));
    }

    /* renamed from: b */
    public void m9369b(C1271l c1271l) {
        if (c1271l != null) {
            this.f6601h.remove(c1271l);
        }
    }

    /* renamed from: c */
    public C1192u<C1272m> m9370c() {
        m9358t();
        return m9349a(new C1270k(this, this.f6600g));
    }

    /* renamed from: c */
    public C1192u<C1272m> m9371c(JSONObject jSONObject) {
        m9358t();
        return m9349a(new C1265f(this, this.f6600g, jSONObject));
    }

    /* renamed from: d */
    public long m9372d() {
        long d;
        synchronized (this.f6595b) {
            d = this.f6597d.m9666d();
        }
        return d;
    }

    /* renamed from: d */
    public C1192u<C1272m> m9373d(JSONObject jSONObject) {
        m9358t();
        return m9349a(new C1266g(this, this.f6600g, jSONObject));
    }

    /* renamed from: e */
    public long m9374e() {
        long e;
        synchronized (this.f6595b) {
            e = this.f6597d.m9667e();
        }
        return e;
    }

    /* renamed from: f */
    public MediaStatus m9375f() {
        MediaStatus f;
        synchronized (this.f6595b) {
            f = this.f6597d.m9668f();
        }
        return f;
    }

    /* renamed from: g */
    public MediaInfo m9376g() {
        MediaInfo g;
        synchronized (this.f6595b) {
            g = this.f6597d.m9669g();
        }
        return g;
    }

    /* renamed from: h */
    public int m9377h() {
        int c;
        synchronized (this.f6595b) {
            MediaStatus f = m9375f();
            c = f != null ? f.m8927c() : 1;
        }
        return c;
    }

    /* renamed from: i */
    public int m9378i() {
        int d;
        synchronized (this.f6595b) {
            MediaStatus f = m9375f();
            d = f != null ? f.m8929d() : 0;
        }
        return d;
    }

    /* renamed from: j */
    public boolean m9379j() {
        MediaInfo g = m9376g();
        return g != null && g.m8885c() == 2;
    }

    /* renamed from: k */
    public boolean m9380k() {
        MediaStatus f = m9375f();
        return f != null && f.m8927c() == 2;
    }

    /* renamed from: l */
    public boolean m9381l() {
        MediaStatus f = m9375f();
        return f != null && (f.m8927c() == 3 || (m9379j() && m9378i() == 2));
    }

    /* renamed from: m */
    public boolean m9382m() {
        MediaStatus f = m9375f();
        return f != null && f.m8927c() == 4;
    }

    /* renamed from: n */
    public boolean m9383n() {
        MediaStatus f = m9375f();
        return (f == null || f.m8937l() == 0) ? false : true;
    }

    /* renamed from: o */
    public MediaQueueItem m9384o() {
        MediaStatus f = m9375f();
        return f == null ? null : f.m8922a(f.m8937l());
    }

    /* renamed from: p */
    public void m9385p() {
        int h = m9377h();
        if (h == 4 || h == 2) {
            m9360a();
        } else {
            m9367b();
        }
    }

    /* renamed from: q */
    public boolean m9386q() {
        return m9382m() || m9380k() || m9381l() || m9383n();
    }

    /* renamed from: r */
    public boolean m9387r() {
        MediaStatus f = m9375f();
        return f != null && f.m8941p();
    }

    /* renamed from: s */
    public String m9388s() {
        return this.f6597d.m9515b();
    }
}
