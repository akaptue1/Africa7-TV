package com.google.android.gms.cast.framework;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.p034a.C0827c;

/* renamed from: com.google.android.gms.cast.framework.v */
public abstract class C1291v extends Binder implements C1290u {
    /* renamed from: a */
    public static C1290u m9471a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.framework.IAppVisibilityListener");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof C1290u)) ? new C1292w(iBinder) : (C1290u) queryLocalInterface;
    }

    public IBinder asBinder() {
        return this;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        switch (i) {
            case 1:
                parcel.enforceInterface("com.google.android.gms.cast.framework.IAppVisibilityListener");
                C0827c b = mo1551b();
                parcel2.writeNoException();
                parcel2.writeStrongBinder(b != null ? b.asBinder() : null);
                return true;
            case 2:
                parcel.enforceInterface("com.google.android.gms.cast.framework.IAppVisibilityListener");
                mo1552c();
                parcel2.writeNoException();
                return true;
            case 3:
                parcel.enforceInterface("com.google.android.gms.cast.framework.IAppVisibilityListener");
                mo1553d();
                parcel2.writeNoException();
                return true;
            case 4:
                parcel.enforceInterface("com.google.android.gms.cast.framework.IAppVisibilityListener");
                int a = mo1550a();
                parcel2.writeNoException();
                parcel2.writeInt(a);
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.framework.IAppVisibilityListener");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
