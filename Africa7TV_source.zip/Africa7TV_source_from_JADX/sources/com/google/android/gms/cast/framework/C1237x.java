package com.google.android.gms.cast.framework;

import android.os.IInterface;
import com.google.android.gms.cast.LaunchOptions;

/* renamed from: com.google.android.gms.cast.framework.x */
public interface C1237x extends IInterface {
    /* renamed from: a */
    int mo1513a();

    /* renamed from: a */
    void mo1514a(int i);

    /* renamed from: a */
    void mo1515a(String str);

    /* renamed from: a */
    void mo1516a(String str, LaunchOptions launchOptions);

    /* renamed from: a */
    void mo1517a(String str, String str2);
}
