package com.google.android.gms.cast.framework.media;

import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.p034a.C0827c;
import com.google.android.gms.p034a.C0830f;

/* renamed from: com.google.android.gms.cast.framework.media.c */
class C1259c extends C1258y {
    /* renamed from: a */
    final /* synthetic */ C1255a f6593a;

    private C1259c(C1255a c1255a) {
        this.f6593a = c1255a;
    }

    /* renamed from: a */
    public int mo1532a() {
        return 9877208;
    }

    /* renamed from: a */
    public WebImage mo1533a(MediaMetadata mediaMetadata, int i) {
        return this.f6593a.m9322a(mediaMetadata, i);
    }

    /* renamed from: a */
    public WebImage mo1534a(MediaMetadata mediaMetadata, ImageHints imageHints) {
        return this.f6593a.m9323a(mediaMetadata, imageHints);
    }

    /* renamed from: b */
    public C0827c mo1535b() {
        return C0830f.m6210a(this.f6593a);
    }
}
