package com.google.android.gms.cast.framework;

import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface av extends IInterface {
    /* renamed from: a */
    C0827c mo1484a();

    /* renamed from: a */
    void mo1485a(ag agVar);

    /* renamed from: a */
    void mo1486a(ay ayVar);

    /* renamed from: a */
    void mo1487a(boolean z, boolean z2);

    /* renamed from: b */
    C0827c mo1488b();

    /* renamed from: b */
    void mo1489b(ag agVar);

    /* renamed from: b */
    void mo1490b(ay ayVar);
}
