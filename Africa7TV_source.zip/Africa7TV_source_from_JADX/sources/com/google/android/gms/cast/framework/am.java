package com.google.android.gms.cast.framework;

import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface am extends IInterface {
    /* renamed from: a */
    int mo1460a();

    /* renamed from: a */
    void mo1461a(boolean z);

    /* renamed from: b */
    C0827c mo1462b();
}
