package com.google.android.gms.cast;

import com.google.android.gms.common.api.C1192u;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.cast.d */
public interface C1225d {
    /* renamed from: a */
    C1192u<Status> mo1429a(C1352q c1352q, String str);

    /* renamed from: a */
    C1192u<C1224c> mo1430a(C1352q c1352q, String str, LaunchOptions launchOptions);

    /* renamed from: a */
    C1192u<Status> mo1431a(C1352q c1352q, String str, String str2);

    /* renamed from: a */
    void mo1432a(C1352q c1352q, String str, C1260m c1260m);

    /* renamed from: b */
    C1192u<C1224c> mo1433b(C1352q c1352q, String str, String str2);

    /* renamed from: b */
    void mo1434b(C1352q c1352q, String str);
}
