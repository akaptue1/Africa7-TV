package com.google.android.gms.cast.internal;

/* renamed from: com.google.android.gms.cast.internal.l */
class C1310l implements Runnable {
    /* renamed from: a */
    final /* synthetic */ C1303g f6718a;
    /* renamed from: b */
    final /* synthetic */ ApplicationStatus f6719b;
    /* renamed from: c */
    final /* synthetic */ C1307i f6720c;

    C1310l(C1307i c1307i, C1303g c1303g, ApplicationStatus applicationStatus) {
        this.f6720c = c1307i;
        this.f6718a = c1303g;
        this.f6719b = applicationStatus;
    }

    public void run() {
        this.f6718a.m9526a(this.f6719b);
    }
}
