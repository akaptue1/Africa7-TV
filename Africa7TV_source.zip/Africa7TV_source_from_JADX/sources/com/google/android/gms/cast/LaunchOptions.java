package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.cast.internal.C1312n;
import com.google.android.gms.common.internal.bp;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Locale;

public class LaunchOptions extends AbstractSafeParcelable {
    public static final Creator<LaunchOptions> CREATOR = new C1332x();
    /* renamed from: a */
    private final int f6371a;
    /* renamed from: b */
    private boolean f6372b;
    /* renamed from: c */
    private String f6373c;

    public LaunchOptions() {
        this(1, false, C1312n.m9599a(Locale.getDefault()));
    }

    LaunchOptions(int i, boolean z, String str) {
        this.f6371a = i;
        this.f6372b = z;
        this.f6373c = str;
    }

    /* renamed from: a */
    int m8879a() {
        return this.f6371a;
    }

    /* renamed from: b */
    public boolean m8880b() {
        return this.f6372b;
    }

    /* renamed from: c */
    public String m8881c() {
        return this.f6373c;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof LaunchOptions)) {
            return false;
        }
        LaunchOptions launchOptions = (LaunchOptions) obj;
        return this.f6372b == launchOptions.f6372b && C1312n.m9602a(this.f6373c, launchOptions.f6373c);
    }

    public int hashCode() {
        return bp.m10107a(Boolean.valueOf(this.f6372b), this.f6373c);
    }

    public String toString() {
        return String.format("LaunchOptions(relaunchIfRunning=%b, language=%s)", new Object[]{Boolean.valueOf(this.f6372b), this.f6373c});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1332x.m9699a(this, parcel, i);
    }
}
