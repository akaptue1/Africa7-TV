package com.google.android.gms.cast;

import com.google.android.gms.common.api.C1223y;

/* renamed from: com.google.android.gms.cast.c */
public interface C1224c extends C1223y {
    /* renamed from: a */
    ApplicationMetadata mo1562a();

    /* renamed from: b */
    String mo1563b();

    /* renamed from: c */
    String mo1564c();

    /* renamed from: d */
    boolean mo1565d();
}
