package com.google.android.gms.cast.framework.media;

import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.common.images.WebImage;

/* renamed from: com.google.android.gms.cast.framework.media.a */
public class C1255a {
    /* renamed from: a */
    private final C1257x f6591a = new C1259c();

    @Deprecated
    /* renamed from: a */
    public WebImage m9322a(MediaMetadata mediaMetadata, int i) {
        return (mediaMetadata == null || !mediaMetadata.m8904f()) ? null : (WebImage) mediaMetadata.m8903e().get(0);
    }

    /* renamed from: a */
    public WebImage m9323a(MediaMetadata mediaMetadata, ImageHints imageHints) {
        return m9322a(mediaMetadata, imageHints.m9277b());
    }
}
