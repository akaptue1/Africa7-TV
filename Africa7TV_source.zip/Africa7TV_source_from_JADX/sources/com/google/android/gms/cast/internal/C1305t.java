package com.google.android.gms.cast.internal;

import android.os.IInterface;
import com.google.android.gms.cast.ApplicationMetadata;

/* renamed from: com.google.android.gms.cast.internal.t */
public interface C1305t extends IInterface {
    /* renamed from: a */
    void mo1566a(int i);

    /* renamed from: a */
    void mo1567a(ApplicationMetadata applicationMetadata, String str, String str2, boolean z);

    /* renamed from: a */
    void mo1568a(ApplicationStatus applicationStatus);

    /* renamed from: a */
    void mo1569a(DeviceStatus deviceStatus);

    /* renamed from: a */
    void mo1570a(String str, double d, boolean z);

    /* renamed from: a */
    void mo1571a(String str, long j);

    /* renamed from: a */
    void mo1572a(String str, long j, int i);

    /* renamed from: a */
    void mo1573a(String str, String str2);

    /* renamed from: a */
    void mo1574a(String str, byte[] bArr);

    /* renamed from: b */
    void mo1575b(int i);

    /* renamed from: c */
    void mo1576c(int i);

    /* renamed from: d */
    void mo1577d(int i);

    /* renamed from: e */
    void mo1578e(int i);
}
