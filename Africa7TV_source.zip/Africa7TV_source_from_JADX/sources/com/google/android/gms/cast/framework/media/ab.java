package com.google.android.gms.cast.framework.media;

import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public abstract class ab extends Binder implements aa {
    /* renamed from: a */
    public static aa m9328a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.framework.media.IMediaNotificationService");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof aa)) ? new ac(iBinder) : (aa) queryLocalInterface;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        Intent intent = null;
        switch (i) {
            case 1:
                parcel.enforceInterface("com.google.android.gms.cast.framework.media.IMediaNotificationService");
                mo1530a();
                parcel2.writeNoException();
                return true;
            case 2:
                parcel.enforceInterface("com.google.android.gms.cast.framework.media.IMediaNotificationService");
                if (parcel.readInt() != 0) {
                    intent = (Intent) Intent.CREATOR.createFromParcel(parcel);
                }
                int a = mo1528a(intent, parcel.readInt(), parcel.readInt());
                parcel2.writeNoException();
                parcel2.writeInt(a);
                return true;
            case 3:
                parcel.enforceInterface("com.google.android.gms.cast.framework.media.IMediaNotificationService");
                if (parcel.readInt() != 0) {
                    intent = (Intent) Intent.CREATOR.createFromParcel(parcel);
                }
                IBinder a2 = mo1529a(intent);
                parcel2.writeNoException();
                parcel2.writeStrongBinder(a2);
                return true;
            case 4:
                parcel.enforceInterface("com.google.android.gms.cast.framework.media.IMediaNotificationService");
                mo1531b();
                parcel2.writeNoException();
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.framework.media.IMediaNotificationService");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
