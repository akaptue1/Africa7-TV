package com.google.android.gms.cast.framework;

import android.os.Bundle;
import android.os.IInterface;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.common.ConnectionResult;

public interface ad extends IInterface {
    /* renamed from: a */
    void mo1446a(int i);

    /* renamed from: a */
    void mo1447a(Bundle bundle);

    /* renamed from: a */
    void mo1448a(ApplicationMetadata applicationMetadata, String str, String str2, boolean z);

    /* renamed from: a */
    void mo1449a(ConnectionResult connectionResult);

    /* renamed from: a */
    void mo1450a(boolean z, int i);

    /* renamed from: b */
    void mo1451b(int i);
}
