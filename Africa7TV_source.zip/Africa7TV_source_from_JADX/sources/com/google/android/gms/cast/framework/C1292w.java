package com.google.android.gms.cast.framework;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.p034a.C0827c;
import com.google.android.gms.p034a.C0828d;

/* renamed from: com.google.android.gms.cast.framework.w */
class C1292w implements C1290u {
    /* renamed from: a */
    private IBinder f6645a;

    C1292w(IBinder iBinder) {
        this.f6645a = iBinder;
    }

    /* renamed from: a */
    public int mo1550a() {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.IAppVisibilityListener");
            this.f6645a.transact(4, obtain, obtain2, 0);
            obtain2.readException();
            int readInt = obtain2.readInt();
            return readInt;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    public IBinder asBinder() {
        return this.f6645a;
    }

    /* renamed from: b */
    public C0827c mo1551b() {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.IAppVisibilityListener");
            this.f6645a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
            C0827c a = C0828d.m6209a(obtain2.readStrongBinder());
            return a;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: c */
    public void mo1552c() {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.IAppVisibilityListener");
            this.f6645a.transact(2, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: d */
    public void mo1553d() {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.IAppVisibilityListener");
            this.f6645a.transact(3, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }
}
