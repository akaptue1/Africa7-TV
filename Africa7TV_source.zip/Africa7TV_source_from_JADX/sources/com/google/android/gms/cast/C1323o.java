package com.google.android.gms.cast;

import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.cast.o */
class C1323o implements C1224c {
    /* renamed from: a */
    final /* synthetic */ Status f6764a;
    /* renamed from: b */
    final /* synthetic */ C1294n f6765b;

    C1323o(C1294n c1294n, Status status) {
        this.f6765b = c1294n;
        this.f6764a = status;
    }

    /* renamed from: a */
    public ApplicationMetadata mo1562a() {
        return null;
    }

    /* renamed from: b */
    public String mo1563b() {
        return null;
    }

    /* renamed from: c */
    public String mo1564c() {
        return null;
    }

    /* renamed from: d */
    public boolean mo1565d() {
        return false;
    }

    /* renamed from: e */
    public Status mo1546e() {
        return this.f6764a;
    }
}
