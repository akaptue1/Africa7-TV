package com.google.android.gms.cast.internal;

import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaQueueItem;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.common.util.C1417f;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.internal.x */
public class C1319x extends C1300c {
    /* renamed from: g */
    public static final String f6739g = C1312n.m9603b("com.google.cast.media");
    /* renamed from: h */
    private long f6740h;
    /* renamed from: i */
    private MediaStatus f6741i;
    /* renamed from: j */
    private final List<ac> f6742j = new ArrayList();
    /* renamed from: k */
    private C1262y f6743k;
    /* renamed from: l */
    private final ac f6744l = new ac(this.b, 86400000);
    /* renamed from: m */
    private final ac f6745m = new ac(this.b, 86400000);
    /* renamed from: n */
    private final ac f6746n = new ac(this.b, 86400000);
    /* renamed from: o */
    private final ac f6747o = new ac(this.b, 86400000);
    /* renamed from: p */
    private final ac f6748p = new ac(this.b, 86400000);
    /* renamed from: q */
    private final ac f6749q = new ac(this.b, 86400000);
    /* renamed from: r */
    private final ac f6750r = new ac(this.b, 86400000);
    /* renamed from: s */
    private final ac f6751s = new ac(this.b, 86400000);
    /* renamed from: t */
    private final ac f6752t = new ac(this.b, 86400000);
    /* renamed from: u */
    private final ac f6753u = new ac(this.b, 86400000);
    /* renamed from: v */
    private final ac f6754v = new ac(this.b, 86400000);
    /* renamed from: w */
    private final ac f6755w = new ac(this.b, 86400000);
    /* renamed from: x */
    private final ac f6756x = new ac(this.b, 86400000);
    /* renamed from: y */
    private final ac f6757y = new ac(this.b, 86400000);

    public C1319x(String str) {
        super(f6739g, C1417f.m10332d(), "MediaControlChannel", str, 1000);
        this.f6742j.add(this.f6744l);
        this.f6742j.add(this.f6745m);
        this.f6742j.add(this.f6746n);
        this.f6742j.add(this.f6747o);
        this.f6742j.add(this.f6748p);
        this.f6742j.add(this.f6749q);
        this.f6742j.add(this.f6750r);
        this.f6742j.add(this.f6751s);
        this.f6742j.add(this.f6752t);
        this.f6742j.add(this.f6753u);
        this.f6742j.add(this.f6754v);
        this.f6742j.add(this.f6755w);
        this.f6742j.add(this.f6756x);
        this.f6742j.add(this.f6757y);
        m9655m();
    }

    /* renamed from: a */
    private void m9650a(long j, JSONObject jSONObject) {
        int i = 1;
        boolean a = this.f6744l.m9505a(j);
        int i2 = (!this.f6748p.m9508b() || this.f6748p.m9505a(j)) ? 0 : 1;
        if ((!this.f6749q.m9508b() || this.f6749q.m9505a(j)) && (!this.f6750r.m9508b() || this.f6750r.m9505a(j))) {
            i = 0;
        }
        i2 = i2 != 0 ? 2 : 0;
        if (i != 0) {
            i2 |= 1;
        }
        if (a || this.f6741i == null) {
            this.f6741i = new MediaStatus(jSONObject);
            this.f6740h = this.b.mo1681b();
            i2 = 31;
        } else {
            i2 = this.f6741i.m8921a(jSONObject, i2);
        }
        if ((i2 & 1) != 0) {
            this.f6740h = this.b.mo1681b();
            m9651i();
        }
        if ((i2 & 2) != 0) {
            this.f6740h = this.b.mo1681b();
            m9651i();
        }
        if ((i2 & 4) != 0) {
            m9652j();
        }
        if ((i2 & 8) != 0) {
            m9653k();
        }
        if ((i2 & 16) != 0) {
            m9654l();
        }
        for (ac a2 : this.f6742j) {
            a2.m9506a(j, 0);
        }
    }

    /* renamed from: i */
    private void m9651i() {
        if (this.f6743k != null) {
            this.f6743k.mo1537a();
        }
    }

    /* renamed from: j */
    private void m9652j() {
        if (this.f6743k != null) {
            this.f6743k.mo1538b();
        }
    }

    /* renamed from: k */
    private void m9653k() {
        if (this.f6743k != null) {
            this.f6743k.mo1539c();
        }
    }

    /* renamed from: l */
    private void m9654l() {
        if (this.f6743k != null) {
            this.f6743k.mo1540d();
        }
    }

    /* renamed from: m */
    private void m9655m() {
        this.f6740h = 0;
        this.f6741i = null;
        for (ac a : this.f6742j) {
            a.m9503a();
        }
    }

    /* renamed from: a */
    public long m9656a(ab abVar) {
        JSONObject jSONObject = new JSONObject();
        long c = m9517c();
        this.f6751s.m9504a(c, abVar);
        m9519a(true);
        try {
            jSONObject.put("requestId", c);
            jSONObject.put("type", "GET_STATUS");
            if (this.f6741i != null) {
                jSONObject.put("mediaSessionId", this.f6741i.m8925b());
            }
        } catch (JSONException e) {
        }
        m9514a(jSONObject.toString(), c, null);
        return c;
    }

    /* renamed from: a */
    public long m9657a(ab abVar, int i, long j, MediaQueueItem[] mediaQueueItemArr, int i2, Integer num, JSONObject jSONObject) {
        if (j == -1 || j >= 0) {
            JSONObject jSONObject2 = new JSONObject();
            long c = m9517c();
            this.f6755w.m9504a(c, abVar);
            m9519a(true);
            try {
                jSONObject2.put("requestId", c);
                jSONObject2.put("type", "QUEUE_UPDATE");
                jSONObject2.put("mediaSessionId", m9670h());
                if (i != 0) {
                    jSONObject2.put("currentItemId", i);
                }
                if (i2 != 0) {
                    jSONObject2.put("jump", i2);
                }
                if (mediaQueueItemArr != null && mediaQueueItemArr.length > 0) {
                    JSONArray jSONArray = new JSONArray();
                    for (int i3 = 0; i3 < mediaQueueItemArr.length; i3++) {
                        jSONArray.put(i3, mediaQueueItemArr[i3].m8915j());
                    }
                    jSONObject2.put("items", jSONArray);
                }
                if (num != null) {
                    switch (num.intValue()) {
                        case 0:
                            jSONObject2.put("repeatMode", "REPEAT_OFF");
                            break;
                        case 1:
                            jSONObject2.put("repeatMode", "REPEAT_ALL");
                            break;
                        case 2:
                            jSONObject2.put("repeatMode", "REPEAT_SINGLE");
                            break;
                        case 3:
                            jSONObject2.put("repeatMode", "REPEAT_ALL_AND_SHUFFLE");
                            break;
                    }
                }
                if (j != -1) {
                    jSONObject2.put("currentTime", C1312n.m9597a(j));
                }
                if (jSONObject != null) {
                    jSONObject2.put("customData", jSONObject);
                }
            } catch (JSONException e) {
            }
            m9514a(jSONObject2.toString(), c, null);
            return c;
        }
        throw new IllegalArgumentException("playPosition cannot be negative: " + j);
    }

    /* renamed from: a */
    public long m9658a(ab abVar, long j, int i, JSONObject jSONObject) {
        JSONObject jSONObject2 = new JSONObject();
        long c = m9517c();
        this.f6748p.m9504a(c, abVar);
        m9519a(true);
        try {
            jSONObject2.put("requestId", c);
            jSONObject2.put("type", "SEEK");
            jSONObject2.put("mediaSessionId", m9670h());
            jSONObject2.put("currentTime", C1312n.m9597a(j));
            if (i == 1) {
                jSONObject2.put("resumeState", "PLAYBACK_START");
            } else if (i == 2) {
                jSONObject2.put("resumeState", "PLAYBACK_PAUSE");
            }
            if (jSONObject != null) {
                jSONObject2.put("customData", jSONObject);
            }
        } catch (JSONException e) {
        }
        m9514a(jSONObject2.toString(), c, null);
        return c;
    }

    /* renamed from: a */
    public long m9659a(ab abVar, JSONObject jSONObject) {
        JSONObject jSONObject2 = new JSONObject();
        long c = m9517c();
        this.f6745m.m9504a(c, abVar);
        m9519a(true);
        try {
            jSONObject2.put("requestId", c);
            jSONObject2.put("type", "PAUSE");
            jSONObject2.put("mediaSessionId", m9670h());
            if (jSONObject != null) {
                jSONObject2.put("customData", jSONObject);
            }
        } catch (JSONException e) {
        }
        m9514a(jSONObject2.toString(), c, null);
        return c;
    }

    /* renamed from: a */
    public void mo1555a() {
        super.mo1555a();
        m9655m();
    }

    /* renamed from: a */
    public void mo1594a(long j, int i) {
        for (ac a : this.f6742j) {
            a.m9506a(j, i);
        }
    }

    /* renamed from: a */
    public void m9662a(C1262y c1262y) {
        this.f6743k = c1262y;
    }

    /* renamed from: a */
    protected boolean mo1595a(long j) {
        boolean z;
        for (ac b : this.f6742j) {
            b.m9509b(j, 2102);
        }
        synchronized (ac.f6664a) {
            for (ac b2 : this.f6742j) {
                if (b2.m9508b()) {
                    z = true;
                    break;
                }
            }
            z = false;
        }
        return z;
    }

    /* renamed from: b */
    public long m9664b(ab abVar, JSONObject jSONObject) {
        JSONObject jSONObject2 = new JSONObject();
        long c = m9517c();
        this.f6746n.m9504a(c, abVar);
        m9519a(true);
        try {
            jSONObject2.put("requestId", c);
            jSONObject2.put("type", "PLAY");
            jSONObject2.put("mediaSessionId", m9670h());
            if (jSONObject != null) {
                jSONObject2.put("customData", jSONObject);
            }
        } catch (JSONException e) {
        }
        m9514a(jSONObject2.toString(), c, null);
        return c;
    }

    /* renamed from: b */
    public final void mo1596b(String str) {
        this.f.m9644b("message received: %s", str);
        try {
            JSONObject jSONObject = new JSONObject(str);
            String string = jSONObject.getString("type");
            long optLong = jSONObject.optLong("requestId", -1);
            if (string.equals("MEDIA_STATUS")) {
                JSONArray jSONArray = jSONObject.getJSONArray("status");
                if (jSONArray.length() > 0) {
                    m9650a(optLong, jSONArray.getJSONObject(0));
                    return;
                }
                this.f6741i = null;
                m9651i();
                m9652j();
                m9653k();
                m9654l();
                this.f6751s.m9506a(optLong, 0);
            } else if (string.equals("INVALID_PLAYER_STATE")) {
                this.f.m9648d("received unexpected error: Invalid Player State.", new Object[0]);
                r1 = jSONObject.optJSONObject("customData");
                for (ac a : this.f6742j) {
                    a.m9507a(optLong, 2100, r1);
                }
            } else if (string.equals("LOAD_FAILED")) {
                this.f6744l.m9507a(optLong, 2100, jSONObject.optJSONObject("customData"));
            } else if (string.equals("LOAD_CANCELLED")) {
                this.f6744l.m9507a(optLong, 2101, jSONObject.optJSONObject("customData"));
            } else if (string.equals("INVALID_REQUEST")) {
                this.f.m9648d("received unexpected error: Invalid Request.", new Object[0]);
                r1 = jSONObject.optJSONObject("customData");
                for (ac a2 : this.f6742j) {
                    a2.m9507a(optLong, 2100, r1);
                }
            }
        } catch (JSONException e) {
            this.f.m9648d("Message is malformed (%s); ignoring: %s", e.getMessage(), str);
        }
    }

    /* renamed from: d */
    public long m9666d() {
        MediaInfo g = m9669g();
        if (g == null || this.f6740h == 0) {
            return 0;
        }
        double e = this.f6741i.m8930e();
        long g2 = this.f6741i.m8932g();
        int c = this.f6741i.m8927c();
        if (e == 0.0d || c != 2) {
            return g2;
        }
        long b = this.b.mo1681b() - this.f6740h;
        long j = b < 0 ? 0 : b;
        if (j == 0) {
            return g2;
        }
        b = g.m8888f();
        g2 += (long) (((double) j) * e);
        if (b <= 0 || g2 <= b) {
            b = g2 < 0 ? 0 : g2;
        }
        return b;
    }

    /* renamed from: e */
    public long m9667e() {
        MediaInfo g = m9669g();
        return g != null ? g.m8888f() : 0;
    }

    /* renamed from: f */
    public MediaStatus m9668f() {
        return this.f6741i;
    }

    /* renamed from: g */
    public MediaInfo m9669g() {
        return this.f6741i == null ? null : this.f6741i.m8931f();
    }

    /* renamed from: h */
    public long m9670h() {
        if (this.f6741i != null) {
            return this.f6741i.m8925b();
        }
        throw new C1320z();
    }
}
