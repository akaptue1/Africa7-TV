package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.content.Context;
import android.support.annotation.Keep;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.C1433e;
import com.google.android.gms.internal.gu;

@Keep
public class HelpTextView extends LinearLayout implements C1246c {
    /* renamed from: a */
    private TextView f6501a;
    /* renamed from: b */
    private TextView f6502b;

    @Keep
    public HelpTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: a */
    private void m9242a(TextView textView, CharSequence charSequence) {
        textView.setText(charSequence);
        textView.setVisibility(TextUtils.isEmpty(charSequence) ? 8 : 0);
    }

    @Keep
    public View asView() {
        return this;
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.f6501a = (TextView) gu.m13936a((TextView) findViewById(C1433e.cast_featurehighlight_help_text_header_view));
        this.f6502b = (TextView) gu.m13936a((TextView) findViewById(C1433e.cast_featurehighlight_help_text_body_view));
    }

    @Keep
    public void setText(CharSequence charSequence, CharSequence charSequence2) {
        m9242a(this.f6501a, charSequence);
        m9242a(this.f6502b, charSequence2);
    }
}
