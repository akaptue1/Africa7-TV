package com.google.android.gms.cast.framework.media;

import java.util.Set;

/* renamed from: com.google.android.gms.cast.framework.media.v */
class C1280v {
    /* renamed from: a */
    final /* synthetic */ C1261d f6630a;
    /* renamed from: b */
    private final Set<C1274o> f6631b;
    /* renamed from: c */
    private final long f6632c;
    /* renamed from: d */
    private final Runnable f6633d;
    /* renamed from: e */
    private boolean f6634e;

    /* renamed from: a */
    public void m9436a() {
        this.f6630a.f6596c.removeCallbacks(this.f6633d);
        this.f6634e = true;
        this.f6630a.f6596c.postDelayed(this.f6633d, this.f6632c);
    }

    /* renamed from: b */
    public void m9437b() {
        this.f6630a.f6596c.removeCallbacks(this.f6633d);
        this.f6634e = false;
    }

    /* renamed from: c */
    public boolean m9438c() {
        return this.f6634e;
    }
}
