package com.google.android.gms.cast;

/* renamed from: com.google.android.gms.cast.s */
public class C1327s {
    /* renamed from: a */
    private final MediaQueueItem f6769a;

    public C1327s(MediaInfo mediaInfo) {
        this.f6769a = new MediaQueueItem(mediaInfo);
    }

    /* renamed from: a */
    public MediaQueueItem m9686a() {
        this.f6769a.m8914i();
        return this.f6769a;
    }
}
