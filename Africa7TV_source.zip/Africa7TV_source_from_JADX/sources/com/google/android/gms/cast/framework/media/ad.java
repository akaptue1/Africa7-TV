package com.google.android.gms.cast.framework.media;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;

public class ad implements Creator<ImageHints> {
    /* renamed from: a */
    static void m9333a(ImageHints imageHints, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, imageHints.m9276a());
        C1386c.m10198a(parcel, 2, imageHints.m9277b());
        C1386c.m10198a(parcel, 3, imageHints.m9278c());
        C1386c.m10198a(parcel, 4, imageHints.m9279d());
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public ImageHints m9334a(Parcel parcel) {
        int i = 0;
        int b = C1384a.m10169b(parcel);
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i4 = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    i3 = C1384a.m10175e(parcel, a);
                    break;
                case 3:
                    i2 = C1384a.m10175e(parcel, a);
                    break;
                case 4:
                    i = C1384a.m10175e(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ImageHints(i4, i3, i2, i);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public ImageHints[] m9335a(int i) {
        return new ImageHints[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9334a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9335a(i);
    }
}
