package com.google.android.gms.cast;

import com.google.android.gms.common.api.C1167c;

/* renamed from: com.google.android.gms.cast.j */
public final class C1321j implements C1167c {
    /* renamed from: a */
    final CastDevice f6758a;
    /* renamed from: b */
    final C1240l f6759b;
    /* renamed from: c */
    private final int f6760c;

    private C1321j(C1322k c1322k) {
        this.f6758a = c1322k.f6761a;
        this.f6759b = c1322k.f6762b;
        this.f6760c = c1322k.f6763c;
    }
}
