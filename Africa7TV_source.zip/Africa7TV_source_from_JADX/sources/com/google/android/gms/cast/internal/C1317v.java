package com.google.android.gms.cast.internal;

import com.google.android.gms.common.api.C1347l;
import java.nio.charset.Charset;
import java.nio.charset.IllegalCharsetNameException;
import java.nio.charset.UnsupportedCharsetException;
import oauth.signpost.OAuth;

/* renamed from: com.google.android.gms.cast.internal.v */
public final class C1317v {
    /* renamed from: a */
    public static final C1347l<C1303g> f6727a = new C1347l();
    /* renamed from: b */
    public static final C1347l<Object> f6728b = new C1347l();
    /* renamed from: c */
    public static final C1347l<Object> f6729c = new C1347l();
    /* renamed from: d */
    public static final C1347l<Object> f6730d = new C1347l();
    /* renamed from: e */
    public static final Charset f6731e;
    /* renamed from: f */
    public static final String f6732f = C1312n.m9603b("com.google.cast.multizone");

    static {
        Charset charset = null;
        try {
            charset = Charset.forName(OAuth.ENCODING);
        } catch (IllegalCharsetNameException e) {
        } catch (UnsupportedCharsetException e2) {
        }
        f6731e = charset;
    }
}
