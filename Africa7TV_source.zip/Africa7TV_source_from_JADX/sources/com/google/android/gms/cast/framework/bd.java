package com.google.android.gms.cast.framework;

import android.os.Bundle;
import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface bd extends IInterface {
    /* renamed from: a */
    int mo1502a();

    /* renamed from: a */
    void mo1503a(Bundle bundle);

    /* renamed from: a */
    void mo1504a(boolean z);

    /* renamed from: b */
    C0827c mo1505b();

    /* renamed from: b */
    void mo1506b(Bundle bundle);

    /* renamed from: c */
    long mo1507c();
}
