package com.google.android.gms.cast.framework;

import android.content.Context;
import java.util.List;

/* renamed from: com.google.android.gms.cast.framework.k */
public interface C1253k {
    /* renamed from: a */
    CastOptions m9268a(Context context);

    /* renamed from: b */
    List<C1285p> m9269b(Context context);
}
