package com.google.android.gms.cast.internal;

/* renamed from: com.google.android.gms.cast.internal.k */
class C1309k implements Runnable {
    /* renamed from: a */
    final /* synthetic */ C1303g f6715a;
    /* renamed from: b */
    final /* synthetic */ DeviceStatus f6716b;
    /* renamed from: c */
    final /* synthetic */ C1307i f6717c;

    C1309k(C1307i c1307i, C1303g c1303g, DeviceStatus deviceStatus) {
        this.f6717c = c1307i;
        this.f6715a = c1303g;
        this.f6716b = deviceStatus;
    }

    public void run() {
        this.f6715a.m9527a(this.f6716b);
    }
}
