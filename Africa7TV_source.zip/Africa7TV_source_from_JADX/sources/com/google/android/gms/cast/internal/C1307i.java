package com.google.android.gms.cast.internal;

import android.os.Handler;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.avz;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: com.google.android.gms.cast.internal.i */
class C1307i extends C1306u {
    /* renamed from: a */
    private final AtomicReference<C1303g> f6710a;
    /* renamed from: b */
    private final Handler f6711b;

    public C1307i(C1303g c1303g) {
        this.f6710a = new AtomicReference(c1303g);
        this.f6711b = new Handler(c1303g.m6737v());
    }

    /* renamed from: a */
    private void m9580a(C1303g c1303g, long j, int i) {
        synchronized (c1303g.f6702x) {
            avz avz = (avz) c1303g.f6702x.remove(Long.valueOf(j));
        }
        if (avz != null) {
            avz.mo1412a(new Status(i));
        }
    }

    /* renamed from: a */
    private boolean m9581a(C1303g c1303g, int i) {
        synchronized (C1303g.f6681C) {
            if (c1303g.f6683A != null) {
                c1303g.f6683A.mo1412a(new Status(i));
                c1303g.f6683A = null;
                return true;
            }
            return false;
        }
    }

    /* renamed from: a */
    public C1303g m9582a() {
        C1303g c1303g = (C1303g) this.f6710a.getAndSet(null);
        if (c1303g == null) {
            return null;
        }
        c1303g.m9521D();
        return c1303g;
    }

    /* renamed from: a */
    public void mo1566a(int i) {
        C1303g a = m9582a();
        if (a != null) {
            C1303g.f6682a.m9644b("ICastDeviceControllerListener.onDisconnected: %d", Integer.valueOf(i));
            if (i != 0) {
                a.m6722b(2);
            }
        }
    }

    /* renamed from: a */
    public void mo1567a(ApplicationMetadata applicationMetadata, String str, String str2, boolean z) {
        C1303g c1303g = (C1303g) this.f6710a.get();
        if (c1303g != null) {
            c1303g.f6684f = applicationMetadata;
            c1303g.f6699u = applicationMetadata.m8858b();
            c1303g.f6700v = str2;
            c1303g.f6690l = str;
            synchronized (C1303g.f6680B) {
                if (c1303g.f6704z != null) {
                    c1303g.f6704z.mo1412a(new C1304h(new Status(0), applicationMetadata, str, str2, z));
                    c1303g.f6704z = null;
                }
            }
        }
    }

    /* renamed from: a */
    public void mo1568a(ApplicationStatus applicationStatus) {
        C1303g c1303g = (C1303g) this.f6710a.get();
        if (c1303g != null) {
            C1303g.f6682a.m9644b("onApplicationStatusChanged", new Object[0]);
            this.f6711b.post(new C1310l(this, c1303g, applicationStatus));
        }
    }

    /* renamed from: a */
    public void mo1569a(DeviceStatus deviceStatus) {
        C1303g c1303g = (C1303g) this.f6710a.get();
        if (c1303g != null) {
            C1303g.f6682a.m9644b("onDeviceStatusChanged", new Object[0]);
            this.f6711b.post(new C1309k(this, c1303g, deviceStatus));
        }
    }

    /* renamed from: a */
    public void mo1570a(String str, double d, boolean z) {
        C1303g.f6682a.m9644b("Deprecated callback: \"onStatusreceived\"", new Object[0]);
    }

    /* renamed from: a */
    public void mo1571a(String str, long j) {
        C1303g c1303g = (C1303g) this.f6710a.get();
        if (c1303g != null) {
            m9580a(c1303g, j, 0);
        }
    }

    /* renamed from: a */
    public void mo1572a(String str, long j, int i) {
        C1303g c1303g = (C1303g) this.f6710a.get();
        if (c1303g != null) {
            m9580a(c1303g, j, i);
        }
    }

    /* renamed from: a */
    public void mo1573a(String str, String str2) {
        C1303g c1303g = (C1303g) this.f6710a.get();
        if (c1303g != null) {
            C1303g.f6682a.m9644b("Receive (type=text, ns=%s) %s", str, str2);
            this.f6711b.post(new C1311m(this, c1303g, str, str2));
        }
    }

    /* renamed from: a */
    public void mo1574a(String str, byte[] bArr) {
        if (((C1303g) this.f6710a.get()) != null) {
            C1303g.f6682a.m9644b("IGNORING: Receive (type=binary, ns=%s) <%d bytes>", str, Integer.valueOf(bArr.length));
        }
    }

    /* renamed from: b */
    public void mo1575b(int i) {
        C1303g c1303g = (C1303g) this.f6710a.get();
        if (c1303g != null) {
            synchronized (C1303g.f6680B) {
                if (c1303g.f6704z != null) {
                    c1303g.f6704z.mo1412a(new C1304h(new Status(i)));
                    c1303g.f6704z = null;
                }
            }
        }
    }

    /* renamed from: b */
    public boolean m9593b() {
        return this.f6710a.get() == null;
    }

    /* renamed from: c */
    public void mo1576c(int i) {
        C1303g c1303g = (C1303g) this.f6710a.get();
        if (c1303g != null) {
            m9581a(c1303g, i);
        }
    }

    /* renamed from: d */
    public void mo1577d(int i) {
        C1303g c1303g = (C1303g) this.f6710a.get();
        if (c1303g != null) {
            m9581a(c1303g, i);
        }
    }

    /* renamed from: e */
    public void mo1578e(int i) {
        C1303g c1303g = (C1303g) this.f6710a.get();
        if (c1303g != null) {
            c1303g.f6699u = null;
            c1303g.f6700v = null;
            m9581a(c1303g, i);
            if (c1303g.f6686h != null) {
                this.f6711b.post(new C1308j(this, c1303g, i));
            }
        }
    }
}
