package com.google.android.gms.cast.internal;

/* renamed from: com.google.android.gms.cast.internal.z */
public class C1320z extends Exception {
}
