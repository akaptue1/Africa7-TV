package com.google.android.gms.cast.framework;

import android.content.Context;
import android.os.IBinder;
import com.google.android.gms.common.internal.C1370c;

/* renamed from: com.google.android.gms.cast.framework.p */
public abstract class C1285p {
    /* renamed from: a */
    private final Context f6639a;
    /* renamed from: b */
    private final String f6640b;
    /* renamed from: c */
    private final C1287r f6641c = new C1287r();

    protected C1285p(Context context, String str) {
        this.f6639a = ((Context) C1370c.m10112a((Object) context)).getApplicationContext();
        this.f6640b = C1370c.m10114a(str);
    }

    /* renamed from: a */
    public final Context m9455a() {
        return this.f6639a;
    }

    /* renamed from: a */
    public abstract C1232l mo1947a(String str);

    /* renamed from: b */
    public final String m9457b() {
        return this.f6640b;
    }

    /* renamed from: c */
    public abstract boolean mo1948c();

    /* renamed from: d */
    public IBinder m9459d() {
        return this.f6641c;
    }
}
