package com.google.android.gms.cast;

import com.google.android.gms.cast.internal.C1312n;
import java.util.Collection;

/* renamed from: com.google.android.gms.cast.p */
public final class C1324p {
    /* renamed from: a */
    public static String m9679a(String str) {
        if (str != null) {
            return C1324p.m9680a("com.google.android.gms.cast.CATEGORY_CAST", str, null);
        }
        throw new IllegalArgumentException("applicationId cannot be null");
    }

    /* renamed from: a */
    private static String m9680a(String str, String str2, Collection<String> collection) {
        String toUpperCase;
        StringBuilder stringBuilder = new StringBuilder(str);
        if (str2 != null) {
            toUpperCase = str2.toUpperCase();
            if (toUpperCase.matches("[A-F0-9]+")) {
                stringBuilder.append("/").append(toUpperCase);
            } else {
                String str3 = "Invalid application ID: ";
                toUpperCase = String.valueOf(str2);
                throw new IllegalArgumentException(toUpperCase.length() != 0 ? str3.concat(toUpperCase) : new String(str3));
            }
        }
        if (collection != null) {
            if (collection.isEmpty()) {
                throw new IllegalArgumentException("Must specify at least one namespace");
            }
            if (str2 == null) {
                stringBuilder.append("/");
            }
            stringBuilder.append("/");
            Object obj = 1;
            for (String toUpperCase2 : collection) {
                C1312n.m9600a(toUpperCase2);
                if (obj != null) {
                    obj = null;
                } else {
                    stringBuilder.append(",");
                }
                stringBuilder.append(C1312n.m9604c(toUpperCase2));
            }
        }
        return stringBuilder.toString();
    }

    /* renamed from: a */
    public static String m9681a(String str, Collection<String> collection) {
        if (str == null) {
            throw new IllegalArgumentException("applicationId cannot be null");
        } else if (collection != null) {
            return C1324p.m9680a("com.google.android.gms.cast.CATEGORY_CAST", str, collection);
        } else {
            throw new IllegalArgumentException("namespaces cannot be null");
        }
    }
}
