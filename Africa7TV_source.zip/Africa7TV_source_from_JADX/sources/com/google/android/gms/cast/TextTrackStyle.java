package com.google.android.gms.cast;

import android.graphics.Color;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.cast.internal.C1312n;
import com.google.android.gms.common.internal.bp;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.util.C1424m;
import org.json.JSONException;
import org.json.JSONObject;

public final class TextTrackStyle extends AbstractSafeParcelable {
    public static final Creator<TextTrackStyle> CREATOR = new ad();
    /* renamed from: a */
    String f6431a;
    /* renamed from: b */
    private final int f6432b;
    /* renamed from: c */
    private float f6433c;
    /* renamed from: d */
    private int f6434d;
    /* renamed from: e */
    private int f6435e;
    /* renamed from: f */
    private int f6436f;
    /* renamed from: g */
    private int f6437g;
    /* renamed from: h */
    private int f6438h;
    /* renamed from: i */
    private int f6439i;
    /* renamed from: j */
    private int f6440j;
    /* renamed from: k */
    private String f6441k;
    /* renamed from: l */
    private int f6442l;
    /* renamed from: m */
    private int f6443m;
    /* renamed from: n */
    private JSONObject f6444n;

    public TextTrackStyle() {
        this(1, 1.0f, 0, 0, -1, 0, -1, 0, 0, null, -1, -1, null);
    }

    TextTrackStyle(int i, float f, int i2, int i3, int i4, int i5, int i6, int i7, int i8, String str, int i9, int i10, String str2) {
        this.f6432b = i;
        this.f6433c = f;
        this.f6434d = i2;
        this.f6435e = i3;
        this.f6436f = i4;
        this.f6437g = i5;
        this.f6438h = i6;
        this.f6439i = i7;
        this.f6440j = i8;
        this.f6441k = str;
        this.f6442l = i9;
        this.f6443m = i10;
        this.f6431a = str2;
        if (this.f6431a != null) {
            try {
                this.f6444n = new JSONObject(this.f6431a);
                return;
            } catch (JSONException e) {
                this.f6444n = null;
                this.f6431a = null;
                return;
            }
        }
        this.f6444n = null;
    }

    /* renamed from: a */
    private int m8952a(String str) {
        int i = 0;
        if (str != null && str.length() == 9 && str.charAt(i) == '#') {
            try {
                i = Color.argb(Integer.parseInt(str.substring(7, 9), 16), Integer.parseInt(str.substring(1, 3), 16), Integer.parseInt(str.substring(3, 5), 16), Integer.parseInt(str.substring(5, 7), 16));
            } catch (NumberFormatException e) {
            }
        }
        return i;
    }

    /* renamed from: a */
    private String m8953a(int i) {
        return String.format("#%02X%02X%02X%02X", new Object[]{Integer.valueOf(Color.red(i)), Integer.valueOf(Color.green(i)), Integer.valueOf(Color.blue(i)), Integer.valueOf(Color.alpha(i))});
    }

    /* renamed from: a */
    int m8954a() {
        return this.f6432b;
    }

    /* renamed from: a */
    public void m8955a(JSONObject jSONObject) {
        String string;
        this.f6433c = (float) jSONObject.optDouble("fontScale", 1.0d);
        this.f6434d = m8952a(jSONObject.optString("foregroundColor"));
        this.f6435e = m8952a(jSONObject.optString("backgroundColor"));
        if (jSONObject.has("edgeType")) {
            string = jSONObject.getString("edgeType");
            if ("NONE".equals(string)) {
                this.f6436f = 0;
            } else if ("OUTLINE".equals(string)) {
                this.f6436f = 1;
            } else if ("DROP_SHADOW".equals(string)) {
                this.f6436f = 2;
            } else if ("RAISED".equals(string)) {
                this.f6436f = 3;
            } else if ("DEPRESSED".equals(string)) {
                this.f6436f = 4;
            }
        }
        this.f6437g = m8952a(jSONObject.optString("edgeColor"));
        if (jSONObject.has("windowType")) {
            string = jSONObject.getString("windowType");
            if ("NONE".equals(string)) {
                this.f6438h = 0;
            } else if ("NORMAL".equals(string)) {
                this.f6438h = 1;
            } else if ("ROUNDED_CORNERS".equals(string)) {
                this.f6438h = 2;
            }
        }
        this.f6439i = m8952a(jSONObject.optString("windowColor"));
        if (this.f6438h == 2) {
            this.f6440j = jSONObject.optInt("windowRoundedCornerRadius", 0);
        }
        this.f6441k = jSONObject.optString("fontFamily", null);
        if (jSONObject.has("fontGenericFamily")) {
            string = jSONObject.getString("fontGenericFamily");
            if ("SANS_SERIF".equals(string)) {
                this.f6442l = 0;
            } else if ("MONOSPACED_SANS_SERIF".equals(string)) {
                this.f6442l = 1;
            } else if ("SERIF".equals(string)) {
                this.f6442l = 2;
            } else if ("MONOSPACED_SERIF".equals(string)) {
                this.f6442l = 3;
            } else if ("CASUAL".equals(string)) {
                this.f6442l = 4;
            } else if ("CURSIVE".equals(string)) {
                this.f6442l = 5;
            } else if ("SMALL_CAPITALS".equals(string)) {
                this.f6442l = 6;
            }
        }
        if (jSONObject.has("fontStyle")) {
            string = jSONObject.getString("fontStyle");
            if ("NORMAL".equals(string)) {
                this.f6443m = 0;
            } else if ("BOLD".equals(string)) {
                this.f6443m = 1;
            } else if ("ITALIC".equals(string)) {
                this.f6443m = 2;
            } else if ("BOLD_ITALIC".equals(string)) {
                this.f6443m = 3;
            }
        }
        this.f6444n = jSONObject.optJSONObject("customData");
    }

    /* renamed from: b */
    public float m8956b() {
        return this.f6433c;
    }

    /* renamed from: c */
    public int m8957c() {
        return this.f6434d;
    }

    /* renamed from: d */
    public int m8958d() {
        return this.f6435e;
    }

    /* renamed from: e */
    public int m8959e() {
        return this.f6436f;
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TextTrackStyle)) {
            return false;
        }
        TextTrackStyle textTrackStyle = (TextTrackStyle) obj;
        if ((this.f6444n == null) != (textTrackStyle.f6444n == null)) {
            return false;
        }
        if (this.f6444n != null && textTrackStyle.f6444n != null && !C1424m.m10351a(this.f6444n, textTrackStyle.f6444n)) {
            return false;
        }
        if (!(this.f6433c == textTrackStyle.f6433c && this.f6434d == textTrackStyle.f6434d && this.f6435e == textTrackStyle.f6435e && this.f6436f == textTrackStyle.f6436f && this.f6437g == textTrackStyle.f6437g && this.f6438h == textTrackStyle.f6438h && this.f6440j == textTrackStyle.f6440j && C1312n.m9602a(this.f6441k, textTrackStyle.f6441k) && this.f6442l == textTrackStyle.f6442l && this.f6443m == textTrackStyle.f6443m)) {
            z = false;
        }
        return z;
    }

    /* renamed from: f */
    public int m8960f() {
        return this.f6437g;
    }

    /* renamed from: g */
    public int m8961g() {
        return this.f6438h;
    }

    /* renamed from: h */
    public int m8962h() {
        return this.f6439i;
    }

    public int hashCode() {
        return bp.m10107a(Float.valueOf(this.f6433c), Integer.valueOf(this.f6434d), Integer.valueOf(this.f6435e), Integer.valueOf(this.f6436f), Integer.valueOf(this.f6437g), Integer.valueOf(this.f6438h), Integer.valueOf(this.f6439i), Integer.valueOf(this.f6440j), this.f6441k, Integer.valueOf(this.f6442l), Integer.valueOf(this.f6443m), this.f6444n);
    }

    /* renamed from: i */
    public int m8963i() {
        return this.f6440j;
    }

    /* renamed from: j */
    public String m8964j() {
        return this.f6441k;
    }

    /* renamed from: k */
    public int m8965k() {
        return this.f6442l;
    }

    /* renamed from: l */
    public int m8966l() {
        return this.f6443m;
    }

    /* renamed from: m */
    public JSONObject m8967m() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("fontScale", (double) this.f6433c);
            if (this.f6434d != 0) {
                jSONObject.put("foregroundColor", m8953a(this.f6434d));
            }
            if (this.f6435e != 0) {
                jSONObject.put("backgroundColor", m8953a(this.f6435e));
            }
            switch (this.f6436f) {
                case 0:
                    jSONObject.put("edgeType", "NONE");
                    break;
                case 1:
                    jSONObject.put("edgeType", "OUTLINE");
                    break;
                case 2:
                    jSONObject.put("edgeType", "DROP_SHADOW");
                    break;
                case 3:
                    jSONObject.put("edgeType", "RAISED");
                    break;
                case 4:
                    jSONObject.put("edgeType", "DEPRESSED");
                    break;
            }
            if (this.f6437g != 0) {
                jSONObject.put("edgeColor", m8953a(this.f6437g));
            }
            switch (this.f6438h) {
                case 0:
                    jSONObject.put("windowType", "NONE");
                    break;
                case 1:
                    jSONObject.put("windowType", "NORMAL");
                    break;
                case 2:
                    jSONObject.put("windowType", "ROUNDED_CORNERS");
                    break;
            }
            if (this.f6439i != 0) {
                jSONObject.put("windowColor", m8953a(this.f6439i));
            }
            if (this.f6438h == 2) {
                jSONObject.put("windowRoundedCornerRadius", this.f6440j);
            }
            if (this.f6441k != null) {
                jSONObject.put("fontFamily", this.f6441k);
            }
            switch (this.f6442l) {
                case 0:
                    jSONObject.put("fontGenericFamily", "SANS_SERIF");
                    break;
                case 1:
                    jSONObject.put("fontGenericFamily", "MONOSPACED_SANS_SERIF");
                    break;
                case 2:
                    jSONObject.put("fontGenericFamily", "SERIF");
                    break;
                case 3:
                    jSONObject.put("fontGenericFamily", "MONOSPACED_SERIF");
                    break;
                case 4:
                    jSONObject.put("fontGenericFamily", "CASUAL");
                    break;
                case 5:
                    jSONObject.put("fontGenericFamily", "CURSIVE");
                    break;
                case 6:
                    jSONObject.put("fontGenericFamily", "SMALL_CAPITALS");
                    break;
            }
            switch (this.f6443m) {
                case 0:
                    jSONObject.put("fontStyle", "NORMAL");
                    break;
                case 1:
                    jSONObject.put("fontStyle", "BOLD");
                    break;
                case 2:
                    jSONObject.put("fontStyle", "ITALIC");
                    break;
                case 3:
                    jSONObject.put("fontStyle", "BOLD_ITALIC");
                    break;
            }
            if (this.f6444n != null) {
                jSONObject.put("customData", this.f6444n);
            }
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i) {
        this.f6431a = this.f6444n == null ? null : this.f6444n.toString();
        ad.m8977a(this, parcel, i);
    }
}
