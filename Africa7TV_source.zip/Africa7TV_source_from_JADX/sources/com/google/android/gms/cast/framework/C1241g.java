package com.google.android.gms.cast.framework;

import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.cast.C1240l;
import java.util.HashSet;

/* renamed from: com.google.android.gms.cast.framework.g */
class C1241g extends C1240l {
    /* renamed from: a */
    final /* synthetic */ C1233c f6499a;

    private C1241g(C1233c c1233c) {
        this.f6499a = c1233c;
    }

    /* renamed from: a */
    public void mo1518a() {
        for (C1240l a : new HashSet(this.f6499a.f6487c)) {
            a.mo1518a();
        }
    }

    /* renamed from: a */
    public void mo1519a(int i) {
        this.f6499a.m9201d(i);
        this.f6499a.m9185b(i);
        for (C1240l a : new HashSet(this.f6499a.f6487c)) {
            a.mo1519a(i);
        }
    }

    /* renamed from: a */
    public void mo1520a(ApplicationMetadata applicationMetadata) {
        for (C1240l a : new HashSet(this.f6499a.f6487c)) {
            a.mo1520a(applicationMetadata);
        }
    }

    /* renamed from: b */
    public void mo1521b() {
        for (C1240l b : new HashSet(this.f6499a.f6487c)) {
            b.mo1521b();
        }
    }

    /* renamed from: b */
    public void mo1522b(int i) {
        for (C1240l b : new HashSet(this.f6499a.f6487c)) {
            b.mo1522b(i);
        }
    }

    /* renamed from: c */
    public void mo1523c(int i) {
        for (C1240l c : new HashSet(this.f6499a.f6487c)) {
            c.mo1523c(i);
        }
    }
}
