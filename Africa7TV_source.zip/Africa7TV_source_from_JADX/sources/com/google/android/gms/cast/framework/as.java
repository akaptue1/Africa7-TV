package com.google.android.gms.cast.framework;

import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface as extends IInterface {
    /* renamed from: a */
    C0827c mo1468a();

    /* renamed from: a */
    void mo1469a(int i);

    /* renamed from: a */
    void mo1470a(String str);

    /* renamed from: a */
    void mo1471a(boolean z);

    /* renamed from: b */
    String mo1472b();

    /* renamed from: b */
    void mo1473b(int i);

    /* renamed from: c */
    String mo1474c();

    /* renamed from: c */
    void mo1475c(int i);

    /* renamed from: d */
    String mo1476d();

    /* renamed from: d */
    void mo1477d(int i);

    /* renamed from: e */
    boolean mo1478e();

    /* renamed from: f */
    boolean mo1479f();

    /* renamed from: g */
    boolean mo1480g();

    /* renamed from: h */
    boolean mo1481h();

    /* renamed from: i */
    boolean mo1482i();

    /* renamed from: j */
    boolean mo1483j();
}
