package com.google.android.gms.cast.internal;

import com.google.android.gms.cast.C1221a;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.avy;

/* renamed from: com.google.android.gms.cast.internal.b */
public abstract class C1227b<R extends C1223y> extends avy<R, C1303g> {
    public C1227b(C1352q c1352q) {
        super(C1221a.f6446b, c1352q);
    }

    /* renamed from: a */
    public void m9000a(int i) {
        m8763b(mo1416b(new Status(i)));
    }

    /* renamed from: a */
    public void m9001a(int i, String str) {
        m8763b(mo1416b(new Status(i, str, null)));
    }
}
