package com.google.android.gms.cast.framework;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.cast.LaunchOptions;
import com.google.android.gms.cast.framework.media.CastMediaOptions;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CastOptions extends AbstractSafeParcelable {
    public static final Creator<CastOptions> CREATOR = new C1288s();
    /* renamed from: a */
    private final int f6451a;
    /* renamed from: b */
    private final String f6452b;
    /* renamed from: c */
    private final List<String> f6453c;
    /* renamed from: d */
    private final boolean f6454d;
    /* renamed from: e */
    private final LaunchOptions f6455e;
    /* renamed from: f */
    private final boolean f6456f;
    /* renamed from: g */
    private final CastMediaOptions f6457g;
    /* renamed from: h */
    private final boolean f6458h;
    /* renamed from: i */
    private final double f6459i;

    CastOptions(int i, String str, List<String> list, boolean z, LaunchOptions launchOptions, boolean z2, CastMediaOptions castMediaOptions, boolean z3, double d) {
        this.f6451a = i;
        if (TextUtils.isEmpty(str)) {
            str = "";
        }
        this.f6452b = str;
        int size = list == null ? 0 : list.size();
        this.f6453c = new ArrayList(size);
        if (size > 0) {
            this.f6453c.addAll(list);
        }
        this.f6454d = z;
        if (launchOptions == null) {
            launchOptions = new LaunchOptions();
        }
        this.f6455e = launchOptions;
        this.f6456f = z2;
        this.f6457g = castMediaOptions;
        this.f6458h = z3;
        this.f6459i = d;
    }

    /* renamed from: a */
    int m9008a() {
        return this.f6451a;
    }

    /* renamed from: b */
    public String m9009b() {
        return this.f6452b;
    }

    /* renamed from: c */
    public List<String> m9010c() {
        return Collections.unmodifiableList(this.f6453c);
    }

    /* renamed from: d */
    public boolean m9011d() {
        return this.f6454d;
    }

    /* renamed from: e */
    public LaunchOptions m9012e() {
        return this.f6455e;
    }

    /* renamed from: f */
    public boolean m9013f() {
        return this.f6456f;
    }

    /* renamed from: g */
    public CastMediaOptions m9014g() {
        return this.f6457g;
    }

    /* renamed from: h */
    public boolean m9015h() {
        return this.f6458h;
    }

    /* renamed from: i */
    public double m9016i() {
        return this.f6459i;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1288s.m9463a(this, parcel, i);
    }
}
