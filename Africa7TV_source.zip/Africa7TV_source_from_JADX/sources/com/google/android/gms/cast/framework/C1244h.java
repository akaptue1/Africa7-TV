package com.google.android.gms.cast.framework;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C1242s;
import com.google.android.gms.common.api.C1243t;

/* renamed from: com.google.android.gms.cast.framework.h */
class C1244h implements C1242s, C1243t {
    /* renamed from: a */
    final /* synthetic */ C1233c f6500a;

    private C1244h(C1233c c1233c) {
        this.f6500a = c1233c;
    }

    /* renamed from: a */
    public void mo1524a(int i) {
        try {
            this.f6500a.f6488d.mo1446a(i);
        } catch (Throwable e) {
            C1233c.f6485a.m9642a(e, "Unable to call %s on %s.", "onConnectionSuspended", ad.class.getSimpleName());
        }
    }

    /* renamed from: a */
    public void mo1525a(Bundle bundle) {
        try {
            this.f6500a.f6488d.mo1447a(bundle);
        } catch (Throwable e) {
            C1233c.f6485a.m9642a(e, "Unable to call %s on %s.", "onConnected", ad.class.getSimpleName());
        }
    }

    /* renamed from: a */
    public void mo1526a(ConnectionResult connectionResult) {
        try {
            this.f6500a.f6488d.mo1449a(connectionResult);
        } catch (Throwable e) {
            C1233c.f6485a.m9642a(e, "Unable to call %s on %s.", "onConnectionFailed", ad.class.getSimpleName());
        }
    }
}
