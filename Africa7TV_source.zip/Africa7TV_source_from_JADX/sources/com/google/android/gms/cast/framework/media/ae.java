package com.google.android.gms.cast.framework.media;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;
import java.util.List;

public class ae implements Creator<NotificationOptions> {
    /* renamed from: a */
    static void m9336a(NotificationOptions notificationOptions, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, notificationOptions.m9296a());
        C1386c.m10219b(parcel, 2, notificationOptions.m9297b(), false);
        C1386c.m10211a(parcel, 3, notificationOptions.m9298c(), false);
        C1386c.m10199a(parcel, 4, notificationOptions.m9299d());
        C1386c.m10207a(parcel, 5, notificationOptions.m9300e(), false);
        C1386c.m10198a(parcel, 6, notificationOptions.m9301f());
        C1386c.m10198a(parcel, 7, notificationOptions.m9302g());
        C1386c.m10198a(parcel, 8, notificationOptions.m9303h());
        C1386c.m10198a(parcel, 9, notificationOptions.m9304i());
        C1386c.m10198a(parcel, 10, notificationOptions.m9305j());
        C1386c.m10198a(parcel, 11, notificationOptions.m9306k());
        C1386c.m10198a(parcel, 12, notificationOptions.m9307l());
        C1386c.m10198a(parcel, 13, notificationOptions.m9308m());
        C1386c.m10198a(parcel, 14, notificationOptions.m9309n());
        C1386c.m10198a(parcel, 15, notificationOptions.m9310o());
        C1386c.m10198a(parcel, 16, notificationOptions.m9311p());
        C1386c.m10198a(parcel, 17, notificationOptions.m9312q());
        C1386c.m10198a(parcel, 18, notificationOptions.m9313r());
        C1386c.m10198a(parcel, 19, notificationOptions.m9314s());
        C1386c.m10198a(parcel, 20, notificationOptions.m9315t());
        C1386c.m10198a(parcel, 21, notificationOptions.m9316u());
        C1386c.m10198a(parcel, 22, notificationOptions.m9317v());
        C1386c.m10198a(parcel, 23, notificationOptions.m9318w());
        C1386c.m10198a(parcel, 24, notificationOptions.m9319x());
        C1386c.m10198a(parcel, 25, notificationOptions.m9320y());
        C1386c.m10198a(parcel, 26, notificationOptions.m9321z());
        C1386c.m10198a(parcel, 27, notificationOptions.m9290A());
        C1386c.m10198a(parcel, 28, notificationOptions.m9291B());
        C1386c.m10198a(parcel, 29, notificationOptions.m9292C());
        C1386c.m10198a(parcel, 30, notificationOptions.m9293D());
        C1386c.m10198a(parcel, 31, notificationOptions.m9294E());
        C1386c.m10198a(parcel, 32, notificationOptions.m9295F());
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public NotificationOptions m9337a(Parcel parcel) {
        int b = C1384a.m10169b(parcel);
        int i = 0;
        List list = null;
        int[] iArr = null;
        long j = 0;
        String str = null;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        int i10 = 0;
        int i11 = 0;
        int i12 = 0;
        int i13 = 0;
        int i14 = 0;
        int i15 = 0;
        int i16 = 0;
        int i17 = 0;
        int i18 = 0;
        int i19 = 0;
        int i20 = 0;
        int i21 = 0;
        int i22 = 0;
        int i23 = 0;
        int i24 = 0;
        int i25 = 0;
        int i26 = 0;
        int i27 = 0;
        int i28 = 0;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    list = C1384a.m10192v(parcel, a);
                    break;
                case 3:
                    iArr = C1384a.m10188r(parcel, a);
                    break;
                case 4:
                    j = C1384a.m10177g(parcel, a);
                    break;
                case 5:
                    str = C1384a.m10183m(parcel, a);
                    break;
                case 6:
                    i2 = C1384a.m10175e(parcel, a);
                    break;
                case 7:
                    i3 = C1384a.m10175e(parcel, a);
                    break;
                case 8:
                    i4 = C1384a.m10175e(parcel, a);
                    break;
                case 9:
                    i5 = C1384a.m10175e(parcel, a);
                    break;
                case 10:
                    i6 = C1384a.m10175e(parcel, a);
                    break;
                case 11:
                    i7 = C1384a.m10175e(parcel, a);
                    break;
                case 12:
                    i8 = C1384a.m10175e(parcel, a);
                    break;
                case 13:
                    i9 = C1384a.m10175e(parcel, a);
                    break;
                case 14:
                    i10 = C1384a.m10175e(parcel, a);
                    break;
                case 15:
                    i11 = C1384a.m10175e(parcel, a);
                    break;
                case 16:
                    i12 = C1384a.m10175e(parcel, a);
                    break;
                case 17:
                    i13 = C1384a.m10175e(parcel, a);
                    break;
                case 18:
                    i14 = C1384a.m10175e(parcel, a);
                    break;
                case 19:
                    i15 = C1384a.m10175e(parcel, a);
                    break;
                case 20:
                    i16 = C1384a.m10175e(parcel, a);
                    break;
                case 21:
                    i17 = C1384a.m10175e(parcel, a);
                    break;
                case 22:
                    i18 = C1384a.m10175e(parcel, a);
                    break;
                case 23:
                    i19 = C1384a.m10175e(parcel, a);
                    break;
                case 24:
                    i20 = C1384a.m10175e(parcel, a);
                    break;
                case 25:
                    i21 = C1384a.m10175e(parcel, a);
                    break;
                case 26:
                    i22 = C1384a.m10175e(parcel, a);
                    break;
                case 27:
                    i23 = C1384a.m10175e(parcel, a);
                    break;
                case 28:
                    i24 = C1384a.m10175e(parcel, a);
                    break;
                case 29:
                    i25 = C1384a.m10175e(parcel, a);
                    break;
                case 30:
                    i26 = C1384a.m10175e(parcel, a);
                    break;
                case 31:
                    i27 = C1384a.m10175e(parcel, a);
                    break;
                case 32:
                    i28 = C1384a.m10175e(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new NotificationOptions(i, list, iArr, j, str, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12, i13, i14, i15, i16, i17, i18, i19, i20, i21, i22, i23, i24, i25, i26, i27, i28);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public NotificationOptions[] m9338a(int i) {
        return new NotificationOptions[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9337a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9338a(i);
    }
}
