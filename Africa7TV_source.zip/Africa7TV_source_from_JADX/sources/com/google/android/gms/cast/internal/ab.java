package com.google.android.gms.cast.internal;

public interface ab {
    /* renamed from: a */
    void mo1544a(long j);

    /* renamed from: a */
    void mo1545a(long j, int i, Object obj);
}
