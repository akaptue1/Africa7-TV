package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.cast.internal.C1312n;
import com.google.android.gms.common.internal.bp;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.util.C1424m;
import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaQueueItem extends AbstractSafeParcelable {
    public static final Creator<MediaQueueItem> CREATOR = new aa();
    /* renamed from: a */
    String f6391a;
    /* renamed from: b */
    private final int f6392b;
    /* renamed from: c */
    private MediaInfo f6393c;
    /* renamed from: d */
    private int f6394d;
    /* renamed from: e */
    private boolean f6395e;
    /* renamed from: f */
    private double f6396f;
    /* renamed from: g */
    private double f6397g;
    /* renamed from: h */
    private double f6398h;
    /* renamed from: i */
    private long[] f6399i;
    /* renamed from: j */
    private JSONObject f6400j;

    MediaQueueItem(int i, MediaInfo mediaInfo, int i2, boolean z, double d, double d2, double d3, long[] jArr, String str) {
        this.f6392b = i;
        this.f6393c = mediaInfo;
        this.f6394d = i2;
        this.f6395e = z;
        this.f6396f = d;
        this.f6397g = d2;
        this.f6398h = d3;
        this.f6399i = jArr;
        this.f6391a = str;
        if (this.f6391a != null) {
            try {
                this.f6400j = new JSONObject(this.f6391a);
                return;
            } catch (JSONException e) {
                this.f6400j = null;
                this.f6391a = null;
                return;
            }
        }
        this.f6400j = null;
    }

    private MediaQueueItem(MediaInfo mediaInfo) {
        this(1, mediaInfo, 0, true, 0.0d, Double.POSITIVE_INFINITY, 0.0d, null, null);
        if (mediaInfo == null) {
            throw new IllegalArgumentException("media cannot be null.");
        }
    }

    MediaQueueItem(JSONObject jSONObject) {
        this(1, null, 0, true, 0.0d, Double.POSITIVE_INFINITY, 0.0d, null, null);
        m8906a(jSONObject);
    }

    /* renamed from: a */
    int m8905a() {
        return this.f6392b;
    }

    /* renamed from: a */
    public boolean m8906a(JSONObject jSONObject) {
        boolean z;
        boolean z2;
        double d;
        long[] jArr;
        if (jSONObject.has("media")) {
            this.f6393c = new MediaInfo(jSONObject.getJSONObject("media"));
            z = true;
        } else {
            z = false;
        }
        if (jSONObject.has("itemId")) {
            int i = jSONObject.getInt("itemId");
            if (this.f6394d != i) {
                this.f6394d = i;
                z = true;
            }
        }
        if (jSONObject.has("autoplay")) {
            z2 = jSONObject.getBoolean("autoplay");
            if (this.f6395e != z2) {
                this.f6395e = z2;
                z = true;
            }
        }
        if (jSONObject.has("startTime")) {
            d = jSONObject.getDouble("startTime");
            if (Math.abs(d - this.f6396f) > 1.0E-7d) {
                this.f6396f = d;
                z = true;
            }
        }
        if (jSONObject.has("playbackDuration")) {
            d = jSONObject.getDouble("playbackDuration");
            if (Math.abs(d - this.f6397g) > 1.0E-7d) {
                this.f6397g = d;
                z = true;
            }
        }
        if (jSONObject.has("preloadTime")) {
            d = jSONObject.getDouble("preloadTime");
            if (Math.abs(d - this.f6398h) > 1.0E-7d) {
                this.f6398h = d;
                z = true;
            }
        }
        if (jSONObject.has("activeTrackIds")) {
            int i2;
            JSONArray jSONArray = jSONObject.getJSONArray("activeTrackIds");
            int length = jSONArray.length();
            long[] jArr2 = new long[length];
            for (i2 = 0; i2 < length; i2++) {
                jArr2[i2] = jSONArray.getLong(i2);
            }
            if (this.f6399i == null) {
                jArr = jArr2;
                z2 = true;
            } else if (this.f6399i.length != length) {
                jArr = jArr2;
                z2 = true;
            } else {
                for (i2 = 0; i2 < length; i2++) {
                    if (this.f6399i[i2] != jArr2[i2]) {
                        jArr = jArr2;
                        z2 = true;
                        break;
                    }
                }
                long[] jArr3 = jArr2;
                z2 = false;
                jArr = jArr3;
            }
        } else {
            z2 = false;
            jArr = null;
        }
        if (z2) {
            this.f6399i = jArr;
            z = true;
        }
        if (!jSONObject.has("customData")) {
            return z;
        }
        this.f6400j = jSONObject.getJSONObject("customData");
        return true;
    }

    /* renamed from: b */
    public MediaInfo m8907b() {
        return this.f6393c;
    }

    /* renamed from: c */
    public int m8908c() {
        return this.f6394d;
    }

    /* renamed from: d */
    public boolean m8909d() {
        return this.f6395e;
    }

    /* renamed from: e */
    public double m8910e() {
        return this.f6396f;
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaQueueItem)) {
            return false;
        }
        MediaQueueItem mediaQueueItem = (MediaQueueItem) obj;
        if ((this.f6400j == null) != (mediaQueueItem.f6400j == null)) {
            return false;
        }
        if (this.f6400j != null && mediaQueueItem.f6400j != null && !C1424m.m10351a(this.f6400j, mediaQueueItem.f6400j)) {
            return false;
        }
        if (!(C1312n.m9602a(this.f6393c, mediaQueueItem.f6393c) && this.f6394d == mediaQueueItem.f6394d && this.f6395e == mediaQueueItem.f6395e && this.f6396f == mediaQueueItem.f6396f && this.f6397g == mediaQueueItem.f6397g && this.f6398h == mediaQueueItem.f6398h && Arrays.equals(this.f6399i, mediaQueueItem.f6399i))) {
            z = false;
        }
        return z;
    }

    /* renamed from: f */
    public double m8911f() {
        return this.f6397g;
    }

    /* renamed from: g */
    public double m8912g() {
        return this.f6398h;
    }

    /* renamed from: h */
    public long[] m8913h() {
        return this.f6399i;
    }

    public int hashCode() {
        return bp.m10107a(this.f6393c, Integer.valueOf(this.f6394d), Boolean.valueOf(this.f6395e), Double.valueOf(this.f6396f), Double.valueOf(this.f6397g), Double.valueOf(this.f6398h), Integer.valueOf(Arrays.hashCode(this.f6399i)), String.valueOf(this.f6400j));
    }

    /* renamed from: i */
    void m8914i() {
        if (this.f6393c == null) {
            throw new IllegalArgumentException("media cannot be null.");
        } else if (Double.isNaN(this.f6396f) || this.f6396f < 0.0d) {
            throw new IllegalArgumentException("startTime cannot be negative or NaN.");
        } else if (Double.isNaN(this.f6397g)) {
            throw new IllegalArgumentException("playbackDuration cannot be NaN.");
        } else if (Double.isNaN(this.f6398h) || this.f6398h < 0.0d) {
            throw new IllegalArgumentException("preloadTime cannot be negative or Nan.");
        }
    }

    /* renamed from: j */
    public JSONObject m8915j() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("media", this.f6393c.m8892j());
            if (this.f6394d != 0) {
                jSONObject.put("itemId", this.f6394d);
            }
            jSONObject.put("autoplay", this.f6395e);
            jSONObject.put("startTime", this.f6396f);
            if (this.f6397g != Double.POSITIVE_INFINITY) {
                jSONObject.put("playbackDuration", this.f6397g);
            }
            jSONObject.put("preloadTime", this.f6398h);
            if (this.f6399i != null) {
                JSONArray jSONArray = new JSONArray();
                for (long put : this.f6399i) {
                    jSONArray.put(put);
                }
                jSONObject.put("activeTrackIds", jSONArray);
            }
            if (this.f6400j != null) {
                jSONObject.put("customData", this.f6400j);
            }
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i) {
        this.f6391a = this.f6400j == null ? null : this.f6400j.toString();
        aa.m8968a(this, parcel, i);
    }
}
