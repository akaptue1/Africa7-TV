package com.google.android.gms.cast.internal;

/* renamed from: com.google.android.gms.cast.internal.y */
public interface C1262y {
    /* renamed from: a */
    void mo1537a();

    /* renamed from: b */
    void mo1538b();

    /* renamed from: c */
    void mo1539c();

    /* renamed from: d */
    void mo1540d();
}
