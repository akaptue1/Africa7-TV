package com.google.android.gms.cast.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;

/* renamed from: com.google.android.gms.cast.internal.a */
public class C1298a implements Creator<ApplicationStatus> {
    /* renamed from: a */
    static void m9499a(ApplicationStatus applicationStatus, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, applicationStatus.m9491a());
        C1386c.m10207a(parcel, 2, applicationStatus.m9492b(), false);
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public ApplicationStatus m9500a(Parcel parcel) {
        int b = C1384a.m10169b(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    str = C1384a.m10183m(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ApplicationStatus(i, str);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public ApplicationStatus[] m9501a(int i) {
        return new ApplicationStatus[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9500a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9501a(i);
    }
}
