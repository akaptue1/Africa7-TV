package com.google.android.gms.cast.framework;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.cast.C1224c;
import com.google.android.gms.cast.C1225d;
import com.google.android.gms.cast.C1240l;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.cast.framework.media.C1261d;
import com.google.android.gms.cast.internal.C1318w;
import com.google.android.gms.common.api.C1242s;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.internal.atq;
import com.google.android.gms.internal.ats;
import com.google.android.gms.internal.aus;
import java.util.HashSet;
import java.util.Set;

/* renamed from: com.google.android.gms.cast.framework.c */
public class C1233c extends C1232l {
    /* renamed from: a */
    private static final C1318w f6485a = new C1318w("CastSession");
    /* renamed from: b */
    private final Context f6486b;
    /* renamed from: c */
    private final Set<C1240l> f6487c = new HashSet();
    /* renamed from: d */
    private final ad f6488d;
    /* renamed from: e */
    private final C1225d f6489e;
    /* renamed from: f */
    private final ats f6490f;
    /* renamed from: g */
    private final aus f6491g;
    /* renamed from: h */
    private C1352q f6492h;
    /* renamed from: i */
    private C1261d f6493i;
    /* renamed from: j */
    private CastDevice f6494j;
    /* renamed from: k */
    private C1224c f6495k;

    public C1233c(Context context, String str, String str2, CastOptions castOptions, C1225d c1225d, ats ats, aus aus) {
        super(context, str, str2);
        this.f6486b = context.getApplicationContext();
        this.f6489e = c1225d;
        this.f6490f = ats;
        this.f6491g = aus;
        this.f6488d = atq.m12324a(context, castOptions, m9191g(), new C1239f());
    }

    /* renamed from: c */
    private void m9198c(Bundle bundle) {
        this.f6494j = CastDevice.m8865b(bundle);
        if (this.f6494j != null) {
            if (this.f6492h != null) {
                this.f6492h.mo2025g();
                this.f6492h = null;
            }
            f6485a.m9644b("Acquiring a connection to Google Play Services for %s", this.f6494j);
            C1242s c1244h = new C1244h();
            this.f6492h = this.f6490f.m12333a(this.f6486b, this.f6494j, new C1241g(), c1244h, c1244h);
            this.f6492h.mo2023e();
        } else if (m9190f()) {
            m9188c(8);
        } else {
            m9182a(8);
        }
    }

    /* renamed from: d */
    private void m9201d(int i) {
        this.f6491g.m12437a(i);
        if (this.f6492h != null) {
            this.f6492h.mo2025g();
            this.f6492h = null;
        }
        this.f6494j = null;
        if (this.f6493i != null) {
            try {
                this.f6493i.m9366a(null);
            } catch (Throwable e) {
                f6485a.m9645b(e, "Exception when setting GoogleApiClient.", new Object[0]);
            }
            this.f6493i = null;
        }
        this.f6495k = null;
    }

    /* renamed from: a */
    public C1261d m9204a() {
        return this.f6493i;
    }

    /* renamed from: a */
    protected void mo1508a(Bundle bundle) {
        m9198c(bundle);
    }

    /* renamed from: a */
    protected void mo1509a(boolean z) {
        try {
            this.f6488d.mo1450a(z, 0);
        } catch (Throwable e) {
            f6485a.m9642a(e, "Unable to call %s on %s.", "disconnectFromDevice", ad.class.getSimpleName());
        }
        m9185b(0);
    }

    /* renamed from: b */
    public CastDevice m9207b() {
        return this.f6494j;
    }

    /* renamed from: b */
    protected void mo1510b(Bundle bundle) {
        m9198c(bundle);
    }

    /* renamed from: c */
    public long mo1511c() {
        return this.f6493i == null ? 0 : this.f6493i.m9374e() - this.f6493i.m9372d();
    }
}
