package com.google.android.gms.cast;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.cast.internal.C1312n;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.bp;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ApplicationMetadata extends AbstractSafeParcelable {
    public static final Creator<ApplicationMetadata> CREATOR = new C1329u();
    /* renamed from: a */
    String f6350a;
    /* renamed from: b */
    String f6351b;
    /* renamed from: c */
    List<WebImage> f6352c;
    /* renamed from: d */
    List<String> f6353d;
    /* renamed from: e */
    String f6354e;
    /* renamed from: f */
    Uri f6355f;
    /* renamed from: g */
    private final int f6356g;

    private ApplicationMetadata() {
        this.f6356g = 1;
        this.f6352c = new ArrayList();
        this.f6353d = new ArrayList();
    }

    ApplicationMetadata(int i, String str, String str2, List<WebImage> list, List<String> list2, String str3, Uri uri) {
        this.f6356g = i;
        this.f6350a = str;
        this.f6351b = str2;
        this.f6352c = list;
        this.f6353d = list2;
        this.f6354e = str3;
        this.f6355f = uri;
    }

    /* renamed from: a */
    int m8857a() {
        return this.f6356g;
    }

    /* renamed from: b */
    public String m8858b() {
        return this.f6350a;
    }

    /* renamed from: c */
    public String m8859c() {
        return this.f6351b;
    }

    /* renamed from: d */
    public List<String> m8860d() {
        return Collections.unmodifiableList(this.f6353d);
    }

    /* renamed from: e */
    public String m8861e() {
        return this.f6354e;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ApplicationMetadata)) {
            return false;
        }
        ApplicationMetadata applicationMetadata = (ApplicationMetadata) obj;
        return C1312n.m9602a(this.f6350a, applicationMetadata.f6350a) && C1312n.m9602a(this.f6352c, applicationMetadata.f6352c) && C1312n.m9602a(this.f6351b, applicationMetadata.f6351b) && C1312n.m9602a(this.f6353d, applicationMetadata.f6353d) && C1312n.m9602a(this.f6354e, applicationMetadata.f6354e) && C1312n.m9602a(this.f6355f, applicationMetadata.f6355f);
    }

    /* renamed from: f */
    public Uri m8862f() {
        return this.f6355f;
    }

    /* renamed from: g */
    public List<WebImage> m8863g() {
        return this.f6352c;
    }

    public int hashCode() {
        return bp.m10107a(Integer.valueOf(this.f6356g), this.f6350a, this.f6351b, this.f6352c, this.f6353d, this.f6354e, this.f6355f);
    }

    public String toString() {
        int i = 0;
        StringBuilder append = new StringBuilder().append("applicationId: ").append(this.f6350a).append(", name: ").append(this.f6351b).append(", images.count: ").append(this.f6352c == null ? 0 : this.f6352c.size()).append(", namespaces.count: ");
        if (this.f6353d != null) {
            i = this.f6353d.size();
        }
        return append.append(i).append(", senderAppIdentifier: ").append(this.f6354e).append(", senderAppLaunchUrl: ").append(this.f6355f).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1329u.m9690a(this, parcel, i);
    }
}
