package com.google.android.gms.cast.framework.media;

import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.cast.internal.C1262y;
import java.util.List;

/* renamed from: com.google.android.gms.cast.framework.media.e */
class C1263e implements C1262y {
    /* renamed from: a */
    final /* synthetic */ C1261d f6605a;

    C1263e(C1261d c1261d) {
        this.f6605a = c1261d;
    }

    /* renamed from: e */
    private void m9393e() {
        if (this.f6605a.f6604k != null) {
            MediaStatus f = this.f6605a.m9375f();
            if (f != null) {
                f.m8923a(this.f6605a.f6604k.m9419a(f));
                List b = this.f6605a.f6604k.m9420b(f);
                MediaInfo g = this.f6605a.m9376g();
                if (g != null) {
                    g.m8883a(b);
                }
            }
        }
    }

    /* renamed from: a */
    public void mo1537a() {
        m9393e();
        this.f6605a.m9359u();
        for (C1271l a : this.f6605a.f6601h) {
            a.mo1977a();
        }
    }

    /* renamed from: b */
    public void mo1538b() {
        m9393e();
        for (C1271l b : this.f6605a.f6601h) {
            b.mo1978b();
        }
    }

    /* renamed from: c */
    public void mo1539c() {
        for (C1271l c : this.f6605a.f6601h) {
            c.mo1979c();
        }
    }

    /* renamed from: d */
    public void mo1540d() {
        for (C1271l d : this.f6605a.f6601h) {
            d.mo1980d();
        }
    }
}
