package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class AdBreakInfo extends AbstractSafeParcelable {
    public static final Creator<AdBreakInfo> CREATOR = new C1328t();
    /* renamed from: a */
    private final int f6348a;
    /* renamed from: b */
    private final long f6349b;

    AdBreakInfo(int i, long j) {
        this.f6348a = i;
        this.f6349b = j;
    }

    /* renamed from: a */
    int m8855a() {
        return this.f6348a;
    }

    /* renamed from: b */
    public long m8856b() {
        return this.f6349b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1328t.m9687a(this, parcel, i);
    }
}
