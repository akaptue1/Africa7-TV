package com.google.android.gms.cast.framework.media;

import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.cast.framework.media.t */
class C1278t implements C1272m {
    /* renamed from: a */
    final /* synthetic */ Status f6626a;
    /* renamed from: b */
    final /* synthetic */ C1264r f6627b;

    C1278t(C1264r c1264r, Status status) {
        this.f6627b = c1264r;
        this.f6626a = status;
    }

    /* renamed from: e */
    public Status mo1546e() {
        return this.f6626a;
    }
}
