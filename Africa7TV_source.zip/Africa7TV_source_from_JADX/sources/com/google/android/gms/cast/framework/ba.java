package com.google.android.gms.cast.framework;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.p034a.C0827c;
import com.google.android.gms.p034a.C0828d;

class ba implements ay {
    /* renamed from: a */
    private IBinder f6480a;

    ba(IBinder iBinder) {
        this.f6480a = iBinder;
    }

    /* renamed from: a */
    public int mo1491a() {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.ISessionManagerListener");
            this.f6480a.transact(11, obtain, obtain2, 0);
            obtain2.readException();
            int readInt = obtain2.readInt();
            return readInt;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1492a(C0827c c0827c) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.ISessionManagerListener");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            this.f6480a.transact(2, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1493a(C0827c c0827c, int i) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.ISessionManagerListener");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            obtain.writeInt(i);
            this.f6480a.transact(4, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1494a(C0827c c0827c, String str) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.ISessionManagerListener");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            obtain.writeString(str);
            this.f6480a.transact(3, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public void mo1495a(C0827c c0827c, boolean z) {
        int i = 0;
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.ISessionManagerListener");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            if (z) {
                i = 1;
            }
            obtain.writeInt(i);
            this.f6480a.transact(8, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    public IBinder asBinder() {
        return this.f6480a;
    }

    /* renamed from: b */
    public C0827c mo1496b() {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.ISessionManagerListener");
            this.f6480a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
            C0827c a = C0828d.m6209a(obtain2.readStrongBinder());
            return a;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: b */
    public void mo1497b(C0827c c0827c) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.ISessionManagerListener");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            this.f6480a.transact(5, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: b */
    public void mo1498b(C0827c c0827c, int i) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.ISessionManagerListener");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            obtain.writeInt(i);
            this.f6480a.transact(6, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: b */
    public void mo1499b(C0827c c0827c, String str) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.ISessionManagerListener");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            obtain.writeString(str);
            this.f6480a.transact(7, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: c */
    public void mo1500c(C0827c c0827c, int i) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.ISessionManagerListener");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            obtain.writeInt(i);
            this.f6480a.transact(9, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: d */
    public void mo1501d(C0827c c0827c, int i) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.cast.framework.ISessionManagerListener");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            obtain.writeInt(i);
            this.f6480a.transact(10, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }
}
