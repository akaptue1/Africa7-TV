package com.google.android.gms.cast.internal;

import android.text.TextUtils;

/* renamed from: com.google.android.gms.cast.internal.f */
public abstract class C1299f {
    /* renamed from: a */
    private final String f6671a;
    /* renamed from: b */
    private aa f6672b;
    /* renamed from: f */
    protected final C1318w f6673f;

    protected C1299f(String str, String str2, String str3) {
        C1312n.m9600a(str);
        this.f6671a = str;
        this.f6673f = new C1318w(str2);
        m9513a(str3);
    }

    /* renamed from: a */
    public void mo1555a() {
    }

    /* renamed from: a */
    public void mo1594a(long j, int i) {
    }

    /* renamed from: a */
    public final void m9512a(aa aaVar) {
        this.f6672b = aaVar;
        if (this.f6672b == null) {
            mo1555a();
        }
    }

    /* renamed from: a */
    public void m9513a(String str) {
        if (!TextUtils.isEmpty(str)) {
            this.f6673f.m9640a(str);
        }
    }

    /* renamed from: a */
    protected final void m9514a(String str, long j, String str2) {
        this.f6673f.m9641a("Sending text message: %s to: %s", str, str2);
        this.f6672b.mo1543a(this.f6671a, str, j, str2);
    }

    /* renamed from: b */
    public String m9515b() {
        return this.f6671a;
    }

    /* renamed from: b */
    public void mo1596b(String str) {
    }

    /* renamed from: c */
    protected final long m9517c() {
        return this.f6672b.mo1542a();
    }
}
