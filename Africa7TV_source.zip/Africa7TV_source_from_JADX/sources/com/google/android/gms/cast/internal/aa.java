package com.google.android.gms.cast.internal;

public interface aa {
    /* renamed from: a */
    long mo1542a();

    /* renamed from: a */
    void mo1543a(String str, String str2, long j, String str3);
}
