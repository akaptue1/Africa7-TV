package com.google.android.gms.cast.framework;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.p034a.C0827c;
import com.google.android.gms.p034a.C0828d;

public abstract class az extends Binder implements ay {
    /* renamed from: a */
    public static ay m9154a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof ay)) ? new ba(iBinder) : (ay) queryLocalInterface;
    }

    public IBinder asBinder() {
        return this;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        switch (i) {
            case 1:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
                C0827c b = mo1496b();
                parcel2.writeNoException();
                parcel2.writeStrongBinder(b != null ? b.asBinder() : null);
                return true;
            case 2:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
                mo1492a(C0828d.m6209a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 3:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
                mo1494a(C0828d.m6209a(parcel.readStrongBinder()), parcel.readString());
                parcel2.writeNoException();
                return true;
            case 4:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
                mo1493a(C0828d.m6209a(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 5:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
                mo1497b(C0828d.m6209a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 6:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
                mo1498b(C0828d.m6209a(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 7:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
                mo1499b(C0828d.m6209a(parcel.readStrongBinder()), parcel.readString());
                parcel2.writeNoException();
                return true;
            case 8:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
                mo1495a(C0828d.m6209a(parcel.readStrongBinder()), parcel.readInt() != 0);
                parcel2.writeNoException();
                return true;
            case 9:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
                mo1500c(C0828d.m6209a(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 10:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
                mo1501d(C0828d.m6209a(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 11:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISessionManagerListener");
                int a = mo1491a();
                parcel2.writeNoException();
                parcel2.writeInt(a);
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.framework.ISessionManagerListener");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
