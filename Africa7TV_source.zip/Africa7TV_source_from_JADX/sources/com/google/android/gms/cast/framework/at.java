package com.google.android.gms.cast.framework;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.p034a.C0827c;

public abstract class at extends Binder implements as {
    /* renamed from: a */
    public static as m9111a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.framework.ISession");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof as)) ? new au(iBinder) : (as) queryLocalInterface;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        boolean z = false;
        String b;
        boolean e;
        int i3;
        switch (i) {
            case 1:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                C0827c a = mo1468a();
                parcel2.writeNoException();
                parcel2.writeStrongBinder(a != null ? a.asBinder() : null);
                return true;
            case 2:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                b = mo1472b();
                parcel2.writeNoException();
                parcel2.writeString(b);
                return true;
            case 3:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                b = mo1474c();
                parcel2.writeNoException();
                parcel2.writeString(b);
                return true;
            case 4:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                b = mo1476d();
                parcel2.writeNoException();
                parcel2.writeString(b);
                return true;
            case 5:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                e = mo1478e();
                parcel2.writeNoException();
                if (e) {
                    i3 = 1;
                }
                parcel2.writeInt(i3);
                return true;
            case 6:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                e = mo1479f();
                parcel2.writeNoException();
                if (e) {
                    i3 = 1;
                }
                parcel2.writeInt(i3);
                return true;
            case 7:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                e = mo1480g();
                parcel2.writeNoException();
                if (e) {
                    i3 = 1;
                }
                parcel2.writeInt(i3);
                return true;
            case 8:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                e = mo1481h();
                parcel2.writeNoException();
                if (e) {
                    i3 = 1;
                }
                parcel2.writeInt(i3);
                return true;
            case 9:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                e = mo1482i();
                parcel2.writeNoException();
                if (e) {
                    i3 = 1;
                }
                parcel2.writeInt(i3);
                return true;
            case 10:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                e = mo1483j();
                parcel2.writeNoException();
                if (e) {
                    i3 = 1;
                }
                parcel2.writeInt(i3);
                return true;
            case 11:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                mo1470a(parcel.readString());
                parcel2.writeNoException();
                return true;
            case 12:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                mo1469a(parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 13:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                mo1473b(parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 14:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                if (parcel.readInt() != 0) {
                    z = true;
                }
                mo1471a(z);
                parcel2.writeNoException();
                return true;
            case 15:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                mo1475c(parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 16:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ISession");
                mo1477d(parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.framework.ISession");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
