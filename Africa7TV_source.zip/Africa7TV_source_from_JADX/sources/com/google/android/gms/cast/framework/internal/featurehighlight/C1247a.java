package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;

/* renamed from: com.google.android.gms.cast.framework.internal.featurehighlight.a */
class C1247a extends SimpleOnGestureListener {
    /* renamed from: a */
    final /* synthetic */ zza f6503a;

    C1247a(zza zza) {
        this.f6503a = zza;
    }

    public boolean onSingleTapUp(MotionEvent motionEvent) {
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        if (!(this.f6503a.m9261a(x, y) && this.f6503a.f6535d.m9258a(x, y))) {
            this.f6503a.f6543l.m9243a();
        }
        return true;
    }
}
