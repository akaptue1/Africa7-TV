package com.google.android.gms.cast.framework.media;

/* renamed from: com.google.android.gms.cast.framework.media.o */
public interface C1274o {
    /* renamed from: a */
    void m9421a(long j, long j2);
}
