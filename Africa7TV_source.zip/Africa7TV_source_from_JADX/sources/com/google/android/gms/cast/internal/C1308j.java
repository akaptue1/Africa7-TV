package com.google.android.gms.cast.internal;

/* renamed from: com.google.android.gms.cast.internal.j */
class C1308j implements Runnable {
    /* renamed from: a */
    final /* synthetic */ C1303g f6712a;
    /* renamed from: b */
    final /* synthetic */ int f6713b;
    /* renamed from: c */
    final /* synthetic */ C1307i f6714c;

    C1308j(C1307i c1307i, C1303g c1303g, int i) {
        this.f6714c = c1307i;
        this.f6712a = c1303g;
        this.f6713b = i;
    }

    public void run() {
        this.f6712a.f6686h.mo1519a(this.f6713b);
    }
}
