package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;
import java.util.List;

/* renamed from: com.google.android.gms.cast.y */
public class C1333y implements Creator<MediaInfo> {
    /* renamed from: a */
    static void m9702a(MediaInfo mediaInfo, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, mediaInfo.m8882a());
        C1386c.m10207a(parcel, 2, mediaInfo.m8884b(), false);
        C1386c.m10198a(parcel, 3, mediaInfo.m8885c());
        C1386c.m10207a(parcel, 4, mediaInfo.m8886d(), false);
        C1386c.m10202a(parcel, 5, mediaInfo.m8887e(), i, false);
        C1386c.m10199a(parcel, 6, mediaInfo.m8888f());
        C1386c.m10221c(parcel, 7, mediaInfo.m8889g(), false);
        C1386c.m10202a(parcel, 8, mediaInfo.m8890h(), i, false);
        C1386c.m10207a(parcel, 9, mediaInfo.f6374a, false);
        C1386c.m10221c(parcel, 10, mediaInfo.m8891i(), false);
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public MediaInfo m9703a(Parcel parcel) {
        int i = 0;
        List list = null;
        int b = C1384a.m10169b(parcel);
        long j = 0;
        String str = null;
        TextTrackStyle textTrackStyle = null;
        List list2 = null;
        MediaMetadata mediaMetadata = null;
        String str2 = null;
        String str3 = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i2 = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    str3 = C1384a.m10183m(parcel, a);
                    break;
                case 3:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 4:
                    str2 = C1384a.m10183m(parcel, a);
                    break;
                case 5:
                    mediaMetadata = (MediaMetadata) C1384a.m10166a(parcel, a, MediaMetadata.CREATOR);
                    break;
                case 6:
                    j = C1384a.m10177g(parcel, a);
                    break;
                case 7:
                    list2 = C1384a.m10172c(parcel, a, MediaTrack.CREATOR);
                    break;
                case 8:
                    textTrackStyle = (TextTrackStyle) C1384a.m10166a(parcel, a, TextTrackStyle.CREATOR);
                    break;
                case 9:
                    str = C1384a.m10183m(parcel, a);
                    break;
                case 10:
                    list = C1384a.m10172c(parcel, a, AdBreakInfo.CREATOR);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new MediaInfo(i2, str3, i, str2, mediaMetadata, j, list2, textTrackStyle, str, list);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public MediaInfo[] m9704a(int i) {
        return new MediaInfo[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9703a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9704a(i);
    }
}
