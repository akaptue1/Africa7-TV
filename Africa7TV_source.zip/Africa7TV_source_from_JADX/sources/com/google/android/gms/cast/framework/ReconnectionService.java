package com.google.android.gms.cast.framework;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import com.google.android.gms.cast.internal.C1318w;
import com.google.android.gms.internal.atq;

public class ReconnectionService extends Service {
    /* renamed from: a */
    private static final C1318w f6460a = new C1318w("ReconnectionService");
    /* renamed from: b */
    private ap f6461b;

    public IBinder onBind(Intent intent) {
        try {
            return this.f6461b.mo1464a(intent);
        } catch (Throwable e) {
            f6460a.m9642a(e, "Unable to call %s on %s.", "onBind", ap.class.getSimpleName());
            return null;
        }
    }

    public void onCreate() {
        C1230a a = C1230a.m9017a((Context) this);
        this.f6461b = atq.m12325a(this, a.m9021b().m9454b(), a.m9023c().m9466a());
        try {
            this.f6461b.mo1465a();
        } catch (Throwable e) {
            f6460a.m9642a(e, "Unable to call %s on %s.", "onCreate", ap.class.getSimpleName());
        }
        super.onCreate();
    }

    public void onDestroy() {
        try {
            this.f6461b.mo1466b();
        } catch (Throwable e) {
            f6460a.m9642a(e, "Unable to call %s on %s.", "onDestroy", ap.class.getSimpleName());
        }
        super.onDestroy();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        int i3 = 1;
        try {
            i3 = this.f6461b.mo1463a(intent, i, i2);
        } catch (Throwable e) {
            f6460a.m9642a(e, "Unable to call %s on %s.", "onStartCommand", ap.class.getSimpleName());
        }
        return i3;
    }
}
