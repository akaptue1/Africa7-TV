package com.google.android.gms.cast.framework;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.p034a.C0827c;

public abstract class an extends Binder implements am {
    /* renamed from: a */
    public static am m9080a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.framework.IDiscoveryManagerListener");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof am)) ? new ao(iBinder) : (am) queryLocalInterface;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        switch (i) {
            case 1:
                parcel.enforceInterface("com.google.android.gms.cast.framework.IDiscoveryManagerListener");
                C0827c b = mo1462b();
                parcel2.writeNoException();
                parcel2.writeStrongBinder(b != null ? b.asBinder() : null);
                return true;
            case 2:
                parcel.enforceInterface("com.google.android.gms.cast.framework.IDiscoveryManagerListener");
                mo1461a(parcel.readInt() != 0);
                parcel2.writeNoException();
                return true;
            case 3:
                parcel.enforceInterface("com.google.android.gms.cast.framework.IDiscoveryManagerListener");
                int a = mo1460a();
                parcel2.writeNoException();
                parcel2.writeInt(a);
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.framework.IDiscoveryManagerListener");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
