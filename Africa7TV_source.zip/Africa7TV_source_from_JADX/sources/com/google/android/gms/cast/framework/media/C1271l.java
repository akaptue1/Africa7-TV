package com.google.android.gms.cast.framework.media;

/* renamed from: com.google.android.gms.cast.framework.media.l */
public interface C1271l {
    /* renamed from: a */
    void mo1977a();

    /* renamed from: b */
    void mo1978b();

    /* renamed from: c */
    void mo1979c();

    /* renamed from: d */
    void mo1980d();

    /* renamed from: e */
    void mo1981e();
}
