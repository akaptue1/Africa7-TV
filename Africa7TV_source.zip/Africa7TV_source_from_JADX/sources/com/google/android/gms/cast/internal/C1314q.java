package com.google.android.gms.cast.internal;

import android.os.IInterface;
import com.google.android.gms.cast.JoinOptions;
import com.google.android.gms.cast.LaunchOptions;

/* renamed from: com.google.android.gms.cast.internal.q */
public interface C1314q extends IInterface {
    /* renamed from: a */
    void mo1579a();

    /* renamed from: a */
    void mo1580a(double d, double d2, boolean z);

    /* renamed from: a */
    void mo1581a(String str);

    /* renamed from: a */
    void mo1582a(String str, LaunchOptions launchOptions);

    /* renamed from: a */
    void mo1583a(String str, String str2);

    /* renamed from: a */
    void mo1584a(String str, String str2, long j);

    /* renamed from: a */
    void mo1585a(String str, String str2, long j, String str3);

    /* renamed from: a */
    void mo1586a(String str, String str2, JoinOptions joinOptions);

    /* renamed from: a */
    void mo1587a(String str, boolean z);

    /* renamed from: a */
    void mo1588a(String str, byte[] bArr, long j);

    /* renamed from: a */
    void mo1589a(boolean z, double d, boolean z2);

    /* renamed from: b */
    void mo1590b();

    /* renamed from: b */
    void mo1591b(String str);

    /* renamed from: c */
    void mo1592c();

    /* renamed from: c */
    void mo1593c(String str);
}
