package com.google.android.gms.cast.framework.media;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ImageHints extends AbstractSafeParcelable {
    public static final Creator<ImageHints> CREATOR = new ad();
    /* renamed from: a */
    private final int f6551a;
    /* renamed from: b */
    private final int f6552b;
    /* renamed from: c */
    private final int f6553c;
    /* renamed from: d */
    private final int f6554d;

    public ImageHints(int i, int i2, int i3) {
        this(1, i, i2, i3);
    }

    ImageHints(int i, int i2, int i3, int i4) {
        this.f6551a = i;
        this.f6552b = i2;
        this.f6553c = i3;
        this.f6554d = i4;
    }

    /* renamed from: a */
    int m9276a() {
        return this.f6551a;
    }

    /* renamed from: b */
    public int m9277b() {
        return this.f6552b;
    }

    /* renamed from: c */
    public int m9278c() {
        return this.f6553c;
    }

    /* renamed from: d */
    public int m9279d() {
        return this.f6554d;
    }

    public void writeToParcel(Parcel parcel, int i) {
        ad.m9333a(this, parcel, i);
    }
}
