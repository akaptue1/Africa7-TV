package com.google.android.gms.cast.framework;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.cast.LaunchOptions;

/* renamed from: com.google.android.gms.cast.framework.y */
public abstract class C1238y extends Binder implements C1237x {
    public C1238y() {
        attachInterface(this, "com.google.android.gms.cast.framework.ICastConnectionController");
    }

    /* renamed from: a */
    public static C1237x m9218a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.framework.ICastConnectionController");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof C1237x)) ? new C1293z(iBinder) : (C1237x) queryLocalInterface;
    }

    public IBinder asBinder() {
        return this;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        switch (i) {
            case 1:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ICastConnectionController");
                mo1517a(parcel.readString(), parcel.readString());
                parcel2.writeNoException();
                return true;
            case 2:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ICastConnectionController");
                mo1516a(parcel.readString(), parcel.readInt() != 0 ? (LaunchOptions) LaunchOptions.CREATOR.createFromParcel(parcel) : null);
                parcel2.writeNoException();
                return true;
            case 3:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ICastConnectionController");
                mo1515a(parcel.readString());
                parcel2.writeNoException();
                return true;
            case 4:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ICastConnectionController");
                mo1514a(parcel.readInt());
                parcel2.writeNoException();
                return true;
            case 5:
                parcel.enforceInterface("com.google.android.gms.cast.framework.ICastConnectionController");
                int a = mo1513a();
                parcel2.writeNoException();
                parcel2.writeInt(a);
                return true;
            case 1598968902:
                parcel2.writeString("com.google.android.gms.cast.framework.ICastConnectionController");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
