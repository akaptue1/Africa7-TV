package com.google.android.gms.cast;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.internal.aux;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaMetadata extends AbstractSafeParcelable {
    public static final Creator<MediaMetadata> CREATOR = new C1334z();
    /* renamed from: b */
    private static final String[] f6385b = new String[]{null, "String", "int", "double", "ISO-8601 date String"};
    /* renamed from: c */
    private static final C1325q f6386c = new C1325q().m9682a("com.google.android.gms.cast.metadata.CREATION_DATE", "creationDateTime", 4).m9682a("com.google.android.gms.cast.metadata.RELEASE_DATE", "releaseDate", 4).m9682a("com.google.android.gms.cast.metadata.BROADCAST_DATE", "originalAirdate", 4).m9682a("com.google.android.gms.cast.metadata.TITLE", "title", 1).m9682a("com.google.android.gms.cast.metadata.SUBTITLE", "subtitle", 1).m9682a("com.google.android.gms.cast.metadata.ARTIST", "artist", 1).m9682a("com.google.android.gms.cast.metadata.ALBUM_ARTIST", "albumArtist", 1).m9682a("com.google.android.gms.cast.metadata.ALBUM_TITLE", "albumName", 1).m9682a("com.google.android.gms.cast.metadata.COMPOSER", "composer", 1).m9682a("com.google.android.gms.cast.metadata.DISC_NUMBER", "discNumber", 2).m9682a("com.google.android.gms.cast.metadata.TRACK_NUMBER", "trackNumber", 2).m9682a("com.google.android.gms.cast.metadata.SEASON_NUMBER", "season", 2).m9682a("com.google.android.gms.cast.metadata.EPISODE_NUMBER", "episode", 2).m9682a("com.google.android.gms.cast.metadata.SERIES_TITLE", "seriesTitle", 1).m9682a("com.google.android.gms.cast.metadata.STUDIO", "studio", 1).m9682a("com.google.android.gms.cast.metadata.WIDTH", "width", 2).m9682a("com.google.android.gms.cast.metadata.HEIGHT", "height", 2).m9682a("com.google.android.gms.cast.metadata.LOCATION_NAME", "location", 1).m9682a("com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "latitude", 3).m9682a("com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "longitude", 3);
    /* renamed from: a */
    final Bundle f6387a;
    /* renamed from: d */
    private final int f6388d;
    /* renamed from: e */
    private final List<WebImage> f6389e;
    /* renamed from: f */
    private int f6390f;

    public MediaMetadata() {
        this(0);
    }

    public MediaMetadata(int i) {
        this(1, new ArrayList(), new Bundle(), i);
    }

    MediaMetadata(int i, List<WebImage> list, Bundle bundle, int i2) {
        this.f6388d = i;
        this.f6389e = list;
        this.f6387a = bundle;
        this.f6390f = i2;
    }

    /* renamed from: a */
    private void m8893a(String str, int i) {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("null and empty keys are not allowed");
        }
        int c = f6386c.m9685c(str);
        if (c != i && c != 0) {
            String valueOf = String.valueOf(f6385b[i]);
            throw new IllegalArgumentException(new StringBuilder((String.valueOf(str).length() + 21) + String.valueOf(valueOf).length()).append("Value for ").append(str).append(" must be a ").append(valueOf).toString());
        }
    }

    /* renamed from: a */
    private void m8894a(JSONObject jSONObject, String... strArr) {
        try {
            for (String str : strArr) {
                if (this.f6387a.containsKey(str)) {
                    switch (f6386c.m9685c(str)) {
                        case 1:
                        case 4:
                            jSONObject.put(f6386c.m9683a(str), this.f6387a.getString(str));
                            break;
                        case 2:
                            jSONObject.put(f6386c.m9683a(str), this.f6387a.getInt(str));
                            break;
                        case 3:
                            jSONObject.put(f6386c.m9683a(str), this.f6387a.getDouble(str));
                            break;
                        default:
                            break;
                    }
                }
            }
            for (String str2 : this.f6387a.keySet()) {
                if (!str2.startsWith("com.google.")) {
                    Object obj = this.f6387a.get(str2);
                    if (obj instanceof String) {
                        jSONObject.put(str2, obj);
                    } else if (obj instanceof Integer) {
                        jSONObject.put(str2, obj);
                    } else if (obj instanceof Double) {
                        jSONObject.put(str2, obj);
                    }
                }
            }
        } catch (JSONException e) {
        }
    }

    /* renamed from: a */
    private boolean m8895a(Bundle bundle, Bundle bundle2) {
        if (bundle.size() != bundle2.size()) {
            return false;
        }
        for (String str : bundle.keySet()) {
            Object obj = bundle.get(str);
            Object obj2 = bundle2.get(str);
            if ((obj instanceof Bundle) && (obj2 instanceof Bundle) && !m8895a((Bundle) obj, (Bundle) obj2)) {
                return false;
            }
            if (obj == null) {
                if (obj2 != null || !bundle2.containsKey(str)) {
                    return false;
                }
            } else if (!obj.equals(obj2)) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: b */
    private void m8896b(JSONObject jSONObject, String... strArr) {
        Set hashSet = new HashSet(Arrays.asList(strArr));
        try {
            Iterator keys = jSONObject.keys();
            while (keys.hasNext()) {
                String str = (String) keys.next();
                if (!"metadataType".equals(str)) {
                    String b = f6386c.m9684b(str);
                    if (b == null) {
                        Object obj = jSONObject.get(str);
                        if (obj instanceof String) {
                            this.f6387a.putString(str, (String) obj);
                        } else if (obj instanceof Integer) {
                            this.f6387a.putInt(str, ((Integer) obj).intValue());
                        } else if (obj instanceof Double) {
                            this.f6387a.putDouble(str, ((Double) obj).doubleValue());
                        }
                    } else if (hashSet.contains(b)) {
                        try {
                            Object obj2 = jSONObject.get(str);
                            if (obj2 != null) {
                                switch (f6386c.m9685c(b)) {
                                    case 1:
                                        if (!(obj2 instanceof String)) {
                                            break;
                                        }
                                        this.f6387a.putString(b, (String) obj2);
                                        break;
                                    case 2:
                                        if (!(obj2 instanceof Integer)) {
                                            break;
                                        }
                                        this.f6387a.putInt(b, ((Integer) obj2).intValue());
                                        break;
                                    case 3:
                                        if (!(obj2 instanceof Double)) {
                                            break;
                                        }
                                        this.f6387a.putDouble(b, ((Double) obj2).doubleValue());
                                        break;
                                    case 4:
                                        if ((obj2 instanceof String) && aux.m12449a((String) obj2) != null) {
                                            this.f6387a.putString(b, (String) obj2);
                                            break;
                                        }
                                    default:
                                        break;
                                }
                            }
                        } catch (JSONException e) {
                        }
                    }
                }
            }
        } catch (JSONException e2) {
        }
    }

    /* renamed from: a */
    int m8897a() {
        return this.f6388d;
    }

    /* renamed from: a */
    public String m8898a(String str) {
        m8893a(str, 1);
        return this.f6387a.getString(str);
    }

    /* renamed from: a */
    public void m8899a(JSONObject jSONObject) {
        m8901c();
        this.f6390f = 0;
        try {
            this.f6390f = jSONObject.getInt("metadataType");
        } catch (JSONException e) {
        }
        aux.m12450a(this.f6389e, jSONObject);
        switch (this.f6390f) {
            case 0:
                m8896b(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE");
                return;
            case 1:
                m8896b(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.STUDIO", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE");
                return;
            case 2:
                m8896b(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.SERIES_TITLE", "com.google.android.gms.cast.metadata.SEASON_NUMBER", "com.google.android.gms.cast.metadata.EPISODE_NUMBER", "com.google.android.gms.cast.metadata.BROADCAST_DATE");
                return;
            case 3:
                m8896b(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ALBUM_TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.ALBUM_ARTIST", "com.google.android.gms.cast.metadata.COMPOSER", "com.google.android.gms.cast.metadata.TRACK_NUMBER", "com.google.android.gms.cast.metadata.DISC_NUMBER", "com.google.android.gms.cast.metadata.RELEASE_DATE");
                return;
            case 4:
                m8896b(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.LOCATION_NAME", "com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "com.google.android.gms.cast.metadata.WIDTH", "com.google.android.gms.cast.metadata.HEIGHT", "com.google.android.gms.cast.metadata.CREATION_DATE");
                return;
            default:
                m8896b(jSONObject, new String[0]);
                return;
        }
    }

    /* renamed from: b */
    public int m8900b() {
        return this.f6390f;
    }

    /* renamed from: c */
    public void m8901c() {
        this.f6387a.clear();
        this.f6389e.clear();
    }

    /* renamed from: d */
    public JSONObject m8902d() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("metadataType", this.f6390f);
        } catch (JSONException e) {
        }
        aux.m12451a(jSONObject, this.f6389e);
        switch (this.f6390f) {
            case 0:
                m8894a(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE");
                break;
            case 1:
                m8894a(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.STUDIO", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE");
                break;
            case 2:
                m8894a(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.SERIES_TITLE", "com.google.android.gms.cast.metadata.SEASON_NUMBER", "com.google.android.gms.cast.metadata.EPISODE_NUMBER", "com.google.android.gms.cast.metadata.BROADCAST_DATE");
                break;
            case 3:
                m8894a(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.ALBUM_TITLE", "com.google.android.gms.cast.metadata.ALBUM_ARTIST", "com.google.android.gms.cast.metadata.COMPOSER", "com.google.android.gms.cast.metadata.TRACK_NUMBER", "com.google.android.gms.cast.metadata.DISC_NUMBER", "com.google.android.gms.cast.metadata.RELEASE_DATE");
                break;
            case 4:
                m8894a(jSONObject, "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.LOCATION_NAME", "com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "com.google.android.gms.cast.metadata.WIDTH", "com.google.android.gms.cast.metadata.HEIGHT", "com.google.android.gms.cast.metadata.CREATION_DATE");
                break;
            default:
                m8894a(jSONObject, new String[0]);
                break;
        }
        return jSONObject;
    }

    /* renamed from: e */
    public List<WebImage> m8903e() {
        return this.f6389e;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaMetadata)) {
            return false;
        }
        MediaMetadata mediaMetadata = (MediaMetadata) obj;
        return m8895a(this.f6387a, mediaMetadata.f6387a) && this.f6389e.equals(mediaMetadata.f6389e);
    }

    /* renamed from: f */
    public boolean m8904f() {
        return (this.f6389e == null || this.f6389e.isEmpty()) ? false : true;
    }

    public int hashCode() {
        int i = 17;
        for (String str : this.f6387a.keySet()) {
            i *= 31;
            i = this.f6387a.get(str).hashCode() + i;
        }
        return (i * 31) + this.f6389e.hashCode();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1334z.m9705a(this, parcel, i);
    }
}
