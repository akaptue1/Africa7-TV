package com.google.android.gms.cast.framework;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.support.v7.p015d.C0340r;
import com.google.android.gms.cast.internal.C1318w;
import com.google.android.gms.common.internal.C1370c;
import com.google.android.gms.common.util.C1426o;
import com.google.android.gms.internal.atq;
import com.google.android.gms.internal.atr;
import com.google.android.gms.internal.aue;
import com.google.android.gms.p034a.C0827c;
import com.google.android.gms.p034a.C0830f;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: com.google.android.gms.cast.framework.a */
public final class C1230a {
    /* renamed from: a */
    private static final C1318w f6462a = new C1318w("CastContext");
    /* renamed from: b */
    private static C1231b f6463b;
    /* renamed from: c */
    private static C1230a f6464c;
    /* renamed from: d */
    private final Context f6465d;
    /* renamed from: e */
    private final aa f6466e;
    /* renamed from: f */
    private final C1284o f6467f;
    /* renamed from: g */
    private final C1289t f6468g;
    /* renamed from: h */
    private final CastOptions f6469h;
    /* renamed from: i */
    private aue f6470i = new aue(C0340r.m3932a(this.f6465d));

    private C1230a(Context context, CastOptions castOptions, List<C1285p> list) {
        aj d;
        av c;
        C1284o c1284o = null;
        this.f6465d = context.getApplicationContext();
        this.f6469h = castOptions;
        Map hashMap = new HashMap();
        atr atr = new atr(this.f6465d, castOptions, this.f6470i);
        hashMap.put(atr.m9457b(), atr.m9459d());
        if (list != null) {
            for (Object obj : list) {
                C1370c.m10113a(obj, (Object) "Additional SessionProvider must not be null.");
                String a = C1370c.m10115a(obj.m9457b(), (Object) "Category for SessionProvider must not be null or empty string.");
                C1370c.m10121b(!hashMap.containsKey(a), String.format("SessionProvider for category %s already added", new Object[]{a}));
                hashMap.put(a, obj.m9459d());
            }
        }
        this.f6466e = atq.m12323a(this.f6465d, castOptions, this.f6470i, hashMap);
        try {
            d = this.f6466e.mo1443d();
        } catch (Throwable e) {
            f6462a.m9642a(e, "Unable to call %s on %s.", "getDiscoveryManagerImpl", aa.class.getSimpleName());
            d = null;
        }
        this.f6468g = d == null ? null : new C1289t(d);
        try {
            c = this.f6466e.mo1442c();
        } catch (Throwable e2) {
            f6462a.m9642a(e2, "Unable to call %s on %s.", "getSessionManagerImpl", aa.class.getSimpleName());
            c = null;
        }
        if (c != null) {
            c1284o = new C1284o(c);
        }
        this.f6467f = c1284o;
    }

    /* renamed from: a */
    public static C1230a m9017a(Context context) {
        C1370c.m10119b("getSharedInstance must be called from the main thread.");
        if (f6464c == null) {
            C1253k b = C1230a.m9018b(context.getApplicationContext());
            f6464c = new C1230a(context, b.m9268a(context.getApplicationContext()), b.m9269b(context.getApplicationContext()));
            if (C1426o.m10355c()) {
                f6463b = new C1231b(context.getApplicationContext());
                ((Application) context.getApplicationContext()).registerActivityLifecycleCallbacks(f6463b);
            }
        }
        return f6464c;
    }

    /* renamed from: b */
    private static C1253k m9018b(Context context) {
        Throwable e;
        try {
            String string = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData.getString("com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME");
            if (string != null) {
                return (C1253k) Class.forName(string).newInstance();
            }
            throw new IllegalStateException("The fully qualified name of the implementation of OptionsProvider must be provided as a metadata in the AndroidManifest.xml with key com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME.");
        } catch (NameNotFoundException e2) {
            e = e2;
            throw new IllegalStateException("Failed to initialize CastContext.", e);
        } catch (ClassNotFoundException e3) {
            e = e3;
            throw new IllegalStateException("Failed to initialize CastContext.", e);
        } catch (NullPointerException e4) {
            e = e4;
            throw new IllegalStateException("Failed to initialize CastContext.", e);
        } catch (InstantiationException e5) {
            e = e5;
            throw new IllegalStateException("Failed to initialize CastContext.", e);
        } catch (IllegalAccessException e6) {
            e = e6;
            throw new IllegalStateException("Failed to initialize CastContext.", e);
        }
    }

    /* renamed from: a */
    public CastOptions m9019a() {
        C1370c.m10119b("getCastOptions must be called from the main thread.");
        return this.f6469h;
    }

    /* renamed from: a */
    public void m9020a(Activity activity) {
        C1370c.m10119b("onActivityResumed must be called from the main thread.");
        try {
            this.f6466e.mo1437a(C0830f.m6210a((Object) activity));
        } catch (Throwable e) {
            f6462a.m9642a(e, "Unable to call %s on %s.", "onActivityResumed", aa.class.getSimpleName());
        }
    }

    /* renamed from: b */
    public C1284o m9021b() {
        C1370c.m10119b("getSessionManager must be called from the main thread.");
        return this.f6467f;
    }

    /* renamed from: b */
    public void m9022b(Activity activity) {
        C1370c.m10119b("onActivityPaused must be called from the main thread.");
        try {
            this.f6466e.mo1439b(C0830f.m6210a((Object) activity));
        } catch (Throwable e) {
            f6462a.m9642a(e, "Unable to call %s on %s.", "onActivityPaused", aa.class.getSimpleName());
        }
    }

    /* renamed from: c */
    public C1289t m9023c() {
        C1370c.m10119b("getDiscoveryManager must be called from the main thread.");
        return this.f6468g;
    }

    /* renamed from: d */
    public C0827c m9024d() {
        try {
            return this.f6466e.mo1445f();
        } catch (Throwable e) {
            f6462a.m9642a(e, "Unable to call %s on %s.", "getWrappedThis", aa.class.getSimpleName());
            return null;
        }
    }
}
