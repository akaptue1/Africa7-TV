package com.google.android.gms.cast.framework;

import com.google.android.gms.cast.internal.C1318w;
import com.google.android.gms.p034a.C0827c;

/* renamed from: com.google.android.gms.cast.framework.t */
public class C1289t {
    /* renamed from: a */
    private static final C1318w f6643a = new C1318w("DiscoveryManager");
    /* renamed from: b */
    private final aj f6644b;

    C1289t(aj ajVar) {
        this.f6644b = ajVar;
    }

    /* renamed from: a */
    public C0827c m9466a() {
        try {
            return this.f6644b.mo1459c();
        } catch (Throwable e) {
            f6643a.m9642a(e, "Unable to call %s on %s.", "getWrappedThis", aj.class.getSimpleName());
            return null;
        }
    }
}
