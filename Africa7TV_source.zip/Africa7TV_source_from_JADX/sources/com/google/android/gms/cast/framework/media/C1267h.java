package com.google.android.gms.cast.framework.media;

import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.cast.internal.C1320z;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;
import java.io.IOException;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.framework.media.h */
class C1267h extends C1264r {
    /* renamed from: a */
    final /* synthetic */ JSONObject f6611a;
    /* renamed from: b */
    final /* synthetic */ C1261d f6612b;

    C1267h(C1261d c1261d, C1352q c1352q, JSONObject jSONObject) {
        this.f6612b = c1261d;
        this.f6611a = jSONObject;
        super(c1352q);
    }

    /* renamed from: a */
    protected void mo1541a(C1303g c1303g) {
        synchronized (this.f6612b.f6595b) {
            try {
                this.f6612b.f6597d.m9659a(this.e, this.f6611a);
            } catch (IOException e) {
                m8763b((C1223y) (C1272m) mo1416b(new Status(2100)));
            } catch (C1320z e2) {
                m8763b((C1223y) (C1272m) mo1416b(new Status(2100)));
            }
        }
    }
}
