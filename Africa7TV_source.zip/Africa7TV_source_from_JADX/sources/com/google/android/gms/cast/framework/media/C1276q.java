package com.google.android.gms.cast.framework.media;

import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1235z;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.cast.framework.media.q */
final class C1276q implements C1235z<Status> {
    /* renamed from: a */
    final /* synthetic */ C1275p f6623a;
    /* renamed from: b */
    private final long f6624b;

    C1276q(C1275p c1275p, long j) {
        this.f6623a = c1275p;
        this.f6624b = j;
    }

    /* renamed from: a */
    public void m9427a(Status status) {
        if (!status.m9761c()) {
            this.f6623a.f6620a.f6597d.mo1594a(this.f6624b, status.m9762d());
        }
    }

    /* renamed from: a */
    public /* synthetic */ void mo1512a(C1223y c1223y) {
        m9427a((Status) c1223y);
    }
}
