package com.google.android.gms.cast.framework;

import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface ay extends IInterface {
    /* renamed from: a */
    int mo1491a();

    /* renamed from: a */
    void mo1492a(C0827c c0827c);

    /* renamed from: a */
    void mo1493a(C0827c c0827c, int i);

    /* renamed from: a */
    void mo1494a(C0827c c0827c, String str);

    /* renamed from: a */
    void mo1495a(C0827c c0827c, boolean z);

    /* renamed from: b */
    C0827c mo1496b();

    /* renamed from: b */
    void mo1497b(C0827c c0827c);

    /* renamed from: b */
    void mo1498b(C0827c c0827c, int i);

    /* renamed from: b */
    void mo1499b(C0827c c0827c, String str);

    /* renamed from: c */
    void mo1500c(C0827c c0827c, int i);

    /* renamed from: d */
    void mo1501d(C0827c c0827c, int i);
}
