package com.google.android.gms.cast;

import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.internal.avz;

/* renamed from: com.google.android.gms.cast.g */
class C1295g extends C1294n {
    /* renamed from: a */
    final /* synthetic */ String f6647a;
    /* renamed from: b */
    final /* synthetic */ LaunchOptions f6648b;
    /* renamed from: c */
    final /* synthetic */ C1226e f6649c;

    C1295g(C1226e c1226e, C1352q c1352q, String str, LaunchOptions launchOptions) {
        this.f6649c = c1226e;
        this.f6647a = str;
        this.f6648b = launchOptions;
        super(c1352q);
    }

    /* renamed from: a */
    public void mo1554a(C1303g c1303g) {
        try {
            c1303g.m9550a(this.f6647a, this.f6648b, (avz) this);
        } catch (IllegalStateException e) {
            m9000a(2001);
        }
    }
}
