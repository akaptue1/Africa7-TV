package com.google.android.gms.cast.framework.media;

import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.cast.internal.C1320z;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;
import java.io.IOException;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.cast.framework.media.j */
class C1269j extends C1264r {
    /* renamed from: a */
    final /* synthetic */ long f6615a;
    /* renamed from: b */
    final /* synthetic */ int f6616b;
    /* renamed from: c */
    final /* synthetic */ JSONObject f6617c;
    /* renamed from: d */
    final /* synthetic */ C1261d f6618d;

    C1269j(C1261d c1261d, C1352q c1352q, long j, int i, JSONObject jSONObject) {
        this.f6618d = c1261d;
        this.f6615a = j;
        this.f6616b = i;
        this.f6617c = jSONObject;
        super(c1352q);
    }

    /* renamed from: a */
    protected void mo1541a(C1303g c1303g) {
        synchronized (this.f6618d.f6595b) {
            try {
                this.f6618d.f6597d.m9658a(this.e, this.f6615a, this.f6616b, this.f6617c);
            } catch (IOException e) {
                m8763b((C1223y) (C1272m) mo1416b(new Status(2100)));
            } catch (C1320z e2) {
                m8763b((C1223y) (C1272m) mo1416b(new Status(2100)));
            }
        }
    }
}
