package com.google.android.gms.cast;

import com.google.android.gms.cast.internal.C1227b;
import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.cast.n */
abstract class C1294n extends C1227b<C1224c> {
    public C1294n(C1352q c1352q) {
        super(c1352q);
    }

    /* renamed from: a */
    public C1224c m9481a(Status status) {
        return new C1323o(this, status);
    }

    /* renamed from: a */
    public void mo1554a(C1303g c1303g) {
    }

    /* renamed from: b */
    public /* synthetic */ C1223y mo1416b(Status status) {
        return m9481a(status);
    }
}
