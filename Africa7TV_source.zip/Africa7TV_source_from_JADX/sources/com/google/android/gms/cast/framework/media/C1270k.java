package com.google.android.gms.cast.framework.media;

import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;
import java.io.IOException;

/* renamed from: com.google.android.gms.cast.framework.media.k */
class C1270k extends C1264r {
    /* renamed from: a */
    final /* synthetic */ C1261d f6619a;

    C1270k(C1261d c1261d, C1352q c1352q) {
        this.f6619a = c1261d;
        super(c1352q);
    }

    /* renamed from: a */
    protected void mo1541a(C1303g c1303g) {
        synchronized (this.f6619a.f6595b) {
            try {
                this.f6619a.f6597d.m9656a(this.e);
            } catch (IOException e) {
                m8763b((C1223y) (C1272m) mo1416b(new Status(2100)));
            }
        }
    }
}
