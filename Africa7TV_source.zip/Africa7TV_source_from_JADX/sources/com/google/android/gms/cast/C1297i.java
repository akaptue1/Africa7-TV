package com.google.android.gms.cast;

import android.text.TextUtils;
import com.google.android.gms.cast.internal.C1228p;
import com.google.android.gms.cast.internal.C1303g;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.internal.avz;

/* renamed from: com.google.android.gms.cast.i */
class C1297i extends C1228p {
    /* renamed from: a */
    final /* synthetic */ String f6654a;
    /* renamed from: b */
    final /* synthetic */ C1226e f6655b;

    C1297i(C1226e c1226e, C1352q c1352q, String str) {
        this.f6655b = c1226e;
        this.f6654a = str;
        super(c1352q);
    }

    /* renamed from: a */
    public void mo1435a(C1303g c1303g) {
        if (TextUtils.isEmpty(this.f6654a)) {
            m9001a(2001, "IllegalArgument: sessionId cannot be null or empty");
            return;
        }
        try {
            c1303g.m9552a(this.f6654a, (avz) this);
        } catch (IllegalStateException e) {
            m9000a(2001);
        }
    }
}
