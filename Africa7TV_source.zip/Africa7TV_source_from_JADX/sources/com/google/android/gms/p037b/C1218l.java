package com.google.android.gms.p037b;

import com.google.android.gms.common.internal.C1370c;
import java.util.concurrent.Executor;

/* renamed from: com.google.android.gms.b.l */
final class C1218l<TResult> extends C1210d<TResult> {
    /* renamed from: a */
    private final Object f6340a = new Object();
    /* renamed from: b */
    private final C1217k<TResult> f6341b = new C1217k();
    /* renamed from: c */
    private boolean f6342c;
    /* renamed from: d */
    private TResult f6343d;
    /* renamed from: e */
    private Exception f6344e;

    C1218l() {
    }

    /* renamed from: d */
    private void m8844d() {
        C1370c.m10117a(this.f6342c, (Object) "Task is not yet complete");
    }

    /* renamed from: e */
    private void m8845e() {
        C1370c.m10117a(!this.f6342c, (Object) "Task is already complete");
    }

    /* renamed from: f */
    private void m8846f() {
        synchronized (this.f6340a) {
            if (this.f6342c) {
                this.f6341b.m8842a((C1210d) this);
                return;
            }
        }
    }

    /* renamed from: a */
    public C1210d<TResult> mo1424a(Executor executor, C1207a c1207a) {
        this.f6341b.m8843a(new C1213f(executor, c1207a));
        m8846f();
        return this;
    }

    /* renamed from: a */
    public C1210d<TResult> mo1425a(Executor executor, C1208b<? super TResult> c1208b) {
        this.f6341b.m8843a(new C1215h(executor, c1208b));
        m8846f();
        return this;
    }

    /* renamed from: a */
    public void m8849a(Exception exception) {
        C1370c.m10113a((Object) exception, (Object) "Exception must not be null");
        synchronized (this.f6340a) {
            m8845e();
            this.f6342c = true;
            this.f6344e = exception;
        }
        this.f6341b.m8842a((C1210d) this);
    }

    /* renamed from: a */
    public void m8850a(TResult tResult) {
        synchronized (this.f6340a) {
            m8845e();
            this.f6342c = true;
            this.f6343d = tResult;
        }
        this.f6341b.m8842a((C1210d) this);
    }

    /* renamed from: a */
    public boolean mo1426a() {
        boolean z;
        synchronized (this.f6340a) {
            z = this.f6342c && this.f6344e == null;
        }
        return z;
    }

    /* renamed from: b */
    public TResult mo1427b() {
        TResult tResult;
        synchronized (this.f6340a) {
            m8844d();
            if (this.f6344e != null) {
                throw new C1209c(this.f6344e);
            }
            tResult = this.f6343d;
        }
        return tResult;
    }

    /* renamed from: b */
    public boolean m8853b(Exception exception) {
        boolean z = true;
        C1370c.m10113a((Object) exception, (Object) "Exception must not be null");
        synchronized (this.f6340a) {
            if (this.f6342c) {
                z = false;
            } else {
                this.f6342c = true;
                this.f6344e = exception;
                this.f6341b.m8842a((C1210d) this);
            }
        }
        return z;
    }

    /* renamed from: c */
    public Exception mo1428c() {
        Exception exception;
        synchronized (this.f6340a) {
            exception = this.f6344e;
        }
        return exception;
    }
}
