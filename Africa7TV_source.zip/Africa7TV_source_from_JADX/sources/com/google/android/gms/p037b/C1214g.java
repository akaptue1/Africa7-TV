package com.google.android.gms.p037b;

/* renamed from: com.google.android.gms.b.g */
class C1214g implements Runnable {
    /* renamed from: a */
    final /* synthetic */ C1210d f6330a;
    /* renamed from: b */
    final /* synthetic */ C1213f f6331b;

    C1214g(C1213f c1213f, C1210d c1210d) {
        this.f6331b = c1213f;
        this.f6330a = c1210d;
    }

    public void run() {
        synchronized (this.f6331b.f6328b) {
            if (this.f6331b.f6329c != null) {
                this.f6331b.f6329c.mo2017a(this.f6330a.mo1428c());
            }
        }
    }
}
