package com.google.android.gms.p037b;

import java.util.concurrent.Executor;

/* renamed from: com.google.android.gms.b.h */
class C1215h<TResult> implements C1212j<TResult> {
    /* renamed from: a */
    private final Executor f6332a;
    /* renamed from: b */
    private final Object f6333b = new Object();
    /* renamed from: c */
    private C1208b<? super TResult> f6334c;

    public C1215h(Executor executor, C1208b<? super TResult> c1208b) {
        this.f6332a = executor;
        this.f6334c = c1208b;
    }

    /* renamed from: a */
    public void mo1423a(C1210d<TResult> c1210d) {
        if (c1210d.mo1426a()) {
            synchronized (this.f6333b) {
                if (this.f6334c == null) {
                    return;
                }
                this.f6332a.execute(new C1216i(this, c1210d));
            }
        }
    }
}
