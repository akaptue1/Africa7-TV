package com.google.android.gms.p037b;

/* renamed from: com.google.android.gms.b.a */
public interface C1207a {
    /* renamed from: a */
    void mo2017a(Exception exception);
}
