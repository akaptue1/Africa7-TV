package com.google.android.gms.p037b;

/* renamed from: com.google.android.gms.b.e */
public class C1211e<TResult> {
    /* renamed from: a */
    private final C1218l<TResult> f6326a = new C1218l();

    /* renamed from: a */
    public C1210d<TResult> m8831a() {
        return this.f6326a;
    }

    /* renamed from: a */
    public void m8832a(Exception exception) {
        this.f6326a.m8849a(exception);
    }

    /* renamed from: a */
    public void m8833a(TResult tResult) {
        this.f6326a.m8850a((Object) tResult);
    }

    /* renamed from: b */
    public boolean m8834b(Exception exception) {
        return this.f6326a.m8853b(exception);
    }
}
