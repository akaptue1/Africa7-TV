package com.google.android.gms.p037b;

/* renamed from: com.google.android.gms.b.i */
class C1216i implements Runnable {
    /* renamed from: a */
    final /* synthetic */ C1210d f6335a;
    /* renamed from: b */
    final /* synthetic */ C1215h f6336b;

    C1216i(C1215h c1215h, C1210d c1210d) {
        this.f6336b = c1215h;
        this.f6335a = c1210d;
    }

    public void run() {
        synchronized (this.f6336b.f6333b) {
            if (this.f6336b.f6334c != null) {
                this.f6336b.f6334c.mo2018a(this.f6335a.mo1427b());
            }
        }
    }
}
