package com.google.android.gms.p037b;

import java.util.concurrent.Executor;

/* renamed from: com.google.android.gms.b.f */
class C1213f<TResult> implements C1212j<TResult> {
    /* renamed from: a */
    private final Executor f6327a;
    /* renamed from: b */
    private final Object f6328b = new Object();
    /* renamed from: c */
    private C1207a f6329c;

    public C1213f(Executor executor, C1207a c1207a) {
        this.f6327a = executor;
        this.f6329c = c1207a;
    }

    /* renamed from: a */
    public void mo1423a(C1210d<TResult> c1210d) {
        if (!c1210d.mo1426a()) {
            synchronized (this.f6328b) {
                if (this.f6329c == null) {
                    return;
                }
                this.f6327a.execute(new C1214g(this, c1210d));
            }
        }
    }
}
