package com.google.android.gms.p037b;

/* renamed from: com.google.android.gms.b.b */
public interface C1208b<TResult> {
    /* renamed from: a */
    void mo2018a(TResult tResult);
}
