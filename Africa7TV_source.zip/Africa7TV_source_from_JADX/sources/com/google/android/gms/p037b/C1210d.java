package com.google.android.gms.p037b;

import java.util.concurrent.Executor;

/* renamed from: com.google.android.gms.b.d */
public abstract class C1210d<TResult> {
    /* renamed from: a */
    public abstract C1210d<TResult> mo1424a(Executor executor, C1207a c1207a);

    /* renamed from: a */
    public abstract C1210d<TResult> mo1425a(Executor executor, C1208b<? super TResult> c1208b);

    /* renamed from: a */
    public abstract boolean mo1426a();

    /* renamed from: b */
    public abstract TResult mo1427b();

    /* renamed from: c */
    public abstract Exception mo1428c();
}
