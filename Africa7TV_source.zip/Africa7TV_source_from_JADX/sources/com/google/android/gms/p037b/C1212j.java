package com.google.android.gms.p037b;

/* renamed from: com.google.android.gms.b.j */
interface C1212j<TResult> {
    /* renamed from: a */
    void mo1423a(C1210d<TResult> c1210d);
}
