package com.google.android.gms.p037b;

/* renamed from: com.google.android.gms.b.c */
public class C1209c extends RuntimeException {
    public C1209c(Throwable th) {
        super(th);
    }
}
