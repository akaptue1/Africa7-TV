package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

/* renamed from: com.google.android.gms.flags.impl.c */
final class C1437c implements Callable<Boolean> {
    /* renamed from: a */
    final /* synthetic */ SharedPreferences f7101a;
    /* renamed from: b */
    final /* synthetic */ String f7102b;
    /* renamed from: c */
    final /* synthetic */ Boolean f7103c;

    C1437c(SharedPreferences sharedPreferences, String str, Boolean bool) {
        this.f7101a = sharedPreferences;
        this.f7102b = str;
        this.f7103c = bool;
    }

    /* renamed from: a */
    public Boolean m10384a() {
        return Boolean.valueOf(this.f7101a.getBoolean(this.f7102b, this.f7103c.booleanValue()));
    }

    public /* synthetic */ Object call() {
        return m10384a();
    }
}
