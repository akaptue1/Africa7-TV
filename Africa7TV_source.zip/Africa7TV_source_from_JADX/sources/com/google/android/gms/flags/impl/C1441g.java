package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

/* renamed from: com.google.android.gms.flags.impl.g */
final class C1441g implements Callable<Long> {
    /* renamed from: a */
    final /* synthetic */ SharedPreferences f7107a;
    /* renamed from: b */
    final /* synthetic */ String f7108b;
    /* renamed from: c */
    final /* synthetic */ Long f7109c;

    C1441g(SharedPreferences sharedPreferences, String str, Long l) {
        this.f7107a = sharedPreferences;
        this.f7108b = str;
        this.f7109c = l;
    }

    /* renamed from: a */
    public Long m10388a() {
        return Long.valueOf(this.f7107a.getLong(this.f7108b, this.f7109c.longValue()));
    }

    public /* synthetic */ Object call() {
        return m10388a();
    }
}
