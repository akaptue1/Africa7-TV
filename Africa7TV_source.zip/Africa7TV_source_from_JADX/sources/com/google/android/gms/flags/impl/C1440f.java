package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import com.google.android.gms.internal.bbz;

/* renamed from: com.google.android.gms.flags.impl.f */
public class C1440f extends C1435a<Long> {
    /* renamed from: a */
    public static Long m10387a(SharedPreferences sharedPreferences, String str, Long l) {
        return (Long) bbz.m13122a(new C1441g(sharedPreferences, str, l));
    }
}
