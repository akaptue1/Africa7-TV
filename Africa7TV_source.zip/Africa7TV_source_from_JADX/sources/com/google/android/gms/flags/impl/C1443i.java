package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

/* renamed from: com.google.android.gms.flags.impl.i */
final class C1443i implements Callable<String> {
    /* renamed from: a */
    final /* synthetic */ SharedPreferences f7110a;
    /* renamed from: b */
    final /* synthetic */ String f7111b;
    /* renamed from: c */
    final /* synthetic */ String f7112c;

    C1443i(SharedPreferences sharedPreferences, String str, String str2) {
        this.f7110a = sharedPreferences;
        this.f7111b = str;
        this.f7112c = str2;
    }

    /* renamed from: a */
    public String m10390a() {
        return this.f7110a.getString(this.f7111b, this.f7112c);
    }

    public /* synthetic */ Object call() {
        return m10390a();
    }
}
