package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.android.gms.internal.bbz;

/* renamed from: com.google.android.gms.flags.impl.j */
public class C1444j {
    /* renamed from: a */
    private static SharedPreferences f7113a = null;

    /* renamed from: a */
    public static SharedPreferences m10391a(Context context) {
        SharedPreferences sharedPreferences;
        synchronized (SharedPreferences.class) {
            if (f7113a == null) {
                f7113a = (SharedPreferences) bbz.m13122a(new C1445k(context));
            }
            sharedPreferences = f7113a;
        }
        return sharedPreferences;
    }
}
