package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import com.google.android.gms.internal.bbz;

/* renamed from: com.google.android.gms.flags.impl.h */
public class C1442h extends C1435a<String> {
    /* renamed from: a */
    public static String m10389a(SharedPreferences sharedPreferences, String str, String str2) {
        return (String) bbz.m13122a(new C1443i(sharedPreferences, str, str2));
    }
}
