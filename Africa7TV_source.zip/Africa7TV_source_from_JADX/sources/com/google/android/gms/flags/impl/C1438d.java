package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import com.google.android.gms.internal.bbz;

/* renamed from: com.google.android.gms.flags.impl.d */
public class C1438d extends C1435a<Integer> {
    /* renamed from: a */
    public static Integer m10385a(SharedPreferences sharedPreferences, String str, Integer num) {
        return (Integer) bbz.m13122a(new C1439e(sharedPreferences, str, num));
    }
}
