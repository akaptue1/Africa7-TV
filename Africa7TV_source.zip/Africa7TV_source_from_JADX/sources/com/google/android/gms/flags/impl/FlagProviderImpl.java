package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.internal.bbw;
import com.google.android.gms.p034a.C0827c;
import com.google.android.gms.p034a.C0830f;

@DynamiteApi
public class FlagProviderImpl extends bbw {
    /* renamed from: a */
    private boolean f7099a = false;
    /* renamed from: b */
    private SharedPreferences f7100b;

    public boolean getBooleanFlagValue(String str, boolean z, int i) {
        return !this.f7099a ? z : C1436b.m10383a(this.f7100b, str, Boolean.valueOf(z)).booleanValue();
    }

    public int getIntFlagValue(String str, int i, int i2) {
        return !this.f7099a ? i : C1438d.m10385a(this.f7100b, str, Integer.valueOf(i)).intValue();
    }

    public long getLongFlagValue(String str, long j, int i) {
        return !this.f7099a ? j : C1440f.m10387a(this.f7100b, str, Long.valueOf(j)).longValue();
    }

    public String getStringFlagValue(String str, String str2, int i) {
        return !this.f7099a ? str2 : C1442h.m10389a(this.f7100b, str, str2);
    }

    public void init(C0827c c0827c) {
        Context context = (Context) C0830f.m6211a(c0827c);
        if (!this.f7099a) {
            try {
                this.f7100b = C1444j.m10391a(context.createPackageContext("com.google.android.gms", 0));
                this.f7099a = true;
            } catch (NameNotFoundException e) {
            }
        }
    }
}
