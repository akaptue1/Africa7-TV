package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

/* renamed from: com.google.android.gms.flags.impl.e */
final class C1439e implements Callable<Integer> {
    /* renamed from: a */
    final /* synthetic */ SharedPreferences f7104a;
    /* renamed from: b */
    final /* synthetic */ String f7105b;
    /* renamed from: c */
    final /* synthetic */ Integer f7106c;

    C1439e(SharedPreferences sharedPreferences, String str, Integer num) {
        this.f7104a = sharedPreferences;
        this.f7105b = str;
        this.f7106c = num;
    }

    /* renamed from: a */
    public Integer m10386a() {
        return Integer.valueOf(this.f7104a.getInt(this.f7105b, this.f7106c.intValue()));
    }

    public /* synthetic */ Object call() {
        return m10386a();
    }
}
