package com.google.android.gms.flags.impl;

/* renamed from: com.google.android.gms.flags.impl.a */
public abstract class C1435a<T> {
}
