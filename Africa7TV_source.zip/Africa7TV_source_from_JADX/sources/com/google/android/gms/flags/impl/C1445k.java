package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.concurrent.Callable;

/* renamed from: com.google.android.gms.flags.impl.k */
final class C1445k implements Callable<SharedPreferences> {
    /* renamed from: a */
    final /* synthetic */ Context f7114a;

    C1445k(Context context) {
        this.f7114a = context;
    }

    /* renamed from: a */
    public SharedPreferences m10392a() {
        return this.f7114a.getSharedPreferences("google_sdk_flags", 1);
    }

    public /* synthetic */ Object call() {
        return m10392a();
    }
}
