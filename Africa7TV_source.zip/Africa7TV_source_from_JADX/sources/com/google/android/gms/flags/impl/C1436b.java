package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import com.google.android.gms.internal.bbz;

/* renamed from: com.google.android.gms.flags.impl.b */
public class C1436b extends C1435a<Boolean> {
    /* renamed from: a */
    public static Boolean m10383a(SharedPreferences sharedPreferences, String str, Boolean bool) {
        return (Boolean) bbz.m13122a(new C1437c(sharedPreferences, str, bool));
    }
}
