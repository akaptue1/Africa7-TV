package com.google.android.gms;

/* compiled from: R */
/* renamed from: com.google.android.gms.b */
public final class C1219b {
    public static final int cast_expanded_controller_ad_container_white_stripe_color = 2131492884;
    public static final int cast_expanded_controller_ad_label_background_color = 2131492885;
    public static final int cast_expanded_controller_background_color = 2131492886;
    public static final int cast_expanded_controller_progress_text_color = 2131492887;
    public static final int cast_expanded_controller_seek_bar_progress_background_tint_color = 2131492888;
    public static final int cast_expanded_controller_text_color = 2131492889;
    public static final int cast_intro_overlay_background_color = 2131492890;
    public static final int cast_intro_overlay_button_background_color = 2131492891;
    /* renamed from: cast_libraries_material_featurehighlight_outer_highlight_default_color */
    public static final int f6345xfbd34f47 = 2131492892;
    public static final int cast_libraries_material_featurehighlight_text_body_color = 2131492893;
    public static final int cast_libraries_material_featurehighlight_text_header_color = 2131492894;
    public static final int common_google_signin_btn_text_dark = 2131493000;
    public static final int common_google_signin_btn_text_dark_default = 2131492906;
    public static final int common_google_signin_btn_text_dark_disabled = 2131492907;
    public static final int common_google_signin_btn_text_dark_focused = 2131492908;
    public static final int common_google_signin_btn_text_dark_pressed = 2131492909;
    public static final int common_google_signin_btn_text_light = 2131493001;
    public static final int common_google_signin_btn_text_light_default = 2131492910;
    public static final int common_google_signin_btn_text_light_disabled = 2131492911;
    public static final int common_google_signin_btn_text_light_focused = 2131492912;
    public static final int common_google_signin_btn_text_light_pressed = 2131492913;
    public static final int place_autocomplete_prediction_primary_text = 2131492942;
    public static final int place_autocomplete_prediction_primary_text_highlight = 2131492943;
    public static final int place_autocomplete_prediction_secondary_text = 2131492944;
    public static final int place_autocomplete_search_hint = 2131492945;
    public static final int place_autocomplete_search_text = 2131492946;
    public static final int place_autocomplete_separator = 2131492947;
    public static final int wallet_bright_foreground_disabled_holo_light = 2131492968;
    public static final int wallet_bright_foreground_holo_dark = 2131492969;
    public static final int wallet_bright_foreground_holo_light = 2131492970;
    public static final int wallet_dim_foreground_disabled_holo_dark = 2131492971;
    public static final int wallet_dim_foreground_holo_dark = 2131492972;
    public static final int wallet_dim_foreground_inverse_disabled_holo_dark = 2131492973;
    public static final int wallet_dim_foreground_inverse_holo_dark = 2131492974;
    public static final int wallet_highlighted_text_holo_dark = 2131492975;
    public static final int wallet_highlighted_text_holo_light = 2131492976;
    public static final int wallet_hint_foreground_holo_dark = 2131492977;
    public static final int wallet_hint_foreground_holo_light = 2131492978;
    public static final int wallet_holo_blue_light = 2131492979;
    public static final int wallet_link_text_light = 2131492980;
    public static final int wallet_primary_text_holo_light = 2131493004;
    public static final int wallet_secondary_text_holo_dark = 2131493005;
}
