package com.google.android.gms.internal;

import java.util.Map;

class in implements is {
    /* renamed from: a */
    final /* synthetic */ boolean f9711a;
    /* renamed from: b */
    final /* synthetic */ ij f9712b;

    in(ij ijVar, boolean z) {
        this.f9712b = ijVar;
        this.f9711a = z;
    }

    /* renamed from: a */
    public void mo2208a(Map<String, Object> map) {
        this.f9712b.f9688j = it.Connected;
        String str = (String) map.get("s");
        if (str.equals("ok")) {
            this.f9712b.f9704z = 0;
            this.f9712b.f9681c.mo2454a(true);
            if (this.f9711a) {
                this.f9712b.m14197n();
                return;
            }
            return;
        }
        this.f9712b.f9695q = null;
        this.f9712b.f9696r = true;
        this.f9712b.f9681c.mo2454a(false);
        String str2 = (String) map.get("d");
        this.f9712b.f9700v.m14342a(new StringBuilder((String.valueOf(str).length() + 26) + String.valueOf(str2).length()).append("Authentication failed: ").append(str).append(" (").append(str2).append(")").toString(), new Object[0]);
        this.f9712b.f9687i.m14102b();
        if (str.equals("invalid_token")) {
            this.f9712b.f9704z = this.f9712b.f9704z + 1;
            if (((long) this.f9712b.f9704z) >= 3) {
                this.f9712b.f9701w.m14303b();
                this.f9712b.f9700v.m14339a("Provided authentication credentials are invalid. This usually indicates your FirebaseApp instance was not initialized correctly. Make sure your google-services.json file has the correct firebase_url and api_key. You can re-download google-services.json from https://console.firebase.google.com/.");
            }
        }
    }
}
