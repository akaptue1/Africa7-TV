package com.google.android.gms.internal;

public interface ig {
    /* renamed from: a */
    String mo2439a();

    /* renamed from: b */
    boolean mo2440b();

    /* renamed from: c */
    hw mo2441c();
}
