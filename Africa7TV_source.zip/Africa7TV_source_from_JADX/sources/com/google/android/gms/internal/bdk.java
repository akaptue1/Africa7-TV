package com.google.android.gms.internal;

import android.os.Bundle;
import com.google.android.gms.common.internal.C1370c;
import com.google.android.gms.common.util.C1415d;
import com.google.android.gms.tagmanager.C1575q;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class bdk {
    /* renamed from: a */
    private final String f8965a;
    /* renamed from: b */
    private final String f8966b;
    /* renamed from: c */
    private final String f8967c;
    /* renamed from: d */
    private final bfe f8968d;
    /* renamed from: e */
    private final eg f8969e;
    /* renamed from: f */
    private final ExecutorService f8970f;
    /* renamed from: g */
    private final ScheduledExecutorService f8971g;
    /* renamed from: h */
    private final C1575q f8972h;
    /* renamed from: i */
    private final C1415d f8973i;
    /* renamed from: j */
    private final bdt f8974j;
    /* renamed from: k */
    private bez f8975k;
    /* renamed from: l */
    private volatile int f8976l = 1;
    /* renamed from: m */
    private List<bdy> f8977m = new ArrayList();
    /* renamed from: n */
    private ScheduledFuture<?> f8978n = null;
    /* renamed from: o */
    private boolean f8979o = false;

    bdk(String str, String str2, String str3, bfe bfe, eg egVar, ExecutorService executorService, ScheduledExecutorService scheduledExecutorService, C1575q c1575q, C1415d c1415d, bdt bdt) {
        this.f8965a = (String) C1370c.m10112a((Object) str);
        this.f8968d = (bfe) C1370c.m10112a((Object) bfe);
        this.f8969e = (eg) C1370c.m10112a((Object) egVar);
        this.f8970f = (ExecutorService) C1370c.m10112a((Object) executorService);
        this.f8971g = (ScheduledExecutorService) C1370c.m10112a((Object) scheduledExecutorService);
        this.f8972h = (C1575q) C1370c.m10112a((Object) c1575q);
        this.f8973i = (C1415d) C1370c.m10112a((Object) c1415d);
        this.f8974j = (bdt) C1370c.m10112a((Object) bdt);
        this.f8966b = str3;
        this.f8967c = str2;
        this.f8977m.add(new bdy("gtm.load", new Bundle(), "gtm", new Date(), false, this.f8972h));
        String str4 = this.f8965a;
        beo.m13392d(new StringBuilder(String.valueOf(str4).length() + 35).append("Container ").append(str4).append("is scheduled for loading.").toString());
        this.f8970f.execute(new bdo());
    }

    /* renamed from: a */
    private void m13282a(long j) {
        if (this.f8978n != null) {
            this.f8978n.cancel(false);
        }
        String str = this.f8965a;
        beo.m13392d(new StringBuilder(String.valueOf(str).length() + 45).append("Refresh container ").append(str).append(" in ").append(j).append("ms.").toString());
        this.f8978n = this.f8971g.schedule(new bdm(this), j, TimeUnit.MILLISECONDS);
    }

    /* renamed from: a */
    public void m13297a() {
        this.f8970f.execute(new bdl(this));
    }

    /* renamed from: a */
    public void m13298a(bdy bdy) {
        this.f8970f.execute(new bdp(this, bdy));
    }
}
