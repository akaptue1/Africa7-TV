package com.google.android.gms.internal;

import java.util.Map;

class vb implements aau {
    /* renamed from: a */
    final /* synthetic */ uy f10484a;

    vb(uy uyVar) {
        this.f10484a = uyVar;
    }

    /* renamed from: a */
    public void mo1150a(arh arh, Map<String, String> map) {
        this.f10484a.f10477a.m15413b((Map) map);
    }
}
