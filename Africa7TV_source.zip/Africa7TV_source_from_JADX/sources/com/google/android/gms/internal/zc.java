package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;
import java.util.List;

public interface zc extends IInterface {
    /* renamed from: a */
    String mo1220a();

    /* renamed from: b */
    List mo1221b();

    /* renamed from: c */
    String mo1222c();

    /* renamed from: d */
    yo mo1223d();

    /* renamed from: e */
    String mo1224e();

    /* renamed from: f */
    String mo1225f();

    /* renamed from: g */
    C0827c mo1226g();

    /* renamed from: h */
    Bundle mo1227h();

    /* renamed from: i */
    void mo1228i();
}
