package com.google.android.gms.internal;

import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public final class pv extends nd<Time> {
    /* renamed from: a */
    public static final ne f10143a = new pw();
    /* renamed from: b */
    private final DateFormat f10144b = new SimpleDateFormat("hh:mm:ss a");

    /* renamed from: a */
    public synchronized Time m14817a(ri riVar) {
        Time time;
        if (riVar.mo2248f() == rk.NULL) {
            riVar.mo2252j();
            time = null;
        } else {
            try {
                time = new Time(this.f10144b.parse(riVar.mo2250h()).getTime());
            } catch (Throwable e) {
                throw new mw(e);
            }
        }
        return time;
    }

    /* renamed from: a */
    public synchronized void m14819a(rl rlVar, Time time) {
        rlVar.mo2265b(time == null ? null : this.f10144b.format(time));
    }

    /* renamed from: b */
    public /* synthetic */ Object mo2144b(ri riVar) {
        return m14817a(riVar);
    }
}
