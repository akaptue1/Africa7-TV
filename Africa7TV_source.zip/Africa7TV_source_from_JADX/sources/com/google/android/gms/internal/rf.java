package com.google.android.gms.internal;

final class rf extends nd<StringBuffer> {
    rf() {
    }

    /* renamed from: a */
    public StringBuffer m14935a(ri riVar) {
        if (riVar.mo2248f() != rk.NULL) {
            return new StringBuffer(riVar.mo2250h());
        }
        riVar.mo2252j();
        return null;
    }

    /* renamed from: a */
    public void m14937a(rl rlVar, StringBuffer stringBuffer) {
        rlVar.mo2265b(stringBuffer == null ? null : stringBuffer.toString());
    }

    /* renamed from: b */
    public /* synthetic */ Object mo2144b(ri riVar) {
        return m14935a(riVar);
    }
}
