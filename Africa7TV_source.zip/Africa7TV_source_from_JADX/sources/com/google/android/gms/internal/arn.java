package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.overlay.C0862w;

class arn implements C0862w {
    /* renamed from: a */
    private arh f8282a;
    /* renamed from: b */
    private C0862w f8283b;

    public arn(arh arh, C0862w c0862w) {
        this.f8282a = arh;
        this.f8283b = c0862w;
    }

    public void e_() {
        this.f8283b.e_();
        this.f8282a.mo1901c();
    }

    public void f_() {
        this.f8283b.f_();
        this.f8282a.mo1903d();
    }

    /* renamed from: g */
    public void mo1121g() {
    }

    public void g_() {
    }
}
