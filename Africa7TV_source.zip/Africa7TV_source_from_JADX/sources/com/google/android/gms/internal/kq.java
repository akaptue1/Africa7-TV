package com.google.android.gms.internal;

import java.io.DataInputStream;
import java.net.SocketTimeoutException;

class kq {
    /* renamed from: a */
    private DataInputStream f9848a = null;
    /* renamed from: b */
    private ke f9849b = null;
    /* renamed from: c */
    private kj f9850c = null;
    /* renamed from: d */
    private byte[] f9851d = new byte[112];
    /* renamed from: e */
    private jz f9852e;
    /* renamed from: f */
    private volatile boolean f9853f = false;

    kq(ke keVar) {
        this.f9849b = keVar;
    }

    /* renamed from: a */
    private int m14401a(byte[] bArr, int i, int i2) {
        this.f9848a.readFully(bArr, i, i2);
        return i2;
    }

    /* renamed from: a */
    private long m14402a(byte[] bArr, int i) {
        return (((((((((long) bArr[i + 0]) << 56) + (((long) (bArr[i + 1] & 255)) << 48)) + (((long) (bArr[i + 2] & 255)) << 40)) + (((long) (bArr[i + 3] & 255)) << 32)) + (((long) (bArr[i + 4] & 255)) << 24)) + ((long) ((bArr[i + 5] & 255) << 16))) + ((long) ((bArr[i + 6] & 255) << 8))) + ((long) ((bArr[i + 7] & 255) << 0));
    }

    /* renamed from: a */
    private void m14403a(kk kkVar) {
        m14408b();
        this.f9849b.m14369a(kkVar);
    }

    /* renamed from: a */
    private void m14404a(boolean z, byte b, byte[] bArr) {
        if (b == (byte) 9) {
            if (z) {
                m14405a(bArr);
                return;
            }
            throw new kk("PING must not fragment across frames");
        } else if (this.f9852e != null && b != (byte) 0) {
            throw new kk("Failed to continue outstanding frame");
        } else if (this.f9852e == null && b == (byte) 0) {
            throw new kk("Received continuing frame, but there's nothing to continue");
        } else {
            if (this.f9852e == null) {
                this.f9852e = jx.m14348a(b);
            }
            if (!this.f9852e.mo2226a(bArr)) {
                throw new kk("Failed to decode frame");
            } else if (z) {
                km a = this.f9852e.mo2225a();
                this.f9852e = null;
                if (a == null) {
                    throw new kk("Failed to decode whole message");
                }
                this.f9850c.mo2211a(a);
            }
        }
    }

    /* renamed from: a */
    private void m14405a(byte[] bArr) {
        if (bArr.length <= 125) {
            this.f9849b.m14371a(bArr);
            return;
        }
        throw new kk("PING frame too long");
    }

    /* renamed from: a */
    void m14406a() {
        this.f9850c = this.f9849b.m14372c();
        while (!this.f9853f) {
            try {
                int a = m14401a(this.f9851d, 0, 1) + 0;
                boolean z = (this.f9851d[0] & 128) != 0;
                if (((this.f9851d[0] & 112) != 0 ? 1 : null) != null) {
                    throw new kk("Invalid frame received");
                }
                byte b = (byte) (this.f9851d[0] & 15);
                int a2 = a + m14401a(this.f9851d, a, 1);
                byte b2 = this.f9851d[1];
                long j = 0;
                if (b2 < (byte) 126) {
                    j = (long) b2;
                } else if (b2 == (byte) 126) {
                    int a3 = m14401a(this.f9851d, a2, 2) + a2;
                    j = (long) (((this.f9851d[2] & 255) << 8) | (this.f9851d[3] & 255));
                } else if (b2 == Byte.MAX_VALUE) {
                    j = m14402a(this.f9851d, (m14401a(this.f9851d, a2, 8) + a2) - 8);
                }
                byte[] bArr = new byte[((int) j)];
                m14401a(bArr, 0, (int) j);
                if (b == (byte) 8) {
                    this.f9849b.m14375f();
                } else if (b == (byte) 10) {
                    continue;
                } else if (b == (byte) 1 || b == (byte) 2 || b == (byte) 9 || b == (byte) 0) {
                    m14404a(z, b, bArr);
                } else {
                    throw new kk("Unsupported opcode: " + b);
                }
            } catch (SocketTimeoutException e) {
            } catch (Throwable e2) {
                m14403a(new kk("IO Error", e2));
            } catch (kk e3) {
                m14403a(e3);
            }
        }
    }

    /* renamed from: a */
    void m14407a(DataInputStream dataInputStream) {
        this.f9848a = dataInputStream;
    }

    /* renamed from: b */
    void m14408b() {
        this.f9853f = true;
    }
}
