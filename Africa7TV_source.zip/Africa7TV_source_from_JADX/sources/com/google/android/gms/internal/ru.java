package com.google.android.gms.internal;

public final class ru implements Cloneable {
    /* renamed from: a */
    private static final rv f10253a = new rv();
    /* renamed from: b */
    private boolean f10254b;
    /* renamed from: c */
    private int[] f10255c;
    /* renamed from: d */
    private rv[] f10256d;
    /* renamed from: e */
    private int f10257e;

    ru() {
        this(10);
    }

    ru(int i) {
        this.f10254b = false;
        int c = m15065c(i);
        this.f10255c = new int[c];
        this.f10256d = new rv[c];
        this.f10257e = 0;
    }

    /* renamed from: a */
    private boolean m15063a(int[] iArr, int[] iArr2, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            if (iArr[i2] != iArr2[i2]) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: a */
    private boolean m15064a(rv[] rvVarArr, rv[] rvVarArr2, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            if (!rvVarArr[i2].equals(rvVarArr2[i2])) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: c */
    private int m15065c(int i) {
        return m15066d(i * 4) / 4;
    }

    /* renamed from: d */
    private int m15066d(int i) {
        for (int i2 = 4; i2 < 32; i2++) {
            if (i <= (1 << i2) - 12) {
                return (1 << i2) - 12;
            }
        }
        return i;
    }

    /* renamed from: e */
    private int m15067e(int i) {
        int i2 = 0;
        int i3 = this.f10257e - 1;
        while (i2 <= i3) {
            int i4 = (i2 + i3) >>> 1;
            int i5 = this.f10255c[i4];
            if (i5 < i) {
                i2 = i4 + 1;
            } else if (i5 <= i) {
                return i4;
            } else {
                i3 = i4 - 1;
            }
        }
        return i2 ^ -1;
    }

    /* renamed from: a */
    int m15068a() {
        return this.f10257e;
    }

    /* renamed from: a */
    rv m15069a(int i) {
        int e = m15067e(i);
        return (e < 0 || this.f10256d[e] == f10253a) ? null : this.f10256d[e];
    }

    /* renamed from: a */
    void m15070a(int i, rv rvVar) {
        int e = m15067e(i);
        if (e >= 0) {
            this.f10256d[e] = rvVar;
            return;
        }
        e ^= -1;
        if (e >= this.f10257e || this.f10256d[e] != f10253a) {
            if (this.f10257e >= this.f10255c.length) {
                int c = m15065c(this.f10257e + 1);
                Object obj = new int[c];
                Object obj2 = new rv[c];
                System.arraycopy(this.f10255c, 0, obj, 0, this.f10255c.length);
                System.arraycopy(this.f10256d, 0, obj2, 0, this.f10256d.length);
                this.f10255c = obj;
                this.f10256d = obj2;
            }
            if (this.f10257e - e != 0) {
                System.arraycopy(this.f10255c, e, this.f10255c, e + 1, this.f10257e - e);
                System.arraycopy(this.f10256d, e, this.f10256d, e + 1, this.f10257e - e);
            }
            this.f10255c[e] = i;
            this.f10256d[e] = rvVar;
            this.f10257e++;
            return;
        }
        this.f10255c[e] = i;
        this.f10256d[e] = rvVar;
    }

    /* renamed from: b */
    rv m15071b(int i) {
        return this.f10256d[i];
    }

    /* renamed from: b */
    public boolean m15072b() {
        return m15068a() == 0;
    }

    /* renamed from: c */
    public final ru m15073c() {
        int a = m15068a();
        ru ruVar = new ru(a);
        System.arraycopy(this.f10255c, 0, ruVar.f10255c, 0, a);
        for (int i = 0; i < a; i++) {
            if (this.f10256d[i] != null) {
                ruVar.f10256d[i] = (rv) this.f10256d[i].clone();
            }
        }
        ruVar.f10257e = a;
        return ruVar;
    }

    public /* synthetic */ Object clone() {
        return m15073c();
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ru)) {
            return false;
        }
        ru ruVar = (ru) obj;
        return m15068a() != ruVar.m15068a() ? false : m15063a(this.f10255c, ruVar.f10255c, this.f10257e) && m15064a(this.f10256d, ruVar.f10256d, this.f10257e);
    }

    public int hashCode() {
        int i = 17;
        for (int i2 = 0; i2 < this.f10257e; i2++) {
            i = (((i * 31) + this.f10255c[i2]) * 31) + this.f10256d[i2].hashCode();
        }
        return i;
    }
}
