package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class bai implements ThreadFactory {
    /* renamed from: a */
    private final String f8754a;
    /* renamed from: b */
    private final int f8755b;
    /* renamed from: c */
    private final AtomicInteger f8756c;
    /* renamed from: d */
    private final ThreadFactory f8757d;

    public bai(String str) {
        this(str, 0);
    }

    public bai(String str, int i) {
        this.f8756c = new AtomicInteger();
        this.f8757d = Executors.defaultThreadFactory();
        this.f8754a = (String) C1370c.m10113a((Object) str, (Object) "Name must not be null");
        this.f8755b = i;
    }

    public Thread newThread(Runnable runnable) {
        Thread newThread = this.f8757d.newThread(new baj(runnable, this.f8755b));
        String str = this.f8754a;
        newThread.setName(new StringBuilder(String.valueOf(str).length() + 13).append(str).append("[").append(this.f8756c.getAndIncrement()).append("]").toString());
        return newThread;
    }
}
