package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface ys extends IInterface {
    /* renamed from: a */
    C0827c mo1197a(String str);

    /* renamed from: a */
    void mo1198a();

    /* renamed from: a */
    void mo1199a(C0827c c0827c);

    /* renamed from: a */
    void mo1200a(String str, C0827c c0827c);
}
