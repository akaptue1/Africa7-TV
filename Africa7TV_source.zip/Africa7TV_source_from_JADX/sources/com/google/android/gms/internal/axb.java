package com.google.android.gms.internal;

import android.os.Looper;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C1344a;
import com.google.android.gms.common.internal.C1370c;
import com.google.android.gms.common.internal.C1387t;
import java.lang.ref.WeakReference;

class axb implements C1387t {
    /* renamed from: a */
    private final WeakReference<awz> f8565a;
    /* renamed from: b */
    private final C1344a<?> f8566b;
    /* renamed from: c */
    private final int f8567c;

    public axb(awz awz, C1344a<?> c1344a, int i) {
        this.f8565a = new WeakReference(awz);
        this.f8566b = c1344a;
        this.f8567c = i;
    }

    /* renamed from: a */
    public void mo1669a(ConnectionResult connectionResult) {
        boolean z = false;
        awz awz = (awz) this.f8565a.get();
        if (awz != null) {
            if (Looper.myLooper() == awz.f8543a.f8626g.mo2048c()) {
                z = true;
            }
            C1370c.m10117a(z, (Object) "onReportServiceBinding must be called on the GoogleApiClient handler thread");
            awz.f8544b.lock();
            try {
                if (awz.m12691b(0)) {
                    if (!connectionResult.m9744b()) {
                        awz.m12690b(connectionResult, this.f8566b, this.f8567c);
                    }
                    if (awz.m12698d()) {
                        awz.m12699e();
                    }
                    awz.f8544b.unlock();
                }
            } finally {
                awz.f8544b.unlock();
            }
        }
    }
}
