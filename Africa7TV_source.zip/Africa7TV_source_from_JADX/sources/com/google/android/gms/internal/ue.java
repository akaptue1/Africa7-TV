package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.common.C1357k;
import com.google.android.gms.p034a.C0827c;
import com.google.android.gms.p034a.C0830f;
import com.google.android.gms.p034a.C0831h;
import com.google.android.gms.p034a.C0832i;

public final class ue extends C0831h<ui> {
    /* renamed from: a */
    private static final ue f10434a = new ue();

    private ue() {
        super("com.google.android.gms.ads.adshield.AdShieldCreatorImpl");
    }

    /* renamed from: a */
    public static uf m15349a(String str, Context context, boolean z) {
        if (C1357k.m9833b().mo1597a(context) == 0) {
            uf b = f10434a.m15350b(str, context, z);
            if (b != null) {
                return b;
            }
        }
        return new ud(str, context, z);
    }

    /* renamed from: b */
    private uf m15350b(String str, Context context, boolean z) {
        IBinder a;
        C0827c a2 = C0830f.m6210a((Object) context);
        if (z) {
            try {
                a = ((ui) m6212a(context)).mo2296a(str, a2);
            } catch (RemoteException e) {
                return null;
            } catch (C0832i e2) {
                return null;
            }
        }
        a = ((ui) m6212a(context)).mo2297b(str, a2);
        return ug.m15335a(a);
    }

    /* renamed from: a */
    protected ui m15351a(IBinder iBinder) {
        return uj.m15367a(iBinder);
    }

    /* renamed from: b */
    protected /* synthetic */ Object mo1172b(IBinder iBinder) {
        return m15351a(iBinder);
    }
}
