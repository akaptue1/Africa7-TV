package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.List;

public class fu {
    /* renamed from: a */
    private final List<fp> f9430a = new ArrayList();
    /* renamed from: b */
    private final List<fp> f9431b = new ArrayList();
    /* renamed from: c */
    private final List<fp> f9432c = new ArrayList();
    /* renamed from: d */
    private final List<fp> f9433d = new ArrayList();

    /* renamed from: a */
    public fs m13838a() {
        return new fs(this.f9430a, this.f9431b, this.f9432c, this.f9433d);
    }

    /* renamed from: a */
    public fu m13839a(fp fpVar) {
        this.f9430a.add(fpVar);
        return this;
    }

    /* renamed from: b */
    public fu m13840b(fp fpVar) {
        this.f9431b.add(fpVar);
        return this;
    }

    /* renamed from: c */
    public fu m13841c(fp fpVar) {
        this.f9432c.add(fpVar);
        return this;
    }

    /* renamed from: d */
    public fu m13842d(fp fpVar) {
        this.f9433d.add(fpVar);
        return this;
    }
}
