package com.google.android.gms.internal;

import com.facebook.widget.PlacePickerFragment;
import twitter4j.internal.http.HttpResponseCode;

public final class fa extends rs<fa> {
    /* renamed from: A */
    public Long f9319A;
    /* renamed from: B */
    public String f9320B;
    /* renamed from: C */
    public Long f9321C;
    /* renamed from: D */
    public Long f9322D;
    /* renamed from: E */
    public Long f9323E;
    /* renamed from: F */
    public fd f9324F;
    /* renamed from: G */
    public Long f9325G;
    /* renamed from: H */
    public Long f9326H;
    /* renamed from: I */
    public Long f9327I;
    /* renamed from: J */
    public Long f9328J;
    /* renamed from: K */
    public Long f9329K;
    /* renamed from: L */
    public Long f9330L;
    /* renamed from: M */
    public String f9331M;
    /* renamed from: N */
    public String f9332N;
    /* renamed from: O */
    public Integer f9333O;
    /* renamed from: P */
    public Integer f9334P;
    /* renamed from: Q */
    public Long f9335Q;
    /* renamed from: R */
    public Long f9336R;
    /* renamed from: S */
    public Long f9337S;
    /* renamed from: T */
    public Long f9338T;
    /* renamed from: U */
    public Long f9339U;
    /* renamed from: V */
    public Integer f9340V;
    /* renamed from: W */
    public fb f9341W;
    /* renamed from: X */
    public fb[] f9342X;
    /* renamed from: Y */
    public fc f9343Y;
    /* renamed from: Z */
    public Long f9344Z;
    /* renamed from: a */
    public String f9345a;
    public String aa;
    public Integer ab;
    public Boolean ac;
    public String ad;
    public Long ae;
    public fg af;
    /* renamed from: b */
    public String f9346b;
    /* renamed from: c */
    public Long f9347c;
    /* renamed from: d */
    public Long f9348d;
    /* renamed from: e */
    public Long f9349e;
    /* renamed from: f */
    public Long f9350f;
    /* renamed from: g */
    public Long f9351g;
    /* renamed from: h */
    public Long f9352h;
    /* renamed from: i */
    public Long f9353i;
    /* renamed from: j */
    public Long f9354j;
    /* renamed from: k */
    public Long f9355k;
    /* renamed from: l */
    public Long f9356l;
    /* renamed from: m */
    public String f9357m;
    /* renamed from: n */
    public Long f9358n;
    /* renamed from: o */
    public Long f9359o;
    /* renamed from: p */
    public Long f9360p;
    /* renamed from: q */
    public Long f9361q;
    /* renamed from: r */
    public Long f9362r;
    /* renamed from: s */
    public Long f9363s;
    /* renamed from: t */
    public Long f9364t;
    /* renamed from: u */
    public Long f9365u;
    /* renamed from: v */
    public Long f9366v;
    /* renamed from: w */
    public String f9367w;
    /* renamed from: x */
    public String f9368x;
    /* renamed from: y */
    public Long f9369y;
    /* renamed from: z */
    public Long f9370z;

    public fa() {
        this.f9345a = null;
        this.f9346b = null;
        this.f9347c = null;
        this.f9348d = null;
        this.f9349e = null;
        this.f9350f = null;
        this.f9351g = null;
        this.f9352h = null;
        this.f9353i = null;
        this.f9354j = null;
        this.f9355k = null;
        this.f9356l = null;
        this.f9357m = null;
        this.f9358n = null;
        this.f9359o = null;
        this.f9360p = null;
        this.f9361q = null;
        this.f9362r = null;
        this.f9363s = null;
        this.f9364t = null;
        this.f9365u = null;
        this.f9366v = null;
        this.f9367w = null;
        this.f9368x = null;
        this.f9369y = null;
        this.f9370z = null;
        this.f9319A = null;
        this.f9320B = null;
        this.f9321C = null;
        this.f9322D = null;
        this.f9323E = null;
        this.f9325G = null;
        this.f9326H = null;
        this.f9327I = null;
        this.f9328J = null;
        this.f9329K = null;
        this.f9330L = null;
        this.f9331M = null;
        this.f9332N = null;
        this.f9333O = null;
        this.f9334P = null;
        this.f9335Q = null;
        this.f9336R = null;
        this.f9337S = null;
        this.f9338T = null;
        this.f9339U = null;
        this.f9340V = null;
        this.f9342X = fb.m13788a();
        this.f9344Z = null;
        this.aa = null;
        this.ab = null;
        this.ac = null;
        this.ad = null;
        this.ae = null;
        this.ah = -1;
    }

    /* renamed from: a */
    public static fa m13783a(byte[] bArr) {
        return (fa) rz.m13130a(new fa(), bArr);
    }

    /* renamed from: a */
    public fa m13784a(rp rpVar) {
        while (true) {
            int a = rpVar.m14968a();
            switch (a) {
                case 0:
                    break;
                case 10:
                    this.f9345a = rpVar.m14984i();
                    continue;
                case 18:
                    this.f9346b = rpVar.m14984i();
                    continue;
                case 24:
                    this.f9347c = Long.valueOf(rpVar.m14980f());
                    continue;
                case 32:
                    this.f9348d = Long.valueOf(rpVar.m14980f());
                    continue;
                case 40:
                    this.f9349e = Long.valueOf(rpVar.m14980f());
                    continue;
                case 48:
                    this.f9350f = Long.valueOf(rpVar.m14980f());
                    continue;
                case 56:
                    this.f9351g = Long.valueOf(rpVar.m14980f());
                    continue;
                case 64:
                    this.f9352h = Long.valueOf(rpVar.m14980f());
                    continue;
                case 72:
                    this.f9353i = Long.valueOf(rpVar.m14980f());
                    continue;
                case 80:
                    this.f9354j = Long.valueOf(rpVar.m14980f());
                    continue;
                case 88:
                    this.f9355k = Long.valueOf(rpVar.m14980f());
                    continue;
                case 96:
                    this.f9356l = Long.valueOf(rpVar.m14980f());
                    continue;
                case 106:
                    this.f9357m = rpVar.m14984i();
                    continue;
                case 112:
                    this.f9358n = Long.valueOf(rpVar.m14980f());
                    continue;
                case 120:
                    this.f9359o = Long.valueOf(rpVar.m14980f());
                    continue;
                case 128:
                    this.f9360p = Long.valueOf(rpVar.m14980f());
                    continue;
                case 136:
                    this.f9361q = Long.valueOf(rpVar.m14980f());
                    continue;
                case 144:
                    this.f9362r = Long.valueOf(rpVar.m14980f());
                    continue;
                case 152:
                    this.f9363s = Long.valueOf(rpVar.m14980f());
                    continue;
                case 160:
                    this.f9364t = Long.valueOf(rpVar.m14980f());
                    continue;
                case 168:
                    this.f9344Z = Long.valueOf(rpVar.m14980f());
                    continue;
                case 176:
                    this.f9365u = Long.valueOf(rpVar.m14980f());
                    continue;
                case 184:
                    this.f9366v = Long.valueOf(rpVar.m14980f());
                    continue;
                case 194:
                    this.aa = rpVar.m14984i();
                    continue;
                case HttpResponseCode.OK /*200*/:
                    this.ae = Long.valueOf(rpVar.m14980f());
                    continue;
                case 208:
                    a = rpVar.m14982g();
                    switch (a) {
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                            this.ab = Integer.valueOf(a);
                            break;
                        default:
                            continue;
                    }
                case 218:
                    this.f9367w = rpVar.m14984i();
                    continue;
                case 224:
                    this.ac = Boolean.valueOf(rpVar.m14983h());
                    continue;
                case 234:
                    this.f9368x = rpVar.m14984i();
                    continue;
                case 242:
                    this.ad = rpVar.m14984i();
                    continue;
                case 248:
                    this.f9369y = Long.valueOf(rpVar.m14980f());
                    continue;
                case 256:
                    this.f9370z = Long.valueOf(rpVar.m14980f());
                    continue;
                case 264:
                    this.f9319A = Long.valueOf(rpVar.m14980f());
                    continue;
                case 274:
                    this.f9320B = rpVar.m14984i();
                    continue;
                case 280:
                    this.f9321C = Long.valueOf(rpVar.m14980f());
                    continue;
                case 288:
                    this.f9322D = Long.valueOf(rpVar.m14980f());
                    continue;
                case 296:
                    this.f9323E = Long.valueOf(rpVar.m14980f());
                    continue;
                case 306:
                    if (this.f9324F == null) {
                        this.f9324F = new fd();
                    }
                    rpVar.m14970a(this.f9324F);
                    continue;
                case 312:
                    this.f9325G = Long.valueOf(rpVar.m14980f());
                    continue;
                case 320:
                    this.f9326H = Long.valueOf(rpVar.m14980f());
                    continue;
                case 328:
                    this.f9327I = Long.valueOf(rpVar.m14980f());
                    continue;
                case 336:
                    this.f9328J = Long.valueOf(rpVar.m14980f());
                    continue;
                case 346:
                    int b = sc.m15128b(rpVar, 346);
                    a = this.f9342X == null ? 0 : this.f9342X.length;
                    Object obj = new fb[(b + a)];
                    if (a != 0) {
                        System.arraycopy(this.f9342X, 0, obj, 0, a);
                    }
                    while (a < obj.length - 1) {
                        obj[a] = new fb();
                        rpVar.m14970a(obj[a]);
                        rpVar.m14968a();
                        a++;
                    }
                    obj[a] = new fb();
                    rpVar.m14970a(obj[a]);
                    this.f9342X = obj;
                    continue;
                case 352:
                    this.f9329K = Long.valueOf(rpVar.m14980f());
                    continue;
                case 360:
                    this.f9330L = Long.valueOf(rpVar.m14980f());
                    continue;
                case 370:
                    this.f9331M = rpVar.m14984i();
                    continue;
                case 378:
                    this.f9332N = rpVar.m14984i();
                    continue;
                case 384:
                    a = rpVar.m14982g();
                    switch (a) {
                        case 0:
                        case 1:
                        case 2:
                        case PlacePickerFragment.DEFAULT_RADIUS_IN_METERS /*1000*/:
                            this.f9333O = Integer.valueOf(a);
                            break;
                        default:
                            continue;
                    }
                case 392:
                    a = rpVar.m14982g();
                    switch (a) {
                        case 0:
                        case 1:
                        case 2:
                        case PlacePickerFragment.DEFAULT_RADIUS_IN_METERS /*1000*/:
                            this.f9334P = Integer.valueOf(a);
                            break;
                        default:
                            continue;
                    }
                case 402:
                    if (this.f9341W == null) {
                        this.f9341W = new fb();
                    }
                    rpVar.m14970a(this.f9341W);
                    continue;
                case 408:
                    this.f9335Q = Long.valueOf(rpVar.m14980f());
                    continue;
                case 416:
                    this.f9336R = Long.valueOf(rpVar.m14980f());
                    continue;
                case 424:
                    this.f9337S = Long.valueOf(rpVar.m14980f());
                    continue;
                case 432:
                    this.f9338T = Long.valueOf(rpVar.m14980f());
                    continue;
                case 440:
                    this.f9339U = Long.valueOf(rpVar.m14980f());
                    continue;
                case 448:
                    a = rpVar.m14982g();
                    switch (a) {
                        case 0:
                        case 1:
                        case 2:
                        case PlacePickerFragment.DEFAULT_RADIUS_IN_METERS /*1000*/:
                            this.f9340V = Integer.valueOf(a);
                            break;
                        default:
                            continue;
                    }
                case 458:
                    if (this.f9343Y == null) {
                        this.f9343Y = new fc();
                    }
                    rpVar.m14970a(this.f9343Y);
                    continue;
                case 1610:
                    if (this.af == null) {
                        this.af = new fg();
                    }
                    rpVar.m14970a(this.af);
                    continue;
                default:
                    if (!super.m13673a(rpVar, a)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    /* renamed from: a */
    public void mo2082a(rq rqVar) {
        if (this.f9345a != null) {
            rqVar.m15035a(1, this.f9345a);
        }
        if (this.f9346b != null) {
            rqVar.m15035a(2, this.f9346b);
        }
        if (this.f9347c != null) {
            rqVar.m15043b(3, this.f9347c.longValue());
        }
        if (this.f9348d != null) {
            rqVar.m15043b(4, this.f9348d.longValue());
        }
        if (this.f9349e != null) {
            rqVar.m15043b(5, this.f9349e.longValue());
        }
        if (this.f9350f != null) {
            rqVar.m15043b(6, this.f9350f.longValue());
        }
        if (this.f9351g != null) {
            rqVar.m15043b(7, this.f9351g.longValue());
        }
        if (this.f9352h != null) {
            rqVar.m15043b(8, this.f9352h.longValue());
        }
        if (this.f9353i != null) {
            rqVar.m15043b(9, this.f9353i.longValue());
        }
        if (this.f9354j != null) {
            rqVar.m15043b(10, this.f9354j.longValue());
        }
        if (this.f9355k != null) {
            rqVar.m15043b(11, this.f9355k.longValue());
        }
        if (this.f9356l != null) {
            rqVar.m15043b(12, this.f9356l.longValue());
        }
        if (this.f9357m != null) {
            rqVar.m15035a(13, this.f9357m);
        }
        if (this.f9358n != null) {
            rqVar.m15043b(14, this.f9358n.longValue());
        }
        if (this.f9359o != null) {
            rqVar.m15043b(15, this.f9359o.longValue());
        }
        if (this.f9360p != null) {
            rqVar.m15043b(16, this.f9360p.longValue());
        }
        if (this.f9361q != null) {
            rqVar.m15043b(17, this.f9361q.longValue());
        }
        if (this.f9362r != null) {
            rqVar.m15043b(18, this.f9362r.longValue());
        }
        if (this.f9363s != null) {
            rqVar.m15043b(19, this.f9363s.longValue());
        }
        if (this.f9364t != null) {
            rqVar.m15043b(20, this.f9364t.longValue());
        }
        if (this.f9344Z != null) {
            rqVar.m15043b(21, this.f9344Z.longValue());
        }
        if (this.f9365u != null) {
            rqVar.m15043b(22, this.f9365u.longValue());
        }
        if (this.f9366v != null) {
            rqVar.m15043b(23, this.f9366v.longValue());
        }
        if (this.aa != null) {
            rqVar.m15035a(24, this.aa);
        }
        if (this.ae != null) {
            rqVar.m15043b(25, this.ae.longValue());
        }
        if (this.ab != null) {
            rqVar.m15032a(26, this.ab.intValue());
        }
        if (this.f9367w != null) {
            rqVar.m15035a(27, this.f9367w);
        }
        if (this.ac != null) {
            rqVar.m15036a(28, this.ac.booleanValue());
        }
        if (this.f9368x != null) {
            rqVar.m15035a(29, this.f9368x);
        }
        if (this.ad != null) {
            rqVar.m15035a(30, this.ad);
        }
        if (this.f9369y != null) {
            rqVar.m15043b(31, this.f9369y.longValue());
        }
        if (this.f9370z != null) {
            rqVar.m15043b(32, this.f9370z.longValue());
        }
        if (this.f9319A != null) {
            rqVar.m15043b(33, this.f9319A.longValue());
        }
        if (this.f9320B != null) {
            rqVar.m15035a(34, this.f9320B);
        }
        if (this.f9321C != null) {
            rqVar.m15043b(35, this.f9321C.longValue());
        }
        if (this.f9322D != null) {
            rqVar.m15043b(36, this.f9322D.longValue());
        }
        if (this.f9323E != null) {
            rqVar.m15043b(37, this.f9323E.longValue());
        }
        if (this.f9324F != null) {
            rqVar.m15034a(38, this.f9324F);
        }
        if (this.f9325G != null) {
            rqVar.m15043b(39, this.f9325G.longValue());
        }
        if (this.f9326H != null) {
            rqVar.m15043b(40, this.f9326H.longValue());
        }
        if (this.f9327I != null) {
            rqVar.m15043b(41, this.f9327I.longValue());
        }
        if (this.f9328J != null) {
            rqVar.m15043b(42, this.f9328J.longValue());
        }
        if (this.f9342X != null && this.f9342X.length > 0) {
            for (rz rzVar : this.f9342X) {
                if (rzVar != null) {
                    rqVar.m15034a(43, rzVar);
                }
            }
        }
        if (this.f9329K != null) {
            rqVar.m15043b(44, this.f9329K.longValue());
        }
        if (this.f9330L != null) {
            rqVar.m15043b(45, this.f9330L.longValue());
        }
        if (this.f9331M != null) {
            rqVar.m15035a(46, this.f9331M);
        }
        if (this.f9332N != null) {
            rqVar.m15035a(47, this.f9332N);
        }
        if (this.f9333O != null) {
            rqVar.m15032a(48, this.f9333O.intValue());
        }
        if (this.f9334P != null) {
            rqVar.m15032a(49, this.f9334P.intValue());
        }
        if (this.f9341W != null) {
            rqVar.m15034a(50, this.f9341W);
        }
        if (this.f9335Q != null) {
            rqVar.m15043b(51, this.f9335Q.longValue());
        }
        if (this.f9336R != null) {
            rqVar.m15043b(52, this.f9336R.longValue());
        }
        if (this.f9337S != null) {
            rqVar.m15043b(53, this.f9337S.longValue());
        }
        if (this.f9338T != null) {
            rqVar.m15043b(54, this.f9338T.longValue());
        }
        if (this.f9339U != null) {
            rqVar.m15043b(55, this.f9339U.longValue());
        }
        if (this.f9340V != null) {
            rqVar.m15032a(56, this.f9340V.intValue());
        }
        if (this.f9343Y != null) {
            rqVar.m15034a(57, this.f9343Y);
        }
        if (this.af != null) {
            rqVar.m15034a(201, this.af);
        }
        super.mo2082a(rqVar);
    }

    /* renamed from: b */
    protected int mo2083b() {
        int b = super.mo2083b();
        if (this.f9345a != null) {
            b += rq.m15006b(1, this.f9345a);
        }
        if (this.f9346b != null) {
            b += rq.m15006b(2, this.f9346b);
        }
        if (this.f9347c != null) {
            b += rq.m15018e(3, this.f9347c.longValue());
        }
        if (this.f9348d != null) {
            b += rq.m15018e(4, this.f9348d.longValue());
        }
        if (this.f9349e != null) {
            b += rq.m15018e(5, this.f9349e.longValue());
        }
        if (this.f9350f != null) {
            b += rq.m15018e(6, this.f9350f.longValue());
        }
        if (this.f9351g != null) {
            b += rq.m15018e(7, this.f9351g.longValue());
        }
        if (this.f9352h != null) {
            b += rq.m15018e(8, this.f9352h.longValue());
        }
        if (this.f9353i != null) {
            b += rq.m15018e(9, this.f9353i.longValue());
        }
        if (this.f9354j != null) {
            b += rq.m15018e(10, this.f9354j.longValue());
        }
        if (this.f9355k != null) {
            b += rq.m15018e(11, this.f9355k.longValue());
        }
        if (this.f9356l != null) {
            b += rq.m15018e(12, this.f9356l.longValue());
        }
        if (this.f9357m != null) {
            b += rq.m15006b(13, this.f9357m);
        }
        if (this.f9358n != null) {
            b += rq.m15018e(14, this.f9358n.longValue());
        }
        if (this.f9359o != null) {
            b += rq.m15018e(15, this.f9359o.longValue());
        }
        if (this.f9360p != null) {
            b += rq.m15018e(16, this.f9360p.longValue());
        }
        if (this.f9361q != null) {
            b += rq.m15018e(17, this.f9361q.longValue());
        }
        if (this.f9362r != null) {
            b += rq.m15018e(18, this.f9362r.longValue());
        }
        if (this.f9363s != null) {
            b += rq.m15018e(19, this.f9363s.longValue());
        }
        if (this.f9364t != null) {
            b += rq.m15018e(20, this.f9364t.longValue());
        }
        if (this.f9344Z != null) {
            b += rq.m15018e(21, this.f9344Z.longValue());
        }
        if (this.f9365u != null) {
            b += rq.m15018e(22, this.f9365u.longValue());
        }
        if (this.f9366v != null) {
            b += rq.m15018e(23, this.f9366v.longValue());
        }
        if (this.aa != null) {
            b += rq.m15006b(24, this.aa);
        }
        if (this.ae != null) {
            b += rq.m15018e(25, this.ae.longValue());
        }
        if (this.ab != null) {
            b += rq.m15004b(26, this.ab.intValue());
        }
        if (this.f9367w != null) {
            b += rq.m15006b(27, this.f9367w);
        }
        if (this.ac != null) {
            b += rq.m15007b(28, this.ac.booleanValue());
        }
        if (this.f9368x != null) {
            b += rq.m15006b(29, this.f9368x);
        }
        if (this.ad != null) {
            b += rq.m15006b(30, this.ad);
        }
        if (this.f9369y != null) {
            b += rq.m15018e(31, this.f9369y.longValue());
        }
        if (this.f9370z != null) {
            b += rq.m15018e(32, this.f9370z.longValue());
        }
        if (this.f9319A != null) {
            b += rq.m15018e(33, this.f9319A.longValue());
        }
        if (this.f9320B != null) {
            b += rq.m15006b(34, this.f9320B);
        }
        if (this.f9321C != null) {
            b += rq.m15018e(35, this.f9321C.longValue());
        }
        if (this.f9322D != null) {
            b += rq.m15018e(36, this.f9322D.longValue());
        }
        if (this.f9323E != null) {
            b += rq.m15018e(37, this.f9323E.longValue());
        }
        if (this.f9324F != null) {
            b += rq.m15011c(38, this.f9324F);
        }
        if (this.f9325G != null) {
            b += rq.m15018e(39, this.f9325G.longValue());
        }
        if (this.f9326H != null) {
            b += rq.m15018e(40, this.f9326H.longValue());
        }
        if (this.f9327I != null) {
            b += rq.m15018e(41, this.f9327I.longValue());
        }
        if (this.f9328J != null) {
            b += rq.m15018e(42, this.f9328J.longValue());
        }
        if (this.f9342X != null && this.f9342X.length > 0) {
            int i = b;
            for (rz rzVar : this.f9342X) {
                if (rzVar != null) {
                    i += rq.m15011c(43, rzVar);
                }
            }
            b = i;
        }
        if (this.f9329K != null) {
            b += rq.m15018e(44, this.f9329K.longValue());
        }
        if (this.f9330L != null) {
            b += rq.m15018e(45, this.f9330L.longValue());
        }
        if (this.f9331M != null) {
            b += rq.m15006b(46, this.f9331M);
        }
        if (this.f9332N != null) {
            b += rq.m15006b(47, this.f9332N);
        }
        if (this.f9333O != null) {
            b += rq.m15004b(48, this.f9333O.intValue());
        }
        if (this.f9334P != null) {
            b += rq.m15004b(49, this.f9334P.intValue());
        }
        if (this.f9341W != null) {
            b += rq.m15011c(50, this.f9341W);
        }
        if (this.f9335Q != null) {
            b += rq.m15018e(51, this.f9335Q.longValue());
        }
        if (this.f9336R != null) {
            b += rq.m15018e(52, this.f9336R.longValue());
        }
        if (this.f9337S != null) {
            b += rq.m15018e(53, this.f9337S.longValue());
        }
        if (this.f9338T != null) {
            b += rq.m15018e(54, this.f9338T.longValue());
        }
        if (this.f9339U != null) {
            b += rq.m15018e(55, this.f9339U.longValue());
        }
        if (this.f9340V != null) {
            b += rq.m15004b(56, this.f9340V.intValue());
        }
        if (this.f9343Y != null) {
            b += rq.m15011c(57, this.f9343Y);
        }
        return this.af != null ? b + rq.m15011c(201, this.af) : b;
    }

    /* renamed from: b */
    public /* synthetic */ rz mo2084b(rp rpVar) {
        return m13784a(rpVar);
    }
}
