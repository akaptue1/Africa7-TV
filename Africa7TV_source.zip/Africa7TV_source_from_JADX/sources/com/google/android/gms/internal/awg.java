package com.google.android.gms.internal;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1235z;
import com.google.android.gms.common.api.Status;

public class awg<R extends C1223y> extends Handler {
    public awg() {
        this(Looper.getMainLooper());
    }

    public awg(Looper looper) {
        super(looper);
    }

    /* renamed from: a */
    public void m12554a() {
        removeMessages(2);
    }

    /* renamed from: a */
    public void m12555a(C1235z<? super R> c1235z, R r) {
        sendMessage(obtainMessage(1, new Pair(c1235z, r)));
    }

    /* renamed from: b */
    protected void m12556b(C1235z<? super R> c1235z, R r) {
        try {
            c1235z.mo1512a(r);
        } catch (RuntimeException e) {
            awe.m8757c(r);
            throw e;
        }
    }

    public void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                Pair pair = (Pair) message.obj;
                m12556b((C1235z) pair.first, (C1223y) pair.second);
                return;
            case 2:
                ((awe) message.obj).m8764d(Status.f6827d);
                return;
            default:
                Log.wtf("BasePendingResult", "Don't know how to handle message: " + message.what, new Exception());
                return;
        }
    }
}
