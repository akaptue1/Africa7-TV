package com.google.android.gms.internal;

public interface aqp<D, R> {
    /* renamed from: a */
    R mo1831a(D d);
}
