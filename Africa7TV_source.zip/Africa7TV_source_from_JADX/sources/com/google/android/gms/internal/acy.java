package com.google.android.gms.internal;

interface acy {
    /* renamed from: a */
    void mo1696a(acz acz);
}
