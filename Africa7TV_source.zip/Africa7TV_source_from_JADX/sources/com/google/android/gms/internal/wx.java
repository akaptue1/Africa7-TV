package com.google.android.gms.internal;

import java.util.Comparator;

public class wx implements Comparator<wm> {
    /* renamed from: a */
    final /* synthetic */ ww f10637a;

    public wx(ww wwVar) {
        this.f10637a = wwVar;
    }

    /* renamed from: a */
    public int m15583a(wm wmVar, wm wmVar2) {
        if (wmVar.m15551b() < wmVar2.m15551b()) {
            return -1;
        }
        if (wmVar.m15551b() > wmVar2.m15551b()) {
            return 1;
        }
        if (wmVar.m15550a() < wmVar2.m15550a()) {
            return -1;
        }
        if (wmVar.m15550a() > wmVar2.m15550a()) {
            return 1;
        }
        float d = (wmVar.m15553d() - wmVar.m15551b()) * (wmVar.m15552c() - wmVar.m15550a());
        float d2 = (wmVar2.m15553d() - wmVar2.m15551b()) * (wmVar2.m15552c() - wmVar2.m15550a());
        return d <= d2 ? d < d2 ? 1 : 0 : -1;
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m15583a((wm) obj, (wm) obj2);
    }
}
