package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;

public class cx implements bhb {
    public gb<?> a_(bff bff, gb<?>... gbVarArr) {
        boolean z = true;
        C1370c.m10120b(gbVarArr != null);
        if (gbVarArr.length != 0) {
            z = false;
        }
        C1370c.m10120b(z);
        return new gn("5.02");
    }
}
