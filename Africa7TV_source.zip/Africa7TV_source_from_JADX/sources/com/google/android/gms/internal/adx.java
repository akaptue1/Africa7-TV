package com.google.android.gms.internal;

class adx implements adj {
    /* renamed from: a */
    final /* synthetic */ adi f7332a;
    /* renamed from: b */
    final /* synthetic */ adw f7333b;

    adx(adw adw, adi adi) {
        this.f7333b = adw;
        this.f7332a = adi;
    }

    /* renamed from: a */
    public void mo1699a() {
        aoq.f8164a.postDelayed(new ady(this), (long) aeg.f7349b);
    }
}
