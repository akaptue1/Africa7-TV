package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences.Editor;

final class anz extends aog {
    /* renamed from: a */
    final /* synthetic */ Context f8128a;
    /* renamed from: b */
    final /* synthetic */ boolean f8129b;

    anz(Context context, boolean z) {
        this.f8128a = context;
        this.f8129b = z;
        super();
    }

    /* renamed from: a */
    public void mo1147a() {
        Editor edit = anq.m11654a(this.f8128a).edit();
        edit.putBoolean("auto_collect_location", this.f8129b);
        edit.apply();
    }
}
