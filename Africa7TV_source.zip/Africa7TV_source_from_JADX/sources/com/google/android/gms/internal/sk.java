package com.google.android.gms.internal;

import android.support.customtabs.CustomTabsServiceConnection;
import java.lang.ref.WeakReference;

public class sk extends CustomTabsServiceConnection {
    /* renamed from: a */
    private WeakReference<sl> f10320a;

    public sk(sl slVar) {
        this.f10320a = new WeakReference(slVar);
    }
}
