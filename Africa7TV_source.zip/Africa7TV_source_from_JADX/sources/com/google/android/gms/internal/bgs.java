package com.google.android.gms.internal;

import java.util.concurrent.ThreadFactory;

final class bgs implements ThreadFactory {
    bgs() {
    }

    public Thread newThread(Runnable runnable) {
        return new Thread(runnable, "google-tag-manager-background-thread");
    }
}
