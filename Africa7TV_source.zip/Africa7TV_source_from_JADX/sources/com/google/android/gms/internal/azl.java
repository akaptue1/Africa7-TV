package com.google.android.gms.internal;

final class azl extends azj<Long> {
    azl(String str, Long l) {
        super(str, l);
    }

    /* renamed from: a */
    protected /* synthetic */ Object mo2057a(String str) {
        return m12968b(str);
    }

    /* renamed from: b */
    protected Long m12968b(String str) {
        return null.m12978a(this.a, (Long) this.b);
    }
}
