package com.google.android.gms.internal;

class ajv implements app<adi> {
    /* renamed from: a */
    final /* synthetic */ ajs f7689a;

    ajv(ajs ajs) {
        this.f7689a = ajs;
    }

    /* renamed from: a */
    public void m11274a(adi adi) {
        adi.mo1702a(this.f7689a.f7679g, this.f7689a.f7679g, this.f7689a.f7679g, this.f7689a.f7679g, false, null, null, null, null);
    }

    /* renamed from: a */
    public /* synthetic */ void mo1310a(Object obj) {
        m11274a((adi) obj);
    }
}
