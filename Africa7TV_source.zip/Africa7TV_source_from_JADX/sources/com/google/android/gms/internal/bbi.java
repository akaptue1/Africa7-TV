package com.google.android.gms.internal;

import java.util.Comparator;

final class bbi implements Comparator<byte[]> {
    bbi() {
    }

    /* renamed from: a */
    public int m13070a(byte[] bArr, byte[] bArr2) {
        return bArr.length - bArr2.length;
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m13070a((byte[]) obj, (byte[]) obj2);
    }
}
