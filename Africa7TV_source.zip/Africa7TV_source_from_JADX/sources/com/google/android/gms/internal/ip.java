package com.google.android.gms.internal;

import java.util.List;
import java.util.Map;

class ip implements is {
    /* renamed from: a */
    final /* synthetic */ iw f9718a;
    /* renamed from: b */
    final /* synthetic */ ij f9719b;

    ip(ij ijVar, iw iwVar) {
        this.f9719b = ijVar;
        this.f9718a = iwVar;
    }

    /* renamed from: a */
    public void mo2208a(Map<String, Object> map) {
        String str = (String) map.get("s");
        if (str.equals("ok")) {
            Map map2 = (Map) map.get("d");
            if (map2.containsKey("w")) {
                this.f9719b.m14169a((List) map2.get("w"), this.f9718a.f9735b);
            }
        }
        if (((iw) this.f9719b.f9694p.get(this.f9718a.m14246a())) != this.f9718a) {
            return;
        }
        if (str.equals("ok")) {
            this.f9718a.f9734a.mo2443a(null, null);
            return;
        }
        this.f9719b.m14154a(this.f9718a.m14246a());
        this.f9718a.f9734a.mo2443a(str, (String) map.get("d"));
    }
}
