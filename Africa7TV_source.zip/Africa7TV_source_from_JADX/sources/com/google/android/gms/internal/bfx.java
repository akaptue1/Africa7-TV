package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.tagmanager.C1575q;
import com.google.android.gms.tagmanager.C1580h;

final class bfx implements bgl {
    bfx() {
    }

    /* renamed from: a */
    public bfw mo2122a(Context context, C1575q c1575q, C1580h c1580h) {
        return new bfw(context, c1575q, c1580h, new bgv(context), bgq.m13563a(), bgq.m13564b(), bew.m13429a(), new bgi(context));
    }
}
