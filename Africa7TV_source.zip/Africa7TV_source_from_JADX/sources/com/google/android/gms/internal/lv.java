package com.google.android.gms.internal;

import java.lang.reflect.Field;

enum lv extends ls {
    lv(String str, int i) {
        super(str, i);
    }

    /* renamed from: a */
    public String mo2231a(Field field) {
        return ls.m14463b(ls.m14464b(field.getName(), " "));
    }
}
