package com.google.android.gms.internal;

public class kk extends RuntimeException {
    public kk(String str) {
        super(str);
    }

    public kk(String str, Throwable th) {
        super(str, th);
    }
}
