package com.google.android.gms.internal;

import android.content.SharedPreferences;

final class xh extends xc<String> {
    xh(int i, String str, String str2) {
        super(i, str, str2);
    }

    /* renamed from: a */
    public /* synthetic */ Object mo2315a(SharedPreferences sharedPreferences) {
        return m15614b(sharedPreferences);
    }

    /* renamed from: b */
    public String m15614b(SharedPreferences sharedPreferences) {
        return sharedPreferences.getString(m15602a(), (String) m15603b());
    }
}
