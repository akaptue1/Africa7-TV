package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;

public abstract class dv extends bhd {
    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        boolean z = true;
        C1370c.m10120b(gbVarArr != null);
        if (gbVarArr.length != 2) {
            z = false;
        }
        C1370c.m10120b(z);
        try {
            double b = bhc.m13592b(gbVarArr[0]);
            double b2 = bhc.m13592b(gbVarArr[1]);
            return (Double.isNaN(b) || Double.isNaN(b2)) ? new ge(Boolean.valueOf(false)) : new ge(Boolean.valueOf(mo2127a(b, b2)));
        } catch (IllegalArgumentException e) {
            return new ge(Boolean.valueOf(false));
        }
    }

    /* renamed from: a */
    protected abstract boolean mo2127a(double d, double d2);
}
