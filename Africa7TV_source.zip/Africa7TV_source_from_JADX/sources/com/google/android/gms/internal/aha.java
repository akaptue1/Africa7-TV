package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class aha implements OnClickListener {
    /* renamed from: a */
    final /* synthetic */ agy f7539a;

    aha(agy agy) {
        this.f7539a = agy;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        this.f7539a.m11100b("Operation denied by user.");
    }
}
