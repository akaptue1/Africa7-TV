package com.google.android.gms.internal;

import java.util.Map;

class vi implements aau {
    /* renamed from: a */
    final /* synthetic */ vc f10497a;

    vi(vc vcVar) {
        this.f10497a = vcVar;
    }

    /* renamed from: a */
    public void mo1150a(arh arh, Map<String, String> map) {
        if (this.f10497a.f10485a.m15410a((Map) map)) {
            this.f10497a.f10485a.m15407a(this.f10497a, (Map) map);
        }
    }
}
