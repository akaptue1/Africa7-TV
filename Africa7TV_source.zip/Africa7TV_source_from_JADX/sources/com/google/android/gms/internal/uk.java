package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.p034a.C0827c;

class uk implements ui {
    /* renamed from: a */
    private IBinder f10436a;

    uk(IBinder iBinder) {
        this.f10436a = iBinder;
    }

    /* renamed from: a */
    public IBinder mo2296a(String str, C0827c c0827c) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.ads.adshield.internal.IAdShieldCreator");
            obtain.writeString(str);
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            this.f10436a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
            IBinder readStrongBinder = obtain2.readStrongBinder();
            return readStrongBinder;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    public IBinder asBinder() {
        return this.f10436a;
    }

    /* renamed from: b */
    public IBinder mo2297b(String str, C0827c c0827c) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.ads.adshield.internal.IAdShieldCreator");
            obtain.writeString(str);
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            this.f10436a.transact(2, obtain, obtain2, 0);
            obtain2.readException();
            IBinder readStrongBinder = obtain2.readStrongBinder();
            return readStrongBinder;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }
}
