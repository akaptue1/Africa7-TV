package com.google.android.gms.internal;

import java.util.HashMap;
import java.util.Map;

@akw
public class xy {
    /* renamed from: a */
    private final Map<String, xx> f10726a = new HashMap();
    /* renamed from: b */
    private final xz f10727b;

    public xy(xz xzVar) {
        this.f10727b = xzVar;
    }

    /* renamed from: a */
    public xz m15656a() {
        return this.f10727b;
    }

    /* renamed from: a */
    public void m15657a(String str, xx xxVar) {
        this.f10726a.put(str, xxVar);
    }

    /* renamed from: a */
    public void m15658a(String str, String str2, long j) {
        xs.m15645a(this.f10727b, (xx) this.f10726a.get(str2), j, str);
        this.f10726a.put(str, xs.m15644a(this.f10727b, j));
    }
}
