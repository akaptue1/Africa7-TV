package com.google.android.gms.internal;

final class xv extends xt {
    xv() {
    }

    /* renamed from: a */
    public String mo2316a(String str, String str2) {
        return str != null ? str : str2;
    }
}
