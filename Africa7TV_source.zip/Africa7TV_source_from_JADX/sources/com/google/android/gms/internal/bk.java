package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;

public class bk extends bhd {
    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        C1370c.m10120b(gbVarArr != null);
        boolean z = gbVarArr.length > 0 && gbVarArr.length <= 3;
        C1370c.m10120b(z);
        C1370c.m10120b(gbVarArr[0] instanceof gn);
        String str = (String) ((gn) gbVarArr[0]).mo2133b();
        int c = (int) bhc.m13594c(gbVarArr.length < 2 ? gh.f9460e : gbVarArr[1]);
        int length = str.length();
        if (gbVarArr.length == 3 && gbVarArr[2] != gh.f9460e) {
            length = (int) bhc.m13594c(gp.m13913a(bff, gbVarArr[2]));
        }
        c = Math.min(Math.max(c, 0), str.length());
        length = Math.min(Math.max(length, 0), str.length());
        return new gn(str.substring(Math.min(c, length), Math.max(c, length)));
    }
}
