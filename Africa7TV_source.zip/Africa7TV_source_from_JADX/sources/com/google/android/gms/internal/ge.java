package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class ge extends gb<Boolean> {
    /* renamed from: c */
    private static final Map<String, bhb> f9451c;
    /* renamed from: b */
    private final Boolean f9452b;

    static {
        Map hashMap = new HashMap();
        hashMap.put("hasOwnProperty", al.f7794a);
        hashMap.put("toString", new bo());
        f9451c = Collections.unmodifiableMap(hashMap);
    }

    public ge(Boolean bool) {
        C1370c.m10112a((Object) bool);
        this.f9452b = bool;
    }

    /* renamed from: b */
    public /* synthetic */ Object mo2133b() {
        return m13867d();
    }

    /* renamed from: c */
    public boolean mo2134c(String str) {
        return f9451c.containsKey(str);
    }

    /* renamed from: d */
    public bhb mo2135d(String str) {
        if (mo2134c(str)) {
            return (bhb) f9451c.get(str);
        }
        throw new IllegalStateException(new StringBuilder(String.valueOf(str).length() + 54).append("Native Method ").append(str).append(" is not defined for type BooleanWrapper.").toString());
    }

    /* renamed from: d */
    public Boolean m13867d() {
        return this.f9452b;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ge)) {
            return false;
        }
        return ((Boolean) ((ge) obj).mo2133b()) == this.f9452b;
    }

    public String toString() {
        return this.f9452b.toString();
    }
}
