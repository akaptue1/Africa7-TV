package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;

class bej implements beh {
    /* renamed from: a */
    private IBinder f9034a;

    bej(IBinder iBinder) {
        this.f9034a = iBinder;
    }

    /* renamed from: a */
    public void mo2099a(boolean z, String str) {
        int i = 1;
        Parcel obtain = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.tagmanager.internal.ITagManagerLoadContainerCallback");
            if (!z) {
                i = 0;
            }
            obtain.writeInt(i);
            obtain.writeString(str);
            this.f9034a.transact(1, obtain, null, 1);
        } finally {
            obtain.recycle();
        }
    }

    public IBinder asBinder() {
        return this.f9034a;
    }
}
