package com.google.android.gms.internal;

interface azp {
    /* renamed from: a */
    Boolean m12975a(String str, Boolean bool);

    /* renamed from: a */
    Float m12976a(String str, Float f);

    /* renamed from: a */
    Integer m12977a(String str, Integer num);

    /* renamed from: a */
    Long m12978a(String str, Long l);

    /* renamed from: a */
    String m12979a(String str, String str2);
}
