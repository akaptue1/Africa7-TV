package com.google.android.gms.internal;

public interface kd {
    /* renamed from: a */
    void mo2227a(Thread thread, String str);
}
