package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.C1043e;
import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;

@akw
public class ww {
    /* renamed from: a */
    private final wn f10630a;
    /* renamed from: b */
    private final int f10631b;
    /* renamed from: c */
    private String f10632c;
    /* renamed from: d */
    private String f10633d;
    /* renamed from: e */
    private final boolean f10634e = false;
    /* renamed from: f */
    private final int f10635f;
    /* renamed from: g */
    private final int f10636g;

    public ww(int i, int i2, int i3) {
        this.f10631b = i;
        if (i2 > 64 || i2 < 0) {
            this.f10635f = 64;
        } else {
            this.f10635f = i2;
        }
        if (i3 < 1) {
            this.f10636g = 1;
        } else {
            this.f10636g = i3;
        }
        this.f10630a = new wv(this.f10635f);
    }

    /* renamed from: a */
    String m15580a(String str, char c) {
        StringBuilder stringBuilder = new StringBuilder(str);
        Object obj = null;
        int i = 1;
        while (i + 2 <= stringBuilder.length()) {
            if (stringBuilder.charAt(i) == '\'') {
                if (stringBuilder.charAt(i - 1) == c || !((stringBuilder.charAt(i + 1) == 's' || stringBuilder.charAt(i + 1) == 'S') && (i + 2 == stringBuilder.length() || stringBuilder.charAt(i + 2) == c))) {
                    stringBuilder.setCharAt(i, c);
                } else {
                    stringBuilder.insert(i, c);
                    i += 2;
                }
                obj = 1;
            }
            i++;
        }
        return obj != null ? stringBuilder.toString() : null;
    }

    /* renamed from: a */
    public String m15581a(ArrayList<String> arrayList, ArrayList<wm> arrayList2) {
        Collections.sort(arrayList2, new wx(this));
        HashSet hashSet = new HashSet();
        int i = 0;
        while (i < arrayList2.size() && m15582a(Normalizer.normalize((CharSequence) arrayList.get(((wm) arrayList2.get(i)).m15554e()), Form.NFKC).toLowerCase(Locale.US), hashSet)) {
            i++;
        }
        wq wqVar = new wq();
        this.f10632c = "";
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            try {
                wqVar.m15561a(this.f10630a.mo2313a((String) it.next()));
            } catch (Throwable e) {
                C1043e.m7798b("Error while writing hash to byteStream", e);
            }
        }
        return wqVar.toString();
    }

    /* renamed from: a */
    boolean m15582a(String str, HashSet<String> hashSet) {
        String[] split = str.split("\n");
        if (split.length == 0) {
            return true;
        }
        for (String str2 : split) {
            String str22;
            String a;
            String[] a2;
            int i;
            Object obj;
            int i2;
            boolean z;
            if (str22.indexOf("'") != -1) {
                a = m15580a(str22, ' ');
                if (a != null) {
                    this.f10633d = a;
                    a2 = wr.m15565a(a, true);
                    if (a2.length < this.f10636g) {
                        for (i = 0; i < a2.length; i++) {
                            obj = "";
                            for (i2 = 0; i2 < this.f10636g; i2++) {
                                if (i + i2 >= a2.length) {
                                    z = false;
                                    break;
                                }
                                if (i2 > 0) {
                                    obj = String.valueOf(obj).concat(" ");
                                }
                                String valueOf = String.valueOf(obj);
                                str22 = String.valueOf(a2[i + i2]);
                                obj = str22.length() == 0 ? valueOf.concat(str22) : new String(valueOf);
                            }
                            z = true;
                            if (!z) {
                                break;
                            }
                            hashSet.add(obj);
                            if (hashSet.size() < this.f10631b) {
                                return false;
                            }
                        }
                        if (hashSet.size() >= this.f10631b) {
                            return false;
                        }
                    }
                }
            }
            a = str22;
            a2 = wr.m15565a(a, true);
            if (a2.length < this.f10636g) {
                for (i = 0; i < a2.length; i++) {
                    obj = "";
                    for (i2 = 0; i2 < this.f10636g; i2++) {
                        if (i + i2 >= a2.length) {
                            z = false;
                            break;
                        }
                        if (i2 > 0) {
                            obj = String.valueOf(obj).concat(" ");
                        }
                        String valueOf2 = String.valueOf(obj);
                        str22 = String.valueOf(a2[i + i2]);
                        if (str22.length() == 0) {
                        }
                    }
                    z = true;
                    if (!z) {
                        break;
                    }
                    hashSet.add(obj);
                    if (hashSet.size() < this.f10631b) {
                        return false;
                    }
                }
                if (hashSet.size() >= this.f10631b) {
                    return false;
                }
            }
        }
        return true;
    }
}
