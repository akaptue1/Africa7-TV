package com.google.android.gms.internal;

import java.lang.reflect.Type;

class np implements on<T> {
    /* renamed from: a */
    final /* synthetic */ mh f10002a;
    /* renamed from: b */
    final /* synthetic */ Type f10003b;
    /* renamed from: c */
    final /* synthetic */ no f10004c;

    np(no noVar, mh mhVar, Type type) {
        this.f10004c = noVar;
        this.f10002a = mhVar;
        this.f10003b = type;
    }

    /* renamed from: a */
    public T mo2240a() {
        return this.f10002a.m14515a(this.f10003b);
    }
}
