package com.google.android.gms.internal;

import java.util.concurrent.Callable;

class afk implements Callable<afg> {
    /* renamed from: a */
    final /* synthetic */ afd f7464a;
    /* renamed from: b */
    final /* synthetic */ afj f7465b;

    afk(afj afj, afd afd) {
        this.f7465b = afj;
        this.f7464a = afd;
    }

    /* renamed from: a */
    public afg m10844a() {
        synchronized (this.f7465b.f7459i) {
            if (this.f7465b.f7460j) {
                return null;
            }
            return this.f7464a.m10823a(this.f7465b.f7456f, this.f7465b.f7457g);
        }
    }

    public /* synthetic */ Object call() {
        return m10844a();
    }
}
