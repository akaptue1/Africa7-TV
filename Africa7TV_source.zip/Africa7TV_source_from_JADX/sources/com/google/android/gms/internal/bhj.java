package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;
import com.google.android.gms.common.internal.bn;
import java.util.ArrayList;
import java.util.List;

public class bhj extends bhd {
    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        C1370c.m10112a((Object) gbVarArr);
        boolean z = gbVarArr.length == 1 || gbVarArr.length == 2;
        C1370c.m10120b(z);
        C1370c.m10120b(gbVarArr[0] instanceof gi);
        List<gb> list = (List) ((gi) gbVarArr[0]).mo2133b();
        gb gbVar = gbVarArr.length < 2 ? gh.f9460e : gbVarArr[1];
        String d = gbVar == gh.f9460e ? "," : bhc.m13596d(gbVar);
        Iterable arrayList = new ArrayList();
        for (gb gbVar2 : list) {
            if (gbVar2 == gh.f9459d || gbVar2 == gh.f9460e) {
                arrayList.add("");
            } else {
                arrayList.add(bhc.m13596d(gbVar2));
            }
        }
        return new gn(bn.m10100a(d).m10102a(arrayList));
    }
}
