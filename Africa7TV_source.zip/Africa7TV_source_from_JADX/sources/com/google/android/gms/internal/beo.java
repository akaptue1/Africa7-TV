package com.google.android.gms.internal;

public final class beo {
    /* renamed from: a */
    static bep f9038a = new bdu();

    /* renamed from: a */
    public static int m13386a() {
        return 0;
    }

    /* renamed from: a */
    public static void m13387a(String str) {
        f9038a.mo2087a(str);
    }

    /* renamed from: a */
    public static void m13388a(String str, Throwable th) {
        f9038a.mo2088a(str, th);
    }

    /* renamed from: b */
    public static void m13389b(String str) {
        f9038a.mo2089b(str);
    }

    /* renamed from: b */
    public static void m13390b(String str, Throwable th) {
        f9038a.mo2090b(str, th);
    }

    /* renamed from: c */
    public static void m13391c(String str) {
        f9038a.mo2091c(str);
    }

    /* renamed from: d */
    public static void m13392d(String str) {
        f9038a.mo2092d(str);
    }
}
