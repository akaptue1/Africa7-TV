package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.text.TextUtils;
import com.google.android.gms.auth.api.C1171f;
import com.google.android.gms.auth.api.C1173h;
import com.google.android.gms.common.api.C1242s;
import com.google.android.gms.common.api.C1243t;
import com.google.android.gms.common.internal.C1393z;
import com.google.android.gms.common.internal.ag;

public final class ath extends ag<atm> {
    /* renamed from: a */
    private final Bundle f8411a;

    public ath(Context context, Looper looper, C1393z c1393z, C1173h c1173h, C1242s c1242s, C1243t c1243t) {
        super(context, looper, 16, c1393z, c1242s, c1243t);
        this.f8411a = c1173h == null ? new Bundle() : c1173h.m8669a();
    }

    /* renamed from: a */
    protected atm m12302a(IBinder iBinder) {
        return atn.m12319a(iBinder);
    }

    /* renamed from: a */
    protected String mo1160a() {
        return "com.google.android.gms.auth.service.START";
    }

    /* renamed from: b */
    protected /* synthetic */ IInterface mo1161b(IBinder iBinder) {
        return m12302a(iBinder);
    }

    /* renamed from: b */
    protected String mo1162b() {
        return "com.google.android.gms.auth.api.internal.IAuthService";
    }

    /* renamed from: c */
    protected Bundle mo1390c() {
        return this.f8411a;
    }

    /* renamed from: o */
    public boolean mo1941o() {
        C1393z C = m8624C();
        return (TextUtils.isEmpty(C.m10232a()) || C.m10233a(C1171f.f6216b).isEmpty()) ? false : true;
    }
}
