package com.google.android.gms.internal;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@akw
public abstract class wn {
    /* renamed from: b */
    private static MessageDigest f10614b = null;
    /* renamed from: a */
    protected Object f10615a = new Object();

    /* renamed from: a */
    protected MessageDigest m15555a() {
        MessageDigest messageDigest;
        synchronized (this.f10615a) {
            if (f10614b != null) {
                messageDigest = f10614b;
            } else {
                for (int i = 0; i < 2; i++) {
                    try {
                        f10614b = MessageDigest.getInstance("MD5");
                    } catch (NoSuchAlgorithmException e) {
                    }
                }
                messageDigest = f10614b;
            }
        }
        return messageDigest;
    }

    /* renamed from: a */
    abstract byte[] mo2313a(String str);
}
