package com.google.android.gms.internal;

enum mz extends mx {
    mz(String str, int i) {
        super(str, i);
    }
}
