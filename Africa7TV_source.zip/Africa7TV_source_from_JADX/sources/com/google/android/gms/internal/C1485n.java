package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;

/* renamed from: com.google.android.gms.internal.n */
public class C1485n extends bhd {
    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        boolean z = true;
        C1370c.m10120b(gbVarArr != null);
        C1370c.m10120b(gbVarArr.length == 2);
        if (bhc.m13597d(gbVarArr[1], gbVarArr[0])) {
            z = false;
        }
        return new ge(Boolean.valueOf(z));
    }
}
