package com.google.android.gms.internal;

class ajl implements Runnable {
    /* renamed from: a */
    final /* synthetic */ ana f7651a;
    /* renamed from: b */
    final /* synthetic */ ajk f7652b;

    ajl(ajk ajk, ana ana) {
        this.f7652b = ajk;
        this.f7651a = ana;
    }

    public void run() {
        this.f7652b.f7648a.mo1092b(this.f7651a);
    }
}
