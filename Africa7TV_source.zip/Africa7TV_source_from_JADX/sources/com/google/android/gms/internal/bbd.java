package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.p034a.C0827c;
import com.google.android.gms.p034a.C0828d;

class bbd implements bbb {
    /* renamed from: a */
    private IBinder f8783a;

    bbd(IBinder iBinder) {
        this.f8783a = iBinder;
    }

    /* renamed from: a */
    public int mo2066a(C0827c c0827c, String str) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.dynamite.IDynamiteLoader");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            obtain.writeString(str);
            this.f8783a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
            int readInt = obtain2.readInt();
            return readInt;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public int mo2067a(C0827c c0827c, String str, boolean z) {
        int i = 0;
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.dynamite.IDynamiteLoader");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            obtain.writeString(str);
            if (z) {
                i = 1;
            }
            obtain.writeInt(i);
            this.f8783a.transact(3, obtain, obtain2, 0);
            obtain2.readException();
            i = obtain2.readInt();
            return i;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    /* renamed from: a */
    public C0827c mo2068a(C0827c c0827c, String str, int i) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.dynamite.IDynamiteLoader");
            obtain.writeStrongBinder(c0827c != null ? c0827c.asBinder() : null);
            obtain.writeString(str);
            obtain.writeInt(i);
            this.f8783a.transact(2, obtain, obtain2, 0);
            obtain2.readException();
            C0827c a = C0828d.m6209a(obtain2.readStrongBinder());
            return a;
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    public IBinder asBinder() {
        return this.f8783a;
    }
}
