package com.google.android.gms.internal;

import java.sql.Timestamp;
import java.util.Date;

final class qf implements ne {
    qf() {
    }

    /* renamed from: a */
    public <T> nd<T> mo2239a(lz lzVar, rh<T> rhVar) {
        return rhVar.m14946a() != Timestamp.class ? null : new qg(this, lzVar.m14478a(Date.class));
    }
}
