package com.google.android.gms.internal;

import android.content.Context;
import android.util.Log;
import com.google.android.gms.clearcut.C1338d;
import com.google.android.gms.common.internal.C1370c;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import oauth.signpost.OAuth;

public class avk implements C1338d {
    /* renamed from: a */
    static Boolean f8463a = null;
    /* renamed from: c */
    private static final Charset f8464c = Charset.forName(OAuth.ENCODING);
    /* renamed from: b */
    final avl f8465b;

    public avk() {
        this(new avl(null));
    }

    public avk(Context context) {
        this(new avl(context));
    }

    avk(avl avl) {
        this.f8465b = (avl) C1370c.m10112a((Object) avl);
    }

    /* renamed from: a */
    static long m12489a(long j) {
        return avd.m12475a(ByteBuffer.allocate(8).putLong(j).array());
    }

    /* renamed from: a */
    static long m12490a(String str, long j) {
        if (str == null || str.isEmpty()) {
            return m12489a(j);
        }
        byte[] bytes = str.getBytes(f8464c);
        ByteBuffer allocate = ByteBuffer.allocate(bytes.length + 8);
        allocate.put(bytes);
        allocate.putLong(j);
        return avd.m12475a(allocate.array());
    }

    /* renamed from: a */
    static avm m12491a(String str) {
        int i = 0;
        if (str == null) {
            return null;
        }
        String str2 = "";
        int indexOf = str.indexOf(44);
        if (indexOf >= 0) {
            str2 = str.substring(0, indexOf);
            i = indexOf + 1;
        }
        int indexOf2 = str.indexOf(47, i);
        if (indexOf2 <= 0) {
            str2 = "LogSamplerImpl";
            String str3 = "Failed to parse the rule: ";
            String valueOf = String.valueOf(str);
            Log.e(str2, valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
            return null;
        }
        try {
            long parseLong = Long.parseLong(str.substring(i, indexOf2));
            long parseLong2 = Long.parseLong(str.substring(indexOf2 + 1));
            if (parseLong >= 0 && parseLong2 >= 0) {
                return new avm(str2, parseLong, parseLong2);
            }
            Log.e("LogSamplerImpl", "negative values not supported: " + parseLong + "/" + parseLong2);
            return null;
        } catch (Throwable e) {
            Throwable th = e;
            str3 = "LogSamplerImpl";
            String str4 = "parseLong() failed while parsing: ";
            valueOf = String.valueOf(str);
            Log.e(str3, valueOf.length() != 0 ? str4.concat(valueOf) : new String(str4), th);
            return null;
        }
    }

    /* renamed from: a */
    static boolean m12492a(long j, long j2, long j3) {
        if (j2 >= 0 && j3 >= 0) {
            return j3 > 0 && avn.m12497a(j, j3) < j2;
        } else {
            throw new IllegalArgumentException("negative values not supported: " + j2 + "/" + j3);
        }
    }

    /* renamed from: a */
    public boolean mo1991a(String str, int i) {
        if (str == null || str.isEmpty()) {
            str = i >= 0 ? String.valueOf(i) : null;
        }
        if (str == null) {
            return true;
        }
        long a = this.f8465b.m12495a();
        avm a2 = m12491a(this.f8465b.m12496a(str));
        return a2 != null ? m12492a(m12490a(a2.f8467a, a), a2.f8468b, a2.f8469c) : true;
    }
}
