package com.google.android.gms.internal;

class ann implements Runnable {
    /* renamed from: a */
    final /* synthetic */ anm f8111a;

    ann(anm anm) {
        this.f8111a = anm;
    }

    public final void run() {
        this.f8111a.f4809b = Thread.currentThread();
        this.f8111a.mo1147a();
    }
}
