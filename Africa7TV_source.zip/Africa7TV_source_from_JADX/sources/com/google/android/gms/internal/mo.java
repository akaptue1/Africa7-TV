package com.google.android.gms.internal;

import com.google.android.gms.clearcut.C1335a;

class mo implements Runnable {
    /* renamed from: a */
    final /* synthetic */ mn f9975a;

    mo(mn mnVar) {
        this.f9975a = mnVar;
    }

    public void run() {
        if (this.f9975a.f9973b == null) {
            synchronized (mn.f9971d) {
                if (this.f9975a.f9973b != null) {
                    return;
                }
                boolean booleanValue = ((Boolean) xm.bp.m15604c()).booleanValue();
                if (booleanValue) {
                    mn.f9970a = new C1335a(this.f9975a.f9974c.m15255a(), "ADSHIELD", null);
                }
                this.f9975a.f9973b = Boolean.valueOf(booleanValue);
                mn.f9971d.open();
            }
        }
    }
}
