package com.google.android.gms.internal;

public interface abx {
    /* renamed from: a */
    abs mo1691a(arh arh, int i, String str);
}
