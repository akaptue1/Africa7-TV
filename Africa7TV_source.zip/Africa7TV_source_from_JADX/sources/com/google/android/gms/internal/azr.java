package com.google.android.gms.internal;

import com.google.android.gms.common.api.C1138g;
import com.google.android.gms.common.api.C1344a;
import com.google.android.gms.common.api.C1345d;
import com.google.android.gms.common.api.C1347l;

public final class azr {
    /* renamed from: a */
    public static final C1347l<azz> f8740a = new C1347l();
    /* renamed from: b */
    public static final C1344a<C1345d> f8741b = new C1344a("Common.API", f8743d, f8740a);
    /* renamed from: c */
    public static final azt f8742c = new azu();
    /* renamed from: d */
    private static final C1138g<azz, C1345d> f8743d = new azs();
}
