package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class bbh {
    /* renamed from: a */
    protected static final Comparator<byte[]> f8785a = new bbi();
    /* renamed from: b */
    private List<byte[]> f8786b = new LinkedList();
    /* renamed from: c */
    private List<byte[]> f8787c = new ArrayList(64);
    /* renamed from: d */
    private int f8788d = 0;
    /* renamed from: e */
    private final int f8789e;

    public bbh(int i) {
        this.f8789e = i;
    }

    /* renamed from: a */
    private synchronized void m13067a() {
        while (this.f8788d > this.f8789e) {
            byte[] bArr = (byte[]) this.f8786b.remove(0);
            this.f8787c.remove(bArr);
            this.f8788d -= bArr.length;
        }
    }

    /* renamed from: a */
    public synchronized void m13068a(byte[] bArr) {
        if (bArr != null) {
            if (bArr.length <= this.f8789e) {
                this.f8786b.add(bArr);
                int binarySearch = Collections.binarySearch(this.f8787c, bArr, f8785a);
                if (binarySearch < 0) {
                    binarySearch = (-binarySearch) - 1;
                }
                this.f8787c.add(binarySearch, bArr);
                this.f8788d += bArr.length;
                m13067a();
            }
        }
    }

    /* renamed from: a */
    public synchronized byte[] m13069a(int i) {
        byte[] bArr;
        for (int i2 = 0; i2 < this.f8787c.size(); i2++) {
            bArr = (byte[]) this.f8787c.get(i2);
            if (bArr.length >= i) {
                this.f8788d -= bArr.length;
                this.f8787c.remove(i2);
                this.f8786b.remove(bArr);
                break;
            }
        }
        bArr = new byte[i];
        return bArr;
    }
}
