package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;

/* renamed from: com.google.android.gms.internal.p */
public class C1487p extends bhd {
    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        boolean z = true;
        boolean z2 = false;
        C1370c.m10120b(gbVarArr != null);
        C1370c.m10120b(gbVarArr.length == 2);
        gb gbVar = gbVarArr[0];
        gb gbVar2 = gbVarArr[1];
        if ((gbVar instanceof gl) || (gbVar instanceof gi) || (gbVar instanceof gg)) {
            gbVar = new gn(bhc.m13596d(gbVar));
        }
        gb gnVar = ((gbVar2 instanceof gl) || (gbVar2 instanceof gi) || (gbVar2 instanceof gg)) ? new gn(bhc.m13596d(gbVar2)) : gbVar2;
        if (((gbVar instanceof gn) && (gnVar instanceof gn)) || !(Double.isNaN(bhc.m13592b(gbVar)) || Double.isNaN(bhc.m13592b(gnVar)))) {
            if (bhc.m13593b(gnVar, gbVar)) {
                z = false;
            }
            z2 = z;
        }
        return new ge(Boolean.valueOf(z2));
    }
}
