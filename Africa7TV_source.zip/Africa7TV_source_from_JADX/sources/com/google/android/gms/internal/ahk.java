package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import com.google.android.gms.ads.internal.bd;
import com.google.android.gms.ads.internal.client.at;
import com.google.android.gms.ads.internal.util.client.C1043e;
import java.util.Map;

@akw
public class ahk extends ahl implements aau {
    /* renamed from: a */
    DisplayMetrics f7579a;
    /* renamed from: b */
    int f7580b = -1;
    /* renamed from: c */
    int f7581c = -1;
    /* renamed from: d */
    int f7582d = -1;
    /* renamed from: e */
    int f7583e = -1;
    /* renamed from: f */
    int f7584f = -1;
    /* renamed from: g */
    int f7585g = -1;
    /* renamed from: h */
    private final arh f7586h;
    /* renamed from: i */
    private final Context f7587i;
    /* renamed from: j */
    private final WindowManager f7588j;
    /* renamed from: k */
    private final wy f7589k;
    /* renamed from: l */
    private float f7590l;
    /* renamed from: m */
    private int f7591m;

    public ahk(arh arh, Context context, wy wyVar) {
        super(arh);
        this.f7586h = arh;
        this.f7587i = context;
        this.f7589k = wyVar;
        this.f7588j = (WindowManager) context.getSystemService("window");
    }

    /* renamed from: g */
    private void m11138g() {
        this.f7579a = new DisplayMetrics();
        Display defaultDisplay = this.f7588j.getDefaultDisplay();
        defaultDisplay.getMetrics(this.f7579a);
        this.f7590l = this.f7579a.density;
        this.f7591m = defaultDisplay.getRotation();
    }

    /* renamed from: h */
    private void m11139h() {
        int[] iArr = new int[2];
        this.f7586h.getLocationOnScreen(iArr);
        m11142a(at.m6849a().m7785b(this.f7587i, iArr[0]), at.m6849a().m7785b(this.f7587i, iArr[1]));
    }

    /* renamed from: i */
    private ahh m11140i() {
        ahj d = new ahj().m11134b(this.f7589k.m15585a()).m11133a(this.f7589k.m15587b()).m11135c(this.f7589k.m15589e()).m11136d(this.f7589k.m15588c());
        wy wyVar = this.f7589k;
        return d.m11137e(true).m11132a();
    }

    /* renamed from: a */
    void m11141a() {
        this.f7580b = at.m6849a().m7786b(this.f7579a, this.f7579a.widthPixels);
        this.f7581c = at.m6849a().m7786b(this.f7579a, this.f7579a.heightPixels);
        Activity f = this.f7586h.mo1907f();
        if (f == null || f.getWindow() == null) {
            this.f7582d = this.f7580b;
            this.f7583e = this.f7581c;
            return;
        }
        int[] a = bd.m6644e().m11749a(f);
        this.f7582d = at.m6849a().m7786b(this.f7579a, a[0]);
        this.f7583e = at.m6849a().m7786b(this.f7579a, a[1]);
    }

    /* renamed from: a */
    public void m11142a(int i, int i2) {
        int i3 = this.f7587i instanceof Activity ? bd.m6644e().m11765d((Activity) this.f7587i)[0] : 0;
        if (this.f7586h.mo1912k() == null || !this.f7586h.mo1912k().f4970e) {
            this.f7584f = at.m6849a().m7785b(this.f7587i, this.f7586h.getMeasuredWidth());
            this.f7585g = at.m6849a().m7785b(this.f7587i, this.f7586h.getMeasuredHeight());
        }
        m11099b(i, i2 - i3, this.f7584f, this.f7585g);
        this.f7586h.mo1913l().zzd(i, i2);
    }

    /* renamed from: a */
    public void mo1150a(arh arh, Map<String, String> map) {
        m11145c();
    }

    /* renamed from: b */
    void m11144b() {
        if (this.f7586h.mo1912k().f4970e) {
            this.f7584f = this.f7580b;
            this.f7585g = this.f7581c;
            return;
        }
        this.f7586h.measure(0, 0);
    }

    /* renamed from: c */
    public void m11145c() {
        m11138g();
        m11141a();
        m11144b();
        m11147e();
        m11148f();
        m11139h();
        m11146d();
    }

    /* renamed from: d */
    void m11146d() {
        if (C1043e.m7796a(2)) {
            C1043e.m7799c("Dispatching Ready Event.");
        }
        m11101c(this.f7586h.mo1919o().f5721b);
    }

    /* renamed from: e */
    void m11147e() {
        m11098a(this.f7580b, this.f7581c, this.f7582d, this.f7583e, this.f7590l, this.f7591m);
    }

    /* renamed from: f */
    void m11148f() {
        this.f7586h.mo1711b("onDeviceFeaturesReceived", m11140i().m11126a());
    }
}
