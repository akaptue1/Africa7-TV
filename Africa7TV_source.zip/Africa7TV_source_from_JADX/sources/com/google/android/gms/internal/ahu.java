package com.google.android.gms.internal;

import java.util.Map;
import twitter4j.internal.http.HttpResponseCode;

public class ahu {
    /* renamed from: a */
    public final int f7594a;
    /* renamed from: b */
    public final byte[] f7595b;
    /* renamed from: c */
    public final Map<String, String> f7596c;
    /* renamed from: d */
    public final boolean f7597d;
    /* renamed from: e */
    public final long f7598e;

    public ahu(int i, byte[] bArr, Map<String, String> map, boolean z, long j) {
        this.f7594a = i;
        this.f7595b = bArr;
        this.f7596c = map;
        this.f7597d = z;
        this.f7598e = j;
    }

    public ahu(byte[] bArr, Map<String, String> map) {
        this(HttpResponseCode.OK, bArr, map, false, 0);
    }
}
