package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;
import com.google.android.gms.common.util.C1415d;
import com.google.android.gms.common.util.C1417f;

public class cp implements bhb {
    /* renamed from: a */
    private C1415d f9224a = C1417f.m10332d();

    /* renamed from: a */
    public void m13655a(C1415d c1415d) {
        this.f9224a = (C1415d) C1370c.m10112a((Object) c1415d);
    }

    public gb<?> a_(bff bff, gb<?>... gbVarArr) {
        boolean z = true;
        C1370c.m10120b(gbVarArr != null);
        if (gbVarArr.length != 0) {
            z = false;
        }
        C1370c.m10120b(z);
        return new gf(Double.valueOf((double) this.f9224a.mo1680a()));
    }
}
