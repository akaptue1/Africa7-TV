package com.google.android.gms.internal;

import java.io.InputStream;

public interface fi {
    /* renamed from: a */
    InputStream mo2131a(String str);

    /* renamed from: a */
    void mo2132a();
}
