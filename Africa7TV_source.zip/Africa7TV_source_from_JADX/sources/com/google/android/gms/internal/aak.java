package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.C1043e;
import java.util.Map;
import java.util.concurrent.Future;

final class aak implements aau {
    aak() {
    }

    /* renamed from: a */
    public void mo1150a(arh arh, Map<String, String> map) {
        String str = (String) map.get("u");
        if (str == null) {
            C1043e.m7801d("URL missing from httpTrack GMSG.");
        } else {
            Future future = (Future) new aqf(arh.getContext(), arh.mo1919o().f5721b, str).mo1146e();
        }
    }
}
