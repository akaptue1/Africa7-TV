package com.google.android.gms.internal;

class aec implements Runnable {
    /* renamed from: a */
    final /* synthetic */ adi f7341a;
    /* renamed from: b */
    final /* synthetic */ adw f7342b;

    aec(adw adw, adi adi) {
        this.f7342b = adw;
        this.f7341a = adi;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
        r3 = this;
        r0 = r3.f7342b;
        r0 = r0.f7331c;
        r1 = r0.f7321a;
        monitor-enter(r1);
        r0 = r3.f7342b;	 Catch:{ all -> 0x003b }
        r0 = r0.f7330b;	 Catch:{ all -> 0x003b }
        r0 = r0.mo1716b();	 Catch:{ all -> 0x003b }
        r2 = -1;
        if (r0 == r2) goto L_0x001f;
    L_0x0014:
        r0 = r3.f7342b;	 Catch:{ all -> 0x003b }
        r0 = r0.f7330b;	 Catch:{ all -> 0x003b }
        r0 = r0.mo1716b();	 Catch:{ all -> 0x003b }
        r2 = 1;
        if (r0 != r2) goto L_0x0021;
    L_0x001f:
        monitor-exit(r1);	 Catch:{ all -> 0x003b }
    L_0x0020:
        return;
    L_0x0021:
        r0 = r3.f7342b;	 Catch:{ all -> 0x003b }
        r0 = r0.f7330b;	 Catch:{ all -> 0x003b }
        r0.mo1715a();	 Catch:{ all -> 0x003b }
        r0 = com.google.android.gms.ads.internal.bd.m6644e();	 Catch:{ all -> 0x003b }
        r2 = new com.google.android.gms.internal.aed;	 Catch:{ all -> 0x003b }
        r2.<init>(r3);	 Catch:{ all -> 0x003b }
        r0.m11739a(r2);	 Catch:{ all -> 0x003b }
        r0 = "Could not receive loaded message in a timely manner. Rejecting.";
        com.google.android.gms.internal.ano.m11653e(r0);	 Catch:{ all -> 0x003b }
        monitor-exit(r1);	 Catch:{ all -> 0x003b }
        goto L_0x0020;
    L_0x003b:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x003b }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.aec.run():void");
    }
}
