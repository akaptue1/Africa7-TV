package com.google.android.gms.internal;

import com.google.android.gms.analytics.C1133x;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public final class asn extends C1133x<asn> {
    /* renamed from: a */
    private Map<Integer, Double> f8369a = new HashMap(4);

    /* renamed from: a */
    public Map<Integer, Double> m12194a() {
        return Collections.unmodifiableMap(this.f8369a);
    }

    /* renamed from: a */
    public /* synthetic */ void mo1938a(C1133x c1133x) {
        m12196a((asn) c1133x);
    }

    /* renamed from: a */
    public void m12196a(asn asn) {
        asn.f8369a.putAll(this.f8369a);
    }

    public String toString() {
        Map hashMap = new HashMap();
        for (Entry entry : this.f8369a.entrySet()) {
            String valueOf = String.valueOf(entry.getKey());
            hashMap.put(new StringBuilder(String.valueOf(valueOf).length() + 6).append("metric").append(valueOf).toString(), entry.getValue());
        }
        return C1133x.m8528a((Object) hashMap);
    }
}
