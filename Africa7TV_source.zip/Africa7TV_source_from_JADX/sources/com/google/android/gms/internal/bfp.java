package com.google.android.gms.internal;

import android.content.SharedPreferences.Editor;

final class bfp implements Runnable {
    /* renamed from: a */
    final /* synthetic */ Editor f9116a;

    bfp(Editor editor) {
        this.f9116a = editor;
    }

    public void run() {
        this.f9116a.commit();
    }
}
