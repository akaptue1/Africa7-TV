package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.client.ba;

class acb extends ba {
    /* renamed from: a */
    final /* synthetic */ aca f7221a;

    acb(aca aca) {
        this.f7221a = aca;
    }

    /* renamed from: a */
    public void mo1167a() {
        this.f7221a.f7220a.add(new acc(this));
    }

    /* renamed from: a */
    public void mo1168a(int i) {
        this.f7221a.f7220a.add(new acd(this, i));
        ano.m11653e("Pooled interstitial failed to load.");
    }

    /* renamed from: b */
    public void mo1169b() {
        this.f7221a.f7220a.add(new ace(this));
    }

    /* renamed from: c */
    public void mo1170c() {
        this.f7221a.f7220a.add(new acf(this));
        ano.m11653e("Pooled interstitial loaded.");
    }

    /* renamed from: d */
    public void mo1171d() {
        this.f7221a.f7220a.add(new acg(this));
    }
}
