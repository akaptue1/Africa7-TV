package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.formats.C0918f;
import java.util.Map;

class akb implements aau {
    /* renamed from: a */
    final /* synthetic */ C0918f f7712a;
    /* renamed from: b */
    final /* synthetic */ ajx f7713b;

    akb(ajx ajx, C0918f c0918f) {
        this.f7713b = ajx;
        this.f7712a = c0918f;
    }

    /* renamed from: a */
    public void mo1150a(arh arh, Map<String, String> map) {
        this.f7713b.m11283a(this.f7712a, (String) map.get("asset"));
    }
}
