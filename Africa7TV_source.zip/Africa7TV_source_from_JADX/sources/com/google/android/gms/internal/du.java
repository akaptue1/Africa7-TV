package com.google.android.gms.internal;

public class du extends dv {
    /* renamed from: a */
    protected boolean mo2127a(double d, double d2) {
        return d < d2;
    }
}
