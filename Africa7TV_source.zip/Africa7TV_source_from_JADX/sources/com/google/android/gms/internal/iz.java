package com.google.android.gms.internal;

public interface iz {
    /* renamed from: a */
    void mo2443a(String str, String str2);
}
