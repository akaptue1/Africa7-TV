package com.google.android.gms.internal;

import android.os.Handler.Callback;
import android.os.Message;

class bfn implements Callback {
    /* renamed from: a */
    final /* synthetic */ bfm f9115a;

    bfn(bfm bfm) {
        this.f9115a = bfm;
    }

    public boolean handleMessage(Message message) {
        if (1 == message.what && bfi.f9096a.equals(message.obj)) {
            this.f9115a.f9113a.m13497d();
            if (!this.f9115a.f9113a.m13490h()) {
                this.f9115a.mo2117a((long) this.f9115a.f9113a.f9101e);
            }
        }
        return true;
    }
}
