package com.google.android.gms.internal;

public interface afb {
    /* renamed from: A */
    void mo1109A();

    /* renamed from: v */
    void mo1125v();

    /* renamed from: w */
    void mo1126w();

    /* renamed from: x */
    void mo1127x();

    /* renamed from: y */
    void mo1128y();

    /* renamed from: z */
    void mo1129z();
}
