package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;

public class az extends bhd {
    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        C1370c.m10120b(gbVarArr != null);
        C1370c.m10120b(gbVarArr.length == 2);
        return new gf(Double.valueOf(bhc.m13590a(gbVarArr[0], new gf(Double.valueOf(-1.0d * bhc.m13592b(gbVarArr[1]))))));
    }
}
