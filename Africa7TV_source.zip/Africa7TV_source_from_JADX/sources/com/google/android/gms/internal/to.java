package com.google.android.gms.internal;

public class to extends ty {
    /* renamed from: i */
    private long f10404i = -1;

    public to(sy syVar, String str, String str2, fa faVar, int i, int i2) {
        super(syVar, str, str2, faVar, i, i2);
    }

    /* renamed from: a */
    protected void mo2283a() {
        this.e.f9356l = Long.valueOf(-1);
        if (this.f10404i == -1) {
            this.f10404i = (long) ((Integer) this.f.invoke(null, new Object[]{this.b.m15255a()})).intValue();
        }
        synchronized (this.e) {
            this.e.f9356l = Long.valueOf(this.f10404i);
        }
    }
}
