package com.google.android.gms.internal;

final class azn extends azj<Float> {
    azn(String str, Float f) {
        super(str, f);
    }

    /* renamed from: a */
    protected /* synthetic */ Object mo2057a(String str) {
        return m12972b(str);
    }

    /* renamed from: b */
    protected Float m12972b(String str) {
        return null.m12976a(this.a, (Float) this.b);
    }
}
