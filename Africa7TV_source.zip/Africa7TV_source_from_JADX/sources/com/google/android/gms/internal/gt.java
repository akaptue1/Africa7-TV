package com.google.android.gms.internal;

public final class gt {
    /* renamed from: a */
    public static float m13933a(float f, float f2, float f3, float f4) {
        return (f <= f2 || f <= f3 || f <= f4) ? (f2 <= f3 || f2 <= f4) ? f3 > f4 ? f3 : f4 : f2 : f;
    }

    /* renamed from: a */
    public static float m13934a(float f, float f2, float f3, float f4, float f5, float f6) {
        return m13933a(m13935b(f, f2, f3, f4), m13935b(f, f2, f5, f4), m13935b(f, f2, f5, f6), m13935b(f, f2, f3, f6));
    }

    /* renamed from: b */
    public static float m13935b(float f, float f2, float f3, float f4) {
        return (float) Math.hypot((double) (f3 - f), (double) (f4 - f2));
    }
}
