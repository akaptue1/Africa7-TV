package com.google.android.gms.internal;

import java.util.concurrent.Future;

@akw
public abstract class anm implements apg<Future> {
    /* renamed from: a */
    private final Runnable f4808a;
    /* renamed from: b */
    private volatile Thread f4809b;
    /* renamed from: c */
    private boolean f4810c;

    public anm() {
        this.f4808a = new ann(this);
        this.f4810c = false;
    }

    public anm(boolean z) {
        this.f4808a = new ann(this);
        this.f4810c = z;
    }

    /* renamed from: a */
    public abstract void mo1147a();

    /* renamed from: b */
    public abstract void mo1148b();

    /* renamed from: d */
    public final void mo1145d() {
        mo1148b();
        if (this.f4809b != null) {
            this.f4809b.interrupt();
        }
    }

    /* renamed from: e */
    public /* synthetic */ Object mo1146e() {
        return m6497h();
    }

    /* renamed from: h */
    public final Future m6497h() {
        return this.f4810c ? aok.m11692a(1, this.f4808a) : aok.m11693a(this.f4808a);
    }
}
