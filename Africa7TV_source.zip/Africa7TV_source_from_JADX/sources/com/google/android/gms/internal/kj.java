package com.google.android.gms.internal;

public interface kj {
    /* renamed from: a */
    void mo2210a(kk kkVar);

    /* renamed from: a */
    void mo2211a(km kmVar);

    /* renamed from: c */
    void mo2214c();

    /* renamed from: d */
    void mo2215d();
}
