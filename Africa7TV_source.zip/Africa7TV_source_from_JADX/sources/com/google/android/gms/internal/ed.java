package com.google.android.gms.internal;

public class ed extends Exception {
    public ed(String str) {
        super(str);
    }
}
