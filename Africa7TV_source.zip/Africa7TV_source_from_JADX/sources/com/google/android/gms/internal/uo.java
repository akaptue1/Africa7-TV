package com.google.android.gms.internal;

public interface uo {
    /* renamed from: a */
    void m15379a(ur urVar, boolean z);
}
