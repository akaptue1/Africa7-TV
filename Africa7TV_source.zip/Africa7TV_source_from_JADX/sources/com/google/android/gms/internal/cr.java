package com.google.android.gms.internal;

import android.content.Context;
import android.provider.Settings.Secure;
import com.google.android.gms.common.internal.C1370c;

public class cr implements bhb {
    /* renamed from: a */
    private final Context f9226a;

    public cr(Context context) {
        this.f9226a = context;
    }

    /* renamed from: a */
    protected String m13656a(Context context) {
        return Secure.getString(this.f9226a.getContentResolver(), "android_id");
    }

    public gb<?> a_(bff bff, gb<?>... gbVarArr) {
        boolean z = true;
        C1370c.m10120b(gbVarArr != null);
        if (gbVarArr.length != 0) {
            z = false;
        }
        C1370c.m10120b(z);
        String a = m13656a(this.f9226a);
        if (a == null) {
            a = "";
        }
        return new gn(a);
    }
}
