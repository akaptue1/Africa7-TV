package com.google.android.gms.internal;

import java.util.Map;
import org.acra.ACRAConstants;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpOptions;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpTrace;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

public class bca implements bdx {
    /* renamed from: a */
    protected final HttpClient f8815a;

    public bca(HttpClient httpClient) {
        this.f8815a = httpClient;
    }

    /* renamed from: a */
    private static void m13125a(HttpEntityEnclosingRequestBase httpEntityEnclosingRequestBase, amb<?> amb) {
        byte[] n = amb.mo1874n();
        if (n != null) {
            httpEntityEnclosingRequestBase.setEntity(new ByteArrayEntity(n));
        }
    }

    /* renamed from: a */
    private static void m13126a(HttpUriRequest httpUriRequest, Map<String, String> map) {
        for (String str : map.keySet()) {
            httpUriRequest.setHeader(str, (String) map.get(str));
        }
    }

    /* renamed from: b */
    static HttpUriRequest m13127b(amb<?> amb, Map<String, String> map) {
        HttpEntityEnclosingRequestBase httpPost;
        switch (amb.m10745a()) {
            case -1:
                byte[] k = amb.m10766k();
                if (k == null) {
                    return new HttpGet(amb.m10757c());
                }
                HttpUriRequest httpPost2 = new HttpPost(amb.m10757c());
                httpPost2.addHeader("Content-Type", amb.m10765j());
                httpPost2.setEntity(new ByteArrayEntity(k));
                return httpPost2;
            case 0:
                return new HttpGet(amb.m10757c());
            case 1:
                httpPost = new HttpPost(amb.m10757c());
                httpPost.addHeader("Content-Type", amb.m10768m());
                m13125a(httpPost, (amb) amb);
                return httpPost;
            case 2:
                httpPost = new HttpPut(amb.m10757c());
                httpPost.addHeader("Content-Type", amb.m10768m());
                m13125a(httpPost, (amb) amb);
                return httpPost;
            case 3:
                return new HttpDelete(amb.m10757c());
            case 4:
                return new HttpHead(amb.m10757c());
            case 5:
                return new HttpOptions(amb.m10757c());
            case 6:
                return new HttpTrace(amb.m10757c());
            case 7:
                httpPost = new bcb(amb.m10757c());
                httpPost.addHeader("Content-Type", amb.m10768m());
                m13125a(httpPost, (amb) amb);
                return httpPost;
            default:
                throw new IllegalStateException("Unknown request method.");
        }
    }

    /* renamed from: a */
    public HttpResponse mo2074a(amb<?> amb, Map<String, String> map) {
        HttpUriRequest b = m13127b(amb, map);
        m13126a(b, (Map) map);
        m13126a(b, amb.mo1873g());
        m13129a(b);
        HttpParams params = b.getParams();
        int q = amb.m10772q();
        HttpConnectionParams.setConnectionTimeout(params, ACRAConstants.DEFAULT_SOCKET_TIMEOUT);
        HttpConnectionParams.setSoTimeout(params, q);
        return this.f8815a.execute(b);
    }

    /* renamed from: a */
    protected void m13129a(HttpUriRequest httpUriRequest) {
    }
}
