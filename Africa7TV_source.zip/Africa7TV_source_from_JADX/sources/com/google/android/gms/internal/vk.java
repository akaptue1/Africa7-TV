package com.google.android.gms.internal;

import org.json.JSONObject;

public interface vk {
    /* renamed from: a */
    void mo2306a(JSONObject jSONObject, boolean z);

    /* renamed from: a */
    boolean mo2307a();

    /* renamed from: b */
    void mo2308b();
}
