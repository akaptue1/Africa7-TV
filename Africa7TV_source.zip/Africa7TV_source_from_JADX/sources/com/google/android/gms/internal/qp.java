package com.google.android.gms.internal;

final class qp extends nd<Boolean> {
    qp() {
    }

    /* renamed from: a */
    public Boolean m14880a(ri riVar) {
        if (riVar.mo2248f() != rk.NULL) {
            return riVar.mo2248f() == rk.STRING ? Boolean.valueOf(Boolean.parseBoolean(riVar.mo2250h())) : Boolean.valueOf(riVar.mo2251i());
        } else {
            riVar.mo2252j();
            return null;
        }
    }

    /* renamed from: a */
    public void m14881a(rl rlVar, Boolean bool) {
        if (bool == null) {
            rlVar.mo2270f();
        } else {
            rlVar.mo2263a(bool.booleanValue());
        }
    }

    /* renamed from: b */
    public /* synthetic */ Object mo2144b(ri riVar) {
        return m14880a(riVar);
    }
}
