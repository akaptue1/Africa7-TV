package com.google.android.gms.internal;

import android.content.Context;

final class bar implements bay {
    bar() {
    }

    /* renamed from: a */
    public bba mo2065a(Context context, String str, baz baz) {
        bba bba = new bba();
        bba.f8780a = baz.mo2062a(context, str);
        if (bba.f8780a != 0) {
            bba.f8782c = -1;
        } else {
            bba.f8781b = baz.mo2063a(context, str, true);
            if (bba.f8781b != 0) {
                bba.f8782c = 1;
            }
        }
        return bba;
    }
}
