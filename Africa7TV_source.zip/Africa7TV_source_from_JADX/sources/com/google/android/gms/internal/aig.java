package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;

class aig implements aie {
    /* renamed from: a */
    private IBinder f7606a;

    aig(IBinder iBinder) {
        this.f7606a = iBinder;
    }

    /* renamed from: a */
    public void mo1697a(aib aib) {
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        try {
            obtain.writeInterfaceToken("com.google.android.gms.ads.internal.purchase.client.IInAppPurchaseListener");
            obtain.writeStrongBinder(aib != null ? aib.asBinder() : null);
            this.f7606a.transact(1, obtain, obtain2, 0);
            obtain2.readException();
        } finally {
            obtain2.recycle();
            obtain.recycle();
        }
    }

    public IBinder asBinder() {
        return this.f7606a;
    }
}
