package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.reward.mediation.client.RewardItemParcel;

public interface amp {
    /* renamed from: G */
    void mo1840G();

    /* renamed from: H */
    void mo1841H();

    /* renamed from: I */
    void mo1842I();

    /* renamed from: J */
    void mo1843J();

    /* renamed from: K */
    void mo1844K();

    /* renamed from: b */
    void mo1845b(RewardItemParcel rewardItemParcel);
}
