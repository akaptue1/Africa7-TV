package com.google.android.gms.internal;

import android.content.Context;

final class bap implements baz {
    bap() {
    }

    /* renamed from: a */
    public int mo2062a(Context context, String str) {
        return ban.m13023a(context, str);
    }

    /* renamed from: a */
    public int mo2063a(Context context, String str, boolean z) {
        return ban.m13031b(context, str, z);
    }

    /* renamed from: a */
    public ban mo2064a(Context context, String str, int i) {
        return ban.m13035d(context, str, i);
    }
}
