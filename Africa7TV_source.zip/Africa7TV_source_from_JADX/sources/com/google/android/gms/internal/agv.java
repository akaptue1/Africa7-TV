package com.google.android.gms.internal;

class agv implements yn {
    /* renamed from: a */
    final /* synthetic */ agu f7525a;

    agv(agu agu) {
        this.f7525a = agu;
    }
}
