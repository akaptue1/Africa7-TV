package com.google.android.gms.internal;

public final class fg extends rs<fg> {
    /* renamed from: a */
    public Long f9398a;
    /* renamed from: b */
    public String f9399b;
    /* renamed from: c */
    public byte[] f9400c;

    public fg() {
        this.f9398a = null;
        this.f9399b = null;
        this.f9400c = null;
        this.ah = -1;
    }

    /* renamed from: a */
    public fg m13810a(rp rpVar) {
        while (true) {
            int a = rpVar.m14968a();
            switch (a) {
                case 0:
                    break;
                case 8:
                    this.f9398a = Long.valueOf(rpVar.m14980f());
                    continue;
                case 26:
                    this.f9399b = rpVar.m14984i();
                    continue;
                case 34:
                    this.f9400c = rpVar.m14985j();
                    continue;
                default:
                    if (!super.m13673a(rpVar, a)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    /* renamed from: a */
    public void mo2082a(rq rqVar) {
        if (this.f9398a != null) {
            rqVar.m15043b(1, this.f9398a.longValue());
        }
        if (this.f9399b != null) {
            rqVar.m15035a(3, this.f9399b);
        }
        if (this.f9400c != null) {
            rqVar.m15037a(4, this.f9400c);
        }
        super.mo2082a(rqVar);
    }

    /* renamed from: b */
    protected int mo2083b() {
        int b = super.mo2083b();
        if (this.f9398a != null) {
            b += rq.m15018e(1, this.f9398a.longValue());
        }
        if (this.f9399b != null) {
            b += rq.m15006b(3, this.f9399b);
        }
        return this.f9400c != null ? b + rq.m15008b(4, this.f9400c) : b;
    }

    /* renamed from: b */
    public /* synthetic */ rz mo2084b(rp rpVar) {
        return m13810a(rpVar);
    }
}
