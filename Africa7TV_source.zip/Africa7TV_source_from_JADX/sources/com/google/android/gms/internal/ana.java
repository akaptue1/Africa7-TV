package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.formats.C0915j;
import com.google.android.gms.ads.internal.request.AutoClickProtectionConfigurationParcel;
import com.google.android.gms.ads.internal.reward.mediation.client.RewardItemParcel;
import java.util.Collections;
import java.util.List;
import org.json.JSONObject;

@akw
public class ana {
    /* renamed from: A */
    public final long f7998A;
    /* renamed from: B */
    public final long f7999B;
    /* renamed from: C */
    public final String f8000C;
    /* renamed from: D */
    public final String f8001D;
    /* renamed from: E */
    public final C0915j f8002E;
    /* renamed from: F */
    public boolean f8003F;
    /* renamed from: G */
    public boolean f8004G;
    /* renamed from: H */
    public boolean f8005H;
    /* renamed from: I */
    public final List<String> f8006I;
    /* renamed from: a */
    public final AdRequestParcel f8007a;
    /* renamed from: b */
    public final arh f8008b;
    /* renamed from: c */
    public final List<String> f8009c;
    /* renamed from: d */
    public final int f8010d;
    /* renamed from: e */
    public final List<String> f8011e;
    /* renamed from: f */
    public final List<String> f8012f;
    /* renamed from: g */
    public final int f8013g;
    /* renamed from: h */
    public final long f8014h;
    /* renamed from: i */
    public final String f8015i;
    /* renamed from: j */
    public final JSONObject f8016j;
    /* renamed from: k */
    public final boolean f8017k;
    /* renamed from: l */
    public final AutoClickProtectionConfigurationParcel f8018l;
    /* renamed from: m */
    public boolean f8019m;
    /* renamed from: n */
    public final boolean f8020n;
    /* renamed from: o */
    public final aez f8021o;
    /* renamed from: p */
    public final aft f8022p;
    /* renamed from: q */
    public final String f8023q;
    /* renamed from: r */
    public final afa f8024r;
    /* renamed from: s */
    public final afc f8025s;
    /* renamed from: t */
    public final long f8026t;
    /* renamed from: u */
    public final String f8027u;
    /* renamed from: v */
    public final AdSizeParcel f8028v;
    /* renamed from: w */
    public final long f8029w;
    /* renamed from: x */
    public final RewardItemParcel f8030x;
    /* renamed from: y */
    public final List<String> f8031y;
    /* renamed from: z */
    public final List<String> f8032z;

    public ana(AdRequestParcel adRequestParcel, arh arh, List<String> list, int i, List<String> list2, List<String> list3, int i2, long j, String str, boolean z, aez aez, aft aft, String str2, afa afa, afc afc, long j2, AdSizeParcel adSizeParcel, long j3, long j4, long j5, String str3, JSONObject jSONObject, C0915j c0915j, RewardItemParcel rewardItemParcel, List<String> list4, List<String> list5, boolean z2, AutoClickProtectionConfigurationParcel autoClickProtectionConfigurationParcel, String str4, List<String> list6, String str5) {
        this.f8003F = false;
        this.f8004G = false;
        this.f8005H = false;
        this.f8007a = adRequestParcel;
        this.f8008b = arh;
        this.f8009c = m11572a(list);
        this.f8010d = i;
        this.f8011e = m11572a(list2);
        this.f8012f = m11572a(list3);
        this.f8013g = i2;
        this.f8014h = j;
        this.f8015i = str;
        this.f8020n = z;
        this.f8021o = aez;
        this.f8022p = aft;
        this.f8023q = str2;
        this.f8024r = afa;
        this.f8025s = afc;
        this.f8026t = j2;
        this.f8028v = adSizeParcel;
        this.f8029w = j3;
        this.f7998A = j4;
        this.f7999B = j5;
        this.f8000C = str3;
        this.f8016j = jSONObject;
        this.f8002E = c0915j;
        this.f8030x = rewardItemParcel;
        this.f8031y = m11572a(list4);
        this.f8032z = m11572a(list5);
        this.f8017k = z2;
        this.f8018l = autoClickProtectionConfigurationParcel;
        this.f8027u = str4;
        this.f8006I = m11572a(list6);
        this.f8001D = str5;
    }

    public ana(anb anb, arh arh, aez aez, aft aft, String str, afc afc, C0915j c0915j, String str2) {
        this(anb.f8033a.f5521c, arh, anb.f8034b.f5564d, anb.f8037e, anb.f8034b.f5566f, anb.f8034b.f5570j, anb.f8034b.f5572l, anb.f8034b.f5571k, anb.f8033a.f5527i, anb.f8034b.f5568h, aez, aft, str, anb.f8035c, afc, anb.f8034b.f5569i, anb.f8036d, anb.f8034b.f5567g, anb.f8038f, anb.f8039g, anb.f8034b.f5575o, anb.f8040h, c0915j, anb.f8034b.f5547C, anb.f8034b.f5548D, anb.f8034b.f5548D, anb.f8034b.f5550F, anb.f8034b.f5551G, str2, anb.f8034b.f5554J, anb.f8034b.f5558N);
    }

    /* renamed from: a */
    private static <T> List<T> m11572a(List<T> list) {
        return list == null ? null : Collections.unmodifiableList(list);
    }

    /* renamed from: a */
    public boolean m11573a() {
        return (this.f8008b == null || this.f8008b.mo1913l() == null) ? false : this.f8008b.mo1913l().zzic();
    }
}
