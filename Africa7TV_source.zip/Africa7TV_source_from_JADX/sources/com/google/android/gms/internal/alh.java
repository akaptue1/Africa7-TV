package com.google.android.gms.internal;

import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug.MemoryInfo;
import android.text.TextUtils;
import com.facebook.internal.NativeProtocol;
import com.google.android.gms.ads.internal.bd;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.SearchAdRequestParcel;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.request.AutoClickProtectionConfigurationParcel;
import com.google.android.gms.ads.internal.reward.mediation.client.RewardItemParcel;
import com.google.android.gms.ads.internal.safebrowsing.SafeBrowsingConfigParcel;
import com.google.android.gms.ads.internal.util.client.C1043e;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.apache.http.client.methods.HttpHead;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@akw
public final class alh {
    /* renamed from: a */
    private static final SimpleDateFormat f7815a = new SimpleDateFormat("yyyyMMdd", Locale.US);

    /* renamed from: a */
    private static Bundle m11384a(Bundle bundle) {
        Bundle bundle2 = new Bundle();
        bundle2.putString("runtime_free", Long.toString(bundle.getLong("runtime_free_memory", -1)));
        bundle2.putString("runtime_max", Long.toString(bundle.getLong("runtime_max_memory", -1)));
        bundle2.putString("runtime_total", Long.toString(bundle.getLong("runtime_total_memory", -1)));
        MemoryInfo memoryInfo = (MemoryInfo) bundle.getParcelable("debug_memory_info");
        if (memoryInfo != null) {
            bundle2.putString("debug_info_dalvik_private_dirty", Integer.toString(memoryInfo.dalvikPrivateDirty));
            bundle2.putString("debug_info_dalvik_pss", Integer.toString(memoryInfo.dalvikPss));
            bundle2.putString("debug_info_dalvik_shared_dirty", Integer.toString(memoryInfo.dalvikSharedDirty));
            bundle2.putString("debug_info_native_private_dirty", Integer.toString(memoryInfo.nativePrivateDirty));
            bundle2.putString("debug_info_native_pss", Integer.toString(memoryInfo.nativePss));
            bundle2.putString("debug_info_native_shared_dirty", Integer.toString(memoryInfo.nativeSharedDirty));
            bundle2.putString("debug_info_other_private_dirty", Integer.toString(memoryInfo.otherPrivateDirty));
            bundle2.putString("debug_info_other_pss", Integer.toString(memoryInfo.otherPss));
            bundle2.putString("debug_info_other_shared_dirty", Integer.toString(memoryInfo.otherSharedDirty));
        }
        return bundle2;
    }

    /* renamed from: a */
    public static AdResponseParcel m11385a(Context context, AdRequestInfoParcel adRequestInfoParcel, String str) {
        String optString;
        try {
            String str2;
            JSONObject jSONObject = new JSONObject(str);
            String optString2 = jSONObject.optString("ad_base_url", null);
            Object optString3 = jSONObject.optString("ad_url", null);
            String optString4 = jSONObject.optString("ad_size", null);
            String optString5 = jSONObject.optString("ad_slot_size", optString4);
            boolean z = (adRequestInfoParcel == null || adRequestInfoParcel.f5531m == 0) ? false : true;
            CharSequence optString6 = jSONObject.optString("ad_json", null);
            if (optString6 == null) {
                optString6 = jSONObject.optString("ad_html", null);
            }
            if (optString6 == null) {
                optString6 = jSONObject.optString("body", null);
            }
            long j = -1;
            String optString7 = jSONObject.optString("debug_dialog", null);
            String optString8 = jSONObject.optString("debug_signals", null);
            long j2 = jSONObject.has("interstitial_timeout") ? (long) (jSONObject.getDouble("interstitial_timeout") * 1000.0d) : -1;
            optString = jSONObject.optString("orientation", null);
            int i = -1;
            if ("portrait".equals(optString)) {
                i = bd.m6646g().mo1854b();
            } else if ("landscape".equals(optString)) {
                i = bd.m6646g().mo1852a();
            }
            AdResponseParcel adResponseParcel = null;
            if (!TextUtils.isEmpty(optString6) || TextUtils.isEmpty(optString3)) {
                CharSequence charSequence = optString6;
            } else {
                adResponseParcel = akz.m11371a(adRequestInfoParcel, context, adRequestInfoParcel.f5529k.f5721b, optString3, null, null, null, null);
                optString2 = adResponseParcel.f5562b;
                str2 = adResponseParcel.f5563c;
                j = adResponseParcel.f5574n;
            }
            if (str2 == null) {
                return new AdResponseParcel(0);
            }
            long j3;
            String optString9;
            String str3;
            boolean optBoolean;
            JSONArray optJSONArray = jSONObject.optJSONArray("click_urls");
            List list = adResponseParcel == null ? null : adResponseParcel.f5564d;
            if (optJSONArray != null) {
                list = m11389a(optJSONArray, list);
            }
            optJSONArray = jSONObject.optJSONArray("impression_urls");
            List list2 = adResponseParcel == null ? null : adResponseParcel.f5566f;
            if (optJSONArray != null) {
                list2 = m11389a(optJSONArray, list2);
            }
            optJSONArray = jSONObject.optJSONArray("manual_impression_urls");
            List list3 = adResponseParcel == null ? null : adResponseParcel.f5570j;
            if (optJSONArray != null) {
                list3 = m11389a(optJSONArray, list3);
            }
            if (adResponseParcel != null) {
                if (adResponseParcel.f5572l != -1) {
                    i = adResponseParcel.f5572l;
                }
                if (adResponseParcel.f5567g > 0) {
                    j3 = adResponseParcel.f5567g;
                    optString9 = jSONObject.optString("active_view");
                    str3 = null;
                    optBoolean = jSONObject.optBoolean("ad_is_javascript", false);
                    if (optBoolean) {
                        str3 = jSONObject.optString("ad_passback_url", null);
                    }
                    return new AdResponseParcel(adRequestInfoParcel, optString2, str2, list, list2, j3, jSONObject.optBoolean("mediation", false), jSONObject.optLong("mediation_config_cache_time_milliseconds", -1), list3, jSONObject.optLong("refresh_interval_milliseconds", -1), i, optString4, j, optString7, optBoolean, str3, optString9, jSONObject.optBoolean("custom_render_allowed", false), z, adRequestInfoParcel.f5534p, jSONObject.optBoolean("content_url_opted_out", true), jSONObject.optBoolean("prefetch", false), jSONObject.optString("gws_query_id", ""), "height".equals(jSONObject.optString("fluid", "")), jSONObject.optBoolean("native_express", false), RewardItemParcel.m7723a(jSONObject.optJSONArray("rewards")), m11389a(jSONObject.optJSONArray("video_start_urls"), null), m11389a(jSONObject.optJSONArray("video_complete_urls"), null), jSONObject.optBoolean("use_displayed_impression", false), AutoClickProtectionConfigurationParcel.m7563a(jSONObject.optJSONObject("auto_protection_configuration")), adRequestInfoParcel.f5511I, jSONObject.optString("set_cookie", ""), m11389a(jSONObject.optJSONArray("remote_ping_urls"), null), jSONObject.optBoolean("render_in_browser", adRequestInfoParcel.f5515M), optString5, SafeBrowsingConfigParcel.m7758a(jSONObject.optJSONObject("safe_browsing")), optString8, jSONObject.optBoolean("content_vertical_opted_out", true));
                }
            }
            j3 = j2;
            optString9 = jSONObject.optString("active_view");
            str3 = null;
            optBoolean = jSONObject.optBoolean("ad_is_javascript", false);
            if (optBoolean) {
                str3 = jSONObject.optString("ad_passback_url", null);
            }
            return new AdResponseParcel(adRequestInfoParcel, optString2, str2, list, list2, j3, jSONObject.optBoolean("mediation", false), jSONObject.optLong("mediation_config_cache_time_milliseconds", -1), list3, jSONObject.optLong("refresh_interval_milliseconds", -1), i, optString4, j, optString7, optBoolean, str3, optString9, jSONObject.optBoolean("custom_render_allowed", false), z, adRequestInfoParcel.f5534p, jSONObject.optBoolean("content_url_opted_out", true), jSONObject.optBoolean("prefetch", false), jSONObject.optString("gws_query_id", ""), "height".equals(jSONObject.optString("fluid", "")), jSONObject.optBoolean("native_express", false), RewardItemParcel.m7723a(jSONObject.optJSONArray("rewards")), m11389a(jSONObject.optJSONArray("video_start_urls"), null), m11389a(jSONObject.optJSONArray("video_complete_urls"), null), jSONObject.optBoolean("use_displayed_impression", false), AutoClickProtectionConfigurationParcel.m7563a(jSONObject.optJSONObject("auto_protection_configuration")), adRequestInfoParcel.f5511I, jSONObject.optString("set_cookie", ""), m11389a(jSONObject.optJSONArray("remote_ping_urls"), null), jSONObject.optBoolean("render_in_browser", adRequestInfoParcel.f5515M), optString5, SafeBrowsingConfigParcel.m7758a(jSONObject.optJSONObject("safe_browsing")), optString8, jSONObject.optBoolean("content_vertical_opted_out", true));
        } catch (JSONException e) {
            String str4 = "Could not parse the inline ad response: ";
            optString = String.valueOf(e.getMessage());
            C1043e.m7801d(optString.length() != 0 ? str4.concat(optString) : new String(str4));
            return new AdResponseParcel(0);
        }
    }

    /* renamed from: a */
    private static Integer m11386a(boolean z) {
        return Integer.valueOf(z ? 1 : 0);
    }

    /* renamed from: a */
    private static String m11387a(int i) {
        return String.format(Locale.US, "#%06x", new Object[]{Integer.valueOf(16777215 & i)});
    }

    /* renamed from: a */
    private static String m11388a(NativeAdOptionsParcel nativeAdOptionsParcel) {
        switch (nativeAdOptionsParcel != null ? nativeAdOptionsParcel.f5155c : 0) {
            case 1:
                return "portrait";
            case 2:
                return "landscape";
            default:
                return "any";
        }
    }

    /* renamed from: a */
    private static List<String> m11389a(JSONArray jSONArray, List<String> list) {
        if (jSONArray == null) {
            return null;
        }
        if (list == null) {
            list = new LinkedList();
        }
        for (int i = 0; i < jSONArray.length(); i++) {
            list.add(jSONArray.getString(i));
        }
        return list;
    }

    /* renamed from: a */
    static JSONArray m11390a(List<String> list) {
        JSONArray jSONArray = new JSONArray();
        for (String put : list) {
            jSONArray.put(put);
        }
        return jSONArray;
    }

    /* renamed from: a */
    public static JSONObject m11391a(Context context, akx akx) {
        Object obj;
        String str;
        String valueOf;
        AdRequestInfoParcel adRequestInfoParcel = akx.f7775h;
        Location location = akx.f7771d;
        alp alp = akx.f7776i;
        Bundle bundle = akx.f7768a;
        JSONObject jSONObject = akx.f7777j;
        HashMap hashMap = new HashMap();
        hashMap.put("extra_caps", xm.bX.m15604c());
        if (akx.f7770c.size() > 0) {
            hashMap.put("eid", TextUtils.join(",", akx.f7770c));
        }
        if (adRequestInfoParcel.f5520b != null) {
            hashMap.put("ad_pos", adRequestInfoParcel.f5520b);
        }
        m11395a(hashMap, adRequestInfoParcel.f5521c);
        if (adRequestInfoParcel.f5522d.f4973h != null) {
            obj = null;
            Object obj2 = null;
            for (AdSizeParcel adSizeParcel : adRequestInfoParcel.f5522d.f4973h) {
                if (!adSizeParcel.f4975j && r3 == null) {
                    hashMap.put("format", adSizeParcel.f4967b);
                    obj2 = 1;
                }
                if (adSizeParcel.f4975j && r2 == null) {
                    hashMap.put("fluid", "height");
                    obj = 1;
                }
                if (obj2 != null && r2 != null) {
                    break;
                }
            }
        } else {
            hashMap.put("format", adRequestInfoParcel.f5522d.f4967b);
            if (adRequestInfoParcel.f5522d.f4975j) {
                hashMap.put("fluid", "height");
            }
        }
        if (adRequestInfoParcel.f5522d.f4971f == -1) {
            hashMap.put("smart_w", "full");
        }
        if (adRequestInfoParcel.f5522d.f4968c == -2) {
            hashMap.put("smart_h", "auto");
        }
        if (adRequestInfoParcel.f5522d.f4973h != null) {
            StringBuilder stringBuilder = new StringBuilder();
            obj = null;
            for (AdSizeParcel adSizeParcel2 : adRequestInfoParcel.f5522d.f4973h) {
                if (adSizeParcel2.f4975j) {
                    obj = 1;
                } else {
                    int i;
                    if (stringBuilder.length() != 0) {
                        stringBuilder.append("|");
                    }
                    if (adSizeParcel2.f4971f == -1) {
                        i = (int) (((float) adSizeParcel2.f4972g) / alp.f7890r);
                    } else {
                        try {
                            i = adSizeParcel2.f4971f;
                        } catch (JSONException e) {
                            str = "Problem serializing ad request to JSON: ";
                            valueOf = String.valueOf(e.getMessage());
                            C1043e.m7801d(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
                            return null;
                        }
                    }
                    stringBuilder.append(i);
                    stringBuilder.append("x");
                    stringBuilder.append(adSizeParcel2.f4968c == -2 ? (int) (((float) adSizeParcel2.f4969d) / alp.f7890r) : adSizeParcel2.f4968c);
                }
            }
            if (obj != null) {
                if (stringBuilder.length() != 0) {
                    stringBuilder.insert(0, "|");
                }
                stringBuilder.insert(0, "320x50");
            }
            hashMap.put("sz", stringBuilder);
        }
        if (adRequestInfoParcel.f5531m != 0) {
            hashMap.put("native_version", Integer.valueOf(adRequestInfoParcel.f5531m));
            hashMap.put("native_templates", adRequestInfoParcel.f5532n);
            hashMap.put("native_image_orientation", m11388a(adRequestInfoParcel.f5544z));
            if (!adRequestInfoParcel.f5503A.isEmpty()) {
                hashMap.put("native_custom_templates", adRequestInfoParcel.f5503A);
            }
        }
        if (adRequestInfoParcel.f5522d.f4976k) {
            hashMap.put("ene", Boolean.valueOf(true));
        }
        hashMap.put("slotname", adRequestInfoParcel.f5523e);
        hashMap.put("pn", adRequestInfoParcel.f5524f.packageName);
        if (adRequestInfoParcel.f5525g != null) {
            hashMap.put("vc", Integer.valueOf(adRequestInfoParcel.f5525g.versionCode));
        }
        hashMap.put("ms", akx.f7774g);
        hashMap.put("seq_num", adRequestInfoParcel.f5527i);
        hashMap.put("session_id", adRequestInfoParcel.f5528j);
        hashMap.put("js", adRequestInfoParcel.f5529k.f5721b);
        m11397a(hashMap, alp, akx.f7772e, adRequestInfoParcel.f5517O, akx.f7769b);
        m11398a(hashMap, akx.f7773f);
        hashMap.put("platform", Build.MANUFACTURER);
        hashMap.put("submodel", Build.MODEL);
        if (location != null) {
            m11394a(hashMap, location);
        } else if (adRequestInfoParcel.f5521c.f4948a >= 2 && adRequestInfoParcel.f5521c.f4958k != null) {
            m11394a(hashMap, adRequestInfoParcel.f5521c.f4958k);
        }
        if (adRequestInfoParcel.f5519a >= 2) {
            hashMap.put("quality_signals", adRequestInfoParcel.f5530l);
        }
        if (adRequestInfoParcel.f5519a >= 4 && adRequestInfoParcel.f5534p) {
            hashMap.put("forceHttps", Boolean.valueOf(adRequestInfoParcel.f5534p));
        }
        if (bundle != null) {
            hashMap.put("content_info", bundle);
        }
        if (adRequestInfoParcel.f5519a >= 5) {
            hashMap.put("u_sd", Float.valueOf(adRequestInfoParcel.f5538t));
            hashMap.put("sh", Integer.valueOf(adRequestInfoParcel.f5537s));
            hashMap.put("sw", Integer.valueOf(adRequestInfoParcel.f5536r));
        } else {
            hashMap.put("u_sd", Float.valueOf(alp.f7890r));
            hashMap.put("sh", Integer.valueOf(alp.f7892t));
            hashMap.put("sw", Integer.valueOf(alp.f7891s));
        }
        if (adRequestInfoParcel.f5519a >= 6) {
            if (!TextUtils.isEmpty(adRequestInfoParcel.f5539u)) {
                try {
                    hashMap.put("view_hierarchy", new JSONObject(adRequestInfoParcel.f5539u));
                } catch (Throwable e2) {
                    C1043e.m7800c("Problem serializing view hierarchy to JSON", e2);
                }
            }
            hashMap.put("correlation_id", Long.valueOf(adRequestInfoParcel.f5540v));
        }
        if (adRequestInfoParcel.f5519a >= 7) {
            hashMap.put("request_id", adRequestInfoParcel.f5541w);
        }
        if (adRequestInfoParcel.f5519a >= 11 && adRequestInfoParcel.f5505C != null) {
            hashMap.put("capability", adRequestInfoParcel.f5505C.m7564a());
        }
        if (adRequestInfoParcel.f5519a >= 12 && !TextUtils.isEmpty(adRequestInfoParcel.f5506D)) {
            hashMap.put("anchor", adRequestInfoParcel.f5506D);
        }
        if (adRequestInfoParcel.f5519a >= 13) {
            hashMap.put("android_app_volume", Float.valueOf(adRequestInfoParcel.f5507E));
        }
        if (adRequestInfoParcel.f5519a >= 18) {
            hashMap.put("android_app_muted", Boolean.valueOf(adRequestInfoParcel.f5513K));
        }
        if (adRequestInfoParcel.f5519a >= 14 && adRequestInfoParcel.f5508F > 0) {
            hashMap.put("target_api", Integer.valueOf(adRequestInfoParcel.f5508F));
        }
        if (adRequestInfoParcel.f5519a >= 15) {
            hashMap.put("scroll_index", Integer.valueOf(adRequestInfoParcel.f5509G == -1 ? -1 : adRequestInfoParcel.f5509G));
        }
        if (adRequestInfoParcel.f5519a >= 16) {
            hashMap.put("_activity_context", Boolean.valueOf(adRequestInfoParcel.f5510H));
        }
        if (adRequestInfoParcel.f5519a >= 18) {
            if (!TextUtils.isEmpty(adRequestInfoParcel.f5514L)) {
                try {
                    hashMap.put("app_settings", new JSONObject(adRequestInfoParcel.f5514L));
                } catch (Throwable e22) {
                    C1043e.m7800c("Problem creating json from app settings", e22);
                }
            }
            hashMap.put("render_in_browser", Boolean.valueOf(adRequestInfoParcel.f5515M));
        }
        if (adRequestInfoParcel.f5519a >= 18) {
            hashMap.put("android_num_video_cache_tasks", Integer.valueOf(adRequestInfoParcel.f5516N));
        }
        m11393a(hashMap);
        hashMap.put("cache_state", jSONObject);
        if (adRequestInfoParcel.f5519a >= 19) {
            hashMap.put("gct", adRequestInfoParcel.f5518P);
        }
        if (C1043e.m7796a(2)) {
            str = "Ad Request JSON: ";
            valueOf = String.valueOf(bd.m6644e().m11727a((Map) hashMap).toString(2));
            ano.m11653e(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        }
        return bd.m6644e().m11727a((Map) hashMap);
    }

    /* renamed from: a */
    public static JSONObject m11392a(AdResponseParcel adResponseParcel) {
        JSONObject jSONObject = new JSONObject();
        if (adResponseParcel.f5562b != null) {
            jSONObject.put("ad_base_url", adResponseParcel.f5562b);
        }
        if (adResponseParcel.f5573m != null) {
            jSONObject.put("ad_size", adResponseParcel.f5573m);
        }
        jSONObject.put("native", adResponseParcel.f5580t);
        if (adResponseParcel.f5580t) {
            jSONObject.put("ad_json", adResponseParcel.f5563c);
        } else {
            jSONObject.put("ad_html", adResponseParcel.f5563c);
        }
        if (adResponseParcel.f5575o != null) {
            jSONObject.put("debug_dialog", adResponseParcel.f5575o);
        }
        if (adResponseParcel.f5558N != null) {
            jSONObject.put("debug_signals", adResponseParcel.f5558N);
        }
        if (adResponseParcel.f5567g != -1) {
            jSONObject.put("interstitial_timeout", ((double) adResponseParcel.f5567g) / 1000.0d);
        }
        if (adResponseParcel.f5572l == bd.m6646g().mo1854b()) {
            jSONObject.put("orientation", "portrait");
        } else if (adResponseParcel.f5572l == bd.m6646g().mo1852a()) {
            jSONObject.put("orientation", "landscape");
        }
        if (adResponseParcel.f5564d != null) {
            jSONObject.put("click_urls", m11390a(adResponseParcel.f5564d));
        }
        if (adResponseParcel.f5566f != null) {
            jSONObject.put("impression_urls", m11390a(adResponseParcel.f5566f));
        }
        if (adResponseParcel.f5570j != null) {
            jSONObject.put("manual_impression_urls", m11390a(adResponseParcel.f5570j));
        }
        if (adResponseParcel.f5578r != null) {
            jSONObject.put("active_view", adResponseParcel.f5578r);
        }
        jSONObject.put("ad_is_javascript", adResponseParcel.f5576p);
        if (adResponseParcel.f5577q != null) {
            jSONObject.put("ad_passback_url", adResponseParcel.f5577q);
        }
        jSONObject.put("mediation", adResponseParcel.f5568h);
        jSONObject.put("custom_render_allowed", adResponseParcel.f5579s);
        jSONObject.put("content_url_opted_out", adResponseParcel.f5582v);
        jSONObject.put("content_vertical_opted_out", adResponseParcel.f5559O);
        jSONObject.put("prefetch", adResponseParcel.f5583w);
        if (adResponseParcel.f5571k != -1) {
            jSONObject.put("refresh_interval_milliseconds", adResponseParcel.f5571k);
        }
        if (adResponseParcel.f5569i != -1) {
            jSONObject.put("mediation_config_cache_time_milliseconds", adResponseParcel.f5569i);
        }
        if (!TextUtils.isEmpty(adResponseParcel.f5586z)) {
            jSONObject.put("gws_query_id", adResponseParcel.f5586z);
        }
        jSONObject.put("fluid", adResponseParcel.f5545A ? "height" : "");
        jSONObject.put("native_express", adResponseParcel.f5546B);
        if (adResponseParcel.f5548D != null) {
            jSONObject.put("video_start_urls", m11390a(adResponseParcel.f5548D));
        }
        if (adResponseParcel.f5549E != null) {
            jSONObject.put("video_complete_urls", m11390a(adResponseParcel.f5549E));
        }
        if (adResponseParcel.f5547C != null) {
            jSONObject.put("rewards", adResponseParcel.f5547C.m7724a());
        }
        jSONObject.put("use_displayed_impression", adResponseParcel.f5550F);
        jSONObject.put("auto_protection_configuration", adResponseParcel.f5551G);
        jSONObject.put("render_in_browser", adResponseParcel.f5555K);
        return jSONObject;
    }

    /* renamed from: a */
    private static void m11393a(HashMap<String, Object> hashMap) {
        Bundle bundle = new Bundle();
        Bundle bundle2 = new Bundle();
        bundle2.putString("cl", "135396225");
        bundle2.putString("rapid_rc", "dev");
        bundle2.putString("rapid_rollup", HttpHead.METHOD_NAME);
        bundle.putBundle("build_meta", bundle2);
        bundle.putString("mf", Boolean.toString(((Boolean) xm.bZ.m15604c()).booleanValue()));
        hashMap.put("sdk_env", bundle);
    }

    /* renamed from: a */
    private static void m11394a(HashMap<String, Object> hashMap, Location location) {
        HashMap hashMap2 = new HashMap();
        Float valueOf = Float.valueOf(location.getAccuracy() * 1000.0f);
        Long valueOf2 = Long.valueOf(location.getTime() * 1000);
        Long valueOf3 = Long.valueOf((long) (location.getLatitude() * 1.0E7d));
        Long valueOf4 = Long.valueOf((long) (location.getLongitude() * 1.0E7d));
        hashMap2.put("radius", valueOf);
        hashMap2.put("lat", valueOf3);
        hashMap2.put("long", valueOf4);
        hashMap2.put("time", valueOf2);
        hashMap.put("uule", hashMap2);
    }

    /* renamed from: a */
    private static void m11395a(HashMap<String, Object> hashMap, AdRequestParcel adRequestParcel) {
        String a = anl.m11648a();
        if (a != null) {
            hashMap.put("abf", a);
        }
        if (adRequestParcel.f4949b != -1) {
            hashMap.put("cust_age", f7815a.format(new Date(adRequestParcel.f4949b)));
        }
        if (adRequestParcel.f4950c != null) {
            hashMap.put("extras", adRequestParcel.f4950c);
        }
        if (adRequestParcel.f4951d != -1) {
            hashMap.put("cust_gender", Integer.valueOf(adRequestParcel.f4951d));
        }
        if (adRequestParcel.f4952e != null) {
            hashMap.put("kw", adRequestParcel.f4952e);
        }
        if (adRequestParcel.f4954g != -1) {
            hashMap.put("tag_for_child_directed_treatment", Integer.valueOf(adRequestParcel.f4954g));
        }
        if (adRequestParcel.f4953f) {
            hashMap.put("adtest", "on");
        }
        if (adRequestParcel.f4948a >= 2) {
            if (adRequestParcel.f4955h) {
                hashMap.put("d_imp_hdr", Integer.valueOf(1));
            }
            if (!TextUtils.isEmpty(adRequestParcel.f4956i)) {
                hashMap.put("ppid", adRequestParcel.f4956i);
            }
            if (adRequestParcel.f4957j != null) {
                m11396a((HashMap) hashMap, adRequestParcel.f4957j);
            }
        }
        if (adRequestParcel.f4948a >= 3 && adRequestParcel.f4959l != null) {
            hashMap.put(NativeProtocol.IMAGE_URL_KEY, adRequestParcel.f4959l);
        }
        if (adRequestParcel.f4948a >= 5) {
            if (adRequestParcel.f4961n != null) {
                hashMap.put("custom_targeting", adRequestParcel.f4961n);
            }
            if (adRequestParcel.f4962o != null) {
                hashMap.put("category_exclusions", adRequestParcel.f4962o);
            }
            if (adRequestParcel.f4963p != null) {
                hashMap.put("request_agent", adRequestParcel.f4963p);
            }
        }
        if (adRequestParcel.f4948a >= 6 && adRequestParcel.f4964q != null) {
            hashMap.put("request_pkg", adRequestParcel.f4964q);
        }
        if (adRequestParcel.f4948a >= 7) {
            hashMap.put("is_designed_for_families", Boolean.valueOf(adRequestParcel.f4965r));
        }
    }

    /* renamed from: a */
    private static void m11396a(HashMap<String, Object> hashMap, SearchAdRequestParcel searchAdRequestParcel) {
        Object obj;
        Object obj2 = null;
        if (Color.alpha(searchAdRequestParcel.f4978b) != 0) {
            hashMap.put("acolor", m11387a(searchAdRequestParcel.f4978b));
        }
        if (Color.alpha(searchAdRequestParcel.f4979c) != 0) {
            hashMap.put("bgcolor", m11387a(searchAdRequestParcel.f4979c));
        }
        if (!(Color.alpha(searchAdRequestParcel.f4980d) == 0 || Color.alpha(searchAdRequestParcel.f4981e) == 0)) {
            hashMap.put("gradientto", m11387a(searchAdRequestParcel.f4980d));
            hashMap.put("gradientfrom", m11387a(searchAdRequestParcel.f4981e));
        }
        if (Color.alpha(searchAdRequestParcel.f4982f) != 0) {
            hashMap.put("bcolor", m11387a(searchAdRequestParcel.f4982f));
        }
        hashMap.put("bthick", Integer.toString(searchAdRequestParcel.f4983g));
        switch (searchAdRequestParcel.f4984h) {
            case 0:
                obj = "none";
                break;
            case 1:
                obj = "dashed";
                break;
            case 2:
                obj = "dotted";
                break;
            case 3:
                obj = "solid";
                break;
            default:
                obj = null;
                break;
        }
        if (obj != null) {
            hashMap.put("btype", obj);
        }
        switch (searchAdRequestParcel.f4985i) {
            case 0:
                obj2 = "light";
                break;
            case 1:
                obj2 = "medium";
                break;
            case 2:
                obj2 = "dark";
                break;
        }
        if (obj2 != null) {
            hashMap.put("callbuttoncolor", obj2);
        }
        if (searchAdRequestParcel.f4986j != null) {
            hashMap.put("channel", searchAdRequestParcel.f4986j);
        }
        if (Color.alpha(searchAdRequestParcel.f4987k) != 0) {
            hashMap.put("dcolor", m11387a(searchAdRequestParcel.f4987k));
        }
        if (searchAdRequestParcel.f4988l != null) {
            hashMap.put("font", searchAdRequestParcel.f4988l);
        }
        if (Color.alpha(searchAdRequestParcel.f4989m) != 0) {
            hashMap.put("hcolor", m11387a(searchAdRequestParcel.f4989m));
        }
        hashMap.put("headersize", Integer.toString(searchAdRequestParcel.f4990n));
        if (searchAdRequestParcel.f4991o != null) {
            hashMap.put("q", searchAdRequestParcel.f4991o);
        }
    }

    /* renamed from: a */
    private static void m11397a(HashMap<String, Object> hashMap, alp alp, alw alw, Bundle bundle, Bundle bundle2) {
        hashMap.put("am", Integer.valueOf(alp.f7873a));
        hashMap.put("cog", m11386a(alp.f7874b));
        hashMap.put("coh", m11386a(alp.f7875c));
        if (!TextUtils.isEmpty(alp.f7876d)) {
            hashMap.put("carrier", alp.f7876d);
        }
        hashMap.put("gl", alp.f7877e);
        if (alp.f7878f) {
            hashMap.put("simulator", Integer.valueOf(1));
        }
        if (alp.f7879g) {
            hashMap.put("is_sidewinder", Integer.valueOf(1));
        }
        hashMap.put("ma", m11386a(alp.f7880h));
        hashMap.put("sp", m11386a(alp.f7881i));
        hashMap.put("hl", alp.f7882j);
        if (!TextUtils.isEmpty(alp.f7883k)) {
            hashMap.put("mv", alp.f7883k);
        }
        hashMap.put("muv", Integer.valueOf(alp.f7884l));
        if (alp.f7885m != -2) {
            hashMap.put("cnt", Integer.valueOf(alp.f7885m));
        }
        hashMap.put("gnt", Integer.valueOf(alp.f7886n));
        hashMap.put("pt", Integer.valueOf(alp.f7887o));
        hashMap.put("rm", Integer.valueOf(alp.f7888p));
        hashMap.put("riv", Integer.valueOf(alp.f7889q));
        Bundle bundle3 = new Bundle();
        bundle3.putString("build", alp.f7897y);
        Bundle bundle4 = new Bundle();
        bundle4.putBoolean("is_charging", alp.f7894v);
        bundle4.putDouble("battery_level", alp.f7893u);
        bundle3.putBundle("battery", bundle4);
        bundle4 = new Bundle();
        bundle4.putInt("active_network_state", alp.f7896x);
        bundle4.putBoolean("active_network_metered", alp.f7895w);
        if (alw != null) {
            Bundle bundle5 = new Bundle();
            bundle5.putInt("predicted_latency_micros", alw.f7929a);
            bundle5.putLong("predicted_down_throughput_bps", alw.f7930b);
            bundle5.putLong("predicted_up_throughput_bps", alw.f7931c);
            bundle4.putBundle("predictions", bundle5);
        }
        bundle3.putBundle("network", bundle4);
        bundle4 = new Bundle();
        bundle4.putBoolean("is_browser_custom_tabs_capable", alp.f7898z);
        bundle3.putBundle("browser", bundle4);
        if (bundle != null) {
            bundle3.putBundle("android_mem_info", m11384a(bundle));
        }
        bundle4 = new Bundle();
        bundle4.putBundle("parental_controls", bundle2);
        bundle3.putBundle("play_store", bundle4);
        hashMap.put("device", bundle3);
    }

    /* renamed from: a */
    private static void m11398a(HashMap<String, Object> hashMap, String str) {
        Bundle bundle = new Bundle();
        bundle.putString("doritos", str);
        hashMap.put("pii", bundle);
    }
}
