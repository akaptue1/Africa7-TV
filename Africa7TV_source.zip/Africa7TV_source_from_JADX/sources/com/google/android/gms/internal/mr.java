package com.google.android.gms.internal;

public class mr extends RuntimeException {
    public mr(String str) {
        super(str);
    }

    public mr(String str, Throwable th) {
        super(str, th);
    }

    public mr(Throwable th) {
        super(th);
    }
}
