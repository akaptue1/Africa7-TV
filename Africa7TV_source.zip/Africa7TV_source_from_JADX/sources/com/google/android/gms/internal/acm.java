package com.google.android.gms.internal;

class acm implements acy {
    /* renamed from: a */
    final /* synthetic */ yf f7236a;
    /* renamed from: b */
    final /* synthetic */ acl f7237b;

    acm(acl acl, yf yfVar) {
        this.f7237b = acl;
        this.f7236a = yfVar;
    }

    /* renamed from: a */
    public void mo1696a(acz acz) {
        if (acz.f7256d != null) {
            acz.f7256d.mo1698a(this.f7236a);
        }
    }
}
