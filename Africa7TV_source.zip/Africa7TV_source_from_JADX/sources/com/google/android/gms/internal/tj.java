package com.google.android.gms.internal;

public class tj extends ty {
    /* renamed from: i */
    private static volatile Long f10397i = null;
    /* renamed from: j */
    private static final Object f10398j = new Object();

    public tj(sy syVar, String str, String str2, fa faVar, int i, int i2) {
        super(syVar, str, str2, faVar, i, i2);
    }

    /* renamed from: a */
    protected void mo2283a() {
        if (f10397i == null) {
            synchronized (f10398j) {
                if (f10397i == null) {
                    f10397i = (Long) this.f.invoke(null, new Object[0]);
                }
            }
        }
        synchronized (this.e) {
            this.e.f9329K = f10397i;
        }
    }
}
