package com.google.android.gms.internal;

import android.os.IInterface;

public interface zp extends IInterface {
    /* renamed from: a */
    void mo2347a(zg zgVar, String str);
}
