package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface mk<T> {
    /* renamed from: b */
    T mo2230b(ml mlVar, Type type, mj mjVar);
}
