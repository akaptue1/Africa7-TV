package com.google.android.gms.internal;

import com.google.android.gms.ads.formats.C0816i;

@akw
public class zx extends zn {
    /* renamed from: a */
    private final C0816i f10775a;

    public zx(C0816i c0816i) {
        this.f10775a = c0816i;
    }

    /* renamed from: a */
    public void mo2346a(zc zcVar) {
        this.f10775a.mo1049a(m15777b(zcVar));
    }

    /* renamed from: b */
    zf m15777b(zc zcVar) {
        return new zf(zcVar);
    }
}
