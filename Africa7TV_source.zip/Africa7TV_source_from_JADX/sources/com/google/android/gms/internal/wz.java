package com.google.android.gms.internal;

import android.text.TextUtils;

@akw
public final class wz {
    /* renamed from: a */
    private String f10639a;

    public wz() {
        this((String) xm.f10679b.m15603b());
    }

    public wz(String str) {
        this.f10639a = TextUtils.isEmpty(str) ? (String) xm.f10679b.m15603b() : str;
    }

    /* renamed from: a */
    public String m15590a() {
        return this.f10639a;
    }
}
