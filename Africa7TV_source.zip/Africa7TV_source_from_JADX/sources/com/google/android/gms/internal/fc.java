package com.google.android.gms.internal;

public final class fc extends rs<fc> {
    /* renamed from: a */
    public Long f9384a;
    /* renamed from: b */
    public Long f9385b;
    /* renamed from: c */
    public Long f9386c;

    public fc() {
        this.f9384a = null;
        this.f9385b = null;
        this.f9386c = null;
        this.ah = -1;
    }

    /* renamed from: a */
    public fc m13793a(rp rpVar) {
        while (true) {
            int a = rpVar.m14968a();
            switch (a) {
                case 0:
                    break;
                case 8:
                    this.f9384a = Long.valueOf(rpVar.m14980f());
                    continue;
                case 16:
                    this.f9385b = Long.valueOf(rpVar.m14980f());
                    continue;
                case 24:
                    this.f9386c = Long.valueOf(rpVar.m14980f());
                    continue;
                default:
                    if (!super.m13673a(rpVar, a)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    /* renamed from: a */
    public void mo2082a(rq rqVar) {
        if (this.f9384a != null) {
            rqVar.m15043b(1, this.f9384a.longValue());
        }
        if (this.f9385b != null) {
            rqVar.m15043b(2, this.f9385b.longValue());
        }
        if (this.f9386c != null) {
            rqVar.m15043b(3, this.f9386c.longValue());
        }
        super.mo2082a(rqVar);
    }

    /* renamed from: b */
    protected int mo2083b() {
        int b = super.mo2083b();
        if (this.f9384a != null) {
            b += rq.m15018e(1, this.f9384a.longValue());
        }
        if (this.f9385b != null) {
            b += rq.m15018e(2, this.f9385b.longValue());
        }
        return this.f9386c != null ? b + rq.m15018e(3, this.f9386c.longValue()) : b;
    }

    /* renamed from: b */
    public /* synthetic */ rz mo2084b(rp rpVar) {
        return m13793a(rpVar);
    }
}
