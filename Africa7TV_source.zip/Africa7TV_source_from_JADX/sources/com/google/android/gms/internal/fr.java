package com.google.android.gms.internal;

import java.util.HashMap;
import java.util.Map;

public class fr {
    /* renamed from: a */
    private final Map<String, fy> f9424a = new HashMap();
    /* renamed from: b */
    private fy f9425b;

    /* renamed from: a */
    public fp m13831a() {
        return new fp(this.f9424a, this.f9425b);
    }

    /* renamed from: a */
    public fr m13832a(fy fyVar) {
        this.f9425b = fyVar;
        return this;
    }

    /* renamed from: a */
    public fr m13833a(String str, fy fyVar) {
        this.f9424a.put(str, fyVar);
        return this;
    }
}
