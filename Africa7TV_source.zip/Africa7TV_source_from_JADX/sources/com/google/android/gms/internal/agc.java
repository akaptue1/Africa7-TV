package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IInterface;
import com.google.android.gms.ads.internal.client.C0887e;
import com.google.android.gms.p034a.C0827c;
import java.util.List;

public interface agc extends IInterface {
    /* renamed from: a */
    String mo1759a();

    /* renamed from: a */
    void mo1760a(C0827c c0827c);

    /* renamed from: b */
    List mo1761b();

    /* renamed from: b */
    void mo1762b(C0827c c0827c);

    /* renamed from: c */
    String mo1763c();

    /* renamed from: c */
    void mo1764c(C0827c c0827c);

    /* renamed from: d */
    yo mo1765d();

    /* renamed from: e */
    String mo1766e();

    /* renamed from: f */
    double mo1767f();

    /* renamed from: g */
    String mo1768g();

    /* renamed from: h */
    String mo1769h();

    /* renamed from: i */
    void mo1770i();

    /* renamed from: j */
    boolean mo1771j();

    /* renamed from: k */
    boolean mo1772k();

    /* renamed from: l */
    Bundle mo1773l();

    /* renamed from: m */
    C0887e mo1774m();
}
