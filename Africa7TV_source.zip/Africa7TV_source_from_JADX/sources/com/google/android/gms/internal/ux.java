package com.google.android.gms.internal;

public interface ux {
    /* renamed from: a */
    void mo2302a(ur urVar);
}
