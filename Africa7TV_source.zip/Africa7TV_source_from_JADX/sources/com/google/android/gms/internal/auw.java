package com.google.android.gms.internal;

public class auw extends awv {
    public auw(ahu ahu) {
        super(ahu);
    }
}
