package com.google.android.gms.internal;

import java.net.InetAddress;

final class qd extends nd<InetAddress> {
    qd() {
    }

    /* renamed from: a */
    public InetAddress m14847a(ri riVar) {
        if (riVar.mo2248f() != rk.NULL) {
            return InetAddress.getByName(riVar.mo2250h());
        }
        riVar.mo2252j();
        return null;
    }

    /* renamed from: a */
    public void m14849a(rl rlVar, InetAddress inetAddress) {
        rlVar.mo2265b(inetAddress == null ? null : inetAddress.getHostAddress());
    }

    /* renamed from: b */
    public /* synthetic */ Object mo2144b(ri riVar) {
        return m14847a(riVar);
    }
}
