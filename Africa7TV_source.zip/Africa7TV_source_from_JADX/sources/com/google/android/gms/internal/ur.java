package com.google.android.gms.internal;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;
import android.view.WindowManager;
import com.facebook.AppEventsConstants;
import com.facebook.internal.ServerProtocol;
import com.google.android.gms.ads.internal.bd;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.util.client.C1043e;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;

@akw
public class ur implements OnGlobalLayoutListener, OnScrollChangedListener {
    /* renamed from: a */
    protected final Object f10450a = new Object();
    /* renamed from: b */
    protected final up f10451b;
    /* renamed from: c */
    BroadcastReceiver f10452c;
    /* renamed from: d */
    private final WeakReference<ana> f10453d;
    /* renamed from: e */
    private WeakReference<ViewTreeObserver> f10454e;
    /* renamed from: f */
    private final vz f10455f;
    /* renamed from: g */
    private final Context f10456g;
    /* renamed from: h */
    private final WindowManager f10457h;
    /* renamed from: i */
    private final PowerManager f10458i;
    /* renamed from: j */
    private final KeyguardManager f10459j;
    /* renamed from: k */
    private ux f10460k;
    /* renamed from: l */
    private boolean f10461l;
    /* renamed from: m */
    private boolean f10462m = false;
    /* renamed from: n */
    private boolean f10463n = false;
    /* renamed from: o */
    private boolean f10464o;
    /* renamed from: p */
    private boolean f10465p;
    /* renamed from: q */
    private boolean f10466q;
    /* renamed from: r */
    private final HashSet<uo> f10467r = new HashSet();
    /* renamed from: s */
    private aqg f10468s;
    /* renamed from: t */
    private final HashSet<vk> f10469t = new HashSet();

    public ur(Context context, AdSizeParcel adSizeParcel, ana ana, VersionInfoParcel versionInfoParcel, vz vzVar) {
        this.f10453d = new WeakReference(ana);
        this.f10455f = vzVar;
        this.f10454e = new WeakReference(null);
        this.f10464o = true;
        this.f10466q = false;
        this.f10468s = new aqg(200);
        this.f10451b = new up(UUID.randomUUID().toString(), versionInfoParcel, adSizeParcel.f4967b, ana.f8016j, ana.m11573a(), adSizeParcel.f4974i);
        this.f10457h = (WindowManager) context.getSystemService("window");
        this.f10458i = (PowerManager) context.getApplicationContext().getSystemService("power");
        this.f10459j = (KeyguardManager) context.getSystemService("keyguard");
        this.f10456g = context;
    }

    /* renamed from: a */
    protected int m15398a(int i, DisplayMetrics displayMetrics) {
        return (int) (((float) i) / displayMetrics.density);
    }

    /* renamed from: a */
    protected JSONObject m15399a(View view) {
        if (view == null) {
            return m15424l();
        }
        boolean a = bd.m6646g().mo1868a(view);
        int[] iArr = new int[2];
        int[] iArr2 = new int[2];
        try {
            view.getLocationOnScreen(iArr);
            view.getLocationInWindow(iArr2);
        } catch (Throwable e) {
            C1043e.m7798b("Failure getting view location.", e);
        }
        DisplayMetrics displayMetrics = view.getContext().getResources().getDisplayMetrics();
        Rect rect = new Rect();
        rect.left = iArr[0];
        rect.top = iArr[1];
        rect.right = rect.left + view.getWidth();
        rect.bottom = rect.top + view.getHeight();
        Rect rect2 = new Rect();
        rect2.right = this.f10457h.getDefaultDisplay().getWidth();
        rect2.bottom = this.f10457h.getDefaultDisplay().getHeight();
        Rect rect3 = new Rect();
        boolean globalVisibleRect = view.getGlobalVisibleRect(rect3, null);
        Rect rect4 = new Rect();
        boolean localVisibleRect = view.getLocalVisibleRect(rect4);
        Rect rect5 = new Rect();
        view.getHitRect(rect5);
        JSONObject i = m15421i();
        i.put("windowVisibility", view.getWindowVisibility()).put("isAttachedToWindow", a).put("viewBox", new JSONObject().put("top", m15398a(rect2.top, displayMetrics)).put("bottom", m15398a(rect2.bottom, displayMetrics)).put("left", m15398a(rect2.left, displayMetrics)).put("right", m15398a(rect2.right, displayMetrics))).put("adBox", new JSONObject().put("top", m15398a(rect.top, displayMetrics)).put("bottom", m15398a(rect.bottom, displayMetrics)).put("left", m15398a(rect.left, displayMetrics)).put("right", m15398a(rect.right, displayMetrics))).put("globalVisibleBox", new JSONObject().put("top", m15398a(rect3.top, displayMetrics)).put("bottom", m15398a(rect3.bottom, displayMetrics)).put("left", m15398a(rect3.left, displayMetrics)).put("right", m15398a(rect3.right, displayMetrics))).put("globalVisibleBoxVisible", globalVisibleRect).put("localVisibleBox", new JSONObject().put("top", m15398a(rect4.top, displayMetrics)).put("bottom", m15398a(rect4.bottom, displayMetrics)).put("left", m15398a(rect4.left, displayMetrics)).put("right", m15398a(rect4.right, displayMetrics))).put("localVisibleBoxVisible", localVisibleRect).put("hitBox", new JSONObject().put("top", m15398a(rect5.top, displayMetrics)).put("bottom", m15398a(rect5.bottom, displayMetrics)).put("left", m15398a(rect5.left, displayMetrics)).put("right", m15398a(rect5.right, displayMetrics))).put("screenDensity", (double) displayMetrics.density).put("isVisible", bd.m6644e().m11747a(view, this.f10458i, this.f10459j));
        return i;
    }

    /* renamed from: a */
    JSONObject m15400a(JSONObject jSONObject) {
        JSONArray jSONArray = new JSONArray();
        JSONObject jSONObject2 = new JSONObject();
        jSONArray.put(jSONObject);
        jSONObject2.put("units", jSONArray);
        return jSONObject2;
    }

    /* renamed from: a */
    protected void m15401a() {
        synchronized (this.f10450a) {
            if (this.f10452c != null) {
                return;
            }
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.SCREEN_ON");
            intentFilter.addAction("android.intent.action.SCREEN_OFF");
            this.f10452c = new us(this);
            this.f10456g.registerReceiver(this.f10452c, intentFilter);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    protected void m15402a(int r8) {
        /*
        r7 = this;
        r0 = 0;
        r1 = 1;
        r3 = r7.f10450a;
        monitor-enter(r3);
        r2 = r7.m15423k();	 Catch:{ all -> 0x0041 }
        if (r2 == 0) goto L_0x000f;
    L_0x000b:
        r2 = r7.f10464o;	 Catch:{ all -> 0x0041 }
        if (r2 != 0) goto L_0x0011;
    L_0x000f:
        monitor-exit(r3);	 Catch:{ all -> 0x0041 }
    L_0x0010:
        return;
    L_0x0011:
        r2 = r7.f10455f;	 Catch:{ all -> 0x0041 }
        r4 = r2.mo2303a();	 Catch:{ all -> 0x0041 }
        if (r4 == 0) goto L_0x0044;
    L_0x0019:
        r2 = com.google.android.gms.ads.internal.bd.m6644e();	 Catch:{ all -> 0x0041 }
        r5 = r7.f10458i;	 Catch:{ all -> 0x0041 }
        r6 = r7.f10459j;	 Catch:{ all -> 0x0041 }
        r2 = r2.m11747a(r4, r5, r6);	 Catch:{ all -> 0x0041 }
        if (r2 == 0) goto L_0x0044;
    L_0x0027:
        r2 = new android.graphics.Rect;	 Catch:{ all -> 0x0041 }
        r2.<init>();	 Catch:{ all -> 0x0041 }
        r5 = 0;
        r2 = r4.getGlobalVisibleRect(r2, r5);	 Catch:{ all -> 0x0041 }
        if (r2 == 0) goto L_0x0044;
    L_0x0033:
        r2 = r1;
    L_0x0034:
        r5 = r7.f10455f;	 Catch:{ all -> 0x0041 }
        r5 = r5.mo2304b();	 Catch:{ all -> 0x0041 }
        if (r5 == 0) goto L_0x0046;
    L_0x003c:
        r7.m15416d();	 Catch:{ all -> 0x0041 }
        monitor-exit(r3);	 Catch:{ all -> 0x0041 }
        goto L_0x0010;
    L_0x0041:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x0041 }
        throw r0;
    L_0x0044:
        r2 = r0;
        goto L_0x0034;
    L_0x0046:
        if (r8 != r1) goto L_0x0049;
    L_0x0048:
        r0 = r1;
    L_0x0049:
        if (r0 == 0) goto L_0x0059;
    L_0x004b:
        r0 = r7.f10468s;	 Catch:{ all -> 0x0041 }
        r0 = r0.m11899a();	 Catch:{ all -> 0x0041 }
        if (r0 != 0) goto L_0x0059;
    L_0x0053:
        r0 = r7.f10466q;	 Catch:{ all -> 0x0041 }
        if (r2 != r0) goto L_0x0059;
    L_0x0057:
        monitor-exit(r3);	 Catch:{ all -> 0x0041 }
        goto L_0x0010;
    L_0x0059:
        if (r2 != 0) goto L_0x0063;
    L_0x005b:
        r0 = r7.f10466q;	 Catch:{ all -> 0x0041 }
        if (r0 != 0) goto L_0x0063;
    L_0x005f:
        if (r8 != r1) goto L_0x0063;
    L_0x0061:
        monitor-exit(r3);	 Catch:{ all -> 0x0041 }
        goto L_0x0010;
    L_0x0063:
        r0 = r7.m15399a(r4);	 Catch:{ JSONException -> 0x0075, RuntimeException -> 0x007c }
        r1 = 0;
        r7.m15408a(r0, r1);	 Catch:{ JSONException -> 0x0075, RuntimeException -> 0x007c }
        r7.f10466q = r2;	 Catch:{ JSONException -> 0x0075, RuntimeException -> 0x007c }
    L_0x006d:
        r7.m15419g();	 Catch:{ all -> 0x0041 }
        r7.m15417e();	 Catch:{ all -> 0x0041 }
        monitor-exit(r3);	 Catch:{ all -> 0x0041 }
        goto L_0x0010;
    L_0x0075:
        r0 = move-exception;
    L_0x0076:
        r1 = "Active view update failed.";
        com.google.android.gms.ads.internal.util.client.C1043e.m7795a(r1, r0);	 Catch:{ all -> 0x0041 }
        goto L_0x006d;
    L_0x007c:
        r0 = move-exception;
        goto L_0x0076;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ur.a(int):void");
    }

    /* renamed from: a */
    protected void m15403a(View view, Map<String, String> map) {
        m15402a(3);
    }

    /* renamed from: a */
    void m15404a(arh arh, Map<String, String> map) {
        m15403a(arh.mo1896b(), (Map) map);
    }

    /* renamed from: a */
    public void m15405a(ux uxVar) {
        synchronized (this.f10450a) {
            this.f10460k = uxVar;
        }
    }

    /* renamed from: a */
    public void m15406a(vk vkVar) {
        if (this.f10469t.isEmpty()) {
            m15401a();
            m15402a(3);
        }
        this.f10469t.add(vkVar);
        try {
            vkVar.mo2306a(m15400a(m15399a(this.f10455f.mo2303a())), false);
        } catch (Throwable e) {
            C1043e.m7798b("Skipping measurement update for new client.", e);
        }
    }

    /* renamed from: a */
    void m15407a(vk vkVar, Map<String, String> map) {
        String str = "Received request to untrack: ";
        String valueOf = String.valueOf(this.f10451b.m15383d());
        C1043e.m7794a(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        m15412b(vkVar);
    }

    /* renamed from: a */
    protected void m15408a(JSONObject jSONObject, boolean z) {
        try {
            m15414b(m15400a(jSONObject), z);
        } catch (Throwable th) {
            C1043e.m7798b("Skipping active view message.", th);
        }
    }

    /* renamed from: a */
    protected void m15409a(boolean z) {
        Iterator it = this.f10467r.iterator();
        while (it.hasNext()) {
            ((uo) it.next()).m15379a(this, z);
        }
    }

    /* renamed from: a */
    boolean m15410a(Map<String, String> map) {
        if (map == null) {
            return false;
        }
        String str = (String) map.get("hashCode");
        boolean z = !TextUtils.isEmpty(str) && str.equals(this.f10451b.m15383d());
        return z;
    }

    /* renamed from: b */
    protected void m15411b() {
        synchronized (this.f10450a) {
            if (this.f10452c != null) {
                try {
                    this.f10456g.unregisterReceiver(this.f10452c);
                } catch (Throwable e) {
                    C1043e.m7798b("Failed trying to unregister the receiver", e);
                } catch (Throwable e2) {
                    bd.m6648i().m11608a(e2, "ActiveViewUnit.stopScreenStatusMonitoring");
                }
                this.f10452c = null;
            }
        }
    }

    /* renamed from: b */
    public void m15412b(vk vkVar) {
        this.f10469t.remove(vkVar);
        vkVar.mo2308b();
        if (this.f10469t.isEmpty()) {
            m15415c();
        }
    }

    /* renamed from: b */
    void m15413b(Map<String, String> map) {
        if (map.containsKey("isVisible")) {
            boolean z = AppEventsConstants.EVENT_PARAM_VALUE_YES.equals(map.get("isVisible")) || ServerProtocol.DIALOG_RETURN_SCOPES_TRUE.equals(map.get("isVisible"));
            m15409a(z);
        }
    }

    /* renamed from: b */
    protected void m15414b(JSONObject jSONObject, boolean z) {
        Iterator it = new ArrayList(this.f10469t).iterator();
        while (it.hasNext()) {
            ((vk) it.next()).mo2306a(jSONObject, z);
        }
    }

    /* renamed from: c */
    protected void m15415c() {
        synchronized (this.f10450a) {
            m15420h();
            m15411b();
            this.f10464o = false;
            m15417e();
            m15422j();
        }
    }

    /* renamed from: d */
    public void m15416d() {
        synchronized (this.f10450a) {
            if (this.f10464o) {
                this.f10465p = true;
                try {
                    m15408a(m15426n(), true);
                } catch (Throwable e) {
                    C1043e.m7798b("JSON failure while processing active view data.", e);
                } catch (Throwable e2) {
                    C1043e.m7798b("Failure while processing active view data.", e2);
                }
                String str = "Untracking ad unit: ";
                String valueOf = String.valueOf(this.f10451b.m15383d());
                C1043e.m7794a(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            }
        }
    }

    /* renamed from: e */
    protected void m15417e() {
        if (this.f10460k != null) {
            this.f10460k.mo2302a(this);
        }
    }

    /* renamed from: f */
    public boolean m15418f() {
        boolean z;
        synchronized (this.f10450a) {
            z = this.f10464o;
        }
        return z;
    }

    /* renamed from: g */
    protected void m15419g() {
        View a = this.f10455f.mo2305c().mo2303a();
        if (a != null) {
            ViewTreeObserver viewTreeObserver = (ViewTreeObserver) this.f10454e.get();
            ViewTreeObserver viewTreeObserver2 = a.getViewTreeObserver();
            if (viewTreeObserver2 != viewTreeObserver) {
                m15420h();
                if (!this.f10461l || (viewTreeObserver != null && viewTreeObserver.isAlive())) {
                    this.f10461l = true;
                    viewTreeObserver2.addOnScrollChangedListener(this);
                    viewTreeObserver2.addOnGlobalLayoutListener(this);
                }
                this.f10454e = new WeakReference(viewTreeObserver2);
            }
        }
    }

    /* renamed from: h */
    protected void m15420h() {
        ViewTreeObserver viewTreeObserver = (ViewTreeObserver) this.f10454e.get();
        if (viewTreeObserver != null && viewTreeObserver.isAlive()) {
            viewTreeObserver.removeOnScrollChangedListener(this);
            viewTreeObserver.removeGlobalOnLayoutListener(this);
        }
    }

    /* renamed from: i */
    protected JSONObject m15421i() {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("afmaVersion", this.f10451b.m15381b()).put("activeViewJSON", this.f10451b.m15382c()).put("timestamp", bd.m6650k().mo1681b()).put("adFormat", this.f10451b.m15380a()).put("hashCode", this.f10451b.m15383d()).put("isMraid", this.f10451b.m15384e()).put("isStopped", this.f10463n).put("isPaused", this.f10462m).put("isScreenOn", m15425m()).put("isNative", this.f10451b.m15385f()).put("appMuted", bd.m6644e().m11773h()).put("appVolume", (double) bd.m6644e().m11770g()).put("deviceVolume", (double) bd.m6644e().m11776j(this.f10456g));
        return jSONObject;
    }

    /* renamed from: j */
    protected void m15422j() {
        Iterator it = new ArrayList(this.f10469t).iterator();
        while (it.hasNext()) {
            m15412b((vk) it.next());
        }
    }

    /* renamed from: k */
    protected boolean m15423k() {
        Iterator it = this.f10469t.iterator();
        while (it.hasNext()) {
            if (((vk) it.next()).mo2307a()) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: l */
    protected JSONObject m15424l() {
        return m15421i().put("isAttachedToWindow", false).put("isScreenOn", m15425m()).put("isVisible", false);
    }

    /* renamed from: m */
    boolean m15425m() {
        return this.f10458i.isScreenOn();
    }

    /* renamed from: n */
    protected JSONObject m15426n() {
        JSONObject i = m15421i();
        i.put("doneReasonCode", "u");
        return i;
    }

    /* renamed from: o */
    public void m15427o() {
        synchronized (this.f10450a) {
            this.f10463n = true;
            m15402a(3);
        }
    }

    public void onGlobalLayout() {
        m15402a(2);
    }

    public void onScrollChanged() {
        m15402a(1);
    }

    /* renamed from: p */
    public void m15428p() {
        synchronized (this.f10450a) {
            this.f10462m = true;
            m15402a(3);
        }
    }

    /* renamed from: q */
    public void m15429q() {
        synchronized (this.f10450a) {
            this.f10462m = false;
            m15402a(3);
        }
    }

    /* renamed from: r */
    public up m15430r() {
        return this.f10451b;
    }
}
