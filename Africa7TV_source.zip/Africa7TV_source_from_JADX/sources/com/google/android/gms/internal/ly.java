package com.google.android.gms.internal;

import java.lang.reflect.Field;

public interface ly {
    /* renamed from: a */
    String mo2231a(Field field);
}
