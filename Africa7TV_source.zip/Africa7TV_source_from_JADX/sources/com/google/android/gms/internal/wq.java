package com.google.android.gms.internal;

import android.util.Base64OutputStream;
import com.google.android.gms.ads.internal.util.client.C1043e;
import java.io.ByteArrayOutputStream;

class wq {
    /* renamed from: a */
    ByteArrayOutputStream f10621a = new ByteArrayOutputStream(4096);
    /* renamed from: b */
    Base64OutputStream f10622b = new Base64OutputStream(this.f10621a, 10);

    /* renamed from: a */
    public void m15561a(byte[] bArr) {
        this.f10622b.write(bArr);
    }

    public String toString() {
        String byteArrayOutputStream;
        try {
            this.f10622b.close();
        } catch (Throwable e) {
            C1043e.m7798b("HashManager: Unable to convert to Base64.", e);
        }
        try {
            this.f10621a.close();
            byteArrayOutputStream = this.f10621a.toString();
        } catch (Throwable e2) {
            C1043e.m7798b("HashManager: Unable to convert to Base64.", e2);
            byteArrayOutputStream = "";
        } finally {
            this.f10621a = null;
            this.f10622b = null;
        }
        return byteArrayOutputStream;
    }
}
