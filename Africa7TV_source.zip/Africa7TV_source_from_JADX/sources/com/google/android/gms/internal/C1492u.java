package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;

/* renamed from: com.google.android.gms.internal.u */
public class C1492u extends bhd {
    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        boolean z = true;
        C1370c.m10120b(gbVarArr != null);
        if (gbVarArr.length != 2) {
            z = false;
        }
        C1370c.m10120b(z);
        return gbVarArr[0];
    }
}
