package com.google.android.gms.internal;

class oc extends nd<T> {
    /* renamed from: a */
    final /* synthetic */ boolean f10029a;
    /* renamed from: b */
    final /* synthetic */ boolean f10030b;
    /* renamed from: c */
    final /* synthetic */ lz f10031c;
    /* renamed from: d */
    final /* synthetic */ rh f10032d;
    /* renamed from: e */
    final /* synthetic */ ob f10033e;
    /* renamed from: f */
    private nd<T> f10034f;

    oc(ob obVar, boolean z, boolean z2, lz lzVar, rh rhVar) {
        this.f10033e = obVar;
        this.f10029a = z;
        this.f10030b = z2;
        this.f10031c = lzVar;
        this.f10032d = rhVar;
    }

    /* renamed from: a */
    private nd<T> m14636a() {
        nd<T> ndVar = this.f10034f;
        if (ndVar != null) {
            return ndVar;
        }
        ndVar = this.f10031c.m14476a(this.f10033e, this.f10032d);
        this.f10034f = ndVar;
        return ndVar;
    }

    /* renamed from: a */
    public void mo2143a(rl rlVar, T t) {
        if (this.f10030b) {
            rlVar.mo2270f();
        } else {
            m14636a().mo2143a(rlVar, t);
        }
    }

    /* renamed from: b */
    public T mo2144b(ri riVar) {
        if (!this.f10029a) {
            return m14636a().mo2144b(riVar);
        }
        riVar.mo2256n();
        return null;
    }
}
