package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;

public class dx extends bhd {
    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        C1370c.m10120b(gbVarArr != null);
        C1370c.m10120b(gbVarArr.length == 2);
        return new ge(Boolean.valueOf(bhc.m13596d(gbVarArr[0]).startsWith(bhc.m13596d(gbVarArr[1]))));
    }
}
