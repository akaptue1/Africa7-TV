package com.google.android.gms.internal;

public interface ayw {
    /* renamed from: f */
    void mo1406f();
}
