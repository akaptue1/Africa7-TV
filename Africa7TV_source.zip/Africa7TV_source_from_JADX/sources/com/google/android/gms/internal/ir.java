package com.google.android.gms.internal;

class ir implements Runnable {
    /* renamed from: a */
    final /* synthetic */ ij f9721a;

    ir(ij ijVar) {
        this.f9721a = ijVar;
    }

    public void run() {
        this.f9721a.f9678A = null;
        if (this.f9721a.m14205s()) {
            this.f9721a.mo2203d("connection_idle");
        } else {
            this.f9721a.m14203q();
        }
    }
}
