package com.google.android.gms.internal;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.ads.p035a.C0835a;
import com.google.android.gms.clearcut.C1335a;
import com.google.android.gms.common.C1357k;
import com.google.android.gms.common.C1360d;
import com.google.android.gms.common.C1362e;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.C1353r;
import com.google.android.gms.gass.internal.C1447a;
import dalvik.system.DexClassLoader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class sy {
    /* renamed from: c */
    protected static final Object f10345c = new Object();
    /* renamed from: e */
    protected static final Object f10346e = new Object();
    /* renamed from: h */
    private static final String f10347h = sy.class.getSimpleName();
    /* renamed from: u */
    private static C1357k f10348u = null;
    /* renamed from: a */
    protected Context f10349a;
    /* renamed from: b */
    protected Context f10350b;
    /* renamed from: d */
    protected boolean f10351d = false;
    /* renamed from: f */
    protected boolean f10352f = false;
    /* renamed from: g */
    protected boolean f10353g = false;
    /* renamed from: i */
    private ExecutorService f10354i;
    /* renamed from: j */
    private DexClassLoader f10355j;
    /* renamed from: k */
    private sq f10356k;
    /* renamed from: l */
    private byte[] f10357l;
    /* renamed from: m */
    private volatile C0835a f10358m = null;
    /* renamed from: n */
    private volatile boolean f10359n = false;
    /* renamed from: o */
    private Future f10360o = null;
    /* renamed from: p */
    private volatile fa f10361p = null;
    /* renamed from: q */
    private Future f10362q = null;
    /* renamed from: r */
    private volatile boolean f10363r = false;
    /* renamed from: s */
    private mn f10364s;
    /* renamed from: t */
    private C1352q f10365t = null;
    /* renamed from: v */
    private Map<Pair<String, String>, tw> f10366v;

    private sy(Context context) {
        this.f10349a = context;
        this.f10350b = context.getApplicationContext();
        this.f10366v = new HashMap();
    }

    /* renamed from: a */
    public static sy m15238a(Context context, String str, String str2, boolean z) {
        sy syVar = new sy(context);
        try {
            if (syVar.m15246a(str, str2, z)) {
                return syVar;
            }
        } catch (st e) {
        }
        return null;
    }

    /* renamed from: a */
    private File m15239a(String str, File file, String str2) {
        File file2 = new File(String.format("%s/%s.jar", new Object[]{file, str2}));
        if (!file2.exists()) {
            byte[] a = this.f10356k.m15192a(this.f10357l, str);
            file2.createNewFile();
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            fileOutputStream.write(a, 0, a.length);
            fileOutputStream.close();
        }
        return file2;
    }

    /* renamed from: a */
    private void m15241a(File file) {
        if (file.exists()) {
            file.delete();
            return;
        }
        Log.d(f10347h, String.format("File %s not found. No need for deletion", new Object[]{file.getAbsolutePath()}));
    }

    /* renamed from: a */
    private void m15242a(File file, String str) {
        FileInputStream fileInputStream;
        FileOutputStream fileOutputStream;
        FileInputStream fileInputStream2;
        Throwable th;
        FileOutputStream fileOutputStream2 = null;
        File file2 = new File(String.format("%s/%s.tmp", new Object[]{file, str}));
        if (!file2.exists()) {
            File file3 = new File(String.format("%s/%s.dex", new Object[]{file, str}));
            if (file3.exists()) {
                long length = file3.length();
                if (length > 0) {
                    byte[] bArr = new byte[((int) length)];
                    try {
                        fileInputStream = new FileInputStream(file3);
                        try {
                            if (fileInputStream.read(bArr) <= 0) {
                                if (fileInputStream != null) {
                                    try {
                                        fileInputStream.close();
                                    } catch (IOException e) {
                                    }
                                }
                                m15241a(file3);
                                return;
                            }
                            rz ffVar = new ff();
                            ffVar.f9397d = VERSION.SDK.getBytes();
                            ffVar.f9396c = str.getBytes();
                            bArr = this.f10356k.m15190a(this.f10357l, bArr).getBytes();
                            ffVar.f9394a = bArr;
                            ffVar.f9395b = kn.m14395a(bArr);
                            file2.createNewFile();
                            fileOutputStream = new FileOutputStream(file2);
                            try {
                                byte[] a = rz.m13132a(ffVar);
                                fileOutputStream.write(a, 0, a.length);
                                fileOutputStream.close();
                                if (fileInputStream != null) {
                                    try {
                                        fileInputStream.close();
                                    } catch (IOException e2) {
                                    }
                                }
                                if (fileOutputStream != null) {
                                    try {
                                        fileOutputStream.close();
                                    } catch (IOException e3) {
                                    }
                                }
                                m15241a(file3);
                            } catch (IOException e4) {
                                fileInputStream2 = fileInputStream;
                                if (fileInputStream2 != null) {
                                    try {
                                        fileInputStream2.close();
                                    } catch (IOException e5) {
                                    }
                                }
                                if (fileOutputStream != null) {
                                    try {
                                        fileOutputStream.close();
                                    } catch (IOException e6) {
                                    }
                                }
                                m15241a(file3);
                            } catch (NoSuchAlgorithmException e7) {
                                fileInputStream2 = fileInputStream;
                                if (fileInputStream2 != null) {
                                    fileInputStream2.close();
                                }
                                if (fileOutputStream != null) {
                                    fileOutputStream.close();
                                }
                                m15241a(file3);
                            } catch (sr e8) {
                                fileInputStream2 = fileInputStream;
                                if (fileInputStream2 != null) {
                                    fileInputStream2.close();
                                }
                                if (fileOutputStream != null) {
                                    fileOutputStream.close();
                                }
                                m15241a(file3);
                            } catch (Throwable th2) {
                                Throwable th3 = th2;
                                fileOutputStream2 = fileOutputStream;
                                th = th3;
                                if (fileInputStream != null) {
                                    try {
                                        fileInputStream.close();
                                    } catch (IOException e9) {
                                    }
                                }
                                if (fileOutputStream2 != null) {
                                    try {
                                        fileOutputStream2.close();
                                    } catch (IOException e10) {
                                    }
                                }
                                m15241a(file3);
                                throw th;
                            }
                        } catch (IOException e11) {
                            fileOutputStream = null;
                            fileInputStream2 = fileInputStream;
                            if (fileInputStream2 != null) {
                                fileInputStream2.close();
                            }
                            if (fileOutputStream != null) {
                                fileOutputStream.close();
                            }
                            m15241a(file3);
                        } catch (NoSuchAlgorithmException e12) {
                            fileOutputStream = null;
                            fileInputStream2 = fileInputStream;
                            if (fileInputStream2 != null) {
                                fileInputStream2.close();
                            }
                            if (fileOutputStream != null) {
                                fileOutputStream.close();
                            }
                            m15241a(file3);
                        } catch (sr e13) {
                            fileOutputStream = null;
                            fileInputStream2 = fileInputStream;
                            if (fileInputStream2 != null) {
                                fileInputStream2.close();
                            }
                            if (fileOutputStream != null) {
                                fileOutputStream.close();
                            }
                            m15241a(file3);
                        } catch (Throwable th4) {
                            th = th4;
                            if (fileInputStream != null) {
                                fileInputStream.close();
                            }
                            if (fileOutputStream2 != null) {
                                fileOutputStream2.close();
                            }
                            m15241a(file3);
                            throw th;
                        }
                    } catch (IOException e14) {
                        fileOutputStream = null;
                        if (fileInputStream2 != null) {
                            fileInputStream2.close();
                        }
                        if (fileOutputStream != null) {
                            fileOutputStream.close();
                        }
                        m15241a(file3);
                    } catch (NoSuchAlgorithmException e15) {
                        fileOutputStream = null;
                        if (fileInputStream2 != null) {
                            fileInputStream2.close();
                        }
                        if (fileOutputStream != null) {
                            fileOutputStream.close();
                        }
                        m15241a(file3);
                    } catch (sr e16) {
                        fileOutputStream = null;
                        if (fileInputStream2 != null) {
                            fileInputStream2.close();
                        }
                        if (fileOutputStream != null) {
                            fileOutputStream.close();
                        }
                        m15241a(file3);
                    } catch (Throwable th5) {
                        th = th5;
                        fileInputStream = null;
                        if (fileInputStream != null) {
                            fileInputStream.close();
                        }
                        if (fileOutputStream2 != null) {
                            fileOutputStream2.close();
                        }
                        m15241a(file3);
                        throw th;
                    }
                }
            }
        }
    }

    /* renamed from: a */
    private void m15243a(String str) {
        this.f10356k = new sq(null);
        try {
            this.f10357l = this.f10356k.m15191a(str);
        } catch (Throwable e) {
            throw new st(e);
        }
    }

    /* renamed from: a */
    private void m15244a(boolean z) {
        this.f10359n = z;
        if (z) {
            this.f10360o = this.f10354i.submit(new sz(this));
        }
    }

    /* renamed from: a */
    private boolean m15246a(String str, String str2, boolean z) {
        this.f10354i = Executors.newCachedThreadPool();
        m15244a(z);
        m15254v();
        m15252t();
        if (td.m15280b() && ((Boolean) xm.bL.m15604c()).booleanValue()) {
            throw new IllegalStateException("Task Context initialization must not be called from the UI thread.");
        }
        m15243a(str);
        m15249b(str2);
        this.f10364s = new mn(this);
        return true;
    }

    /* renamed from: b */
    private boolean m15248b(File file, String str) {
        FileOutputStream fileOutputStream;
        FileInputStream fileInputStream;
        Throwable th;
        FileOutputStream fileOutputStream2 = null;
        File file2 = new File(String.format("%s/%s.tmp", new Object[]{file, str}));
        if (!file2.exists()) {
            return false;
        }
        File file3 = new File(String.format("%s/%s.dex", new Object[]{file, str}));
        if (file3.exists()) {
            return false;
        }
        FileInputStream fileInputStream2;
        try {
            long length = file2.length();
            if (length <= 0) {
                m15241a(file2);
                return false;
            }
            byte[] bArr = new byte[((int) length)];
            fileInputStream2 = new FileInputStream(file2);
            try {
                if (fileInputStream2.read(bArr) <= 0) {
                    Log.d(f10347h, "Cannot read the cache data.");
                    m15241a(file2);
                    if (fileInputStream2 != null) {
                        try {
                            fileInputStream2.close();
                        } catch (IOException e) {
                        }
                    }
                    return false;
                }
                ff a = ff.m13805a(bArr);
                if (str.equals(new String(a.f9396c)) && Arrays.equals(a.f9395b, kn.m14395a(a.f9394a)) && Arrays.equals(a.f9397d, VERSION.SDK.getBytes())) {
                    bArr = this.f10356k.m15192a(this.f10357l, new String(a.f9394a));
                    file3.createNewFile();
                    FileOutputStream fileOutputStream3 = new FileOutputStream(file3);
                    try {
                        fileOutputStream3.write(bArr, 0, bArr.length);
                        if (fileInputStream2 != null) {
                            try {
                                fileInputStream2.close();
                            } catch (IOException e2) {
                            }
                        }
                        if (fileOutputStream3 == null) {
                            return true;
                        }
                        try {
                            fileOutputStream3.close();
                            return true;
                        } catch (IOException e3) {
                            return true;
                        }
                    } catch (IOException e4) {
                        fileOutputStream = fileOutputStream3;
                        fileInputStream = fileInputStream2;
                        if (fileInputStream != null) {
                            try {
                                fileInputStream.close();
                            } catch (IOException e5) {
                            }
                        }
                        if (fileOutputStream != null) {
                            try {
                                fileOutputStream.close();
                            } catch (IOException e6) {
                            }
                        }
                        return false;
                    } catch (NoSuchAlgorithmException e7) {
                        fileOutputStream = fileOutputStream3;
                        fileInputStream = fileInputStream2;
                        if (fileInputStream != null) {
                            fileInputStream.close();
                        }
                        if (fileOutputStream != null) {
                            fileOutputStream.close();
                        }
                        return false;
                    } catch (sr e8) {
                        fileOutputStream = fileOutputStream3;
                        fileInputStream = fileInputStream2;
                        if (fileInputStream != null) {
                            fileInputStream.close();
                        }
                        if (fileOutputStream != null) {
                            fileOutputStream.close();
                        }
                        return false;
                    } catch (Throwable th2) {
                        th = th2;
                        fileOutputStream2 = fileOutputStream3;
                        if (fileInputStream2 != null) {
                            try {
                                fileInputStream2.close();
                            } catch (IOException e9) {
                            }
                        }
                        if (fileOutputStream2 != null) {
                            try {
                                fileOutputStream2.close();
                            } catch (IOException e10) {
                            }
                        }
                        throw th;
                    }
                }
                m15241a(file2);
                if (fileInputStream2 != null) {
                    try {
                        fileInputStream2.close();
                    } catch (IOException e11) {
                    }
                }
                return false;
            } catch (IOException e12) {
                fileOutputStream = null;
                fileInputStream = fileInputStream2;
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                return false;
            } catch (NoSuchAlgorithmException e13) {
                fileOutputStream = null;
                fileInputStream = fileInputStream2;
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                return false;
            } catch (sr e14) {
                fileOutputStream = null;
                fileInputStream = fileInputStream2;
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                return false;
            } catch (Throwable th3) {
                th = th3;
                if (fileInputStream2 != null) {
                    fileInputStream2.close();
                }
                if (fileOutputStream2 != null) {
                    fileOutputStream2.close();
                }
                throw th;
            }
        } catch (IOException e15) {
            fileOutputStream = null;
            if (fileInputStream != null) {
                fileInputStream.close();
            }
            if (fileOutputStream != null) {
                fileOutputStream.close();
            }
            return false;
        } catch (NoSuchAlgorithmException e16) {
            fileOutputStream = null;
            if (fileInputStream != null) {
                fileInputStream.close();
            }
            if (fileOutputStream != null) {
                fileOutputStream.close();
            }
            return false;
        } catch (sr e17) {
            fileOutputStream = null;
            if (fileInputStream != null) {
                fileInputStream.close();
            }
            if (fileOutputStream != null) {
                fileOutputStream.close();
            }
            return false;
        } catch (Throwable th4) {
            th = th4;
            fileInputStream2 = null;
            if (fileInputStream2 != null) {
                fileInputStream2.close();
            }
            if (fileOutputStream2 != null) {
                fileOutputStream2.close();
            }
            throw th;
        }
    }

    /* renamed from: b */
    private boolean m15249b(String str) {
        File file;
        String b;
        File a;
        try {
            File cacheDir = this.f10349a.getCacheDir();
            if (cacheDir == null) {
                cacheDir = this.f10349a.getDir("dex", 0);
                if (cacheDir == null) {
                    throw new st();
                }
            }
            file = cacheDir;
            b = ss.m15207b();
            a = m15239a(str, file, b);
            m15248b(file, b);
            this.f10355j = new DexClassLoader(a.getAbsolutePath(), file.getAbsolutePath(), null, this.f10349a.getClassLoader());
            m15241a(a);
            m15242a(file, b);
            m15250c(String.format("%s/%s.dex", new Object[]{file, b}));
            return true;
        } catch (Throwable e) {
            throw new st(e);
        } catch (Throwable e2) {
            throw new st(e2);
        } catch (Throwable e22) {
            throw new st(e22);
        } catch (Throwable e222) {
            throw new st(e222);
        } catch (Throwable th) {
            m15241a(a);
            m15242a(file, b);
            m15250c(String.format("%s/%s.dex", new Object[]{file, b}));
        }
    }

    /* renamed from: c */
    private void m15250c(String str) {
        m15241a(new File(str));
    }

    /* renamed from: s */
    private void m15251s() {
        try {
            if (this.f10358m == null && this.f10350b != null) {
                C0835a c0835a = new C0835a(this.f10350b);
                c0835a.m6234a();
                this.f10358m = c0835a;
            }
        } catch (C1360d e) {
            this.f10358m = null;
        } catch (IOException e2) {
            this.f10358m = null;
        } catch (C1362e e3) {
            this.f10358m = null;
        }
    }

    /* renamed from: t */
    private void m15252t() {
        if (((Boolean) xm.bN.m15604c()).booleanValue()) {
            m15270n();
        }
    }

    /* renamed from: u */
    private void m15253u() {
        if (this.f10352f) {
            try {
                this.f10361p = C1447a.m10398a(this.f10349a, this.f10349a.getPackageName(), Integer.toString(this.f10349a.getPackageManager().getPackageInfo(this.f10349a.getPackageName(), 0).versionCode));
            } catch (NameNotFoundException e) {
            }
        }
    }

    /* renamed from: v */
    private void m15254v() {
        boolean z = true;
        this.f10354i.execute(new tb(this));
        f10348u = C1357k.m9833b();
        this.f10351d = f10348u.mo1601b(this.f10349a) > 0;
        if (f10348u.mo1597a(this.f10349a) != 0) {
            z = false;
        }
        this.f10352f = z;
        if (this.f10349a.getApplicationContext() != null) {
            this.f10365t = new C1353r(this.f10349a).m9824a(C1335a.f6783c).m9829b();
        }
    }

    /* renamed from: a */
    public Context m15255a() {
        return this.f10349a;
    }

    /* renamed from: a */
    public Method m15256a(String str, String str2) {
        tw twVar = (tw) this.f10366v.get(new Pair(str, str2));
        return twVar == null ? null : twVar.m15316a();
    }

    /* renamed from: a */
    public boolean m15257a(String str, String str2, List<Class> list) {
        if (this.f10366v.containsKey(new Pair(str, str2))) {
            return false;
        }
        this.f10366v.put(new Pair(str, str2), new tw(this, str, str2, list));
        return true;
    }

    /* renamed from: b */
    public Context m15258b() {
        return this.f10350b;
    }

    /* renamed from: c */
    public ExecutorService m15259c() {
        return this.f10354i;
    }

    /* renamed from: d */
    public DexClassLoader m15260d() {
        return this.f10355j;
    }

    /* renamed from: e */
    public sq m15261e() {
        return this.f10356k;
    }

    /* renamed from: f */
    public byte[] m15262f() {
        return this.f10357l;
    }

    /* renamed from: g */
    public C1352q m15263g() {
        return this.f10365t;
    }

    /* renamed from: h */
    public boolean m15264h() {
        return this.f10351d;
    }

    /* renamed from: i */
    public boolean m15265i() {
        return this.f10353g;
    }

    /* renamed from: j */
    public mn m15266j() {
        return this.f10364s;
    }

    /* renamed from: k */
    public boolean m15267k() {
        return this.f10352f;
    }

    /* renamed from: l */
    public fa m15268l() {
        return this.f10361p;
    }

    /* renamed from: m */
    public Future m15269m() {
        return this.f10362q;
    }

    /* renamed from: n */
    public void m15270n() {
        synchronized (f10345c) {
            if (!this.f10363r) {
                this.f10362q = this.f10354i.submit(new ta(this));
                this.f10363r = true;
            }
        }
    }

    /* renamed from: o */
    public C0835a m15271o() {
        if (!this.f10359n) {
            return null;
        }
        if (this.f10358m != null) {
            return this.f10358m;
        }
        if (this.f10360o != null) {
            try {
                this.f10360o.get(2000, TimeUnit.MILLISECONDS);
                this.f10360o = null;
            } catch (InterruptedException e) {
            } catch (ExecutionException e2) {
            } catch (TimeoutException e3) {
                this.f10360o.cancel(true);
            }
        }
        return this.f10358m;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: p */
    public void m15272p() {
        /*
        r2 = this;
        r1 = f10346e;
        monitor-enter(r1);
        r0 = r2.f10353g;	 Catch:{ all -> 0x001b }
        if (r0 == 0) goto L_0x0009;
    L_0x0007:
        monitor-exit(r1);	 Catch:{ all -> 0x001b }
    L_0x0008:
        return;
    L_0x0009:
        r0 = r2.f10352f;	 Catch:{ all -> 0x001b }
        if (r0 == 0) goto L_0x001e;
    L_0x000d:
        r0 = r2.f10365t;	 Catch:{ all -> 0x001b }
        if (r0 == 0) goto L_0x001e;
    L_0x0011:
        r0 = r2.f10365t;	 Catch:{ all -> 0x001b }
        r0.mo2023e();	 Catch:{ all -> 0x001b }
        r0 = 1;
        r2.f10353g = r0;	 Catch:{ all -> 0x001b }
    L_0x0019:
        monitor-exit(r1);	 Catch:{ all -> 0x001b }
        goto L_0x0008;
    L_0x001b:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x001b }
        throw r0;
    L_0x001e:
        r0 = 0;
        r2.f10353g = r0;	 Catch:{ all -> 0x001b }
        goto L_0x0019;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.sy.p():void");
    }

    /* renamed from: q */
    public void m15273q() {
        synchronized (f10346e) {
            if (this.f10353g && this.f10365t != null) {
                this.f10365t.mo2025g();
                this.f10353g = false;
            }
        }
    }

    /* renamed from: r */
    public int m15274r() {
        mn j = m15266j();
        return j != null ? j.m14543a() : Integer.MIN_VALUE;
    }
}
