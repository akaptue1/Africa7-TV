package com.google.android.gms.internal;

class ajf implements Runnable {
    /* renamed from: a */
    final /* synthetic */ ana f7645a;
    /* renamed from: b */
    final /* synthetic */ ajd f7646b;

    ajf(ajd ajd, ana ana) {
        this.f7646b = ajd;
        this.f7645a = ana;
    }

    public void run() {
        synchronized (this.f7646b.f7640c) {
            this.f7646b.m11229a(this.f7645a);
        }
    }
}
