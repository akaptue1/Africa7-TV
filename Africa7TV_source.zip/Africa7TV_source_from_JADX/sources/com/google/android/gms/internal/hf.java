package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.auth.api.model.VerifyAssertionRequest;

public interface hf extends IInterface {
    /* renamed from: a */
    void mo2152a(hc hcVar);

    /* renamed from: a */
    void mo2153a(VerifyAssertionRequest verifyAssertionRequest, hc hcVar);

    /* renamed from: a */
    void mo2154a(String str, hc hcVar);

    /* renamed from: a */
    void mo2155a(String str, UserProfileChangeRequest userProfileChangeRequest, hc hcVar);

    /* renamed from: a */
    void mo2156a(String str, VerifyAssertionRequest verifyAssertionRequest, hc hcVar);

    /* renamed from: a */
    void mo2157a(String str, String str2, hc hcVar);

    /* renamed from: a */
    void mo2158a(String str, String str2, String str3, hc hcVar);

    /* renamed from: b */
    void mo2159b(String str, hc hcVar);

    /* renamed from: b */
    void mo2160b(String str, String str2, hc hcVar);

    /* renamed from: c */
    void mo2161c(String str, hc hcVar);

    /* renamed from: c */
    void mo2162c(String str, String str2, hc hcVar);

    /* renamed from: d */
    void mo2163d(String str, hc hcVar);

    /* renamed from: d */
    void mo2164d(String str, String str2, hc hcVar);

    /* renamed from: e */
    void mo2165e(String str, hc hcVar);

    /* renamed from: e */
    void mo2166e(String str, String str2, hc hcVar);

    /* renamed from: f */
    void mo2167f(String str, hc hcVar);

    /* renamed from: g */
    void mo2168g(String str, hc hcVar);

    /* renamed from: h */
    void mo2169h(String str, hc hcVar);
}
