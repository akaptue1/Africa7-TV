package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import oauth.signpost.OAuth;

public class bt extends bhd {
    /* renamed from: a */
    static String m13629a(String str, String str2) {
        StringBuilder stringBuilder = new StringBuilder();
        Charset forName = Charset.forName(OAuth.ENCODING);
        int i = 0;
        while (i < str.length()) {
            char charAt = str.charAt(i);
            if (str2.indexOf(charAt) != -1) {
                stringBuilder.append((char) charAt);
                i++;
            } else {
                int i2 = 1;
                if (Character.isHighSurrogate((char) charAt)) {
                    if (i + 1 >= str.length()) {
                        throw new UnsupportedEncodingException();
                    } else if (Character.isLowSurrogate(str.charAt(i + 1))) {
                        i2 = 2;
                    } else {
                        throw new UnsupportedEncodingException();
                    }
                }
                byte[] bytes = str.substring(i, i + i2).getBytes(forName);
                for (int i3 = 0; i3 < bytes.length; i3++) {
                    stringBuilder.append("%");
                    stringBuilder.append(Character.toUpperCase(Character.forDigit((bytes[i3] >> 4) & 15, 16)));
                    stringBuilder.append(Character.toUpperCase(Character.forDigit(bytes[i3] & 15, 16)));
                }
                i += i2;
            }
        }
        return stringBuilder.toString().replaceAll(" ", "%20");
    }

    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        C1370c.m10120b(gbVarArr != null);
        try {
            return new gn(m13629a(bhc.m13596d(gbVarArr.length > 0 ? (gb) C1370c.m10112a(gbVarArr[0]) : gh.f9460e), "#;/?:@&=+$,abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_.!~*'()0123456789"));
        } catch (UnsupportedEncodingException e) {
            return gh.f9460e;
        }
    }
}
