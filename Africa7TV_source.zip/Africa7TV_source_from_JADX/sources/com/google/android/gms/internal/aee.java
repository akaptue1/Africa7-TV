package com.google.android.gms.internal;

class aee implements aqw<adi> {
    /* renamed from: a */
    final /* synthetic */ aem f7344a;
    /* renamed from: b */
    final /* synthetic */ adv f7345b;

    aee(adv adv, aem aem) {
        this.f7345b = adv;
        this.f7344a = aem;
    }

    /* renamed from: a */
    public void m10701a(adi adi) {
        synchronized (this.f7345b.f7321a) {
            this.f7345b.f7328h = 0;
            if (!(this.f7345b.f7327g == null || this.f7344a == this.f7345b.f7327g)) {
                ano.m11653e("New JS engine is loaded, marking previous one as destroyable.");
                this.f7345b.f7327g.m10718c();
            }
            this.f7345b.f7327g = this.f7344a;
        }
    }

    /* renamed from: a */
    public /* synthetic */ void mo1308a(Object obj) {
        m10701a((adi) obj);
    }
}
