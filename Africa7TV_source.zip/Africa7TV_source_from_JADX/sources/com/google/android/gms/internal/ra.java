package com.google.android.gms.internal;

final class ra extends nd<Character> {
    ra() {
    }

    /* renamed from: a */
    public Character m14915a(ri riVar) {
        if (riVar.mo2248f() == rk.NULL) {
            riVar.mo2252j();
            return null;
        }
        String h = riVar.mo2250h();
        if (h.length() == 1) {
            return Character.valueOf(h.charAt(0));
        }
        String str = "Expecting character, got: ";
        h = String.valueOf(h);
        throw new mw(h.length() != 0 ? str.concat(h) : new String(str));
    }

    /* renamed from: a */
    public void m14916a(rl rlVar, Character ch) {
        rlVar.mo2265b(ch == null ? null : String.valueOf(ch));
    }

    /* renamed from: b */
    public /* synthetic */ Object mo2144b(ri riVar) {
        return m14915a(riVar);
    }
}
