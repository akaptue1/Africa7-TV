package com.google.android.gms.internal;

class vg implements aqw<aes> {
    /* renamed from: a */
    final /* synthetic */ vc f10495a;

    vg(vc vcVar) {
        this.f10495a = vcVar;
    }

    /* renamed from: a */
    public void m15471a(aes aes) {
        this.f10495a.m15465b(aes);
    }

    /* renamed from: a */
    public /* synthetic */ void mo1308a(Object obj) {
        m15471a((aes) obj);
    }
}
