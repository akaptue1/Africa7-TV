package com.google.android.gms.internal;

import android.accounts.Account;
import android.os.IInterface;

public interface ate extends IInterface {
    /* renamed from: a */
    void mo1940a(Account account, int i, atb atb);
}
