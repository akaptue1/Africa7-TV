package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.analytics.C1090f;
import com.google.android.gms.analytics.C1124n;

public class bgw {
    /* renamed from: a */
    private C1090f f9191a;
    /* renamed from: b */
    private Context f9192b;
    /* renamed from: c */
    private C1124n f9193c;

    public bgw(Context context) {
        this.f9192b = context;
    }

    /* renamed from: b */
    private synchronized void m13573b(String str) {
        if (this.f9191a == null) {
            this.f9191a = C1090f.m7989a(this.f9192b);
            this.f9191a.m7997a(new bgx());
            this.f9193c = this.f9191a.m7992a(str);
        }
    }

    /* renamed from: a */
    public C1124n m13574a(String str) {
        m13573b(str);
        return this.f9193c;
    }
}
