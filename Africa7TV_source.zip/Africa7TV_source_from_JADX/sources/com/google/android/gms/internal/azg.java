package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import com.google.android.gms.common.api.ag;
import java.lang.ref.WeakReference;

class azg implements DeathRecipient, azh {
    /* renamed from: a */
    private final WeakReference<awe<?>> f8730a;
    /* renamed from: b */
    private final WeakReference<ag> f8731b;
    /* renamed from: c */
    private final WeakReference<IBinder> f8732c;

    private azg(awe<?> awe, ag agVar, IBinder iBinder) {
        this.f8731b = new WeakReference(agVar);
        this.f8730a = new WeakReference(awe);
        this.f8732c = new WeakReference(iBinder);
    }

    /* renamed from: a */
    private void m12954a() {
        awe awe = (awe) this.f8730a.get();
        ag agVar = (ag) this.f8731b.get();
        if (!(agVar == null || awe == null)) {
            agVar.m9787a(awe.mo1408a().intValue());
        }
        IBinder iBinder = (IBinder) this.f8732c.get();
        if (iBinder != null) {
            iBinder.unlinkToDeath(this, 0);
        }
    }

    /* renamed from: a */
    public void mo2056a(awe<?> awe) {
        m12954a();
    }

    public void binderDied() {
        m12954a();
    }
}
