package com.google.android.gms.internal;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.WorkSource;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.internal.C1370c;
import com.google.android.gms.common.util.C1426o;
import com.google.android.gms.common.util.C1428q;
import com.google.android.gms.common.util.C1431t;

public class bde {
    /* renamed from: a */
    private static String f8936a = "WakeLock";
    /* renamed from: b */
    private static String f8937b = "*gcore*:";
    /* renamed from: c */
    private static boolean f8938c = false;
    /* renamed from: d */
    private final WakeLock f8939d;
    /* renamed from: e */
    private WorkSource f8940e;
    /* renamed from: f */
    private final int f8941f;
    /* renamed from: g */
    private final String f8942g;
    /* renamed from: h */
    private final String f8943h;
    /* renamed from: i */
    private final String f8944i;
    /* renamed from: j */
    private final Context f8945j;
    /* renamed from: k */
    private boolean f8946k;
    /* renamed from: l */
    private int f8947l;
    /* renamed from: m */
    private int f8948m;

    public bde(Context context, int i, String str) {
        this(context, i, str, null, context == null ? null : context.getPackageName());
    }

    @SuppressLint({"UnwrappedWakeLock"})
    public bde(Context context, int i, String str, String str2, String str3) {
        this(context, i, str, str2, str3, null);
    }

    @SuppressLint({"UnwrappedWakeLock"})
    public bde(Context context, int i, String str, String str2, String str3, String str4) {
        this.f8946k = true;
        C1370c.m10115a(str, (Object) "Wake lock name can NOT be empty");
        this.f8941f = i;
        this.f8943h = str2;
        this.f8944i = str4;
        this.f8945j = context.getApplicationContext();
        if ("com.google.android.gms".equals(context.getPackageName())) {
            this.f8942g = str;
        } else {
            String valueOf = String.valueOf(f8937b);
            String valueOf2 = String.valueOf(str);
            this.f8942g = valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf);
        }
        this.f8939d = ((PowerManager) context.getSystemService("power")).newWakeLock(i, str);
        if (C1431t.m10377a(this.f8945j)) {
            if (C1428q.m10366a(str3)) {
                str3 = context.getPackageName();
            }
            this.f8940e = C1431t.m10373a(context, str3);
            m13260a(this.f8940e);
        }
    }

    /* renamed from: a */
    private String m13253a(String str, boolean z) {
        return this.f8946k ? z ? str : this.f8943h : this.f8943h;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    private void m13254a(java.lang.String r10) {
        /*
        r9 = this;
        r0 = r9.m13257b(r10);
        r5 = r9.m13253a(r10, r0);
        monitor-enter(r9);
        r1 = r9.f8946k;	 Catch:{ all -> 0x0045 }
        if (r1 == 0) goto L_0x0017;
    L_0x000d:
        r1 = r9.f8947l;	 Catch:{ all -> 0x0045 }
        r1 = r1 + -1;
        r9.f8947l = r1;	 Catch:{ all -> 0x0045 }
        if (r1 == 0) goto L_0x0020;
    L_0x0015:
        if (r0 != 0) goto L_0x0020;
    L_0x0017:
        r0 = r9.f8946k;	 Catch:{ all -> 0x0045 }
        if (r0 != 0) goto L_0x0043;
    L_0x001b:
        r0 = r9.f8948m;	 Catch:{ all -> 0x0045 }
        r1 = 1;
        if (r0 != r1) goto L_0x0043;
    L_0x0020:
        r0 = com.google.android.gms.common.stats.C1410i.m10300a();	 Catch:{ all -> 0x0045 }
        r1 = r9.f8945j;	 Catch:{ all -> 0x0045 }
        r2 = r9.f8939d;	 Catch:{ all -> 0x0045 }
        r2 = com.google.android.gms.common.stats.C1408g.m10294a(r2, r5);	 Catch:{ all -> 0x0045 }
        r3 = 8;
        r4 = r9.f8942g;	 Catch:{ all -> 0x0045 }
        r6 = r9.f8944i;	 Catch:{ all -> 0x0045 }
        r7 = r9.f8941f;	 Catch:{ all -> 0x0045 }
        r8 = r9.f8940e;	 Catch:{ all -> 0x0045 }
        r8 = com.google.android.gms.common.util.C1431t.m10379b(r8);	 Catch:{ all -> 0x0045 }
        r0.m10303a(r1, r2, r3, r4, r5, r6, r7, r8);	 Catch:{ all -> 0x0045 }
        r0 = r9.f8948m;	 Catch:{ all -> 0x0045 }
        r0 = r0 + -1;
        r9.f8948m = r0;	 Catch:{ all -> 0x0045 }
    L_0x0043:
        monitor-exit(r9);	 Catch:{ all -> 0x0045 }
        return;
    L_0x0045:
        r0 = move-exception;
        monitor-exit(r9);	 Catch:{ all -> 0x0045 }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.bde.a(java.lang.String):void");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    private void m13255a(java.lang.String r13, long r14) {
        /*
        r12 = this;
        r0 = r12.m13257b(r13);
        r6 = r12.m13253a(r13, r0);
        monitor-enter(r12);
        r1 = r12.f8946k;	 Catch:{ all -> 0x0044 }
        if (r1 == 0) goto L_0x0017;
    L_0x000d:
        r1 = r12.f8947l;	 Catch:{ all -> 0x0044 }
        r2 = r1 + 1;
        r12.f8947l = r2;	 Catch:{ all -> 0x0044 }
        if (r1 == 0) goto L_0x001f;
    L_0x0015:
        if (r0 != 0) goto L_0x001f;
    L_0x0017:
        r0 = r12.f8946k;	 Catch:{ all -> 0x0044 }
        if (r0 != 0) goto L_0x0042;
    L_0x001b:
        r0 = r12.f8948m;	 Catch:{ all -> 0x0044 }
        if (r0 != 0) goto L_0x0042;
    L_0x001f:
        r1 = com.google.android.gms.common.stats.C1410i.m10300a();	 Catch:{ all -> 0x0044 }
        r2 = r12.f8945j;	 Catch:{ all -> 0x0044 }
        r0 = r12.f8939d;	 Catch:{ all -> 0x0044 }
        r3 = com.google.android.gms.common.stats.C1408g.m10294a(r0, r6);	 Catch:{ all -> 0x0044 }
        r4 = 7;
        r5 = r12.f8942g;	 Catch:{ all -> 0x0044 }
        r7 = r12.f8944i;	 Catch:{ all -> 0x0044 }
        r8 = r12.f8941f;	 Catch:{ all -> 0x0044 }
        r0 = r12.f8940e;	 Catch:{ all -> 0x0044 }
        r9 = com.google.android.gms.common.util.C1431t.m10379b(r0);	 Catch:{ all -> 0x0044 }
        r10 = r14;
        r1.m10304a(r2, r3, r4, r5, r6, r7, r8, r9, r10);	 Catch:{ all -> 0x0044 }
        r0 = r12.f8948m;	 Catch:{ all -> 0x0044 }
        r0 = r0 + 1;
        r12.f8948m = r0;	 Catch:{ all -> 0x0044 }
    L_0x0042:
        monitor-exit(r12);	 Catch:{ all -> 0x0044 }
        return;
    L_0x0044:
        r0 = move-exception;
        monitor-exit(r12);	 Catch:{ all -> 0x0044 }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.bde.a(java.lang.String, long):void");
    }

    /* renamed from: b */
    private void m13256b(WorkSource workSource) {
        try {
            this.f8939d.setWorkSource(workSource);
        } catch (IllegalArgumentException e) {
            Log.wtf(f8936a, e.toString());
        }
    }

    /* renamed from: b */
    private boolean m13257b(String str) {
        return (TextUtils.isEmpty(str) || str.equals(this.f8943h)) ? false : true;
    }

    /* renamed from: a */
    public void m13258a() {
        m13254a(null);
        this.f8939d.release();
    }

    /* renamed from: a */
    public void m13259a(long j) {
        if (!C1426o.m10355c() && this.f8946k) {
            String str = f8936a;
            String str2 = "Do not acquire with timeout on reference counted WakeLocks before ICS. wakelock: ";
            String valueOf = String.valueOf(this.f8942g);
            Log.wtf(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        }
        m13255a(null, j);
        this.f8939d.acquire(j);
    }

    /* renamed from: a */
    public void m13260a(WorkSource workSource) {
        if (workSource != null && C1431t.m10377a(this.f8945j)) {
            if (this.f8940e != null) {
                this.f8940e.add(workSource);
            } else {
                this.f8940e = workSource;
            }
            m13256b(this.f8940e);
        }
    }

    /* renamed from: a */
    public void m13261a(boolean z) {
        this.f8939d.setReferenceCounted(z);
        this.f8946k = z;
    }

    /* renamed from: b */
    public boolean m13262b() {
        return this.f8939d.isHeld();
    }
}
