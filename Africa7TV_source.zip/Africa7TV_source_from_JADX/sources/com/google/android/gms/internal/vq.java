package com.google.android.gms.internal;

import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.os.Bundle;
import com.google.android.gms.ads.internal.util.client.C1043e;
import java.lang.ref.WeakReference;

class vq implements ActivityLifecycleCallbacks {
    /* renamed from: a */
    private final Application f10529a;
    /* renamed from: b */
    private final WeakReference<ActivityLifecycleCallbacks> f10530b;

    public vq(Application application, ActivityLifecycleCallbacks activityLifecycleCallbacks) {
        this.f10530b = new WeakReference(activityLifecycleCallbacks);
        this.f10529a = application;
    }

    /* renamed from: a */
    protected void m15488a(vy vyVar) {
        try {
            ActivityLifecycleCallbacks activityLifecycleCallbacks = (ActivityLifecycleCallbacks) this.f10530b.get();
            if (activityLifecycleCallbacks != null) {
                vyVar.mo2309a(activityLifecycleCallbacks);
            } else {
                this.f10529a.unregisterActivityLifecycleCallbacks(this);
            }
        } catch (Throwable e) {
            C1043e.m7798b("Error while dispatching lifecycle callback.", e);
        }
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
        m15488a(new vr(this, activity, bundle));
    }

    public void onActivityDestroyed(Activity activity) {
        m15488a(new vx(this, activity));
    }

    public void onActivityPaused(Activity activity) {
        m15488a(new vu(this, activity));
    }

    public void onActivityResumed(Activity activity) {
        m15488a(new vt(this, activity));
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        m15488a(new vw(this, activity, bundle));
    }

    public void onActivityStarted(Activity activity) {
        m15488a(new vs(this, activity));
    }

    public void onActivityStopped(Activity activity) {
        m15488a(new vv(this, activity));
    }
}
