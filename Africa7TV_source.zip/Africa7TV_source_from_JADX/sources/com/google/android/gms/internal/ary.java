package com.google.android.gms.internal;

import android.annotation.TargetApi;

@TargetApi(17)
@akw
public class ary {
    /* renamed from: a */
    private final arh f8344a;

    public ary(arh arh) {
        this.f8344a = arh;
    }
}
