package com.google.android.gms.internal;

import java.util.UUID;

final class qe extends nd<UUID> {
    qe() {
    }

    /* renamed from: a */
    public UUID m14851a(ri riVar) {
        if (riVar.mo2248f() != rk.NULL) {
            return UUID.fromString(riVar.mo2250h());
        }
        riVar.mo2252j();
        return null;
    }

    /* renamed from: a */
    public void m14853a(rl rlVar, UUID uuid) {
        rlVar.mo2265b(uuid == null ? null : uuid.toString());
    }

    /* renamed from: b */
    public /* synthetic */ Object mo2144b(ri riVar) {
        return m14851a(riVar);
    }
}
