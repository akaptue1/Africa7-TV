package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.bd;

@akw
public class abp extends anm {
    /* renamed from: a */
    final arh f7189a;
    /* renamed from: b */
    final abs f7190b;
    /* renamed from: c */
    private final String f7191c;

    abp(arh arh, abs abs, String str) {
        this.f7189a = arh;
        this.f7190b = abs;
        this.f7191c = str;
        bd.m6636B().m10507a(this);
    }

    /* renamed from: a */
    public void mo1147a() {
        try {
            this.f7190b.mo1694a(this.f7191c);
        } finally {
            aoq.f8164a.post(new abq(this));
        }
    }

    /* renamed from: b */
    public void mo1148b() {
        this.f7190b.mo1695b();
    }
}
