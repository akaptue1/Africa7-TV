package com.google.android.gms.internal;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

class nx implements on<T> {
    /* renamed from: a */
    final /* synthetic */ Constructor f10017a;
    /* renamed from: b */
    final /* synthetic */ no f10018b;

    nx(no noVar, Constructor constructor) {
        this.f10018b = noVar;
        this.f10017a = constructor;
    }

    /* renamed from: a */
    public T mo2240a() {
        String valueOf;
        try {
            return this.f10017a.newInstance(null);
        } catch (Throwable e) {
            valueOf = String.valueOf(this.f10017a);
            throw new RuntimeException(new StringBuilder(String.valueOf(valueOf).length() + 30).append("Failed to invoke ").append(valueOf).append(" with no args").toString(), e);
        } catch (InvocationTargetException e2) {
            valueOf = String.valueOf(this.f10017a);
            throw new RuntimeException(new StringBuilder(String.valueOf(valueOf).length() + 30).append("Failed to invoke ").append(valueOf).append(" with no args").toString(), e2.getTargetException());
        } catch (IllegalAccessException e3) {
            throw new AssertionError(e3);
        }
    }
}
