package com.google.android.gms.internal;

public interface adj {
    /* renamed from: a */
    void mo1699a();
}
