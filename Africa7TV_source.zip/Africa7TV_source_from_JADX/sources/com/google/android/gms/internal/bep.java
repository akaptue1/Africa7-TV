package com.google.android.gms.internal;

public interface bep {
    /* renamed from: a */
    void mo2087a(String str);

    /* renamed from: a */
    void mo2088a(String str, Throwable th);

    /* renamed from: b */
    void mo2089b(String str);

    /* renamed from: b */
    void mo2090b(String str, Throwable th);

    /* renamed from: c */
    void mo2091c(String str);

    /* renamed from: d */
    void mo2092d(String str);
}
