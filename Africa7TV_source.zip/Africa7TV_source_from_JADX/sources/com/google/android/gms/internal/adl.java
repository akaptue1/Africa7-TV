package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.C0941m;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;

class adl implements Runnable {
    /* renamed from: a */
    final /* synthetic */ Context f7290a;
    /* renamed from: b */
    final /* synthetic */ VersionInfoParcel f7291b;
    /* renamed from: c */
    final /* synthetic */ adn f7292c;
    /* renamed from: d */
    final /* synthetic */ so f7293d;
    /* renamed from: e */
    final /* synthetic */ C0941m f7294e;
    /* renamed from: f */
    final /* synthetic */ String f7295f;
    /* renamed from: g */
    final /* synthetic */ adk f7296g;

    adl(adk adk, Context context, VersionInfoParcel versionInfoParcel, adn adn, so soVar, C0941m c0941m, String str) {
        this.f7296g = adk;
        this.f7290a = context;
        this.f7291b = versionInfoParcel;
        this.f7292c = adn;
        this.f7293d = soVar;
        this.f7294e = c0941m;
        this.f7295f = str;
    }

    public void run() {
        this.f7296g.m10658a(this.f7290a, this.f7291b, this.f7292c, this.f7293d, this.f7294e).mo1709b(this.f7295f);
    }
}
