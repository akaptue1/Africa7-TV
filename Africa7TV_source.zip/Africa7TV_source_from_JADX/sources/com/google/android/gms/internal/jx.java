package com.google.android.gms.internal;

class jx {
    /* renamed from: a */
    static jz m14348a(byte b) {
        return b == (byte) 2 ? new jy() : new ka();
    }
}
