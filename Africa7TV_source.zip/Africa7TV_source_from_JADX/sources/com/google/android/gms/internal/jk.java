package com.google.android.gms.internal;

import java.util.Random;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class jk {
    /* renamed from: a */
    private final ScheduledExecutorService f9767a;
    /* renamed from: b */
    private final jt f9768b;
    /* renamed from: c */
    private final long f9769c;
    /* renamed from: d */
    private final long f9770d;
    /* renamed from: e */
    private final double f9771e;
    /* renamed from: f */
    private final double f9772f;
    /* renamed from: g */
    private final Random f9773g;
    /* renamed from: h */
    private ScheduledFuture<?> f9774h;
    /* renamed from: i */
    private long f9775i;
    /* renamed from: j */
    private boolean f9776j;

    private jk(ScheduledExecutorService scheduledExecutorService, jt jtVar, long j, long j2, double d, double d2) {
        this.f9773g = new Random();
        this.f9776j = true;
        this.f9767a = scheduledExecutorService;
        this.f9768b = jtVar;
        this.f9769c = j;
        this.f9770d = j2;
        this.f9772f = d;
        this.f9771e = d2;
    }

    /* renamed from: a */
    public void m14301a() {
        this.f9776j = true;
        this.f9775i = 0;
    }

    /* renamed from: a */
    public void m14302a(Runnable runnable) {
        long j = 0;
        Runnable jlVar = new jl(this, runnable);
        if (this.f9774h != null) {
            this.f9768b.m14342a("Cancelling previous scheduled retry", new Object[0]);
            this.f9774h.cancel(false);
            this.f9774h = null;
        }
        if (!this.f9776j) {
            if (this.f9775i == 0) {
                this.f9775i = this.f9769c;
            } else {
                this.f9775i = Math.min((long) (((double) this.f9775i) * this.f9772f), this.f9770d);
            }
            j = (long) (((1.0d - this.f9771e) * ((double) this.f9775i)) + ((this.f9771e * ((double) this.f9775i)) * this.f9773g.nextDouble()));
        }
        this.f9776j = false;
        this.f9768b.m14342a("Scheduling retry in %dms", Long.valueOf(j));
        this.f9774h = this.f9767a.schedule(jlVar, j, TimeUnit.MILLISECONDS);
    }

    /* renamed from: b */
    public void m14303b() {
        this.f9775i = this.f9770d;
    }

    /* renamed from: c */
    public void m14304c() {
        if (this.f9774h != null) {
            this.f9768b.m14342a("Cancelling existing retry attempt", new Object[0]);
            this.f9774h.cancel(false);
            this.f9774h = null;
        } else {
            this.f9768b.m14342a("No existing retry attempt to cancel", new Object[0]);
        }
        this.f9775i = 0;
    }
}
