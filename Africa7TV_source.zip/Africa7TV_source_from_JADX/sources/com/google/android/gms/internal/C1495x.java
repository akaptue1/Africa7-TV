package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;

/* renamed from: com.google.android.gms.internal.x */
public class C1495x extends bhd {
    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        boolean z = true;
        C1370c.m10120b(gbVarArr != null);
        C1370c.m10120b(gbVarArr.length == 1);
        C1370c.m10120b(!(gbVarArr[0] instanceof gm));
        if (gp.m13922d(gbVarArr[0])) {
            z = false;
        }
        C1370c.m10120b(z);
        gb<?> gbVar = gbVarArr[0];
        String str = "object";
        if (gbVar == gh.f9460e) {
            str = "undefined";
        } else if (gbVar instanceof ge) {
            str = "boolean";
        } else if (gbVar instanceof gf) {
            str = "number";
        } else if (gbVar instanceof gn) {
            str = "string";
        } else if (gbVar instanceof gg) {
            str = "function";
        }
        return new gn(str);
    }
}
