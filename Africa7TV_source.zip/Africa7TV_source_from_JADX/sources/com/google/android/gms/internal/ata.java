package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.api.C1242s;
import com.google.android.gms.common.api.C1243t;
import com.google.android.gms.common.internal.C1393z;
import com.google.android.gms.common.internal.ag;

public class ata extends ag<ate> {
    public ata(Context context, Looper looper, C1393z c1393z, C1242s c1242s, C1243t c1243t) {
        super(context, looper, 74, c1393z, c1242s, c1243t);
    }

    /* renamed from: a */
    protected ate m12292a(IBinder iBinder) {
        return atf.m12300a(iBinder);
    }

    /* renamed from: a */
    protected String mo1160a() {
        return "com.google.android.gms.auth.api.accountactivationstate.START";
    }

    /* renamed from: b */
    protected /* synthetic */ IInterface mo1161b(IBinder iBinder) {
        return m12292a(iBinder);
    }

    /* renamed from: b */
    protected String mo1162b() {
        return "com.google.android.gms.auth.api.accountactivationstate.internal.IAccountActivationStateService";
    }
}
