package com.google.android.gms.internal;

import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.ad;
import com.google.android.gms.p037b.C1211e;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.WeakHashMap;

public class awr {
    /* renamed from: a */
    private final Map<awe<?>, Boolean> f8531a = Collections.synchronizedMap(new WeakHashMap());
    /* renamed from: b */
    private final Map<C1211e<?>, Boolean> f8532b = Collections.synchronizedMap(new WeakHashMap());

    /* renamed from: a */
    private void m12641a(boolean z, Status status) {
        synchronized (this.f8531a) {
            Map hashMap = new HashMap(this.f8531a);
        }
        synchronized (this.f8532b) {
            Map hashMap2 = new HashMap(this.f8532b);
        }
        for (Entry entry : hashMap.entrySet()) {
            if (z || ((Boolean) entry.getValue()).booleanValue()) {
                ((awe) entry.getKey()).m8764d(status);
            }
        }
        for (Entry entry2 : hashMap2.entrySet()) {
            if (z || ((Boolean) entry2.getValue()).booleanValue()) {
                ((C1211e) entry2.getKey()).m8834b(new ad(status));
            }
        }
    }

    /* renamed from: a */
    void m12642a(awe<? extends C1223y> awe, boolean z) {
        this.f8531a.put(awe, Boolean.valueOf(z));
        awe.mo1409a(new aws(this, awe));
    }

    /* renamed from: a */
    boolean m12643a() {
        return (this.f8531a.isEmpty() && this.f8532b.isEmpty()) ? false : true;
    }

    /* renamed from: b */
    public void m12644b() {
        m12641a(false, axx.f8637a);
    }

    /* renamed from: c */
    public void m12645c() {
        m12641a(true, aze.f8724a);
    }
}
