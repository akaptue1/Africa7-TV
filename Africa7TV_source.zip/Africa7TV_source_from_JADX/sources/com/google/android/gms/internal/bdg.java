package com.google.android.gms.internal;

import com.google.android.gms.ads.p035a.C0835a;
import com.google.android.gms.ads.p035a.C0837c;

class bdg implements bdi {
    /* renamed from: a */
    final /* synthetic */ bdf f8963a;

    bdg(bdf bdf) {
        this.f8963a = bdf;
    }

    /* renamed from: a */
    public C0837c mo2085a() {
        C0837c c0837c = null;
        try {
            c0837c = C0835a.m6230b(this.f8963a.f8958h);
        } catch (Throwable e) {
            beo.m13390b("IllegalStateException getting Advertising Id Info", e);
        } catch (Throwable e2) {
            beo.m13390b("GooglePlayServicesRepairableException getting Advertising Id Info", e2);
        } catch (Throwable e22) {
            beo.m13390b("IOException getting Ad Id Info", e22);
        } catch (Throwable e222) {
            this.f8963a.f8953c = false;
            beo.m13390b("GooglePlayServicesNotAvailableException getting Advertising Id Info", e222);
        } catch (Throwable e2222) {
            beo.m13390b("Unknown exception. Could not get the Advertising Id Info.", e2222);
        }
        return c0837c;
    }
}
