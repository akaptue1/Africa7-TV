package com.google.android.gms.internal;

import android.content.Context;

final class bat implements bay {
    bat() {
    }

    /* renamed from: a */
    public bba mo2065a(Context context, String str, baz baz) {
        bba bba = new bba();
        bba.f8780a = baz.mo2062a(context, str);
        bba.f8781b = baz.mo2063a(context, str, true);
        if (bba.f8780a == 0 && bba.f8781b == 0) {
            bba.f8782c = 0;
        } else if (bba.f8781b >= bba.f8780a) {
            bba.f8782c = 1;
        } else {
            bba.f8782c = -1;
        }
        return bba;
    }
}
