package com.google.android.gms.internal;

import android.os.IInterface;

public interface bad extends IInterface {
    /* renamed from: a */
    void mo2060a(baa baa);
}
