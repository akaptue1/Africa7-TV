package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;
import java.util.List;

public class bhp extends bhd {
    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        gb<?> gbVar;
        int i;
        C1370c.m10112a((Object) gbVarArr);
        boolean z = gbVarArr.length == 2 || gbVarArr.length == 3;
        C1370c.m10120b(z);
        C1370c.m10120b(gbVarArr[0] instanceof gi);
        C1370c.m10120b(gbVarArr[1] instanceof gg);
        gi giVar = (gi) gbVarArr[0];
        gg ggVar = (gg) gbVarArr[1];
        int size = ((List) giVar.mo2133b()).size();
        if (gbVarArr.length == 3) {
            gbVar = gbVarArr[2];
            i = size - 1;
        } else {
            C1370c.m10116a(size > 0);
            gb<?> b = giVar.m13884b(size - 1);
            int i2 = size - 2;
            i = size - 1;
            while (i >= 0) {
                if (giVar.m13886c(i)) {
                    b = giVar.m13884b(i);
                    i2 = i - 1;
                    break;
                }
                i--;
            }
            C1370c.m10116a(i >= 0);
            i = i2;
            gbVar = b;
        }
        int i3 = i;
        while (i3 >= 0) {
            gb<?> a_ = giVar.m13886c(i3) ? ((bhb) ggVar.mo2133b()).a_(bff, gbVar, (gb) r2.get(i3), new gf(Double.valueOf((double) i3)), giVar) : gbVar;
            i3--;
            gbVar = a_;
        }
        return gbVar;
    }
}
