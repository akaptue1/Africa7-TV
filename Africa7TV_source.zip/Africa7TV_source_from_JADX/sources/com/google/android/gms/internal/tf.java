package com.google.android.gms.internal;

public class tf extends ty {
    public tf(sy syVar, String str, String str2, fa faVar, int i, int i2) {
        super(syVar, str, str2, faVar, i, i2);
    }

    /* renamed from: a */
    protected void mo2283a() {
        synchronized (this.e) {
            this.e.f9347c = Long.valueOf(-1);
            this.e.f9347c = (Long) this.f.invoke(null, new Object[]{this.b.m15255a()});
        }
    }
}
