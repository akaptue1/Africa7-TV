package com.google.android.gms.internal;

import android.content.Context;
import java.util.ArrayList;
import java.util.Collection;

public class bbt {
    /* renamed from: a */
    private final Collection<bbn> f8806a = new ArrayList();
    /* renamed from: b */
    private final Collection<bbs> f8807b = new ArrayList();
    /* renamed from: c */
    private final Collection<bbs> f8808c = new ArrayList();

    /* renamed from: a */
    public static void m13114a(Context context) {
        bby.m13120b().m13117a(context);
    }

    /* renamed from: a */
    public void m13115a(bbn bbn) {
        this.f8806a.add(bbn);
    }
}
