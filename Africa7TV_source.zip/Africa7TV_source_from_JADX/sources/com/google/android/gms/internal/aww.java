package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.DeadObjectException;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C1152h;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1344a;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C1375h;

public class aww implements axs {
    /* renamed from: a */
    private final axt f8538a;
    /* renamed from: b */
    private boolean f8539b = false;

    public aww(axt axt) {
        this.f8538a = axt;
    }

    /* renamed from: b */
    private <A extends C1152h> void m12667b(avy<? extends C1223y, A> avy) {
        this.f8538a.f8626g.f8591i.m12949a((awe) avy);
        C1152h b = this.f8538a.f8626g.m12772b(avy.mo1413b());
        if (b.m8613m() || !this.f8538a.f8621b.containsKey(avy.mo1413b())) {
            if (b instanceof C1375h) {
                b = ((C1375h) b).mo1560h();
            }
            avy.m8777b(b);
            return;
        }
        avy.m8779c(new Status(17));
    }

    /* renamed from: a */
    public <A extends C1152h, T extends avy<? extends C1223y, A>> T mo2027a(T t) {
        try {
            m12667b(t);
        } catch (DeadObjectException e) {
            this.f8538a.m12805a(new awx(this, this));
        }
        return t;
    }

    /* renamed from: a */
    public void mo2028a() {
    }

    /* renamed from: a */
    public void mo2029a(int i) {
        this.f8538a.m12803a(null);
        this.f8538a.f8627h.mo2014a(i, this.f8539b);
    }

    /* renamed from: a */
    public void mo2030a(Bundle bundle) {
    }

    /* renamed from: a */
    public void mo2031a(ConnectionResult connectionResult, C1344a<?> c1344a, int i) {
    }

    /* renamed from: b */
    public boolean mo2032b() {
        if (this.f8539b) {
            return false;
        }
        if (this.f8538a.f8626g.m12786o()) {
            this.f8539b = true;
            for (azb a : this.f8538a.f8626g.f8590h) {
                a.m12943a();
            }
            return false;
        }
        this.f8538a.m12803a(null);
        return true;
    }

    /* renamed from: c */
    public void mo2033c() {
        if (this.f8539b) {
            this.f8539b = false;
            this.f8538a.m12805a(new awy(this, this));
        }
    }

    /* renamed from: d */
    void m12675d() {
        if (this.f8539b) {
            this.f8539b = false;
            this.f8538a.f8626g.f8591i.m12948a();
            mo2032b();
        }
    }
}
