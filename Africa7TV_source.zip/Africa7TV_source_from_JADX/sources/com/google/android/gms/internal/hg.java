package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.auth.api.model.VerifyAssertionRequest;

public abstract class hg extends Binder implements hf {
    /* renamed from: a */
    public static hf m13991a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
        return (queryLocalInterface == null || !(queryLocalInterface instanceof hf)) ? new hh(iBinder) : (hf) queryLocalInterface;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        VerifyAssertionRequest verifyAssertionRequest = null;
        String readString;
        switch (i) {
            case 1:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2154a(parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 2:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2159b(parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 3:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                if (parcel.readInt() != 0) {
                    verifyAssertionRequest = (VerifyAssertionRequest) VerifyAssertionRequest.CREATOR.createFromParcel(parcel);
                }
                mo2153a(verifyAssertionRequest, hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 4:
                UserProfileChangeRequest userProfileChangeRequest;
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                readString = parcel.readString();
                if (parcel.readInt() != 0) {
                    userProfileChangeRequest = (UserProfileChangeRequest) UserProfileChangeRequest.CREATOR.createFromParcel(parcel);
                }
                mo2155a(readString, userProfileChangeRequest, hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 5:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2157a(parcel.readString(), parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 6:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2160b(parcel.readString(), parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 7:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2162c(parcel.readString(), parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 8:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2164d(parcel.readString(), parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 9:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2161c(parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 10:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2163d(parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 11:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2158a(parcel.readString(), parcel.readString(), parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 12:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                readString = parcel.readString();
                if (parcel.readInt() != 0) {
                    verifyAssertionRequest = (VerifyAssertionRequest) VerifyAssertionRequest.CREATOR.createFromParcel(parcel);
                }
                mo2156a(readString, verifyAssertionRequest, hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 13:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2165e(parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 14:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2166e(parcel.readString(), parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 15:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2167f(parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 16:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2152a(hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 17:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2168g(parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 18:
                parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                mo2169h(parcel.readString(), hd.m13965a(parcel.readStrongBinder()));
                parcel2.writeNoException();
                return true;
            case 1598968902:
                parcel2.writeString("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                return true;
            default:
                return super.onTransact(i, parcel, parcel2, i2);
        }
    }
}
