package com.google.android.gms.internal;

import android.os.IInterface;

public interface baa extends IInterface {
    /* renamed from: a */
    void mo2058a(int i);
}
