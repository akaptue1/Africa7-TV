package com.google.android.gms.internal;

import android.app.DownloadManager;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class ahf implements OnClickListener {
    /* renamed from: a */
    final /* synthetic */ String f7565a;
    /* renamed from: b */
    final /* synthetic */ String f7566b;
    /* renamed from: c */
    final /* synthetic */ ahe f7567c;

    ahf(ahe ahe, String str, String str2) {
        this.f7567c = ahe;
        this.f7565a = str;
        this.f7566b = str2;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        try {
            ((DownloadManager) this.f7567c.f7564b.getSystemService("download")).enqueue(this.f7567c.m11123a(this.f7565a, this.f7566b));
        } catch (IllegalStateException e) {
            this.f7567c.m11100b("Could not store picture.");
        }
    }
}
