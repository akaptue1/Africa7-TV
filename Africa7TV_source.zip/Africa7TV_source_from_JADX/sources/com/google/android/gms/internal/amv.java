package com.google.android.gms.internal;

@akw
public class amv {
    /* renamed from: a */
    private final aft f7996a;
    /* renamed from: b */
    private final amq f7997b;

    public amv(aft aft, amp amp) {
        this.f7996a = aft;
        this.f7997b = new amq(amp);
    }

    /* renamed from: a */
    public aft m11568a() {
        return this.f7996a;
    }

    /* renamed from: b */
    public amq m11569b() {
        return this.f7997b;
    }
}
