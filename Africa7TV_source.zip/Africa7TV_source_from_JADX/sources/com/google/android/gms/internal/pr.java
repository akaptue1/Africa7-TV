package com.google.android.gms.internal;

import java.util.Map;

public final class pr<T> extends nd<T> {
    /* renamed from: a */
    private final on<T> f10139a;
    /* renamed from: b */
    private final Map<String, ps> f10140b;

    private pr(on<T> onVar, Map<String, ps> map) {
        this.f10139a = onVar;
        this.f10140b = map;
    }

    /* renamed from: a */
    public void mo2143a(rl rlVar, T t) {
        if (t == null) {
            rlVar.mo2270f();
            return;
        }
        rlVar.mo2268d();
        try {
            for (ps psVar : this.f10140b.values()) {
                if (psVar.mo2274a(t)) {
                    rlVar.mo2262a(psVar.f10130g);
                    psVar.mo2273a(rlVar, (Object) t);
                }
            }
            rlVar.mo2269e();
        } catch (IllegalAccessException e) {
            throw new AssertionError();
        }
    }

    /* renamed from: b */
    public T mo2144b(ri riVar) {
        if (riVar.mo2248f() == rk.NULL) {
            riVar.mo2252j();
            return null;
        }
        T a = this.f10139a.mo2240a();
        try {
            riVar.mo2244c();
            while (riVar.mo2247e()) {
                ps psVar = (ps) this.f10140b.get(riVar.mo2249g());
                if (psVar == null || !psVar.f10132i) {
                    riVar.mo2256n();
                } else {
                    psVar.mo2272a(riVar, (Object) a);
                }
            }
            riVar.mo2246d();
            return a;
        } catch (Throwable e) {
            throw new mw(e);
        } catch (IllegalAccessException e2) {
            throw new AssertionError(e2);
        }
    }
}
