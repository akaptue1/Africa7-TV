package com.google.android.gms.internal;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.text.TextUtils;
import com.facebook.internal.NativeProtocol;
import com.facebook.widget.PlacePickerFragment;
import com.google.android.gms.ads.internal.bd;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.request.C1009y;
import com.google.android.gms.ads.internal.request.aa;
import com.google.android.gms.ads.internal.util.client.C1043e;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;
import org.json.JSONObject;

@akw
public final class akz extends C1009y {
    /* renamed from: a */
    private static final Object f7788a = new Object();
    /* renamed from: b */
    private static akz f7789b;
    /* renamed from: c */
    private final Context f7790c;
    /* renamed from: d */
    private final aky f7791d;
    /* renamed from: e */
    private final wz f7792e;
    /* renamed from: f */
    private final adv f7793f;

    akz(Context context, wz wzVar, aky aky) {
        this.f7790c = context;
        this.f7791d = aky;
        this.f7792e = wzVar;
        this.f7793f = new adv(context.getApplicationContext() != null ? context.getApplicationContext() : context, VersionInfoParcel.m7771a(), wzVar.m15590a(), new alf(this), new aeh());
    }

    /* renamed from: a */
    private static Location m11369a(aqq<Location> aqq) {
        try {
            return (Location) aqq.get(((Long) xm.cv.m15604c()).longValue(), TimeUnit.MILLISECONDS);
        } catch (Throwable e) {
            C1043e.m7800c("Exception caught while getting location", e);
            return null;
        }
    }

    /* renamed from: a */
    private static AdResponseParcel m11370a(Context context, adv adv, wz wzVar, aky aky, AdRequestInfoParcel adRequestInfoParcel) {
        Bundle bundle;
        Future future;
        Throwable e;
        C1043e.m7794a("Starting ad request from service using: AFMA_getAd");
        xm.m15625a(context);
        aqq a = aky.f7786i.mo1819a();
        xz xzVar = new xz(((Boolean) xm.f10672U.m15604c()).booleanValue(), "load_ad", adRequestInfoParcel.f5522d.f4967b);
        if (adRequestInfoParcel.f5519a > 10 && adRequestInfoParcel.f5504B != -1) {
            xzVar.m15665a(xzVar.m15660a(adRequestInfoParcel.f5504B), "cts");
        }
        xx a2 = xzVar.m15659a();
        Bundle bundle2 = (adRequestInfoParcel.f5519a < 4 || adRequestInfoParcel.f5533o == null) ? null : adRequestInfoParcel.f5533o;
        if (!((Boolean) xm.al.m15604c()).booleanValue() || aky.f7778a == null) {
            bundle = bundle2;
            future = null;
        } else {
            if (bundle2 == null && ((Boolean) xm.am.m15604c()).booleanValue()) {
                ano.m11653e("contentInfo is not present, but we'll still launch the app index task");
                bundle2 = new Bundle();
            }
            if (bundle2 != null) {
                bundle = bundle2;
                future = aok.m11694a(new ala(aky, context, adRequestInfoParcel, bundle2));
            } else {
                bundle = bundle2;
                future = null;
            }
        }
        aql aql = new aql(null);
        Bundle bundle3 = adRequestInfoParcel.f5521c.f4950c;
        Object obj = (bundle3 == null || bundle3.getString("_ad") == null) ? null : 1;
        if (adRequestInfoParcel.f5511I && obj == null) {
            aqq a3 = aky.f7783f.mo1718a(adRequestInfoParcel.f5524f);
        } else {
            Object obj2 = aql;
        }
        alp a4 = bd.m6653n().m11467a(context);
        if (a4.f7885m == -1) {
            C1043e.m7794a("Device is offline.");
            return new AdResponseParcel(2);
        }
        String string;
        String uuid = adRequestInfoParcel.f5519a >= 7 ? adRequestInfoParcel.f5541w : UUID.randomUUID().toString();
        ali ali = new ali(uuid, adRequestInfoParcel.f5524f.packageName);
        if (adRequestInfoParcel.f5521c.f4950c != null) {
            string = adRequestInfoParcel.f5521c.f4950c.getString("_ad");
            if (string != null) {
                return alh.m11385a(context, adRequestInfoParcel, string);
            }
        }
        List a5 = aky.f7781d.mo2314a(adRequestInfoParcel);
        String a6 = aky.f7787j.mo1850a(adRequestInfoParcel);
        alv alv = aky.f7785h;
        if (future != null) {
            try {
                ano.m11653e("Waiting for app index fetching task.");
                future.get(((Long) xm.an.m15604c()).longValue(), TimeUnit.MILLISECONDS);
                ano.m11653e("App index fetching task completed.");
            } catch (ExecutionException e2) {
                e = e2;
                C1043e.m7800c("Failed to fetch app index signal", e);
            } catch (InterruptedException e3) {
                e = e3;
                C1043e.m7800c("Failed to fetch app index signal", e);
            } catch (TimeoutException e4) {
                C1043e.m7794a("Timed out waiting for app index fetching task");
            }
        }
        amw amw = aky.f7780c;
        string = adRequestInfoParcel.f5525g.packageName;
        m11374b(a);
        JSONObject a7 = alh.m11391a(context, new akx().m11360a(adRequestInfoParcel).m11361a(a4).m11362a(null).m11358a(m11369a(a3)).m11359a(m11374b(a)).m11363a(a6).m11364a(a5).m11366b(bundle).m11367b(null).m11365a(aky.f7779b.mo1164a(context)));
        if (a7 == null) {
            return new AdResponseParcel(0);
        }
        if (adRequestInfoParcel.f5519a < 7) {
            try {
                a7.put("request_id", uuid);
            } catch (JSONException e5) {
            }
        }
        try {
            a7.put("prefetch_mode", NativeProtocol.IMAGE_URL_KEY);
        } catch (Throwable e6) {
            C1043e.m7800c("Failed putting prefetch parameters to ad request.", e6);
        }
        String jSONObject = a7.toString();
        xzVar.m15665a(a2, "arc");
        aoq.f8164a.post(new alb(adv, ali, xzVar, xzVar.m15659a(), jSONObject));
        AdResponseParcel adResponseParcel;
        try {
            alo alo = (alo) ali.m11405b().get(10, TimeUnit.SECONDS);
            if (alo == null) {
                adResponseParcel = new AdResponseParcel(0);
                return adResponseParcel;
            } else if (alo.m11450a() != -2) {
                adResponseParcel = new AdResponseParcel(alo.m11450a());
                aoq.f8164a.post(new ale(aky, context, ali, adRequestInfoParcel));
                return adResponseParcel;
            } else {
                if (xzVar.m15669e() != null) {
                    xzVar.m15665a(xzVar.m15669e(), "rur");
                }
                adResponseParcel = null;
                if (!TextUtils.isEmpty(alo.m11459i())) {
                    adResponseParcel = alh.m11385a(context, adRequestInfoParcel, alo.m11459i());
                }
                if (adResponseParcel == null && !TextUtils.isEmpty(alo.m11455e())) {
                    adResponseParcel = m11371a(adRequestInfoParcel, context, adRequestInfoParcel.f5529k.f5721b, alo.m11455e(), null, alo, xzVar, aky);
                }
                if (adResponseParcel == null) {
                    adResponseParcel = new AdResponseParcel(0);
                }
                xzVar.m15665a(a2, "tts");
                adResponseParcel.f5585y = xzVar.m15667c();
                aoq.f8164a.post(new ale(aky, context, ali, adRequestInfoParcel));
                return adResponseParcel;
            }
        } catch (Exception e7) {
            adResponseParcel = new AdResponseParcel(0);
            return adResponseParcel;
        } finally {
            aoq.f8164a.post(new ale(aky, context, ali, adRequestInfoParcel));
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public static com.google.android.gms.ads.internal.request.AdResponseParcel m11371a(com.google.android.gms.ads.internal.request.AdRequestInfoParcel r13, android.content.Context r14, java.lang.String r15, java.lang.String r16, java.lang.String r17, com.google.android.gms.internal.alo r18, com.google.android.gms.internal.xz r19, com.google.android.gms.internal.aky r20) {
        /*
        if (r19 == 0) goto L_0x00ed;
    L_0x0002:
        r2 = r19.m15659a();
        r3 = r2;
    L_0x0007:
        r8 = new com.google.android.gms.internal.alm;	 Catch:{ IOException -> 0x00f8 }
        r2 = r18.m11453c();	 Catch:{ IOException -> 0x00f8 }
        r8.<init>(r13, r2);	 Catch:{ IOException -> 0x00f8 }
        r4 = "AdRequestServiceImpl: Sending request: ";
        r2 = java.lang.String.valueOf(r16);	 Catch:{ IOException -> 0x00f8 }
        r5 = r2.length();	 Catch:{ IOException -> 0x00f8 }
        if (r5 == 0) goto L_0x00f1;
    L_0x001c:
        r2 = r4.concat(r2);	 Catch:{ IOException -> 0x00f8 }
    L_0x0020:
        com.google.android.gms.ads.internal.util.client.C1043e.m7794a(r2);	 Catch:{ IOException -> 0x00f8 }
        r4 = new java.net.URL;	 Catch:{ IOException -> 0x00f8 }
        r0 = r16;
        r4.<init>(r0);	 Catch:{ IOException -> 0x00f8 }
        r2 = 0;
        r5 = com.google.android.gms.ads.internal.bd.m6650k();	 Catch:{ IOException -> 0x00f8 }
        r10 = r5.mo1681b();	 Catch:{ IOException -> 0x00f8 }
        r6 = r2;
        r7 = r4;
    L_0x0035:
        if (r20 == 0) goto L_0x003e;
    L_0x0037:
        r0 = r20;
        r2 = r0.f7784g;	 Catch:{ IOException -> 0x00f8 }
        r2.mo1838a();	 Catch:{ IOException -> 0x00f8 }
    L_0x003e:
        r2 = r7.openConnection();	 Catch:{ IOException -> 0x00f8 }
        r2 = (java.net.HttpURLConnection) r2;	 Catch:{ IOException -> 0x00f8 }
        r4 = com.google.android.gms.ads.internal.bd.m6644e();	 Catch:{ all -> 0x011d }
        r5 = 0;
        r4.m11736a(r14, r15, r5, r2);	 Catch:{ all -> 0x011d }
        r4 = android.text.TextUtils.isEmpty(r17);	 Catch:{ all -> 0x011d }
        if (r4 != 0) goto L_0x005f;
    L_0x0052:
        r4 = r18.m11457g();	 Catch:{ all -> 0x011d }
        if (r4 == 0) goto L_0x005f;
    L_0x0058:
        r4 = "x-afma-drt-cookie";
        r0 = r17;
        r2.addRequestProperty(r4, r0);	 Catch:{ all -> 0x011d }
    L_0x005f:
        r4 = r13.f5512J;	 Catch:{ all -> 0x011d }
        r5 = android.text.TextUtils.isEmpty(r4);	 Catch:{ all -> 0x011d }
        if (r5 != 0) goto L_0x0071;
    L_0x0067:
        r5 = "Sending webview cookie in ad request header.";
        com.google.android.gms.ads.internal.util.client.C1043e.m7794a(r5);	 Catch:{ all -> 0x011d }
        r5 = "Cookie";
        r2.addRequestProperty(r5, r4);	 Catch:{ all -> 0x011d }
    L_0x0071:
        if (r18 == 0) goto L_0x009d;
    L_0x0073:
        r4 = r18.m11454d();	 Catch:{ all -> 0x011d }
        r4 = android.text.TextUtils.isEmpty(r4);	 Catch:{ all -> 0x011d }
        if (r4 != 0) goto L_0x009d;
    L_0x007d:
        r4 = 1;
        r2.setDoOutput(r4);	 Catch:{ all -> 0x011d }
        r4 = r18.m11454d();	 Catch:{ all -> 0x011d }
        r9 = r4.getBytes();	 Catch:{ all -> 0x011d }
        r4 = r9.length;	 Catch:{ all -> 0x011d }
        r2.setFixedLengthStreamingMode(r4);	 Catch:{ all -> 0x011d }
        r5 = 0;
        r4 = new java.io.BufferedOutputStream;	 Catch:{ all -> 0x0117 }
        r12 = r2.getOutputStream();	 Catch:{ all -> 0x0117 }
        r4.<init>(r12);	 Catch:{ all -> 0x0117 }
        r4.write(r9);	 Catch:{ all -> 0x01d4 }
        com.google.android.gms.common.util.C1423l.m10349a(r4);	 Catch:{ all -> 0x011d }
    L_0x009d:
        r9 = r2.getResponseCode();	 Catch:{ all -> 0x011d }
        r12 = r2.getHeaderFields();	 Catch:{ all -> 0x011d }
        r4 = 200; // 0xc8 float:2.8E-43 double:9.9E-322;
        if (r9 < r4) goto L_0x0131;
    L_0x00a9:
        r4 = 300; // 0x12c float:4.2E-43 double:1.48E-321;
        if (r9 >= r4) goto L_0x0131;
    L_0x00ad:
        r6 = r7.toString();	 Catch:{ all -> 0x011d }
        r5 = 0;
        r4 = new java.io.InputStreamReader;	 Catch:{ all -> 0x012b }
        r7 = r2.getInputStream();	 Catch:{ all -> 0x012b }
        r4.<init>(r7);	 Catch:{ all -> 0x012b }
        r5 = com.google.android.gms.ads.internal.bd.m6644e();	 Catch:{ all -> 0x01d1 }
        r5 = r5.m11721a(r4);	 Catch:{ all -> 0x01d1 }
        com.google.android.gms.common.util.C1423l.m10349a(r4);	 Catch:{ all -> 0x011d }
        m11373a(r6, r12, r5, r9);	 Catch:{ all -> 0x011d }
        r8.m11445a(r6, r12, r5);	 Catch:{ all -> 0x011d }
        if (r19 == 0) goto L_0x00db;
    L_0x00ce:
        r4 = 1;
        r4 = new java.lang.String[r4];	 Catch:{ all -> 0x011d }
        r5 = 0;
        r6 = "ufe";
        r4[r5] = r6;	 Catch:{ all -> 0x011d }
        r0 = r19;
        r0.m15665a(r3, r4);	 Catch:{ all -> 0x011d }
    L_0x00db:
        r3 = r8.m11444a(r10);	 Catch:{ all -> 0x011d }
        r2.disconnect();	 Catch:{ IOException -> 0x00f8 }
        if (r20 == 0) goto L_0x00eb;
    L_0x00e4:
        r0 = r20;
        r2 = r0.f7784g;	 Catch:{ IOException -> 0x00f8 }
        r2.mo1839b();	 Catch:{ IOException -> 0x00f8 }
    L_0x00eb:
        r2 = r3;
    L_0x00ec:
        return r2;
    L_0x00ed:
        r2 = 0;
        r3 = r2;
        goto L_0x0007;
    L_0x00f1:
        r2 = new java.lang.String;	 Catch:{ IOException -> 0x00f8 }
        r2.<init>(r4);	 Catch:{ IOException -> 0x00f8 }
        goto L_0x0020;
    L_0x00f8:
        r2 = move-exception;
        r3 = "Error while connecting to ad server: ";
        r2 = r2.getMessage();
        r2 = java.lang.String.valueOf(r2);
        r4 = r2.length();
        if (r4 == 0) goto L_0x01ca;
    L_0x0109:
        r2 = r3.concat(r2);
    L_0x010d:
        com.google.android.gms.ads.internal.util.client.C1043e.m7801d(r2);
        r2 = new com.google.android.gms.ads.internal.request.AdResponseParcel;
        r3 = 2;
        r2.<init>(r3);
        goto L_0x00ec;
    L_0x0117:
        r3 = move-exception;
        r4 = r5;
    L_0x0119:
        com.google.android.gms.common.util.C1423l.m10349a(r4);	 Catch:{ all -> 0x011d }
        throw r3;	 Catch:{ all -> 0x011d }
    L_0x011d:
        r3 = move-exception;
        r2.disconnect();	 Catch:{ IOException -> 0x00f8 }
        if (r20 == 0) goto L_0x012a;
    L_0x0123:
        r0 = r20;
        r2 = r0.f7784g;	 Catch:{ IOException -> 0x00f8 }
        r2.mo1839b();	 Catch:{ IOException -> 0x00f8 }
    L_0x012a:
        throw r3;	 Catch:{ IOException -> 0x00f8 }
    L_0x012b:
        r3 = move-exception;
        r4 = r5;
    L_0x012d:
        com.google.android.gms.common.util.C1423l.m10349a(r4);	 Catch:{ all -> 0x011d }
        throw r3;	 Catch:{ all -> 0x011d }
    L_0x0131:
        r4 = r7.toString();	 Catch:{ all -> 0x011d }
        r5 = 0;
        m11373a(r4, r12, r5, r9);	 Catch:{ all -> 0x011d }
        r4 = 300; // 0x12c float:4.2E-43 double:1.48E-321;
        if (r9 < r4) goto L_0x018a;
    L_0x013d:
        r4 = 400; // 0x190 float:5.6E-43 double:1.976E-321;
        if (r9 >= r4) goto L_0x018a;
    L_0x0141:
        r4 = "Location";
        r4 = r2.getHeaderField(r4);	 Catch:{ all -> 0x011d }
        r5 = android.text.TextUtils.isEmpty(r4);	 Catch:{ all -> 0x011d }
        if (r5 == 0) goto L_0x0166;
    L_0x014d:
        r3 = "No location header to follow redirect.";
        com.google.android.gms.ads.internal.util.client.C1043e.m7801d(r3);	 Catch:{ all -> 0x011d }
        r3 = new com.google.android.gms.ads.internal.request.AdResponseParcel;	 Catch:{ all -> 0x011d }
        r4 = 0;
        r3.<init>(r4);	 Catch:{ all -> 0x011d }
        r2.disconnect();	 Catch:{ IOException -> 0x00f8 }
        if (r20 == 0) goto L_0x0164;
    L_0x015d:
        r0 = r20;
        r2 = r0.f7784g;	 Catch:{ IOException -> 0x00f8 }
        r2.mo1839b();	 Catch:{ IOException -> 0x00f8 }
    L_0x0164:
        r2 = r3;
        goto L_0x00ec;
    L_0x0166:
        r5 = new java.net.URL;	 Catch:{ all -> 0x011d }
        r5.<init>(r4);	 Catch:{ all -> 0x011d }
        r4 = r6 + 1;
        r6 = 5;
        if (r4 <= r6) goto L_0x01b7;
    L_0x0170:
        r3 = "Too many redirects.";
        com.google.android.gms.ads.internal.util.client.C1043e.m7801d(r3);	 Catch:{ all -> 0x011d }
        r3 = new com.google.android.gms.ads.internal.request.AdResponseParcel;	 Catch:{ all -> 0x011d }
        r4 = 0;
        r3.<init>(r4);	 Catch:{ all -> 0x011d }
        r2.disconnect();	 Catch:{ IOException -> 0x00f8 }
        if (r20 == 0) goto L_0x0187;
    L_0x0180:
        r0 = r20;
        r2 = r0.f7784g;	 Catch:{ IOException -> 0x00f8 }
        r2.mo1839b();	 Catch:{ IOException -> 0x00f8 }
    L_0x0187:
        r2 = r3;
        goto L_0x00ec;
    L_0x018a:
        r3 = new java.lang.StringBuilder;	 Catch:{ all -> 0x011d }
        r4 = 46;
        r3.<init>(r4);	 Catch:{ all -> 0x011d }
        r4 = "Received error HTTP response code: ";
        r3 = r3.append(r4);	 Catch:{ all -> 0x011d }
        r3 = r3.append(r9);	 Catch:{ all -> 0x011d }
        r3 = r3.toString();	 Catch:{ all -> 0x011d }
        com.google.android.gms.ads.internal.util.client.C1043e.m7801d(r3);	 Catch:{ all -> 0x011d }
        r3 = new com.google.android.gms.ads.internal.request.AdResponseParcel;	 Catch:{ all -> 0x011d }
        r4 = 0;
        r3.<init>(r4);	 Catch:{ all -> 0x011d }
        r2.disconnect();	 Catch:{ IOException -> 0x00f8 }
        if (r20 == 0) goto L_0x01b4;
    L_0x01ad:
        r0 = r20;
        r2 = r0.f7784g;	 Catch:{ IOException -> 0x00f8 }
        r2.mo1839b();	 Catch:{ IOException -> 0x00f8 }
    L_0x01b4:
        r2 = r3;
        goto L_0x00ec;
    L_0x01b7:
        r8.m11446a(r12);	 Catch:{ all -> 0x011d }
        r2.disconnect();	 Catch:{ IOException -> 0x00f8 }
        if (r20 == 0) goto L_0x01c6;
    L_0x01bf:
        r0 = r20;
        r2 = r0.f7784g;	 Catch:{ IOException -> 0x00f8 }
        r2.mo1839b();	 Catch:{ IOException -> 0x00f8 }
    L_0x01c6:
        r6 = r4;
        r7 = r5;
        goto L_0x0035;
    L_0x01ca:
        r2 = new java.lang.String;
        r2.<init>(r3);
        goto L_0x010d;
    L_0x01d1:
        r3 = move-exception;
        goto L_0x012d;
    L_0x01d4:
        r3 = move-exception;
        goto L_0x0119;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.akz.a(com.google.android.gms.ads.internal.request.AdRequestInfoParcel, android.content.Context, java.lang.String, java.lang.String, java.lang.String, com.google.android.gms.internal.alo, com.google.android.gms.internal.xz, com.google.android.gms.internal.aky):com.google.android.gms.ads.internal.request.AdResponseParcel");
    }

    /* renamed from: a */
    public static akz m11372a(Context context, wz wzVar, aky aky) {
        akz akz;
        synchronized (f7788a) {
            if (f7789b == null) {
                if (context.getApplicationContext() != null) {
                    context = context.getApplicationContext();
                }
                f7789b = new akz(context, wzVar, aky);
            }
            akz = f7789b;
        }
        return akz;
    }

    /* renamed from: a */
    private static void m11373a(String str, Map<String, List<String>> map, String str2, int i) {
        if (C1043e.m7796a(2)) {
            ano.m11653e(new StringBuilder(String.valueOf(str).length() + 39).append("Http Response: {\n  URL:\n    ").append(str).append("\n  Headers:").toString());
            if (map != null) {
                for (String str3 : map.keySet()) {
                    String str32;
                    ano.m11653e(new StringBuilder(String.valueOf(str32).length() + 5).append("    ").append(str32).append(":").toString());
                    for (String str322 : (List) map.get(str322)) {
                        String str4 = "      ";
                        str322 = String.valueOf(str322);
                        ano.m11653e(str322.length() != 0 ? str4.concat(str322) : new String(str4));
                    }
                }
            }
            ano.m11653e("  Body:");
            if (str2 != null) {
                for (int i2 = 0; i2 < Math.min(str2.length(), 100000); i2 += PlacePickerFragment.DEFAULT_RADIUS_IN_METERS) {
                    ano.m11653e(str2.substring(i2, Math.min(str2.length(), i2 + PlacePickerFragment.DEFAULT_RADIUS_IN_METERS)));
                }
            } else {
                ano.m11653e("    null");
            }
            ano.m11653e("  Response Code:\n    " + i + "\n}");
        }
    }

    /* renamed from: b */
    private static Bundle m11374b(aqq<Bundle> aqq) {
        Bundle bundle = new Bundle();
        try {
            return (Bundle) aqq.get(((Long) xm.cN.m15604c()).longValue(), TimeUnit.MILLISECONDS);
        } catch (Throwable e) {
            C1043e.m7800c("Exception caught while getting parental controls.", e);
            return bundle;
        }
    }

    /* renamed from: a */
    public AdResponseParcel mo1315a(AdRequestInfoParcel adRequestInfoParcel) {
        return m11370a(this.f7790c, this.f7793f, this.f7792e, this.f7791d, adRequestInfoParcel);
    }

    /* renamed from: a */
    public void mo1316a(AdRequestInfoParcel adRequestInfoParcel, aa aaVar) {
        bd.m6648i().m11603a(this.f7790c, adRequestInfoParcel.f5529k);
        aok.m11693a(new alg(this, adRequestInfoParcel, aaVar));
    }
}
