package com.google.android.gms.internal;

import android.os.Process;

class baj implements Runnable {
    /* renamed from: a */
    private final Runnable f8758a;
    /* renamed from: b */
    private final int f8759b;

    public baj(Runnable runnable, int i) {
        this.f8758a = runnable;
        this.f8759b = i;
    }

    public void run() {
        Process.setThreadPriority(this.f8759b);
        this.f8758a.run();
    }
}
