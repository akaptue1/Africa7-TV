package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.util.client.C1043e;
import com.google.android.gms.p034a.C0830f;

class amk implements Runnable {
    /* renamed from: a */
    final /* synthetic */ aft f7967a;
    /* renamed from: b */
    final /* synthetic */ AdRequestParcel f7968b;
    /* renamed from: c */
    final /* synthetic */ amq f7969c;
    /* renamed from: d */
    final /* synthetic */ ami f7970d;

    amk(ami ami, aft aft, AdRequestParcel adRequestParcel, amq amq) {
        this.f7970d = ami;
        this.f7967a = aft;
        this.f7968b = adRequestParcel;
        this.f7969c = amq;
    }

    public void run() {
        try {
            this.f7967a.mo1740a(C0830f.m6210a(this.f7970d.f7953b), this.f7968b, null, this.f7969c, this.f7970d.f7958g);
        } catch (Throwable e) {
            Throwable th = e;
            String str = "Fail to initialize adapter ";
            String valueOf = String.valueOf(this.f7970d.f7957f);
            C1043e.m7800c(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), th);
            this.f7970d.mo1848a(this.f7970d.f7957f, 0);
        }
    }
}
