package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IInterface;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.ads.internal.reward.mediation.client.C1027a;
import com.google.android.gms.p034a.C0827c;
import java.util.List;

public interface aft extends IInterface {
    /* renamed from: a */
    C0827c mo1738a();

    /* renamed from: a */
    void mo1739a(C0827c c0827c);

    /* renamed from: a */
    void mo1740a(C0827c c0827c, AdRequestParcel adRequestParcel, String str, C1027a c1027a, String str2);

    /* renamed from: a */
    void mo1741a(C0827c c0827c, AdRequestParcel adRequestParcel, String str, afw afw);

    /* renamed from: a */
    void mo1742a(C0827c c0827c, AdRequestParcel adRequestParcel, String str, String str2, afw afw);

    /* renamed from: a */
    void mo1743a(C0827c c0827c, AdRequestParcel adRequestParcel, String str, String str2, afw afw, NativeAdOptionsParcel nativeAdOptionsParcel, List<String> list);

    /* renamed from: a */
    void mo1744a(C0827c c0827c, AdSizeParcel adSizeParcel, AdRequestParcel adRequestParcel, String str, afw afw);

    /* renamed from: a */
    void mo1745a(C0827c c0827c, AdSizeParcel adSizeParcel, AdRequestParcel adRequestParcel, String str, String str2, afw afw);

    /* renamed from: a */
    void mo1746a(AdRequestParcel adRequestParcel, String str);

    /* renamed from: a */
    void mo1747a(AdRequestParcel adRequestParcel, String str, String str2);

    /* renamed from: b */
    void mo1748b();

    /* renamed from: c */
    void mo1749c();

    /* renamed from: d */
    void mo1750d();

    /* renamed from: e */
    void mo1751e();

    /* renamed from: f */
    void mo1752f();

    /* renamed from: g */
    boolean mo1753g();

    /* renamed from: h */
    agc mo1754h();

    /* renamed from: i */
    agf mo1755i();

    /* renamed from: j */
    Bundle mo1756j();

    /* renamed from: k */
    Bundle mo1757k();

    /* renamed from: l */
    Bundle mo1758l();
}
