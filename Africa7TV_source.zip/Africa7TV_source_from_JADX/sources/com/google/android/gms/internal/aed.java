package com.google.android.gms.internal;

class aed implements Runnable {
    /* renamed from: a */
    final /* synthetic */ aec f7343a;

    aed(aec aec) {
        this.f7343a = aec;
    }

    public void run() {
        this.f7343a.f7341a.mo1701a();
    }
}
