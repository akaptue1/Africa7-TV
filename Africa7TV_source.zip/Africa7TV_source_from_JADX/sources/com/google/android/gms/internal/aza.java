package com.google.android.gms.internal;

class aza implements Runnable {
    /* renamed from: a */
    final /* synthetic */ ayh f8709a;
    /* renamed from: b */
    final /* synthetic */ String f8710b;
    /* renamed from: c */
    final /* synthetic */ ayz f8711c;

    aza(ayz ayz, ayh ayh, String str) {
        this.f8711c = ayz;
        this.f8709a = ayh;
        this.f8710b = str;
    }

    public void run() {
        if (this.f8711c.f8707c >= 1) {
            this.f8709a.mo1998a(this.f8711c.f8708d != null ? this.f8711c.f8708d.getBundle(this.f8710b) : null);
        }
        if (this.f8711c.f8707c >= 2) {
            this.f8709a.mo1996a();
        }
        if (this.f8711c.f8707c >= 3) {
            this.f8709a.mo1999b();
        }
        if (this.f8711c.f8707c >= 4) {
            this.f8709a.m12523g();
        }
    }
}
