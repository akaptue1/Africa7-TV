package com.google.android.gms.internal;

public interface ahx {
    /* renamed from: a */
    void mo1820a(String str, String str2, String str3);
}
