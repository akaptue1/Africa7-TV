package com.google.android.gms.internal;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class sn extends sm {
    /* renamed from: s */
    private static final String f10321s = sn.class.getSimpleName();

    protected sn(Context context, String str, boolean z) {
        super(context, str, z);
    }

    /* renamed from: a */
    public static sn m15172a(String str, Context context, boolean z) {
        sm.m15096a(context, z);
        return new sn(context, str, z);
    }

    /* renamed from: b */
    protected List<Callable<Void>> mo2281b(sy syVar, fa faVar, cj cjVar) {
        if (syVar.m15259c() == null || !this.o) {
            return super.mo2281b(syVar, faVar, cjVar);
        }
        int r = syVar.m15274r();
        List<Callable<Void>> arrayList = new ArrayList();
        arrayList.addAll(super.mo2281b(syVar, faVar, cjVar));
        arrayList.add(new tl(syVar, ss.m15219n(), ss.m15220o(), faVar, r, 24));
        return arrayList;
    }
}
