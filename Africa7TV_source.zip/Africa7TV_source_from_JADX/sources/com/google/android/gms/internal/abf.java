package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.util.client.C1043e;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;
import org.json.JSONObject;

@akw
public class abf implements aau {
    /* renamed from: a */
    final HashMap<String, aqk<JSONObject>> f7177a = new HashMap();

    /* renamed from: a */
    public Future<JSONObject> m10477a(String str) {
        Future aqk = new aqk();
        this.f7177a.put(str, aqk);
        return aqk;
    }

    /* renamed from: a */
    public void mo1150a(arh arh, Map<String, String> map) {
        m10479a((String) map.get("request_id"), (String) map.get("fetched_ad"));
    }

    /* renamed from: a */
    public void m10479a(String str, String str2) {
        C1043e.m7794a("Received ad from the cache.");
        aqk aqk = (aqk) this.f7177a.get(str);
        if (aqk == null) {
            C1043e.m7797b("Could not find the ad request for the corresponding ad response.");
            return;
        }
        try {
            aqk.m10666b(new JSONObject(str2));
        } catch (Throwable e) {
            C1043e.m7798b("Failed constructing JSON object from value passed from javascript", e);
            aqk.m10666b(null);
        } finally {
            this.f7177a.remove(str);
        }
    }

    /* renamed from: b */
    public void m10480b(String str) {
        aqk aqk = (aqk) this.f7177a.get(str);
        if (aqk == null) {
            C1043e.m7797b("Could not find the ad request for the corresponding ad response.");
            return;
        }
        if (!aqk.isDone()) {
            aqk.cancel(true);
        }
        this.f7177a.remove(str);
    }
}
