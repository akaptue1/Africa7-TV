package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.ap;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import com.google.android.gms.ads.internal.util.client.C1043e;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@akw
public class ajp extends anm {
    /* renamed from: a */
    private final aji f7665a;
    /* renamed from: b */
    private final AdResponseParcel f7666b;
    /* renamed from: c */
    private final anb f7667c;
    /* renamed from: d */
    private final ajx f7668d;
    /* renamed from: e */
    private final Object f7669e;
    /* renamed from: f */
    private Future<ana> f7670f;

    public ajp(Context context, ap apVar, anb anb, so soVar, aji aji, xz xzVar) {
        this(anb, aji, new ajx(context, apVar, new apu(context), soVar, anb, xzVar));
    }

    ajp(anb anb, aji aji, ajx ajx) {
        this.f7669e = new Object();
        this.f7667c = anb;
        this.f7666b = anb.f8034b;
        this.f7665a = aji;
        this.f7668d = ajx;
    }

    /* renamed from: a */
    private ana m11255a(int i) {
        return new ana(this.f7667c.f8033a.f5521c, null, null, i, null, null, this.f7666b.f5572l, this.f7666b.f5571k, this.f7667c.f8033a.f5527i, false, null, null, null, null, null, this.f7666b.f5569i, this.f7667c.f8036d, this.f7666b.f5567g, this.f7667c.f8038f, this.f7666b.f5574n, this.f7666b.f5575o, this.f7667c.f8040h, null, null, null, null, this.f7667c.f8034b.f5550F, this.f7667c.f8034b.f5551G, null, null, this.f7666b.f5558N);
    }

    /* renamed from: a */
    public void mo1147a() {
        ana ana;
        int i;
        try {
            synchronized (this.f7669e) {
                this.f7670f = aok.m11694a(this.f7668d);
            }
            ana = (ana) this.f7670f.get(60000, TimeUnit.MILLISECONDS);
            i = -2;
        } catch (TimeoutException e) {
            C1043e.m7801d("Timed out waiting for native ad.");
            this.f7670f.cancel(true);
            i = 2;
            ana = null;
        } catch (ExecutionException e2) {
            ana = null;
            i = 0;
        } catch (InterruptedException e3) {
            ana = null;
            i = 0;
        } catch (CancellationException e4) {
            ana = null;
            i = 0;
        }
        if (ana == null) {
            ana = m11255a(i);
        }
        aoq.f8164a.post(new ajq(this, ana));
    }

    /* renamed from: b */
    public void mo1148b() {
        synchronized (this.f7669e) {
            if (this.f7670f != null) {
                this.f7670f.cancel(true);
            }
        }
    }
}
