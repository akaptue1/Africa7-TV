package com.google.android.gms.internal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

class vn extends BroadcastReceiver {
    /* renamed from: a */
    final /* synthetic */ vl f10515a;

    vn(vl vlVar) {
        this.f10515a = vlVar;
    }

    public void onReceive(Context context, Intent intent) {
        this.f10515a.m15477a(3);
    }
}
