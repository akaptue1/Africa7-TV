package com.google.android.gms.internal;

import org.json.JSONObject;

public interface aes {
    /* renamed from: a */
    void mo1705a(String str, aau aau);

    /* renamed from: a */
    void mo1706a(String str, String str2);

    /* renamed from: a */
    void mo1707a(String str, JSONObject jSONObject);

    /* renamed from: b */
    void mo1710b(String str, aau aau);

    /* renamed from: b */
    void mo1711b(String str, JSONObject jSONObject);
}
