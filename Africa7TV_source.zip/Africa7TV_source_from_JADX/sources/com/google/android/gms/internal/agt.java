package com.google.android.gms.internal;

import com.google.ads.C0783b;
import com.google.ads.C0784c;

/* synthetic */ class agt {
    /* renamed from: a */
    static final /* synthetic */ int[] f7519a = new int[C0784c.values().length];
    /* renamed from: b */
    static final /* synthetic */ int[] f7520b = new int[C0783b.values().length];

    static {
        try {
            f7520b[C0783b.INTERNAL_ERROR.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            f7520b[C0783b.INVALID_REQUEST.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            f7520b[C0783b.NETWORK_ERROR.ordinal()] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            f7520b[C0783b.NO_FILL.ordinal()] = 4;
        } catch (NoSuchFieldError e4) {
        }
        try {
            f7519a[C0784c.FEMALE.ordinal()] = 1;
        } catch (NoSuchFieldError e5) {
        }
        try {
            f7519a[C0784c.MALE.ordinal()] = 2;
        } catch (NoSuchFieldError e6) {
        }
        try {
            f7519a[C0784c.UNKNOWN.ordinal()] = 3;
        } catch (NoSuchFieldError e7) {
        }
    }
}
