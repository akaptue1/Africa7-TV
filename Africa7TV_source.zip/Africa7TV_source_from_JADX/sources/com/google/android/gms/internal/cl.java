package com.google.android.gms.internal;

public final class cl extends rz {
    /* renamed from: a */
    public String f9217a;
    /* renamed from: b */
    public String f9218b;
    /* renamed from: c */
    public String f9219c;
    /* renamed from: d */
    public String f9220d;
    /* renamed from: e */
    public String f9221e;

    public cl() {
        m13650a();
    }

    /* renamed from: a */
    public cl m13650a() {
        this.f9217a = null;
        this.f9218b = null;
        this.f9219c = null;
        this.f9220d = null;
        this.f9221e = null;
        this.ah = -1;
        return this;
    }

    /* renamed from: a */
    public cl m13651a(rp rpVar) {
        while (true) {
            int a = rpVar.m14968a();
            switch (a) {
                case 0:
                    break;
                case 10:
                    this.f9217a = rpVar.m14984i();
                    continue;
                case 18:
                    this.f9218b = rpVar.m14984i();
                    continue;
                case 26:
                    this.f9219c = rpVar.m14984i();
                    continue;
                case 34:
                    this.f9220d = rpVar.m14984i();
                    continue;
                case 42:
                    this.f9221e = rpVar.m14984i();
                    continue;
                default:
                    if (!sc.m15126a(rpVar, a)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    /* renamed from: a */
    public void mo2082a(rq rqVar) {
        if (this.f9217a != null) {
            rqVar.m15035a(1, this.f9217a);
        }
        if (this.f9218b != null) {
            rqVar.m15035a(2, this.f9218b);
        }
        if (this.f9219c != null) {
            rqVar.m15035a(3, this.f9219c);
        }
        if (this.f9220d != null) {
            rqVar.m15035a(4, this.f9220d);
        }
        if (this.f9221e != null) {
            rqVar.m15035a(5, this.f9221e);
        }
        super.mo2082a(rqVar);
    }

    /* renamed from: b */
    protected int mo2083b() {
        int b = super.mo2083b();
        if (this.f9217a != null) {
            b += rq.m15006b(1, this.f9217a);
        }
        if (this.f9218b != null) {
            b += rq.m15006b(2, this.f9218b);
        }
        if (this.f9219c != null) {
            b += rq.m15006b(3, this.f9219c);
        }
        if (this.f9220d != null) {
            b += rq.m15006b(4, this.f9220d);
        }
        return this.f9221e != null ? b + rq.m15006b(5, this.f9221e) : b;
    }

    /* renamed from: b */
    public /* synthetic */ rz mo2084b(rp rpVar) {
        return m13651a(rpVar);
    }
}
