package com.google.android.gms.internal;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import oauth.signpost.OAuth;

final class kn {
    /* renamed from: a */
    static boolean f9843a = false;
    /* renamed from: b */
    static CountDownLatch f9844b = new CountDownLatch(1);
    /* renamed from: c */
    private static MessageDigest f9845c = null;
    /* renamed from: d */
    private static final Object f9846d = new Object();
    /* renamed from: e */
    private static final Object f9847e = new Object();

    /* renamed from: a */
    private static int m14386a(boolean z) {
        return z ? 239 : 255;
    }

    /* renamed from: a */
    static fa m14387a(long j) {
        fa faVar = new fa();
        faVar.f9364t = Long.valueOf(j);
        return faVar;
    }

    /* renamed from: a */
    static String m14388a(fa faVar, String str, boolean z) {
        return m14390a(rz.m13132a((rz) faVar), str, z);
    }

    /* renamed from: a */
    static String m14389a(String str, String str2, boolean z) {
        byte[] b = m14398b(str, str2, z);
        return b != null ? jp.m14319a(b, true) : Integer.toString(7);
    }

    /* renamed from: a */
    static String m14390a(byte[] bArr, String str, boolean z) {
        return jp.m14319a(z ? m14399b(bArr, str) : m14396a(bArr, str), true);
    }

    /* renamed from: a */
    static Vector<byte[]> m14392a(byte[] bArr, int i) {
        if (bArr == null || bArr.length <= 0) {
            return null;
        }
        int length = ((bArr.length + i) - 1) / i;
        Vector<byte[]> vector = new Vector();
        int i2 = 0;
        while (i2 < length) {
            int i3 = i2 * i;
            try {
                vector.add(Arrays.copyOfRange(bArr, i3, bArr.length - i3 > i ? i3 + i : bArr.length));
                i2++;
            } catch (IndexOutOfBoundsException e) {
                return null;
            }
        }
        return vector;
    }

    /* renamed from: a */
    static void m14393a() {
        synchronized (f9847e) {
            if (!f9843a) {
                f9843a = true;
                new Thread(new kp()).start();
            }
        }
    }

    /* renamed from: a */
    static void m14394a(String str, byte[] bArr) {
        if (str.length() > 32) {
            str = str.substring(0, 32);
        }
        new rn(str.getBytes(OAuth.ENCODING)).m14949a(bArr);
    }

    /* renamed from: a */
    public static byte[] m14395a(byte[] bArr) {
        byte[] digest;
        synchronized (f9846d) {
            MessageDigest b = m14397b();
            if (b == null) {
                throw new NoSuchAlgorithmException("Cannot compute hash");
            }
            b.reset();
            b.update(bArr);
            digest = f9845c.digest();
        }
        return digest;
    }

    /* renamed from: a */
    static byte[] m14396a(byte[] bArr, String str) {
        Vector a = m14392a(bArr, 255);
        if (a == null || a.size() == 0) {
            return m14399b(rz.m13132a(m14387a(4096)), str);
        }
        rz fhVar = new fh();
        fhVar.f9401a = new byte[a.size()][];
        Iterator it = a.iterator();
        int i = 0;
        while (it.hasNext()) {
            int i2 = i + 1;
            fhVar.f9401a[i] = m14400b((byte[]) it.next(), str, false);
            i = i2;
        }
        fhVar.f9402b = m14395a(bArr);
        return rz.m13132a(fhVar);
    }

    /* renamed from: b */
    static MessageDigest m14397b() {
        m14393a();
        boolean z = false;
        try {
            z = f9844b.await(2, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
        }
        return (z && f9845c != null) ? f9845c : null;
    }

    /* renamed from: b */
    static byte[] m14398b(String str, String str2, boolean z) {
        rz feVar = new fe();
        try {
            feVar.f9392a = str.length() < 3 ? str.getBytes("ISO-8859-1") : jp.m14320a(str, true);
            byte[] bytes = z ? str2.length() < 3 ? str2.getBytes("ISO-8859-1") : jp.m14320a(str2, true) : (str2 == null || str2.length() == 0) ? Integer.toString(5).getBytes("ISO-8859-1") : jp.m14320a(m14390a(str2.getBytes("ISO-8859-1"), null, ((Boolean) xm.bs.m15604c()).booleanValue()), true);
            feVar.f9393b = bytes;
            return rz.m13132a(feVar);
        } catch (UnsupportedEncodingException e) {
            return null;
        } catch (NoSuchAlgorithmException e2) {
            return null;
        }
    }

    /* renamed from: b */
    static byte[] m14399b(byte[] bArr, String str) {
        return m14400b(bArr, str, true);
    }

    /* renamed from: b */
    private static byte[] m14400b(byte[] bArr, String str, boolean z) {
        byte[] bArr2;
        byte[] array;
        int a = m14386a(z);
        if (bArr.length > a) {
            bArr = rz.m13132a(m14387a(4096));
        }
        if (bArr.length < a) {
            bArr2 = new byte[(a - bArr.length)];
            new SecureRandom().nextBytes(bArr2);
            array = ByteBuffer.allocate(a + 1).put((byte) bArr.length).put(bArr).put(bArr2).array();
        } else {
            array = ByteBuffer.allocate(a + 1).put((byte) bArr.length).put(bArr).array();
        }
        if (z) {
            array = ByteBuffer.allocate(256).put(m14395a(array)).put(array).array();
        }
        bArr2 = new byte[256];
        new la().m14437a(array, bArr2);
        if (str != null && str.length() > 0) {
            m14394a(str, bArr2);
        }
        return bArr2;
    }
}
