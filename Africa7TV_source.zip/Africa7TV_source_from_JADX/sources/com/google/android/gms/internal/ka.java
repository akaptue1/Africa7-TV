package com.google.android.gms.internal;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;

class ka implements jz {
    /* renamed from: a */
    private static ThreadLocal<CharsetDecoder> f9812a = new kb();
    /* renamed from: b */
    private static ThreadLocal<CharsetEncoder> f9813b = new kc();
    /* renamed from: c */
    private StringBuilder f9814c = new StringBuilder();

    ka() {
    }

    /* renamed from: b */
    private String m14354b(byte[] bArr) {
        try {
            return ((CharsetDecoder) f9812a.get()).decode(ByteBuffer.wrap(bArr)).toString();
        } catch (CharacterCodingException e) {
            return null;
        }
    }

    /* renamed from: a */
    public km mo2225a() {
        return new km(this.f9814c.toString());
    }

    /* renamed from: a */
    public boolean mo2226a(byte[] bArr) {
        String b = m14354b(bArr);
        if (b == null) {
            return false;
        }
        this.f9814c.append(b);
        return true;
    }
}
