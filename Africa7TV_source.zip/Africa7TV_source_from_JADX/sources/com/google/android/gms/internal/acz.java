package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.ac;
import com.google.android.gms.ads.internal.client.aw;
import com.google.android.gms.ads.internal.client.az;
import com.google.android.gms.ads.internal.client.br;
import com.google.android.gms.ads.internal.reward.client.C1020j;

@akw
class acz {
    /* renamed from: a */
    az f7253a;
    /* renamed from: b */
    br f7254b;
    /* renamed from: c */
    aie f7255c;
    /* renamed from: d */
    yi f7256d;
    /* renamed from: e */
    aw f7257e;
    /* renamed from: f */
    C1020j f7258f;

    acz() {
    }

    /* renamed from: a */
    void m10573a(ac acVar) {
        if (this.f7253a != null) {
            acVar.mo1078a(new ada(this.f7253a));
        }
        if (this.f7254b != null) {
            acVar.mo1079a(this.f7254b);
        }
        if (this.f7255c != null) {
            acVar.mo1082a(this.f7255c);
        }
        if (this.f7256d != null) {
            acVar.mo1085a(this.f7256d);
        }
        if (this.f7257e != null) {
            acVar.mo1077a(this.f7257e);
        }
        if (this.f7258f != null) {
            acVar.mo1081a(this.f7258f);
        }
    }
}
