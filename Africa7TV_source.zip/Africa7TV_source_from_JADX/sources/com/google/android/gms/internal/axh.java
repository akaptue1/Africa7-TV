package com.google.android.gms.internal;

import com.google.android.gms.signin.internal.SignInResponse;

class axh extends axu {
    /* renamed from: a */
    final /* synthetic */ awz f8578a;
    /* renamed from: b */
    final /* synthetic */ SignInResponse f8579b;
    /* renamed from: c */
    final /* synthetic */ axg f8580c;

    axh(axg axg, axs axs, awz awz, SignInResponse signInResponse) {
        this.f8580c = axg;
        this.f8578a = awz;
        this.f8579b = signInResponse;
        super(axs);
    }

    /* renamed from: a */
    public void mo2034a() {
        this.f8578a.m12684a(this.f8579b);
    }
}
