package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;

public interface amz {
    /* renamed from: a */
    String mo1850a(AdRequestInfoParcel adRequestInfoParcel);
}
