package com.google.android.gms.internal;

import java.util.Map;

@akw
public abstract class xt {
    @akw
    /* renamed from: a */
    public static final xt f10720a = new xu();
    @akw
    /* renamed from: b */
    public static final xt f10721b = new xv();
    @akw
    /* renamed from: c */
    public static final xt f10722c = new xw();

    /* renamed from: a */
    public abstract String mo2316a(String str, String str2);

    /* renamed from: a */
    public final void m15648a(Map<String, String> map, String str, String str2) {
        map.put(str, mo2316a((String) map.get(str), str2));
    }
}
