package com.google.android.gms.internal;

public interface ard<T> {
    /* renamed from: a */
    void mo1875a(T t);
}
