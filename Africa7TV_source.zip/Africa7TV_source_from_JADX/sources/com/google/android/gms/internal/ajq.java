package com.google.android.gms.internal;

class ajq implements Runnable {
    /* renamed from: a */
    final /* synthetic */ ana f7671a;
    /* renamed from: b */
    final /* synthetic */ ajp f7672b;

    ajq(ajp ajp, ana ana) {
        this.f7672b = ajp;
        this.f7671a = ana;
    }

    public void run() {
        this.f7672b.f7665a.mo1092b(this.f7671a);
    }
}
