package com.google.android.gms.internal;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C1152h;
import com.google.android.gms.common.api.C1223y;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public interface aye {
    /* renamed from: a */
    <A extends C1152h, T extends avy<? extends C1223y, A>> T mo2005a(T t);

    /* renamed from: a */
    void mo2006a();

    /* renamed from: a */
    void mo2007a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    /* renamed from: a */
    boolean mo2008a(ayw ayw);

    /* renamed from: b */
    ConnectionResult mo2009b();

    /* renamed from: c */
    void mo2010c();

    /* renamed from: d */
    boolean mo2011d();

    /* renamed from: f */
    void mo2012f();

    /* renamed from: g */
    void mo2013g();
}
