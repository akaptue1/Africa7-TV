package com.google.android.gms.internal;

abstract class aog extends anm {
    private aog() {
    }

    /* renamed from: b */
    public void mo1148b() {
    }
}
