package com.google.android.gms.internal;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.bd;
import com.google.android.gms.ads.internal.request.AdResponseParcel;
import oauth.signpost.OAuth;

@akw
public class aja implements Runnable {
    /* renamed from: a */
    protected final arh f7625a;
    /* renamed from: b */
    protected boolean f7626b;
    /* renamed from: c */
    protected boolean f7627c;
    /* renamed from: d */
    private final Handler f7628d;
    /* renamed from: e */
    private final long f7629e;
    /* renamed from: f */
    private long f7630f;
    /* renamed from: g */
    private ark f7631g;
    /* renamed from: h */
    private final int f7632h;
    /* renamed from: i */
    private final int f7633i;

    public aja(ark ark, arh arh, int i, int i2) {
        this(ark, arh, i, i2, 200, 50);
    }

    public aja(ark ark, arh arh, int i, int i2, long j, long j2) {
        this.f7629e = j;
        this.f7630f = j2;
        this.f7628d = new Handler(Looper.getMainLooper());
        this.f7625a = arh;
        this.f7631g = ark;
        this.f7626b = false;
        this.f7627c = false;
        this.f7632h = i2;
        this.f7633i = i;
    }

    /* renamed from: c */
    static /* synthetic */ long m11211c(aja aja) {
        long j = aja.f7630f - 1;
        aja.f7630f = j;
        return j;
    }

    /* renamed from: a */
    public void m11216a() {
        this.f7628d.postDelayed(this, this.f7629e);
    }

    /* renamed from: a */
    public void m11217a(AdResponseParcel adResponseParcel) {
        m11218a(adResponseParcel, new zzmo(this, this.f7625a, adResponseParcel.f5577q));
    }

    /* renamed from: a */
    public void m11218a(AdResponseParcel adResponseParcel, zzmo zzmo) {
        this.f7625a.setWebViewClient(zzmo);
        this.f7625a.loadDataWithBaseURL(TextUtils.isEmpty(adResponseParcel.f5562b) ? null : bd.m6644e().m11722a(adResponseParcel.f5562b), adResponseParcel.f5563c, "text/html", OAuth.ENCODING, null);
    }

    /* renamed from: b */
    public synchronized void m11219b() {
        this.f7626b = true;
    }

    /* renamed from: c */
    public synchronized boolean m11220c() {
        return this.f7626b;
    }

    /* renamed from: d */
    public boolean m11221d() {
        return this.f7627c;
    }

    public void run() {
        if (this.f7625a == null || m11220c()) {
            this.f7631g.mo1149a(this.f7625a, true);
        } else {
            new ajb(this, this.f7625a.mo1884a()).execute(new Void[0]);
        }
    }
}
