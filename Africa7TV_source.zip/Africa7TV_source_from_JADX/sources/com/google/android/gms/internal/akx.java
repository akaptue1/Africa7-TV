package com.google.android.gms.internal;

import android.location.Location;
import android.os.Bundle;
import com.google.android.gms.ads.internal.request.AdRequestInfoParcel;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

@akw
public class akx {
    /* renamed from: a */
    public Bundle f7768a;
    /* renamed from: b */
    public Bundle f7769b;
    /* renamed from: c */
    public List<String> f7770c = new ArrayList();
    /* renamed from: d */
    public Location f7771d;
    /* renamed from: e */
    public alw f7772e;
    /* renamed from: f */
    public String f7773f;
    /* renamed from: g */
    public String f7774g;
    /* renamed from: h */
    public AdRequestInfoParcel f7775h;
    /* renamed from: i */
    public alp f7776i;
    /* renamed from: j */
    public JSONObject f7777j = new JSONObject();

    /* renamed from: a */
    public akx m11358a(Location location) {
        this.f7771d = location;
        return this;
    }

    /* renamed from: a */
    public akx m11359a(Bundle bundle) {
        this.f7769b = bundle;
        return this;
    }

    /* renamed from: a */
    public akx m11360a(AdRequestInfoParcel adRequestInfoParcel) {
        this.f7775h = adRequestInfoParcel;
        return this;
    }

    /* renamed from: a */
    public akx m11361a(alp alp) {
        this.f7776i = alp;
        return this;
    }

    /* renamed from: a */
    public akx m11362a(alw alw) {
        this.f7772e = alw;
        return this;
    }

    /* renamed from: a */
    public akx m11363a(String str) {
        this.f7774g = str;
        return this;
    }

    /* renamed from: a */
    public akx m11364a(List<String> list) {
        if (list == null) {
            this.f7770c.clear();
        }
        this.f7770c = list;
        return this;
    }

    /* renamed from: a */
    public akx m11365a(JSONObject jSONObject) {
        this.f7777j = jSONObject;
        return this;
    }

    /* renamed from: b */
    public akx m11366b(Bundle bundle) {
        this.f7768a = bundle;
        return this;
    }

    /* renamed from: b */
    public akx m11367b(String str) {
        this.f7773f = str;
        return this;
    }
}
