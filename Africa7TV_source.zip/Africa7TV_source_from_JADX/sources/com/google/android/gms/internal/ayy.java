package com.google.android.gms.internal;

import android.os.Looper;
import com.google.android.gms.common.api.C1223y;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.Status;

public class ayy extends awe<Status> {
    @Deprecated
    public ayy(Looper looper) {
        super(looper);
    }

    public ayy(C1352q c1352q) {
        super(c1352q);
    }

    /* renamed from: a */
    protected Status m12920a(Status status) {
        return status;
    }

    /* renamed from: b */
    protected /* synthetic */ C1223y mo1416b(Status status) {
        return m12920a(status);
    }
}
