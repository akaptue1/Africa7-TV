package com.google.android.gms.internal;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

class bgt {
    /* renamed from: a */
    private static final ScheduledExecutorService f9185a = Executors.newSingleThreadScheduledExecutor(new bgu());
}
