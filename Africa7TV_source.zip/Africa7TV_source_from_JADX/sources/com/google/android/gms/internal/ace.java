package com.google.android.gms.internal;

class ace implements acy {
    /* renamed from: a */
    final /* synthetic */ acb f7225a;

    ace(acb acb) {
        this.f7225a = acb;
    }

    /* renamed from: a */
    public void mo1696a(acz acz) {
        if (acz.f7253a != null) {
            acz.f7253a.mo1169b();
        }
    }
}
