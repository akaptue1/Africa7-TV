package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.client.ax;

class acn extends ax {
    /* renamed from: a */
    final /* synthetic */ aca f7238a;

    acn(aca aca) {
        this.f7238a = aca;
    }

    /* renamed from: a */
    public void mo1166a() {
        this.f7238a.f7220a.add(new aco(this));
    }
}
