package com.google.android.gms.internal;

import android.net.Uri;
import android.os.IInterface;
import com.google.android.gms.p034a.C0827c;

public interface yo extends IInterface {
    /* renamed from: a */
    C0827c mo1201a();

    /* renamed from: b */
    Uri mo1202b();

    /* renamed from: c */
    double mo1203c();
}
