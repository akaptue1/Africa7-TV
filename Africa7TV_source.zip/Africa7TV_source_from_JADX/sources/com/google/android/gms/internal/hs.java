package com.google.android.gms.internal;

import android.net.Uri;
import android.support.v4.p011f.C0125a;
import com.google.android.gms.common.internal.C1370c;
import com.google.firebase.C1590a;
import com.google.firebase.auth.C1477d;
import com.google.firebase.auth.C1478c;
import com.google.firebase.auth.api.model.GetTokenResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class hs extends C1478c {
    /* renamed from: a */
    private GetTokenResponse f9621a;
    /* renamed from: b */
    private hq f9622b;
    /* renamed from: c */
    private String f9623c;
    /* renamed from: d */
    private String f9624d = "com.google.firebase.auth.internal.DefaultFirebaseUser";
    /* renamed from: e */
    private List<hq> f9625e;
    /* renamed from: f */
    private List<String> f9626f;
    /* renamed from: g */
    private Map<String, hq> f9627g;
    /* renamed from: h */
    private String f9628h = "2";
    /* renamed from: i */
    private boolean f9629i;
    /* renamed from: j */
    private lz f9630j = hb.m13957a();

    public hs(C1590a c1590a, List<? extends C1477d> list) {
        C1370c.m10112a((Object) c1590a);
        this.f9623c = c1590a.m16977b();
        mo2176a((List) list);
    }

    /* renamed from: a */
    public hs m14055a(String str) {
        this.f9628h = str;
        return this;
    }

    /* renamed from: a */
    public hs m14056a(boolean z) {
        this.f9629i = z;
        return this;
    }

    /* renamed from: a */
    public C1478c mo2176a(List<? extends C1477d> list) {
        C1370c.m10112a((Object) list);
        this.f9625e = new ArrayList(list.size());
        this.f9626f = new ArrayList(list.size());
        this.f9627g = new C0125a();
        for (int i = 0; i < list.size(); i++) {
            hq hqVar = new hq((C1477d) list.get(i));
            if (hqVar.mo2171b().equals("firebase")) {
                this.f9622b = hqVar;
            } else {
                this.f9626f.add(hqVar.mo2171b());
            }
            this.f9625e.add(hqVar);
            this.f9627g.put(hqVar.mo2171b(), hqVar);
        }
        if (this.f9622b == null) {
            this.f9622b = (hq) this.f9625e.get(0);
        }
        return this;
    }

    /* renamed from: a */
    public String mo2170a() {
        return this.f9622b.mo2170a();
    }

    /* renamed from: a */
    public void mo2177a(GetTokenResponse getTokenResponse) {
        this.f9621a = (GetTokenResponse) C1370c.m10112a((Object) getTokenResponse);
    }

    /* renamed from: b */
    public /* synthetic */ C1478c mo2178b(boolean z) {
        return m14056a(z);
    }

    /* renamed from: b */
    public String mo2171b() {
        return this.f9622b.mo2171b();
    }

    /* renamed from: c */
    public String mo2172c() {
        return this.f9622b.mo2172c();
    }

    /* renamed from: d */
    public Uri mo2173d() {
        return this.f9622b.mo2173d();
    }

    /* renamed from: e */
    public String mo2174e() {
        return this.f9622b.mo2174e();
    }

    /* renamed from: f */
    public boolean mo2175f() {
        return this.f9622b.mo2175f();
    }

    /* renamed from: g */
    public C1590a m14066g() {
        return C1590a.m16962a(this.f9623c);
    }

    /* renamed from: h */
    public List<hq> m14067h() {
        return this.f9625e;
    }

    /* renamed from: i */
    public boolean mo2179i() {
        return this.f9629i;
    }

    /* renamed from: j */
    public List<? extends C1477d> mo2180j() {
        return this.f9625e;
    }

    /* renamed from: k */
    public GetTokenResponse mo2181k() {
        return this.f9621a;
    }

    /* renamed from: l */
    public String mo2182l() {
        return mo2181k().m16999b();
    }

    /* renamed from: m */
    public String m14072m() {
        return this.f9630j.m14487a(this.f9621a);
    }
}
