package com.google.android.gms.internal;

import com.google.android.gms.analytics.C1133x;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public final class asm extends C1133x<asm> {
    /* renamed from: a */
    private Map<Integer, String> f8368a = new HashMap(4);

    /* renamed from: a */
    public Map<Integer, String> m12191a() {
        return Collections.unmodifiableMap(this.f8368a);
    }

    /* renamed from: a */
    public /* synthetic */ void mo1938a(C1133x c1133x) {
        m12193a((asm) c1133x);
    }

    /* renamed from: a */
    public void m12193a(asm asm) {
        asm.f8368a.putAll(this.f8368a);
    }

    public String toString() {
        Map hashMap = new HashMap();
        for (Entry entry : this.f8368a.entrySet()) {
            String valueOf = String.valueOf(entry.getKey());
            hashMap.put(new StringBuilder(String.valueOf(valueOf).length() + 9).append("dimension").append(valueOf).toString(), entry.getValue());
        }
        return C1133x.m8528a((Object) hashMap);
    }
}
