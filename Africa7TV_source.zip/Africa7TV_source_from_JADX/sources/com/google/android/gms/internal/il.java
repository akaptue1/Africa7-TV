package com.google.android.gms.internal;

class il implements ic {
    /* renamed from: a */
    final /* synthetic */ long f9707a;
    /* renamed from: b */
    final /* synthetic */ ik f9708b;

    il(ik ikVar, long j) {
        this.f9708b = ikVar;
        this.f9707a = j;
    }

    /* renamed from: a */
    public void mo2206a(String str) {
        if (this.f9707a != this.f9708b.f9706b.f9703y) {
            this.f9708b.f9706b.f9700v.m14342a("Ignoring getToken result, because this was not the latest attempt.", new Object[0]);
        } else if (this.f9708b.f9706b.f9688j == it.GettingToken) {
            this.f9708b.f9706b.f9700v.m14342a("Successfully fetched token, opening connection", new Object[0]);
            this.f9708b.f9706b.m14228g(str);
        } else {
            ie.m14121a(this.f9708b.f9706b.f9688j == it.Disconnected, "Expected connection state disconnected, but was %s", this.f9708b.f9706b.f9688j);
            this.f9708b.f9706b.f9700v.m14342a("Not opening connection after token refresh, because connection was set to disconnected", new Object[0]);
        }
    }

    /* renamed from: b */
    public void mo2207b(String str) {
        if (this.f9707a == this.f9708b.f9706b.f9703y) {
            this.f9708b.f9706b.f9688j = it.Disconnected;
            jt a = this.f9708b.f9706b.f9700v;
            String str2 = "Error fetching token: ";
            String valueOf = String.valueOf(str);
            a.m14342a(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), new Object[0]);
            this.f9708b.f9706b.m14185h();
            return;
        }
        this.f9708b.f9706b.f9700v.m14342a("Ignoring getToken error, because this was not the latest attempt.", new Object[0]);
    }
}
