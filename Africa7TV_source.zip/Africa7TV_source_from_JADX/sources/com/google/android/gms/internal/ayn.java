package com.google.android.gms.internal;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

public class ayn {
    /* renamed from: a */
    private final Set<ayl<?>> f8688a = Collections.newSetFromMap(new WeakHashMap());

    /* renamed from: a */
    public void m12904a() {
        for (ayl a : this.f8688a) {
            a.m12903a();
        }
        this.f8688a.clear();
    }
}
