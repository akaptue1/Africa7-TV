package com.google.android.gms.internal;

import android.content.Context;
import android.webkit.WebView;
import com.google.android.gms.ads.internal.util.client.C1043e;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@akw
public class ahz implements ahx {
    /* renamed from: a */
    final Set<WebView> f7600a = Collections.synchronizedSet(new HashSet());
    /* renamed from: b */
    private final Context f7601b;

    public ahz(Context context) {
        this.f7601b = context;
    }

    /* renamed from: a */
    public WebView m11172a() {
        WebView webView = new WebView(this.f7601b);
        webView.getSettings().setJavaScriptEnabled(true);
        return webView;
    }

    /* renamed from: a */
    public void mo1820a(String str, String str2, String str3) {
        C1043e.m7794a("Fetching assets for the given html");
        aoq.f8164a.post(new aia(this, str2, str3));
    }
}
