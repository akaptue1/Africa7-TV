package com.google.android.gms.internal;

public interface amo {
    /* renamed from: a */
    void mo1846a(int i);

    /* renamed from: g */
    void mo1849g();
}
