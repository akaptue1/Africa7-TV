package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.net.TrafficStats;
import android.os.Build.VERSION;
import android.os.Process;
import android.os.SystemClock;
import java.util.concurrent.BlockingQueue;

public class adc extends Thread {
    /* renamed from: a */
    private final BlockingQueue<amb<?>> f7263a;
    /* renamed from: b */
    private final zz f7264b;
    /* renamed from: c */
    private final su f7265c;
    /* renamed from: d */
    private final ass f7266d;
    /* renamed from: e */
    private volatile boolean f7267e = false;

    public adc(BlockingQueue<amb<?>> blockingQueue, zz zzVar, su suVar, ass ass) {
        super("VolleyNetworkDispatcher");
        this.f7263a = blockingQueue;
        this.f7264b = zzVar;
        this.f7265c = suVar;
        this.f7266d = ass;
    }

    @TargetApi(14)
    /* renamed from: a */
    private void m10597a(amb<?> amb) {
        if (VERSION.SDK_INT >= 14) {
            TrafficStats.setThreadStatsTag(amb.m10754b());
        }
    }

    /* renamed from: a */
    private void m10598a(amb<?> amb, awv awv) {
        this.f7266d.mo2319a((amb) amb, amb.m10752a(awv));
    }

    /* renamed from: a */
    public void m10599a() {
        this.f7267e = true;
        interrupt();
    }

    public void run() {
        Process.setThreadPriority(10);
        while (true) {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            try {
                amb amb = (amb) this.f7263a.take();
                try {
                    amb.m10756b("network-queue-take");
                    if (amb.m10761f()) {
                        amb.m10758c("network-discard-cancelled");
                    } else {
                        m10597a(amb);
                        ahu a = this.f7264b.mo2061a(amb);
                        amb.m10756b("network-http-complete");
                        if (a.f7597d && amb.m10775t()) {
                            amb.m10758c("not-modified");
                        } else {
                            arb a2 = amb.mo1719a(a);
                            amb.m10756b("network-parse-complete");
                            if (amb.m10770o() && a2.f8272b != null) {
                                this.f7265c.mo2072a(amb.m10759d(), a2.f8272b);
                                amb.m10756b("network-cache-written");
                            }
                            amb.m10774s();
                            this.f7266d.mo2317a(amb, a2);
                        }
                    }
                } catch (awv e) {
                    e.m10431a(SystemClock.elapsedRealtime() - elapsedRealtime);
                    m10598a(amb, e);
                } catch (Throwable e2) {
                    ayt.m12913a(e2, "Unhandled exception %s", e2.toString());
                    awv awv = new awv(e2);
                    awv.m10431a(SystemClock.elapsedRealtime() - elapsedRealtime);
                    this.f7266d.mo2319a(amb, awv);
                }
            } catch (InterruptedException e3) {
                if (this.f7267e) {
                    return;
                }
            }
        }
    }
}
