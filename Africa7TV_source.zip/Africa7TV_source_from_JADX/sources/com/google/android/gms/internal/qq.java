package com.google.android.gms.internal;

final class qq implements ne {
    /* renamed from: a */
    final /* synthetic */ Class f10201a;
    /* renamed from: b */
    final /* synthetic */ Class f10202b;
    /* renamed from: c */
    final /* synthetic */ nd f10203c;

    qq(Class cls, Class cls2, nd ndVar) {
        this.f10201a = cls;
        this.f10202b = cls2;
        this.f10203c = ndVar;
    }

    /* renamed from: a */
    public <T> nd<T> mo2239a(lz lzVar, rh<T> rhVar) {
        Class a = rhVar.m14946a();
        return (a == this.f10201a || a == this.f10202b) ? this.f10203c : null;
    }

    public String toString() {
        String valueOf = String.valueOf(this.f10201a.getName());
        String valueOf2 = String.valueOf(this.f10202b.getName());
        String valueOf3 = String.valueOf(this.f10203c);
        return new StringBuilder(((String.valueOf(valueOf).length() + 24) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append("Factory[type=").append(valueOf).append("+").append(valueOf2).append(",adapter=").append(valueOf3).append("]").toString();
    }
}
