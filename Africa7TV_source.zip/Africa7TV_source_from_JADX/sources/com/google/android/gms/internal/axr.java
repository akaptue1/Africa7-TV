package com.google.android.gms.internal;

import java.lang.ref.WeakReference;

class axr extends ayc {
    /* renamed from: a */
    private WeakReference<axl> f8619a;

    axr(axl axl) {
        this.f8619a = new WeakReference(axl);
    }

    /* renamed from: a */
    public void mo2004a() {
        axl axl = (axl) this.f8619a.get();
        if (axl != null) {
            axl.m12759s();
        }
    }
}
