package com.google.android.gms.internal;

import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.analytics.C1133x;
import com.google.android.gms.common.internal.C1370c;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class asv extends C1133x<asv> {
    /* renamed from: a */
    private String f8395a;
    /* renamed from: b */
    private int f8396b;
    /* renamed from: c */
    private int f8397c;
    /* renamed from: d */
    private String f8398d;
    /* renamed from: e */
    private String f8399e;
    /* renamed from: f */
    private boolean f8400f;
    /* renamed from: g */
    private boolean f8401g;

    public asv() {
        this(false);
    }

    public asv(boolean z) {
        this(z, m12260a());
    }

    public asv(boolean z, int i) {
        C1370c.m10111a(i);
        this.f8396b = i;
        this.f8401g = z;
    }

    /* renamed from: a */
    static int m12260a() {
        UUID randomUUID = UUID.randomUUID();
        int leastSignificantBits = (int) (randomUUID.getLeastSignificantBits() & 2147483647L);
        if (leastSignificantBits != 0) {
            return leastSignificantBits;
        }
        leastSignificantBits = (int) (randomUUID.getMostSignificantBits() & 2147483647L);
        if (leastSignificantBits != 0) {
            return leastSignificantBits;
        }
        Log.e("GAv4", "UUID.randomUUID() returned 0.");
        return Integer.MAX_VALUE;
    }

    /* renamed from: e */
    private void m12261e() {
    }

    /* renamed from: a */
    public void m12262a(int i) {
        m12261e();
        this.f8396b = i;
    }

    /* renamed from: a */
    public /* synthetic */ void mo1938a(C1133x c1133x) {
        m12264a((asv) c1133x);
    }

    /* renamed from: a */
    public void m12264a(asv asv) {
        if (!TextUtils.isEmpty(this.f8395a)) {
            asv.m12265a(this.f8395a);
        }
        if (this.f8396b != 0) {
            asv.m12262a(this.f8396b);
        }
        if (this.f8397c != 0) {
            asv.m12268b(this.f8397c);
        }
        if (!TextUtils.isEmpty(this.f8398d)) {
            asv.m12269b(this.f8398d);
        }
        if (!TextUtils.isEmpty(this.f8399e)) {
            asv.m12272c(this.f8399e);
        }
        if (this.f8400f) {
            asv.m12270b(this.f8400f);
        }
        if (this.f8401g) {
            asv.m12266a(this.f8401g);
        }
    }

    /* renamed from: a */
    public void m12265a(String str) {
        m12261e();
        this.f8395a = str;
    }

    /* renamed from: a */
    public void m12266a(boolean z) {
        m12261e();
        this.f8401g = z;
    }

    /* renamed from: b */
    public String m12267b() {
        return this.f8395a;
    }

    /* renamed from: b */
    public void m12268b(int i) {
        m12261e();
        this.f8397c = i;
    }

    /* renamed from: b */
    public void m12269b(String str) {
        m12261e();
        this.f8398d = str;
    }

    /* renamed from: b */
    public void m12270b(boolean z) {
        m12261e();
        this.f8400f = z;
    }

    /* renamed from: c */
    public int m12271c() {
        return this.f8396b;
    }

    /* renamed from: c */
    public void m12272c(String str) {
        m12261e();
        if (TextUtils.isEmpty(str)) {
            this.f8399e = null;
        } else {
            this.f8399e = str;
        }
    }

    /* renamed from: d */
    public String m12273d() {
        return this.f8399e;
    }

    public String toString() {
        Map hashMap = new HashMap();
        hashMap.put("screenName", this.f8395a);
        hashMap.put("interstitial", Boolean.valueOf(this.f8400f));
        hashMap.put("automatic", Boolean.valueOf(this.f8401g));
        hashMap.put("screenId", Integer.valueOf(this.f8396b));
        hashMap.put("referrerScreenId", Integer.valueOf(this.f8397c));
        hashMap.put("referrerScreenName", this.f8398d);
        hashMap.put("referrerUri", this.f8399e);
        return C1133x.m8528a((Object) hashMap);
    }
}
