package com.google.android.gms.internal;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.http.AndroidHttpClient;
import android.os.Build.VERSION;
import java.io.File;

public class bg {
    /* renamed from: a */
    public static aoi m13548a(Context context) {
        return m13549a(context, null);
    }

    /* renamed from: a */
    public static aoi m13549a(Context context, bdx bdx) {
        File file = new File(context.getCacheDir(), "volley");
        String str = "volley/0";
        try {
            String packageName = context.getPackageName();
            str = new StringBuilder(String.valueOf(packageName).length() + 12).append(packageName).append("/").append(context.getPackageManager().getPackageInfo(packageName, 0).versionCode).toString();
        } catch (NameNotFoundException e) {
        }
        if (bdx == null) {
            bdx = VERSION.SDK_INT >= 9 ? new bfu() : new bca(AndroidHttpClient.newInstance(str));
        }
        aoi aoi = new aoi(new bbj(file), new bam(bdx));
        aoi.m11687a();
        return aoi;
    }
}
