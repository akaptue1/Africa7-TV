package com.google.android.gms.internal;

@akw
public class aqh<T> {
    /* renamed from: a */
    private T f8245a;

    /* renamed from: a */
    public T m11900a() {
        return this.f8245a;
    }

    /* renamed from: a */
    public void m11901a(T t) {
        this.f8245a = t;
    }
}
