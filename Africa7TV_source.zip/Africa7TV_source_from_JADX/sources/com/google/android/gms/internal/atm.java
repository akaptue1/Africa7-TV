package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.android.gms.auth.api.proxy.ProxyGrpcRequest;
import com.google.android.gms.auth.api.proxy.ProxyRequest;

public interface atm extends IInterface {
    /* renamed from: a */
    void mo1944a(ati ati);

    /* renamed from: a */
    void mo1945a(ati ati, ProxyGrpcRequest proxyGrpcRequest);

    /* renamed from: a */
    void mo1946a(ati ati, ProxyRequest proxyRequest);
}
