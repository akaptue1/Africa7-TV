package com.google.android.gms.internal;

import android.os.Bundle;
import com.google.android.gms.tagmanager.C1467o;

class bfy extends C1467o {
    /* renamed from: a */
    final /* synthetic */ bfw f9141a;

    bfy(bfw bfw) {
        this.f9141a = bfw;
    }

    /* renamed from: a */
    public void mo2123a(String str, String str2, Bundle bundle, long j) {
        this.f9141a.f9130g.submit(new bfz(this, str2, bundle, new StringBuilder(String.valueOf(str).length() + 4).append(str).append("+").append("gtm").toString(), j, str));
    }
}
