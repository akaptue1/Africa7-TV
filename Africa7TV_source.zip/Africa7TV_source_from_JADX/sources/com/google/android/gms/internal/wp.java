package com.google.android.gms.internal;

import java.util.Comparator;

class wp implements Comparator<wu> {
    /* renamed from: a */
    final /* synthetic */ wo f10620a;

    wp(wo woVar) {
        this.f10620a = woVar;
    }

    /* renamed from: a */
    public int m15560a(wu wuVar, wu wuVar2) {
        int i = wuVar.f10626c - wuVar2.f10626c;
        return i != 0 ? i : (int) (wuVar.f10624a - wuVar2.f10624a);
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return m15560a((wu) obj, (wu) obj2);
    }
}
