package com.google.android.gms.internal;

class aka implements Runnable {
    /* renamed from: a */
    final /* synthetic */ aqk f7709a;
    /* renamed from: b */
    final /* synthetic */ String f7710b;
    /* renamed from: c */
    final /* synthetic */ ajx f7711c;

    aka(ajx ajx, aqk aqk, String str) {
        this.f7711c = ajx;
        this.f7709a = aqk;
        this.f7710b = str;
    }

    public void run() {
        this.f7709a.m10666b((zs) this.f7711c.f7693d.m6556F().get(this.f7710b));
    }
}
