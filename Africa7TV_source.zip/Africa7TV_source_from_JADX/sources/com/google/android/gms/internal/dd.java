package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.common.internal.C1370c;

public class dd extends bhd {
    /* renamed from: a */
    private final Context f9233a;
    /* renamed from: b */
    private final bfd f9234b;

    public dd(Context context, bfd bfd) {
        this.f9233a = context;
        this.f9234b = bfd;
    }

    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        C1370c.m10120b(gbVarArr != null);
        C1370c.m10120b(gbVarArr.length >= 1);
        Object obj = this.f9234b.mo2110a().m13342g().get(bhc.m13596d(gbVarArr[0]));
        if (obj == null && gbVarArr.length > 1) {
            obj = gbVarArr[1];
        }
        return gp.m13915a(obj);
    }
}
