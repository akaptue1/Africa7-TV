package com.google.android.gms.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C1370c;
import java.util.ArrayList;
import java.util.List;

class bdo implements eh, Runnable {
    /* renamed from: a */
    final /* synthetic */ bdk f8983a;

    private bdo(bdk bdk) {
        this.f8983a = bdk;
    }

    /* renamed from: a */
    public void mo2086a(ep epVar) {
        if (epVar.mo1546e() == Status.f6824a) {
            this.f8983a.f8970f.execute(new bdr(this.f8983a, epVar));
        } else {
            this.f8983a.f8970f.execute(new bdn(this.f8983a));
        }
    }

    public void run() {
        C1370c.m10116a(this.f8983a.f8976l == 1);
        List arrayList = new ArrayList();
        this.f8983a.f8979o = false;
        if (bew.m13429a().m13430a(this.f8983a.f8965a)) {
            arrayList.add(Integer.valueOf(0));
        } else {
            this.f8983a.f8979o = this.f8983a.f8974j.m13308d();
            if (this.f8983a.f8979o) {
                arrayList.add(Integer.valueOf(1));
                arrayList.add(Integer.valueOf(0));
            } else {
                arrayList.add(Integer.valueOf(0));
                arrayList.add(Integer.valueOf(1));
            }
            arrayList.add(Integer.valueOf(2));
        }
        this.f8983a.f8969e.m13738a(this.f8983a.f8965a, this.f8983a.f8967c, this.f8983a.f8966b, arrayList, this, this.f8983a.f8974j);
    }
}
