package com.google.android.gms.internal;

import android.content.Context;
import java.io.InputStream;

class es implements ew {
    /* renamed from: a */
    final /* synthetic */ Context f9306a;

    es(Context context) {
        this.f9306a = context;
    }

    /* renamed from: a */
    public InputStream mo2130a(String str) {
        return this.f9306a.getAssets().open(str);
    }
}
