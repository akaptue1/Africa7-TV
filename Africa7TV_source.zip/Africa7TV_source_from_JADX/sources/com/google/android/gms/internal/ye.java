package com.google.android.gms.internal;

import com.google.android.gms.ads.doubleclick.C0846b;

@akw
public class ye implements C0846b {
    /* renamed from: a */
    private final yf f10745a;

    public ye(yf yfVar) {
        this.f10745a = yfVar;
    }
}
