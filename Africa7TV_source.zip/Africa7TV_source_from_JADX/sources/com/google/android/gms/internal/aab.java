package com.google.android.gms.internal;

@akw
public class aab implements abx {
    /* renamed from: a */
    public abs mo1691a(arh arh, int i, String str) {
        return new aby(arh);
    }
}
