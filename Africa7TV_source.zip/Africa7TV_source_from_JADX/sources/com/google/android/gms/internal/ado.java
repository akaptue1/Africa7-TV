package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.C0941m;
import com.google.android.gms.ads.internal.C0942n;
import com.google.android.gms.ads.internal.bd;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.client.C0812a;
import com.google.android.gms.ads.internal.client.at;
import com.google.android.gms.ads.internal.overlay.C0862w;
import com.google.android.gms.ads.internal.overlay.ae;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import org.json.JSONObject;

@akw
public class ado implements adi {
    /* renamed from: a */
    private final arh f7306a;

    public ado(Context context, VersionInfoParcel versionInfoParcel, so soVar, C0941m c0941m) {
        this.f7306a = bd.m6645f().m11995a(context, new AdSizeParcel(), false, false, soVar, versionInfoParcel, null, null, c0941m);
        this.f7306a.mo1884a().setWillNotDraw(true);
    }

    /* renamed from: a */
    private void m10669a(Runnable runnable) {
        if (at.m6849a().m7787b()) {
            runnable.run();
        } else {
            aoq.f8164a.post(runnable);
        }
    }

    /* renamed from: a */
    public void mo1701a() {
        this.f7306a.destroy();
    }

    /* renamed from: a */
    public void mo1702a(C0812a c0812a, C0862w c0862w, aaa aaa, ae aeVar, boolean z, abc abc, abe abe, C0942n c0942n, ahm ahm) {
        this.f7306a.mo1913l().zza(c0812a, c0862w, aaa, aeVar, z, abc, abe, new C0942n(this.f7306a.getContext(), false), ahm, null);
    }

    /* renamed from: a */
    public void mo1703a(adj adj) {
        this.f7306a.mo1913l().zza(new adu(this, adj));
    }

    /* renamed from: a */
    public void mo1704a(String str) {
        m10669a(new adr(this, String.format("<!DOCTYPE html><html><head><script src=\"%s\"></script></head><body></body></html>", new Object[]{str})));
    }

    /* renamed from: a */
    public void mo1705a(String str, aau aau) {
        this.f7306a.mo1913l().zza(str, aau);
    }

    /* renamed from: a */
    public void mo1706a(String str, String str2) {
        m10669a(new adq(this, str, str2));
    }

    /* renamed from: a */
    public void mo1707a(String str, JSONObject jSONObject) {
        m10669a(new adp(this, str, jSONObject));
    }

    /* renamed from: b */
    public aet mo1708b() {
        return new aeu(this);
    }

    /* renamed from: b */
    public void mo1709b(String str) {
        m10669a(new adt(this, str));
    }

    /* renamed from: b */
    public void mo1710b(String str, aau aau) {
        this.f7306a.mo1913l().zzb(str, aau);
    }

    /* renamed from: b */
    public void mo1711b(String str, JSONObject jSONObject) {
        this.f7306a.mo1711b(str, jSONObject);
    }

    /* renamed from: c */
    public void mo1712c(String str) {
        m10669a(new ads(this, str));
    }
}
