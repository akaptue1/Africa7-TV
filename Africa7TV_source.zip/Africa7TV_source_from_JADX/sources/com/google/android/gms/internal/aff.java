package com.google.android.gms.internal;

final class aff extends aga {
    /* renamed from: a */
    final /* synthetic */ int f7443a;

    aff(int i) {
        this.f7443a = i;
    }

    /* renamed from: a */
    public int mo1732a() {
        return this.f7443a;
    }
}
