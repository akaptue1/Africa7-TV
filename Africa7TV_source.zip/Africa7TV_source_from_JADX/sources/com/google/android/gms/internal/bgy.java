package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class bgy {
    /* renamed from: a */
    private static final Map<String, bgz> f9194a;

    static {
        Map hashMap = new HashMap();
        hashMap.put(gq.CONTAINS.toString(), new bgz("contains"));
        hashMap.put(gq.ENDS_WITH.toString(), new bgz("endsWith"));
        hashMap.put(gq.EQUALS.toString(), new bgz("equals"));
        hashMap.put(gq.GREATER_EQUALS.toString(), new bgz("greaterEquals"));
        hashMap.put(gq.GREATER_THAN.toString(), new bgz("greaterThan"));
        hashMap.put(gq.LESS_EQUALS.toString(), new bgz("lessEquals"));
        hashMap.put(gq.LESS_THAN.toString(), new bgz("lessThan"));
        hashMap.put(gq.REGEX.toString(), new bgz("regex", new String[]{gv.ARG0.toString(), gv.ARG1.toString(), gv.IGNORE_CASE.toString()}));
        hashMap.put(gq.STARTS_WITH.toString(), new bgz("startsWith"));
        f9194a = hashMap;
    }

    /* renamed from: a */
    public static gm m13580a(String str, Map<String, gb<?>> map, bff bff) {
        if (f9194a.containsKey(str)) {
            bgz bgz = (bgz) f9194a.get(str);
            List a = m13583a(bgz.m13585b(), map);
            List arrayList = new ArrayList();
            arrayList.add(new gn("gtmUtils"));
            gm gmVar = new gm("15", arrayList);
            arrayList = new ArrayList();
            arrayList.add(gmVar);
            arrayList.add(new gn("mobile"));
            gmVar = new gm("17", arrayList);
            arrayList = new ArrayList();
            arrayList.add(gmVar);
            arrayList.add(new gn(bgz.m13584a()));
            arrayList.add(new gi(a));
            return new gm("2", arrayList);
        }
        throw new RuntimeException(new StringBuilder(String.valueOf(str).length() + 47).append("Fail to convert ").append(str).append(" to the internal representation").toString());
    }

    /* renamed from: a */
    public static String m13581a(gq gqVar) {
        return m13582a(gqVar.toString());
    }

    /* renamed from: a */
    public static String m13582a(String str) {
        return f9194a.containsKey(str) ? ((bgz) f9194a.get(str)).m13584a() : null;
    }

    /* renamed from: a */
    private static List<gb<?>> m13583a(String[] strArr, Map<String, gb<?>> map) {
        List<gb<?>> arrayList = new ArrayList();
        for (int i = 0; i < strArr.length; i++) {
            if (map.containsKey(strArr[i])) {
                arrayList.add((gb) map.get(strArr[i]));
            } else {
                arrayList.add(gh.f9460e);
            }
        }
        return arrayList;
    }
}
