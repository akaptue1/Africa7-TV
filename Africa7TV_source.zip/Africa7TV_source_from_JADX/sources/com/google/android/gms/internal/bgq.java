package com.google.android.gms.internal;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;

class bgq {
    /* renamed from: a */
    static ExecutorService m13563a() {
        return bgr.f9184a;
    }

    /* renamed from: b */
    static ScheduledExecutorService m13564b() {
        return bgt.f9185a;
    }
}
