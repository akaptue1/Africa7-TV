package com.google.android.gms.internal;

class kg implements Runnable {
    /* renamed from: a */
    final /* synthetic */ ke f9828a;

    kg(ke keVar) {
        this.f9828a = keVar;
    }

    public void run() {
        this.f9828a.m14367l();
    }
}
