package com.google.android.gms.internal;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.gms.common.internal.C1370c;

public class cf implements bhb {
    /* renamed from: a */
    private Context f9211a;

    public cf(Context context) {
        this.f9211a = context;
    }

    public gb<?> a_(bff bff, gb<?>... gbVarArr) {
        boolean z = true;
        C1370c.m10120b(gbVarArr != null);
        if (gbVarArr.length != 0) {
            z = false;
        }
        C1370c.m10120b(z);
        try {
            PackageManager packageManager = this.f9211a.getPackageManager();
            return new gn(packageManager.getApplicationLabel(packageManager.getApplicationInfo(this.f9211a.getPackageName(), 0)).toString());
        } catch (NameNotFoundException e) {
            return new gn("");
        }
    }
}
