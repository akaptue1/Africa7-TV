package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.bd;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.util.client.C1039a;
import com.google.android.gms.ads.internal.util.client.C1043e;

@akw
public class ami extends anm implements amo, amr {
    /* renamed from: a */
    private final anb f7952a;
    /* renamed from: b */
    private final Context f7953b;
    /* renamed from: c */
    private final amv f7954c;
    /* renamed from: d */
    private final amr f7955d;
    /* renamed from: e */
    private final Object f7956e;
    /* renamed from: f */
    private final String f7957f;
    /* renamed from: g */
    private final String f7958g;
    /* renamed from: h */
    private final aez f7959h;
    /* renamed from: i */
    private final long f7960i;
    /* renamed from: j */
    private int f7961j = 0;
    /* renamed from: k */
    private int f7962k = 3;
    /* renamed from: l */
    private aml f7963l;

    public ami(Context context, String str, String str2, aez aez, anb anb, amv amv, amr amr, long j) {
        this.f7953b = context;
        this.f7957f = str;
        this.f7958g = str2;
        this.f7959h = aez;
        this.f7952a = anb;
        this.f7954c = amv;
        this.f7956e = new Object();
        this.f7955d = amr;
        this.f7960i = j;
    }

    /* renamed from: a */
    private void m11520a(AdRequestParcel adRequestParcel, aft aft) {
        this.f7954c.m11569b().m11547a((amr) this);
        try {
            if ("com.google.ads.mediation.admob.AdMobAdapter".equals(this.f7957f)) {
                aft.mo1747a(adRequestParcel, this.f7958g, this.f7959h.f7375a);
            } else {
                aft.mo1746a(adRequestParcel, this.f7958g);
            }
        } catch (Throwable e) {
            C1043e.m7800c("Fail to load ad from adapter.", e);
            mo1848a(this.f7957f, 0);
        }
    }

    /* renamed from: b */
    private void m11523b(long j) {
        while (true) {
            synchronized (this.f7956e) {
                if (this.f7961j != 0) {
                    break;
                } else if (!m11529a(j)) {
                    this.f7963l = new amn().m11539a(this.f7962k).m11540a(bd.m6650k().mo1681b() - j).m11541a(this.f7957f).m11542b(this.f7959h.f7378d).m11538a();
                    return;
                }
            }
        }
        this.f7963l = new amn().m11540a(bd.m6650k().mo1681b() - j).m11539a(1 == this.f7961j ? 6 : this.f7962k).m11541a(this.f7957f).m11542b(this.f7959h.f7378d).m11538a();
    }

    /* renamed from: a */
    public void mo1147a() {
        if (this.f7954c != null && this.f7954c.m11569b() != null && this.f7954c.m11568a() != null) {
            amq b = this.f7954c.m11569b();
            b.m11547a(null);
            b.m11546a((amo) this);
            AdRequestParcel adRequestParcel = this.f7952a.f8033a.f5521c;
            aft a = this.f7954c.m11568a();
            try {
                if (a.mo1753g()) {
                    C1039a.f5725a.post(new amj(this, adRequestParcel, a));
                } else {
                    C1039a.f5725a.post(new amk(this, a, adRequestParcel, b));
                }
            } catch (Throwable e) {
                C1043e.m7800c("Fail to check if adapter is initialized.", e);
                mo1848a(this.f7957f, 0);
            }
            m11523b(bd.m6650k().mo1681b());
            b.m11547a(null);
            b.m11546a(null);
            if (this.f7961j == 1) {
                this.f7955d.mo1847a(this.f7957f);
            } else {
                this.f7955d.mo1848a(this.f7957f, this.f7962k);
            }
        }
    }

    /* renamed from: a */
    public void mo1846a(int i) {
        mo1848a(this.f7957f, 0);
    }

    /* renamed from: a */
    public void mo1847a(String str) {
        synchronized (this.f7956e) {
            this.f7961j = 1;
            this.f7956e.notify();
        }
    }

    /* renamed from: a */
    public void mo1848a(String str, int i) {
        synchronized (this.f7956e) {
            this.f7961j = 2;
            this.f7962k = i;
            this.f7956e.notify();
        }
    }

    /* renamed from: a */
    protected boolean m11529a(long j) {
        long b = this.f7960i - (bd.m6650k().mo1681b() - j);
        if (b <= 0) {
            this.f7962k = 4;
            return false;
        }
        try {
            this.f7956e.wait(b);
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            this.f7962k = 5;
            return false;
        }
    }

    /* renamed from: b */
    public void mo1148b() {
    }

    /* renamed from: c */
    public aml m11531c() {
        aml aml;
        synchronized (this.f7956e) {
            aml = this.f7963l;
        }
        return aml;
    }

    /* renamed from: f */
    public aez m11532f() {
        return this.f7959h;
    }

    /* renamed from: g */
    public void mo1849g() {
        m11520a(this.f7952a.f8033a.f5521c, this.f7954c.m11568a());
    }
}
