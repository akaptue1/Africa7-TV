package com.google.android.gms.internal;

class awx extends axu {
    /* renamed from: a */
    final /* synthetic */ aww f8541a;

    awx(aww aww, axs axs) {
        this.f8541a = aww;
        super(axs);
    }

    /* renamed from: a */
    public void mo2034a() {
        this.f8541a.mo2029a(1);
    }
}
