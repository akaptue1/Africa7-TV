package com.google.android.gms.internal;

import com.facebook.AppEventsConstants;
import com.google.android.gms.ads.internal.util.client.C1043e;
import java.util.Map;

@akw
public class abd implements aau {
    /* renamed from: a */
    private final abe f7176a;

    public abd(abe abe) {
        this.f7176a = abe;
    }

    /* renamed from: a */
    public void mo1150a(arh arh, Map<String, String> map) {
        float parseFloat;
        boolean equals = AppEventsConstants.EVENT_PARAM_VALUE_YES.equals(map.get("transparentBackground"));
        boolean equals2 = AppEventsConstants.EVENT_PARAM_VALUE_YES.equals(map.get("blur"));
        try {
            if (map.get("blurRadius") != null) {
                parseFloat = Float.parseFloat((String) map.get("blurRadius"));
                this.f7176a.mo1141b(equals);
                this.f7176a.mo1138a(equals2, parseFloat);
            }
        } catch (Throwable e) {
            C1043e.m7798b("Fail to parse float", e);
        }
        parseFloat = 0.0f;
        this.f7176a.mo1141b(equals);
        this.f7176a.mo1138a(equals2, parseFloat);
    }
}
