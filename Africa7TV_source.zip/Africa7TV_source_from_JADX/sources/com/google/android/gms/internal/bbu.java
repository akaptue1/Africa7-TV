package com.google.android.gms.internal;

import android.content.Context;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags.ModuleDescriptor;
import com.google.android.gms.p034a.C0830f;

public class bbu {
    /* renamed from: a */
    private boolean f8809a = false;
    /* renamed from: b */
    private bbv f8810b = null;

    /* renamed from: a */
    public <T> T m13116a(bbn<T> bbn) {
        synchronized (this) {
            if (this.f8809a) {
                return bbn.mo2073a(this.f8810b);
            }
            T b = bbn.m13103b();
            return b;
        }
    }

    /* renamed from: a */
    public void m13117a(Context context) {
        Throwable e;
        synchronized (this) {
            if (this.f8809a) {
                return;
            }
            try {
                this.f8810b = bbw.asInterface(ban.m13026a(context, ban.f8768a, ModuleDescriptor.MODULE_ID).m13037a("com.google.android.gms.flags.impl.FlagProviderImpl"));
                this.f8810b.init(C0830f.m6210a((Object) context));
                this.f8809a = true;
            } catch (bax e2) {
                e = e2;
                Log.w("FlagValueProvider", "Failed to initialize flags module.", e);
            } catch (RemoteException e3) {
                e = e3;
                Log.w("FlagValueProvider", "Failed to initialize flags module.", e);
            }
        }
    }
}
