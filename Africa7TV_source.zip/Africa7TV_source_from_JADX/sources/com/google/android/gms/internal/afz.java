package com.google.android.gms.internal;

import android.os.IInterface;

public interface afz extends IInterface {
    /* renamed from: a */
    int mo1732a();
}
