package com.google.android.gms.internal;

class vm implements Runnable {
    /* renamed from: a */
    final /* synthetic */ vl f10514a;

    vm(vl vlVar) {
        this.f10514a = vlVar;
    }

    public void run() {
        this.f10514a.m15477a(3);
    }
}
