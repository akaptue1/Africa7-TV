package com.google.android.gms.internal;

class tx implements Runnable {
    /* renamed from: a */
    final /* synthetic */ tw f10420a;

    tx(tw twVar) {
        this.f10420a = twVar;
    }

    public void run() {
        this.f10420a.m15315b();
    }
}
