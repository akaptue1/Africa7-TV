package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.util.client.C1039a;
import com.google.android.gms.ads.internal.util.client.C1043e;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.Future;
import org.json.JSONObject;

@akw
public class ams extends anm implements amr {
    /* renamed from: a */
    private final anb f7982a;
    /* renamed from: b */
    private final Context f7983b;
    /* renamed from: c */
    private final ArrayList<Future> f7984c;
    /* renamed from: d */
    private final ArrayList<String> f7985d;
    /* renamed from: e */
    private final HashMap<String, ami> f7986e;
    /* renamed from: f */
    private final List<aml> f7987f;
    /* renamed from: g */
    private final HashSet<String> f7988g;
    /* renamed from: h */
    private final Object f7989h;
    /* renamed from: i */
    private final amf f7990i;
    /* renamed from: j */
    private final long f7991j;

    public ams(Context context, anb anb, amf amf) {
        this(context, anb, amf, ((Long) xm.aC.m15604c()).longValue());
    }

    ams(Context context, anb anb, amf amf, long j) {
        this.f7984c = new ArrayList();
        this.f7985d = new ArrayList();
        this.f7986e = new HashMap();
        this.f7987f = new ArrayList();
        this.f7988g = new HashSet();
        this.f7989h = new Object();
        this.f7983b = context;
        this.f7982a = anb;
        this.f7990i = amf;
        this.f7991j = j;
    }

    /* renamed from: a */
    private static int m11555a(int i) {
        switch (i) {
            case 3:
                return 1;
            case 4:
                return 2;
            case 5:
                return 4;
            case 6:
                return 0;
            case 7:
                return 3;
            default:
                return 6;
        }
    }

    /* renamed from: a */
    private ana m11557a(int i, String str, aez aez) {
        return new ana(this.f7982a.f8033a.f5521c, null, this.f7982a.f8034b.f5564d, i, this.f7982a.f8034b.f5566f, this.f7982a.f8034b.f5570j, this.f7982a.f8034b.f5572l, this.f7982a.f8034b.f5571k, this.f7982a.f8033a.f5527i, this.f7982a.f8034b.f5568h, aez, null, str, this.f7982a.f8035c, null, this.f7982a.f8034b.f5569i, this.f7982a.f8036d, this.f7982a.f8034b.f5567g, this.f7982a.f8038f, this.f7982a.f8034b.f5574n, this.f7982a.f8034b.f5575o, this.f7982a.f8040h, null, this.f7982a.f8034b.f5547C, this.f7982a.f8034b.f5548D, this.f7982a.f8034b.f5549E, this.f7982a.f8034b.f5550F, this.f7982a.f8034b.f5551G, m11562f(), this.f7982a.f8034b.f5554J, this.f7982a.f8034b.f5558N);
    }

    /* renamed from: a */
    private ana m11558a(String str, aez aez) {
        return m11557a(-2, str, aez);
    }

    /* renamed from: a */
    private static String m11559a(aml aml) {
        String str = aml.f7972b;
        int a = m11555a(aml.f7973c);
        return new StringBuilder(String.valueOf(str).length() + 33).append(str).append(".").append(a).append(".").append(aml.f7974d).toString();
    }

    /* renamed from: a */
    private void m11560a(String str, String str2, aez aez) {
        synchronized (this.f7989h) {
            amv c = this.f7990i.m11513c(str);
            if (c == null || c.m11569b() == null || c.m11568a() == null) {
                this.f7987f.add(new amn().m11542b(aez.f7378d).m11541a(str).m11540a(0).m11539a(7).m11538a());
                return;
            }
            anm a = m11563a(str, str2, aez, c);
            this.f7984c.add((Future) a.mo1146e());
            this.f7985d.add(str);
            this.f7986e.put(str, a);
        }
    }

    /* renamed from: c */
    private ana m11561c() {
        return m11557a(3, null, null);
    }

    /* renamed from: f */
    private String m11562f() {
        StringBuilder stringBuilder = new StringBuilder("");
        if (this.f7987f == null) {
            return stringBuilder.toString();
        }
        for (aml aml : this.f7987f) {
            if (!(aml == null || TextUtils.isEmpty(aml.f7972b))) {
                stringBuilder.append(String.valueOf(m11559a(aml)).concat("_"));
            }
        }
        return stringBuilder.substring(0, Math.max(0, stringBuilder.length() - 1));
    }

    /* renamed from: a */
    protected ami m11563a(String str, String str2, aez aez, amv amv) {
        return new ami(this.f7983b, str, str2, aez, this.f7982a, amv, this, this.f7991j);
    }

    /* renamed from: a */
    public void mo1147a() {
        ami ami;
        for (aez aez : this.f7982a.f8035c.f7405a) {
            String str = aez.f7383i;
            for (String str2 : aez.f7377c) {
                String str22;
                if ("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter".equals(str22) || "com.google.ads.mediation.customevent.CustomEventAdapter".equals(str22)) {
                    try {
                        str22 = new JSONObject(str).getString("class_name");
                    } catch (Throwable e) {
                        C1043e.m7798b("Unable to determine custom event class name, skipping...", e);
                    }
                }
                m11560a(str22, str, aez);
            }
        }
        int i = 0;
        while (i < this.f7984c.size()) {
            String str3;
            try {
                ((Future) this.f7984c.get(i)).get();
                synchronized (this.f7989h) {
                    str3 = (String) this.f7985d.get(i);
                    if (!TextUtils.isEmpty(str3)) {
                        ami = (ami) this.f7986e.get(str3);
                        if (ami != null) {
                            this.f7987f.add(ami.m11531c());
                        }
                    }
                }
                synchronized (this.f7989h) {
                    if (this.f7988g.contains(this.f7985d.get(i))) {
                        str3 = (String) this.f7985d.get(i);
                        C1039a.f5725a.post(new amt(this, m11558a(str3, this.f7986e.get(str3) != null ? ((ami) this.f7986e.get(str3)).m11532f() : null)));
                        return;
                    }
                }
            } catch (InterruptedException e2) {
                Thread.currentThread().interrupt();
                synchronized (this.f7989h) {
                    str3 = (String) this.f7985d.get(i);
                    if (!TextUtils.isEmpty(str3)) {
                        ami = (ami) this.f7986e.get(str3);
                        if (ami != null) {
                            this.f7987f.add(ami.m11531c());
                        }
                    }
                }
            } catch (Throwable e3) {
                C1043e.m7800c("Unable to resolve rewarded adapter.", e3);
                synchronized (this.f7989h) {
                    str3 = (String) this.f7985d.get(i);
                    if (!TextUtils.isEmpty(str3)) {
                        ami = (ami) this.f7986e.get(str3);
                        if (ami != null) {
                            this.f7987f.add(ami.m11531c());
                        }
                    }
                }
            } catch (Throwable e32) {
                Throwable th = e32;
                synchronized (this.f7989h) {
                    str3 = (String) this.f7985d.get(i);
                    if (!TextUtils.isEmpty(str3)) {
                        ami = (ami) this.f7986e.get(str3);
                        if (ami != null) {
                            this.f7987f.add(ami.m11531c());
                        }
                    }
                }
            }
        }
        C1039a.f5725a.post(new amu(this, m11561c()));
        return;
        i++;
    }

    /* renamed from: a */
    public void mo1847a(String str) {
        synchronized (this.f7989h) {
            this.f7988g.add(str);
        }
    }

    /* renamed from: a */
    public void mo1848a(String str, int i) {
    }

    /* renamed from: b */
    public void mo1148b() {
    }
}
