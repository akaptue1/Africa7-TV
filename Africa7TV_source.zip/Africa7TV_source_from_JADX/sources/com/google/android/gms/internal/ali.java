package com.google.android.gms.internal;

import java.util.concurrent.Future;

@akw
public final class ali {
    /* renamed from: a */
    aei f7816a;
    /* renamed from: b */
    public final aau f7817b = new alj(this);
    /* renamed from: c */
    public final aau f7818c = new alk(this);
    /* renamed from: d */
    public final aau f7819d = new all(this);
    /* renamed from: e */
    private final Object f7820e = new Object();
    /* renamed from: f */
    private String f7821f;
    /* renamed from: g */
    private String f7822g;
    /* renamed from: h */
    private aqk<alo> f7823h = new aqk();

    public ali(String str, String str2) {
        this.f7822g = str2;
        this.f7821f = str;
    }

    /* renamed from: a */
    public aei m11403a() {
        return this.f7816a;
    }

    /* renamed from: a */
    public void m11404a(aei aei) {
        this.f7816a = aei;
    }

    /* renamed from: b */
    public Future<alo> m11405b() {
        return this.f7823h;
    }

    /* renamed from: c */
    public void m11406c() {
    }
}
