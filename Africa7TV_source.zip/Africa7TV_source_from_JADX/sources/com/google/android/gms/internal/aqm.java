package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@akw
public class aqm {
    /* renamed from: a */
    public static <A, B> aqq<B> m11911a(aqq<A> aqq, aqp<A, B> aqp) {
        aqq aqk = new aqk();
        aqq.mo1700a(new aqn(aqk, aqp, aqq));
        return aqk;
    }

    /* renamed from: a */
    public static <V> aqq<List<V>> m11912a(List<aqq<V>> list) {
        aqq aqk = new aqk();
        int size = list.size();
        AtomicInteger atomicInteger = new AtomicInteger(0);
        for (aqq a : list) {
            a.mo1700a(new aqo(atomicInteger, size, aqk, list));
        }
        return aqk;
    }

    /* renamed from: c */
    private static <V> List<V> m11914c(List<aqq<V>> list) {
        List<V> arrayList = new ArrayList();
        for (aqq aqq : list) {
            Object obj = aqq.get();
            if (obj != null) {
                arrayList.add(obj);
            }
        }
        return arrayList;
    }
}
