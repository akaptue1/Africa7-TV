package com.google.android.gms.internal;

import java.util.BitSet;

final class qc extends nd<BitSet> {
    qc() {
    }

    /* renamed from: a */
    public BitSet m14843a(ri riVar) {
        String valueOf;
        if (riVar.mo2248f() == rk.NULL) {
            riVar.mo2252j();
            return null;
        }
        BitSet bitSet = new BitSet();
        riVar.mo2242a();
        rk f = riVar.mo2248f();
        int i = 0;
        while (f != rk.END_ARRAY) {
            boolean z;
            switch (qs.f10206a[f.ordinal()]) {
                case 1:
                    if (riVar.mo2255m() == 0) {
                        z = false;
                        break;
                    }
                    z = true;
                    break;
                case 2:
                    z = riVar.mo2251i();
                    break;
                case 3:
                    Object h = riVar.mo2250h();
                    try {
                        if (Integer.parseInt(h) == 0) {
                            z = false;
                            break;
                        }
                        z = true;
                        break;
                    } catch (NumberFormatException e) {
                        String str = "Error: Expecting: bitset number value (1, 0), Found: ";
                        valueOf = String.valueOf(h);
                        throw new mw(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
                    }
                default:
                    valueOf = String.valueOf(f);
                    throw new mw(new StringBuilder(String.valueOf(valueOf).length() + 27).append("Invalid bitset value type: ").append(valueOf).toString());
            }
            if (z) {
                bitSet.set(i);
            }
            i++;
            f = riVar.mo2248f();
        }
        riVar.mo2243b();
        return bitSet;
    }

    /* renamed from: a */
    public void m14845a(rl rlVar, BitSet bitSet) {
        if (bitSet == null) {
            rlVar.mo2270f();
            return;
        }
        rlVar.mo2264b();
        for (int i = 0; i < bitSet.length(); i++) {
            rlVar.mo2260a((long) (bitSet.get(i) ? 1 : 0));
        }
        rlVar.mo2266c();
    }

    /* renamed from: b */
    public /* synthetic */ Object mo2144b(ri riVar) {
        return m14843a(riVar);
    }
}
