package com.google.android.gms.internal;

import android.content.Intent;
import android.os.IInterface;

public interface aih extends IInterface {
    /* renamed from: a */
    void mo1298a();

    /* renamed from: a */
    void mo1299a(int i, int i2, Intent intent);

    /* renamed from: b */
    void mo1300b();
}
