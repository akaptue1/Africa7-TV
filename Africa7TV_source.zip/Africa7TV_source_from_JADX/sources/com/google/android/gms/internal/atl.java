package com.google.android.gms.internal;

public interface atl {
    /* renamed from: a */
    int mo2310a();

    /* renamed from: a */
    void mo2311a(awv awv);

    /* renamed from: b */
    int mo2312b();
}
