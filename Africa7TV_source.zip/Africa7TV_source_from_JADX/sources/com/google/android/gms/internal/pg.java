package com.google.android.gms.internal;

import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

public final class pg extends ri {
    /* renamed from: a */
    private static final Reader f10099a = new ph();
    /* renamed from: b */
    private static final Object f10100b = new Object();
    /* renamed from: c */
    private final List<Object> f10101c = new ArrayList();

    public pg(ml mlVar) {
        super(f10099a);
        this.f10101c.add(mlVar);
    }

    /* renamed from: a */
    private void m14726a(rk rkVar) {
        if (mo2248f() != rkVar) {
            String valueOf = String.valueOf(rkVar);
            String valueOf2 = String.valueOf(mo2248f());
            throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 18) + String.valueOf(valueOf2).length()).append("Expected ").append(valueOf).append(" but was ").append(valueOf2).toString());
        }
    }

    /* renamed from: r */
    private Object m14727r() {
        return this.f10101c.get(this.f10101c.size() - 1);
    }

    /* renamed from: s */
    private Object m14728s() {
        return this.f10101c.remove(this.f10101c.size() - 1);
    }

    /* renamed from: a */
    public void mo2242a() {
        m14726a(rk.BEGIN_ARRAY);
        this.f10101c.add(((mi) m14727r()).iterator());
    }

    /* renamed from: b */
    public void mo2243b() {
        m14726a(rk.END_ARRAY);
        m14728s();
        m14728s();
    }

    /* renamed from: c */
    public void mo2244c() {
        m14726a(rk.BEGIN_OBJECT);
        this.f10101c.add(((mq) m14727r()).m14546a().iterator());
    }

    public void close() {
        this.f10101c.clear();
        this.f10101c.add(f10100b);
    }

    /* renamed from: d */
    public void mo2246d() {
        m14726a(rk.END_OBJECT);
        m14728s();
        m14728s();
    }

    /* renamed from: e */
    public boolean mo2247e() {
        rk f = mo2248f();
        return (f == rk.END_OBJECT || f == rk.END_ARRAY) ? false : true;
    }

    /* renamed from: f */
    public rk mo2248f() {
        if (this.f10101c.isEmpty()) {
            return rk.END_DOCUMENT;
        }
        Object r = m14727r();
        if (r instanceof Iterator) {
            boolean z = this.f10101c.get(this.f10101c.size() - 2) instanceof mq;
            Iterator it = (Iterator) r;
            if (!it.hasNext()) {
                return z ? rk.END_OBJECT : rk.END_ARRAY;
            } else {
                if (z) {
                    return rk.NAME;
                }
                this.f10101c.add(it.next());
                return mo2248f();
            }
        } else if (r instanceof mq) {
            return rk.BEGIN_OBJECT;
        } else {
            if (r instanceof mi) {
                return rk.BEGIN_ARRAY;
            }
            if (r instanceof mt) {
                mt mtVar = (mt) r;
                if (mtVar.m14568q()) {
                    return rk.STRING;
                }
                if (mtVar.m14559a()) {
                    return rk.BOOLEAN;
                }
                if (mtVar.m14567p()) {
                    return rk.NUMBER;
                }
                throw new AssertionError();
            } else if (r instanceof mp) {
                return rk.NULL;
            } else {
                if (r == f10100b) {
                    throw new IllegalStateException("JsonReader is closed");
                }
                throw new AssertionError();
            }
        }
    }

    /* renamed from: g */
    public String mo2249g() {
        m14726a(rk.NAME);
        Entry entry = (Entry) ((Iterator) m14727r()).next();
        this.f10101c.add(entry.getValue());
        return (String) entry.getKey();
    }

    /* renamed from: h */
    public String mo2250h() {
        rk f = mo2248f();
        if (f == rk.STRING || f == rk.NUMBER) {
            return ((mt) m14728s()).mo2233c();
        }
        String valueOf = String.valueOf(rk.STRING);
        String valueOf2 = String.valueOf(f);
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 18) + String.valueOf(valueOf2).length()).append("Expected ").append(valueOf).append(" but was ").append(valueOf2).toString());
    }

    /* renamed from: i */
    public boolean mo2251i() {
        m14726a(rk.BOOLEAN);
        return ((mt) m14728s()).mo2237g();
    }

    /* renamed from: j */
    public void mo2252j() {
        m14726a(rk.NULL);
        m14728s();
    }

    /* renamed from: k */
    public double mo2253k() {
        rk f = mo2248f();
        if (f == rk.NUMBER || f == rk.STRING) {
            double d = ((mt) m14727r()).mo2234d();
            if (m14724p() || !(Double.isNaN(d) || Double.isInfinite(d))) {
                m14728s();
                return d;
            }
            throw new NumberFormatException("JSON forbids NaN and infinities: " + d);
        }
        String valueOf = String.valueOf(rk.NUMBER);
        String valueOf2 = String.valueOf(f);
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 18) + String.valueOf(valueOf2).length()).append("Expected ").append(valueOf).append(" but was ").append(valueOf2).toString());
    }

    /* renamed from: l */
    public long mo2254l() {
        rk f = mo2248f();
        if (f == rk.NUMBER || f == rk.STRING) {
            long e = ((mt) m14727r()).mo2235e();
            m14728s();
            return e;
        }
        String valueOf = String.valueOf(rk.NUMBER);
        String valueOf2 = String.valueOf(f);
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 18) + String.valueOf(valueOf2).length()).append("Expected ").append(valueOf).append(" but was ").append(valueOf2).toString());
    }

    /* renamed from: m */
    public int mo2255m() {
        rk f = mo2248f();
        if (f == rk.NUMBER || f == rk.STRING) {
            int f2 = ((mt) m14727r()).mo2236f();
            m14728s();
            return f2;
        }
        String valueOf = String.valueOf(rk.NUMBER);
        String valueOf2 = String.valueOf(f);
        throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 18) + String.valueOf(valueOf2).length()).append("Expected ").append(valueOf).append(" but was ").append(valueOf2).toString());
    }

    /* renamed from: n */
    public void mo2256n() {
        if (mo2248f() == rk.NAME) {
            mo2249g();
        } else {
            m14728s();
        }
    }

    /* renamed from: o */
    public void mo2257o() {
        m14726a(rk.NAME);
        Entry entry = (Entry) ((Iterator) m14727r()).next();
        this.f10101c.add(entry.getValue());
        this.f10101c.add(new mt((String) entry.getKey()));
    }

    public String toString() {
        return getClass().getSimpleName();
    }
}
