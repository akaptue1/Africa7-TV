package com.google.android.gms.internal;

enum it {
    Disconnected,
    GettingToken,
    Connecting,
    Authenticating,
    Connected
}
