package com.google.android.gms.internal;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

class ja {
    /* renamed from: a */
    private static long f9745a = 0;
    /* renamed from: b */
    private je f9746b;
    /* renamed from: c */
    private boolean f9747c = false;
    /* renamed from: d */
    private boolean f9748d = false;
    /* renamed from: e */
    private long f9749e = 0;
    /* renamed from: f */
    private jn f9750f;
    /* renamed from: g */
    private jd f9751g;
    /* renamed from: h */
    private ScheduledFuture<?> f9752h;
    /* renamed from: i */
    private ScheduledFuture<?> f9753i;
    /* renamed from: j */
    private final id f9754j;
    /* renamed from: k */
    private final ScheduledExecutorService f9755k;
    /* renamed from: l */
    private final jt f9756l;

    public ja(id idVar, C1480if c1480if, String str, jd jdVar, String str2) {
        this.f9754j = idVar;
        this.f9755k = idVar.m14113c();
        this.f9751g = jdVar;
        long j = f9745a;
        f9745a = 1 + j;
        this.f9756l = new jt(idVar.m14111a(), "WebSocket", "ws_" + j);
        this.f9746b = m14260a(c1480if, str, str2);
    }

    /* renamed from: a */
    private je m14260a(C1480if c1480if, String str, String str2) {
        if (str == null) {
            str = c1480if.m14123a();
        }
        URI a = C1480if.m14122a(str, c1480if.m14125c(), c1480if.m14124b(), str2);
        Map hashMap = new HashMap();
        hashMap.put("User-Agent", this.f9754j.m14116f());
        return new jf(this, new ke(a, null, hashMap));
    }

    /* renamed from: a */
    private void m14262a(int i) {
        this.f9749e = (long) i;
        this.f9750f = new jn();
        if (this.f9756l.m14343a()) {
            this.f9756l.m14342a("HandleNewFrameCount: " + this.f9749e, new Object[0]);
        }
    }

    /* renamed from: a */
    private void m14264a(String str) {
        Throwable th;
        jt jtVar;
        String str2;
        String valueOf;
        this.f9750f.m14315a(str);
        this.f9749e--;
        if (this.f9749e == 0) {
            try {
                this.f9750f.m14314a();
                Map a = kv.m14427a(this.f9750f.toString());
                this.f9750f = null;
                if (this.f9756l.m14343a()) {
                    jt jtVar2 = this.f9756l;
                    String valueOf2 = String.valueOf(a);
                    jtVar2.m14342a(new StringBuilder(String.valueOf(valueOf2).length() + 36).append("handleIncomingFrame complete frame: ").append(valueOf2).toString(), new Object[0]);
                }
                this.f9751g.mo2183a(a);
            } catch (Throwable e) {
                th = e;
                jtVar = this.f9756l;
                str2 = "Error parsing frame: ";
                valueOf = String.valueOf(this.f9750f.toString());
                jtVar.m14340a(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), th);
                m14284c();
                m14279h();
            } catch (Throwable e2) {
                th = e2;
                jtVar = this.f9756l;
                str2 = "Error parsing frame (cast error): ";
                valueOf = String.valueOf(this.f9750f.toString());
                jtVar.m14340a(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), th);
                m14284c();
                m14279h();
            }
        }
    }

    /* renamed from: a */
    private static String[] m14266a(String str, int i) {
        int i2 = 0;
        if (str.length() <= i) {
            return new String[]{str};
        }
        ArrayList arrayList = new ArrayList();
        while (i2 < str.length()) {
            arrayList.add(str.substring(i2, Math.min(i2 + i, str.length())));
            i2 += i;
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    /* renamed from: b */
    private String m14268b(String str) {
        if (str.length() <= 6) {
            try {
                int parseInt = Integer.parseInt(str);
                if (parseInt > 0) {
                    m14262a(parseInt);
                }
                return null;
            } catch (NumberFormatException e) {
            }
        }
        m14262a(1);
        return str;
    }

    /* renamed from: c */
    private void m14270c(String str) {
        if (!this.f9748d) {
            m14272d();
            if (m14276f()) {
                m14264a(str);
                return;
            }
            String b = m14268b(str);
            if (b != null) {
                m14264a(b);
            }
        }
    }

    /* renamed from: d */
    private void m14272d() {
        if (!this.f9748d) {
            if (this.f9752h != null) {
                this.f9752h.cancel(false);
                if (this.f9756l.m14343a()) {
                    this.f9756l.m14342a("Reset keepAlive. Remaining: " + this.f9752h.getDelay(TimeUnit.MILLISECONDS), new Object[0]);
                }
            } else if (this.f9756l.m14343a()) {
                this.f9756l.m14342a("Reset keepAlive", new Object[0]);
            }
            this.f9752h = this.f9755k.schedule(m14273e(), 45000, TimeUnit.MILLISECONDS);
        }
    }

    /* renamed from: e */
    private Runnable m14273e() {
        return new jc(this);
    }

    /* renamed from: f */
    private boolean m14276f() {
        return this.f9750f != null;
    }

    /* renamed from: g */
    private void m14278g() {
        if (!this.f9748d) {
            if (this.f9756l.m14343a()) {
                this.f9756l.m14342a("closing itself", new Object[0]);
            }
            m14279h();
        }
        this.f9746b = null;
        if (this.f9752h != null) {
            this.f9752h.cancel(false);
        }
    }

    /* renamed from: h */
    private void m14279h() {
        this.f9748d = true;
        this.f9751g.mo2184a(this.f9747c);
    }

    /* renamed from: i */
    private void m14280i() {
        if (!this.f9747c && !this.f9748d) {
            if (this.f9756l.m14343a()) {
                this.f9756l.m14342a("timed out on connect", new Object[0]);
            }
            this.f9746b.mo2213b();
        }
    }

    /* renamed from: a */
    public void m14281a() {
        this.f9746b.mo2209a();
        this.f9753i = this.f9755k.schedule(new jb(this), 30000, TimeUnit.MILLISECONDS);
    }

    /* renamed from: a */
    public void m14282a(Map<String, Object> map) {
        m14272d();
        String str;
        try {
            String[] a = m14266a(kv.m14425a((Map) map), 16384);
            if (a.length > 1) {
                this.f9746b.mo2212a(a.length);
            }
            for (String str2 : a) {
                this.f9746b.mo2212a(str2);
            }
        } catch (Throwable e) {
            Throwable th = e;
            jt jtVar = this.f9756l;
            str2 = "Failed to serialize message: ";
            String valueOf = String.valueOf(map.toString());
            jtVar.m14340a(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), th);
            m14279h();
        }
    }

    /* renamed from: b */
    public void m14283b() {
    }

    /* renamed from: c */
    public void m14284c() {
        if (this.f9756l.m14343a()) {
            this.f9756l.m14342a("websocket is being closed", new Object[0]);
        }
        this.f9748d = true;
        this.f9746b.mo2213b();
        if (this.f9753i != null) {
            this.f9753i.cancel(true);
        }
        if (this.f9752h != null) {
            this.f9752h.cancel(true);
        }
    }
}
