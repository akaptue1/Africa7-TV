package com.google.android.gms.internal;

@akw
public class xs {
    /* renamed from: a */
    public static xx m15643a(xz xzVar) {
        return xzVar == null ? null : xzVar.m15659a();
    }

    /* renamed from: a */
    public static xx m15644a(xz xzVar, long j) {
        return xzVar == null ? null : xzVar.m15660a(j);
    }

    /* renamed from: a */
    public static boolean m15645a(xz xzVar, xx xxVar, long j, String... strArr) {
        return (xzVar == null || xxVar == null) ? false : xzVar.m15664a(xxVar, j, strArr);
    }

    /* renamed from: a */
    public static boolean m15646a(xz xzVar, xx xxVar, String... strArr) {
        return (xzVar == null || xxVar == null) ? false : xzVar.m15665a(xxVar, strArr);
    }
}
