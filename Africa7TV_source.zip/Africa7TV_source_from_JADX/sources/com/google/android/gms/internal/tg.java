package com.google.android.gms.internal;

public class tg extends ty {
    /* renamed from: i */
    private static volatile String f10391i = null;
    /* renamed from: j */
    private static final Object f10392j = new Object();

    public tg(sy syVar, String str, String str2, fa faVar, int i, int i2) {
        super(syVar, str, str2, faVar, i, i2);
    }

    /* renamed from: a */
    protected void mo2283a() {
        this.e.f9368x = "E";
        if (f10391i == null) {
            synchronized (f10392j) {
                if (f10391i == null) {
                    f10391i = (String) this.f.invoke(null, new Object[]{this.b.m15255a()});
                }
            }
        }
        synchronized (this.e) {
            this.e.f9368x = jp.m14319a(f10391i.getBytes(), true);
        }
    }
}
