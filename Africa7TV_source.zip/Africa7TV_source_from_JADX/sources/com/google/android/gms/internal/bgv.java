package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import com.google.android.gms.common.stats.C1402a;
import com.google.android.gms.tagmanager.TagManagerService;

public class bgv implements ServiceConnection {
    /* renamed from: a */
    private final Context f9186a;
    /* renamed from: b */
    private final C1402a f9187b;
    /* renamed from: c */
    private volatile boolean f9188c;
    /* renamed from: d */
    private volatile boolean f9189d;
    /* renamed from: e */
    private bek f9190e;

    public bgv(Context context) {
        this(context, C1402a.m10285a());
    }

    bgv(Context context, C1402a c1402a) {
        this.f9188c = false;
        this.f9189d = false;
        this.f9186a = context;
        this.f9187b = c1402a;
    }

    /* renamed from: a */
    private void m13567a(beh beh, String str) {
        if (beh != null) {
            try {
                beh.mo2099a(false, str);
            } catch (Throwable e) {
                beo.m13388a("Error - local callback should not throw RemoteException", e);
            }
        }
    }

    /* renamed from: a */
    public void m13568a(String str, Bundle bundle, String str2, long j, boolean z) {
        if (m13570a()) {
            try {
                this.f9190e.mo2101a(str, bundle, str2, j, z);
            } catch (Throwable e) {
                beo.m13390b("Error calling service to emit event", e);
            }
        }
    }

    /* renamed from: a */
    public void m13569a(String str, String str2, String str3, beh beh) {
        if (m13570a()) {
            try {
                this.f9190e.mo2103a(str, str2, str3, beh);
                return;
            } catch (Throwable e) {
                beo.m13390b("Error calling service to load container", e);
                m13567a(beh, str);
                return;
            }
        }
        m13567a(beh, str);
    }

    /* renamed from: a */
    public boolean m13570a() {
        if (this.f9188c) {
            return true;
        }
        synchronized (this) {
            if (this.f9188c) {
                return true;
            }
            if (!this.f9189d) {
                if (this.f9187b.m10291a(this.f9186a, new Intent(this.f9186a, TagManagerService.class), (ServiceConnection) this, 1)) {
                    this.f9189d = true;
                } else {
                    return false;
                }
            }
            while (this.f9189d) {
                try {
                    wait();
                    this.f9189d = false;
                } catch (Throwable e) {
                    beo.m13390b("Error connecting to TagManagerService", e);
                    this.f9189d = false;
                }
            }
            boolean z = this.f9188c;
            return z;
        }
    }

    /* renamed from: b */
    public boolean m13571b() {
        if (m13570a()) {
            try {
                this.f9190e.mo2100a();
                return true;
            } catch (Throwable e) {
                beo.m13390b("Error in resetting service", e);
            }
        }
        return false;
    }

    /* renamed from: c */
    public void m13572c() {
        if (m13570a()) {
            try {
                this.f9190e.mo2104b();
            } catch (Throwable e) {
                beo.m13390b("Error calling service to dispatch pending events", e);
            }
        }
    }

    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        synchronized (this) {
            this.f9190e = bel.m13378a(iBinder);
            this.f9188c = true;
            this.f9189d = false;
            notifyAll();
        }
    }

    public void onServiceDisconnected(ComponentName componentName) {
        synchronized (this) {
            this.f9190e = null;
            this.f9188c = false;
            this.f9189d = false;
        }
    }
}
