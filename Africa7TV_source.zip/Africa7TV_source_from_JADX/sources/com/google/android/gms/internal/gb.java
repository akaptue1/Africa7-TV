package com.google.android.gms.internal;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public abstract class gb<T> {
    /* renamed from: a */
    protected Map<String, gb<?>> f9448a;

    /* renamed from: a */
    public Iterator<gb<?>> mo2137a() {
        return new gd();
    }

    /* renamed from: a */
    public void m13855a(String str, gb<?> gbVar) {
        if (this.f9448a == null) {
            this.f9448a = new HashMap();
        }
        this.f9448a.put(str, gbVar);
    }

    /* renamed from: a */
    public boolean m13856a(String str) {
        return this.f9448a != null && this.f9448a.containsKey(str);
    }

    /* renamed from: b */
    public gb<?> mo2138b(String str) {
        return this.f9448a != null ? (gb) this.f9448a.get(str) : gh.f9460e;
    }

    /* renamed from: b */
    public abstract T mo2133b();

    /* renamed from: c */
    protected Iterator<gb<?>> m13859c() {
        return this.f9448a == null ? new gd() : new gc(this, this.f9448a.keySet().iterator());
    }

    /* renamed from: c */
    public boolean mo2134c(String str) {
        return false;
    }

    /* renamed from: d */
    public bhb mo2135d(String str) {
        throw new IllegalStateException(new StringBuilder(String.valueOf(str).length() + 56).append("Attempting to access Native Method ").append(str).append(" on unsupported type.").toString());
    }

    public abstract String toString();
}
