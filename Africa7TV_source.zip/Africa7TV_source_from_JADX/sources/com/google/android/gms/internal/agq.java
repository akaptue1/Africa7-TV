package com.google.android.gms.internal;

import com.google.ads.C0783b;
import com.google.android.gms.ads.internal.util.client.C1043e;

class agq implements Runnable {
    /* renamed from: a */
    final /* synthetic */ C0783b f7515a;
    /* renamed from: b */
    final /* synthetic */ agp f7516b;

    agq(agp agp, C0783b c0783b) {
        this.f7516b = agp;
        this.f7515a = c0783b;
    }

    public void run() {
        try {
            this.f7516b.f7514a.mo1723a(ags.m11083a(this.f7515a));
        } catch (Throwable e) {
            C1043e.m7800c("Could not call onAdFailedToLoad.", e);
        }
    }
}
