package com.google.android.gms.internal;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

class bbl {
    /* renamed from: a */
    public long f8794a;
    /* renamed from: b */
    public String f8795b;
    /* renamed from: c */
    public String f8796c;
    /* renamed from: d */
    public long f8797d;
    /* renamed from: e */
    public long f8798e;
    /* renamed from: f */
    public long f8799f;
    /* renamed from: g */
    public long f8800g;
    /* renamed from: h */
    public Map<String, String> f8801h;

    private bbl() {
    }

    public bbl(String str, sv svVar) {
        this.f8795b = str;
        this.f8794a = (long) svVar.f10333a.length;
        this.f8796c = svVar.f10334b;
        this.f8797d = svVar.f10335c;
        this.f8798e = svVar.f10336d;
        this.f8799f = svVar.f10337e;
        this.f8800g = svVar.f10338f;
        this.f8801h = svVar.f10339g;
    }

    /* renamed from: a */
    public static bbl m13093a(InputStream inputStream) {
        bbl bbl = new bbl();
        if (bbj.m13074a(inputStream) != 538247942) {
            throw new IOException();
        }
        bbl.f8795b = bbj.m13083c(inputStream);
        bbl.f8796c = bbj.m13083c(inputStream);
        if (bbl.f8796c.equals("")) {
            bbl.f8796c = null;
        }
        bbl.f8797d = bbj.m13082b(inputStream);
        bbl.f8798e = bbj.m13082b(inputStream);
        bbl.f8799f = bbj.m13082b(inputStream);
        bbl.f8800g = bbj.m13082b(inputStream);
        bbl.f8801h = bbj.m13085d(inputStream);
        return bbl;
    }

    /* renamed from: a */
    public sv m13094a(byte[] bArr) {
        sv svVar = new sv();
        svVar.f10333a = bArr;
        svVar.f10334b = this.f8796c;
        svVar.f10335c = this.f8797d;
        svVar.f10336d = this.f8798e;
        svVar.f10337e = this.f8799f;
        svVar.f10338f = this.f8800g;
        svVar.f10339g = this.f8801h;
        return svVar;
    }

    /* renamed from: a */
    public boolean m13095a(OutputStream outputStream) {
        try {
            bbj.m13076a(outputStream, 538247942);
            bbj.m13078a(outputStream, this.f8795b);
            bbj.m13078a(outputStream, this.f8796c == null ? "" : this.f8796c);
            bbj.m13077a(outputStream, this.f8797d);
            bbj.m13077a(outputStream, this.f8798e);
            bbj.m13077a(outputStream, this.f8799f);
            bbj.m13077a(outputStream, this.f8800g);
            bbj.m13080a(this.f8801h, outputStream);
            outputStream.flush();
            return true;
        } catch (IOException e) {
            ayt.m12914b("%s", e.toString());
            return false;
        }
    }
}
