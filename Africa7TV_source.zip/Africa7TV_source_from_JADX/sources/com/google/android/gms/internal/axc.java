package com.google.android.gms.internal;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C1153k;
import com.google.android.gms.common.internal.C1387t;
import java.util.Map;

class axc extends axj {
    /* renamed from: a */
    final /* synthetic */ awz f8569a;
    /* renamed from: c */
    private final Map<C1153k, axb> f8570c;

    public axc(awz awz, Map<C1153k, axb> map) {
        this.f8569a = awz;
        super(awz);
        this.f8570c = map;
    }

    /* renamed from: a */
    public void mo2035a() {
        int i;
        int i2 = 1;
        int i3 = 0;
        int i4 = 1;
        int i5 = 0;
        for (C1153k c1153k : this.f8570c.keySet()) {
            if (!c1153k.mo2141p()) {
                i = 0;
                i4 = i5;
            } else if (((axb) this.f8570c.get(c1153k)).f8567c == 0) {
                i = 1;
                break;
            } else {
                i = i4;
                i4 = 1;
            }
            i5 = i4;
            i4 = i;
        }
        i2 = i5;
        i = 0;
        if (i2 != 0) {
            i3 = this.f8569a.f8546d.mo1597a(this.f8569a.f8545c);
        }
        if (i3 == 0 || (r0 == 0 && i4 == 0)) {
            if (this.f8569a.f8555m) {
                this.f8569a.f8553k.mo1560h();
            }
            for (C1153k c1153k2 : this.f8570c.keySet()) {
                C1387t c1387t = (C1387t) this.f8570c.get(c1153k2);
                if (!c1153k2.mo2141p() || i3 == 0) {
                    c1153k2.m8608a(c1387t);
                } else {
                    this.f8569a.f8543a.m12805a(new axe(this, this.f8569a, c1387t));
                }
            }
            return;
        }
        this.f8569a.f8543a.m12805a(new axd(this, this.f8569a, new ConnectionResult(i3, null)));
    }
}
