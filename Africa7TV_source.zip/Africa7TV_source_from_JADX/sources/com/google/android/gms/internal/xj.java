package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;

@akw
public class xj {
    /* renamed from: a */
    public SharedPreferences m15620a(Context context) {
        return context.getSharedPreferences("google_ads_flags", 1);
    }
}
