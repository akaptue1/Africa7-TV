package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.RemoteException;
import android.os.SystemClock;
import com.google.android.gms.common.util.C1415d;
import com.google.android.gms.tagmanager.C1575q;
import java.util.Date;
import java.util.Map;

public class bdy implements C1415d {
    /* renamed from: a */
    private final Bundle f9005a;
    /* renamed from: b */
    private final String f9006b;
    /* renamed from: c */
    private final Date f9007c;
    /* renamed from: d */
    private final String f9008d;
    /* renamed from: e */
    private Map<String, Object> f9009e;
    /* renamed from: f */
    private boolean f9010f;
    /* renamed from: g */
    private final C1575q f9011g;

    public bdy(String str, Bundle bundle, String str2, Date date, boolean z, C1575q c1575q) {
        this.f9006b = str;
        if (bundle == null) {
            bundle = new Bundle();
        }
        this.f9005a = bundle;
        this.f9007c = date;
        this.f9008d = str2;
        this.f9010f = z;
        this.f9011g = c1575q;
    }

    /* renamed from: a */
    public long mo1680a() {
        return this.f9007c.getTime();
    }

    /* renamed from: a */
    public void m13336a(boolean z) {
        this.f9010f = z;
    }

    /* renamed from: b */
    public long mo1681b() {
        return SystemClock.elapsedRealtime();
    }

    /* renamed from: c */
    public long mo1682c() {
        return System.nanoTime();
    }

    /* renamed from: d */
    public String m13339d() {
        return this.f9006b;
    }

    /* renamed from: e */
    public Bundle m13340e() {
        return this.f9005a;
    }

    /* renamed from: f */
    public String m13341f() {
        return this.f9008d;
    }

    /* renamed from: g */
    public Map<String, Object> m13342g() {
        if (this.f9009e == null) {
            try {
                this.f9009e = this.f9011g.mo2408a();
            } catch (RemoteException e) {
                String str = "Error calling measurement proxy:";
                String valueOf = String.valueOf(e.getMessage());
                beo.m13387a(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
            }
        }
        return this.f9009e;
    }

    /* renamed from: h */
    public boolean m13343h() {
        return this.f9010f;
    }
}
