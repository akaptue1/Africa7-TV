package com.google.android.gms.internal;

import java.util.AbstractSet;
import java.util.Iterator;

final class oj extends AbstractSet<K> {
    /* renamed from: a */
    final /* synthetic */ of f10052a;

    oj(of ofVar) {
        this.f10052a = ofVar;
    }

    public void clear() {
        this.f10052a.clear();
    }

    public boolean contains(Object obj) {
        return this.f10052a.containsKey(obj);
    }

    public Iterator<K> iterator() {
        return new ok(this);
    }

    public boolean remove(Object obj) {
        return this.f10052a.m14649b(obj) != null;
    }

    public int size() {
        return this.f10052a.f10041c;
    }
}
