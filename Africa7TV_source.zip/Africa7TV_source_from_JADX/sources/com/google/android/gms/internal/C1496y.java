package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C1370c;
import java.util.List;

/* renamed from: com.google.android.gms.internal.y */
public class C1496y extends bhd {
    /* renamed from: a */
    protected gb<?> mo1692a(bff bff, gb<?>... gbVarArr) {
        C1370c.m10120b(gbVarArr != null);
        C1370c.m10120b(gbVarArr.length == 3);
        C1370c.m10120b(gbVarArr[1] instanceof gn);
        C1370c.m10120b(gbVarArr[2] instanceof gi);
        gb gbVar = gbVarArr[0];
        String str = (String) ((gn) gbVarArr[1]).mo2133b();
        List list = (List) ((gi) gbVarArr[2]).mo2133b();
        if (gbVar.m13856a(str)) {
            gb b = gbVar.mo2138b(str);
            if (b instanceof gg) {
                return ((bhb) ((gg) b).mo2133b()).a_(bff, (gb[]) list.toArray(new gb[list.size()]));
            }
            throw new IllegalArgumentException(new StringBuilder(String.valueOf(str).length() + 35).append("Apply TypeError: ").append(str).append(" is not a function").toString());
        } else if (gbVar.mo2134c(str)) {
            bhb d = gbVar.mo2135d(str);
            list.add(0, gbVar);
            return d.a_(bff, (gb[]) list.toArray(new gb[list.size()]));
        } else {
            throw new IllegalArgumentException(new StringBuilder(String.valueOf(str).length() + 40).append("Apply TypeError: object has no ").append(str).append(" property").toString());
        }
    }
}
