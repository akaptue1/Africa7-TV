package com.google.android.gms.internal;

import java.util.Map;

class arw implements Runnable {
    /* renamed from: a */
    final /* synthetic */ Map f8339a;
    /* renamed from: b */
    final /* synthetic */ arv f8340b;

    arw(arv arv, Map map) {
        this.f8340b = arv;
        this.f8339a = map;
    }

    public void run() {
        this.f8340b.f8329a.mo1894a("pubVideoCmd", this.f8339a);
    }
}
