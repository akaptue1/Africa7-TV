package com.google.android.gms.internal;

class awl implements Runnable {
    /* renamed from: a */
    final /* synthetic */ awk f8515a;

    awl(awk awk) {
        this.f8515a = awk;
    }

    public void run() {
        this.f8515a.f8513m.lock();
        try {
            this.f8515a.m12590j();
        } finally {
            this.f8515a.f8513m.unlock();
        }
    }
}
