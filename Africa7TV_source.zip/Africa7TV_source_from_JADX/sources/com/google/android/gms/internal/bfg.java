package com.google.android.gms.internal;

class bfg implements bey {
    /* renamed from: a */
    private final long f9091a;
    /* renamed from: b */
    private final int f9092b;
    /* renamed from: c */
    private double f9093c;
    /* renamed from: d */
    private long f9094d;
    /* renamed from: e */
    private final Object f9095e;

    public bfg() {
        this(60, 2000);
    }

    public bfg(int i, long j) {
        this.f9095e = new Object();
        this.f9092b = i;
        this.f9093c = (double) this.f9092b;
        this.f9091a = j;
    }

    /* renamed from: a */
    public boolean mo2112a() {
        boolean z;
        synchronized (this.f9095e) {
            long currentTimeMillis = System.currentTimeMillis();
            if (this.f9093c < ((double) this.f9092b)) {
                double d = ((double) (currentTimeMillis - this.f9094d)) / ((double) this.f9091a);
                if (d > 0.0d) {
                    this.f9093c = Math.min((double) this.f9092b, d + this.f9093c);
                }
            }
            this.f9094d = currentTimeMillis;
            if (this.f9093c >= 1.0d) {
                this.f9093c -= 1.0d;
                z = true;
            } else {
                beo.m13389b("No more tokens available.");
                z = false;
            }
        }
        return z;
    }
}
