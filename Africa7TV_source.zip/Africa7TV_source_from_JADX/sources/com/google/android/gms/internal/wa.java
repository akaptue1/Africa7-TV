package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.bd;
import com.google.android.gms.ads.internal.util.client.C1043e;
import java.util.ArrayList;
import java.util.Iterator;

@akw
public class wa {
    /* renamed from: a */
    private final int f10547a;
    /* renamed from: b */
    private final int f10548b;
    /* renamed from: c */
    private final int f10549c;
    /* renamed from: d */
    private final wo f10550d;
    /* renamed from: e */
    private final ww f10551e;
    /* renamed from: f */
    private final Object f10552f = new Object();
    /* renamed from: g */
    private ArrayList<String> f10553g = new ArrayList();
    /* renamed from: h */
    private ArrayList<String> f10554h = new ArrayList();
    /* renamed from: i */
    private ArrayList<wm> f10555i = new ArrayList();
    /* renamed from: j */
    private int f10556j = 0;
    /* renamed from: k */
    private int f10557k = 0;
    /* renamed from: l */
    private int f10558l = 0;
    /* renamed from: m */
    private int f10559m;
    /* renamed from: n */
    private String f10560n = "";
    /* renamed from: o */
    private String f10561o = "";
    /* renamed from: p */
    private String f10562p = "";

    public wa(int i, int i2, int i3, int i4, int i5, int i6, int i7) {
        this.f10547a = i;
        this.f10548b = i2;
        this.f10549c = i3;
        this.f10550d = new wo(i4);
        this.f10551e = new ww(i5, i6, i7);
    }

    /* renamed from: a */
    private String m15497a(ArrayList<String> arrayList, int i) {
        if (arrayList.isEmpty()) {
            return "";
        }
        StringBuffer stringBuffer = new StringBuffer();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            stringBuffer.append((String) it.next());
            stringBuffer.append(' ');
            if (stringBuffer.length() > i) {
                break;
            }
        }
        stringBuffer.deleteCharAt(stringBuffer.length() - 1);
        String stringBuffer2 = stringBuffer.toString();
        return stringBuffer2.length() >= i ? stringBuffer2.substring(0, i) : stringBuffer2;
    }

    /* renamed from: c */
    private void m15498c(String str, boolean z, float f, float f2, float f3, float f4) {
        if (str != null && str.length() >= this.f10549c) {
            synchronized (this.f10552f) {
                this.f10553g.add(str);
                this.f10556j += str.length();
                if (z) {
                    this.f10554h.add(str);
                    this.f10555i.add(new wm(f, f2, f3, f4, this.f10554h.size() - 1));
                }
            }
        }
    }

    /* renamed from: a */
    int m15499a(int i, int i2) {
        return (this.f10547a * i) + (this.f10548b * i2);
    }

    /* renamed from: a */
    public void m15500a(int i) {
        this.f10557k = i;
    }

    /* renamed from: a */
    public void m15501a(String str, boolean z, float f, float f2, float f3, float f4) {
        m15498c(str, z, f, f2, f3, f4);
        synchronized (this.f10552f) {
            if (this.f10558l < 0) {
                C1043e.m7794a("ActivityContent: negative number of WebViews.");
            }
            m15510h();
        }
    }

    /* renamed from: a */
    public boolean m15502a() {
        boolean z;
        synchronized (this.f10552f) {
            z = this.f10558l == 0;
        }
        return z;
    }

    /* renamed from: b */
    public String m15503b() {
        return this.f10560n;
    }

    /* renamed from: b */
    public void m15504b(String str, boolean z, float f, float f2, float f3, float f4) {
        m15498c(str, z, f, f2, f3, f4);
    }

    /* renamed from: c */
    public String m15505c() {
        return this.f10561o;
    }

    /* renamed from: d */
    public String m15506d() {
        return this.f10562p;
    }

    /* renamed from: e */
    public void m15507e() {
        synchronized (this.f10552f) {
            this.f10559m -= 100;
        }
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof wa)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        wa waVar = (wa) obj;
        return waVar.m15503b() != null && waVar.m15503b().equals(m15503b());
    }

    /* renamed from: f */
    public void m15508f() {
        synchronized (this.f10552f) {
            this.f10558l--;
        }
    }

    /* renamed from: g */
    public void m15509g() {
        synchronized (this.f10552f) {
            this.f10558l++;
        }
    }

    /* renamed from: h */
    public void m15510h() {
        synchronized (this.f10552f) {
            int a = m15499a(this.f10556j, this.f10557k);
            if (a > this.f10559m) {
                this.f10559m = a;
                if (((Boolean) xm.ae.m15604c()).booleanValue() && !bd.m6648i().m11614b()) {
                    this.f10560n = this.f10550d.m15559a(this.f10553g);
                    this.f10561o = this.f10550d.m15559a(this.f10554h);
                }
                if (((Boolean) xm.ag.m15604c()).booleanValue() && !bd.m6648i().m11616c()) {
                    this.f10562p = this.f10551e.m15581a(this.f10554h, this.f10555i);
                }
            }
        }
    }

    public int hashCode() {
        return m15503b().hashCode();
    }

    /* renamed from: i */
    public int m15511i() {
        return this.f10559m;
    }

    /* renamed from: j */
    int m15512j() {
        return this.f10556j;
    }

    public String toString() {
        int i = this.f10557k;
        int i2 = this.f10559m;
        int i3 = this.f10556j;
        String valueOf = String.valueOf(m15497a(this.f10553g, 100));
        String valueOf2 = String.valueOf(m15497a(this.f10554h, 100));
        String str = this.f10560n;
        String str2 = this.f10561o;
        String str3 = this.f10562p;
        return new StringBuilder(((((String.valueOf(valueOf).length() + 165) + String.valueOf(valueOf2).length()) + String.valueOf(str).length()) + String.valueOf(str2).length()) + String.valueOf(str3).length()).append("ActivityContent fetchId: ").append(i).append(" score:").append(i2).append(" total_length:").append(i3).append("\n text: ").append(valueOf).append("\n viewableText").append(valueOf2).append("\n signture: ").append(str).append("\n viewableSignture: ").append(str2).append("\n viewableSignatureForVertical: ").append(str3).toString();
    }
}
