package com.google.android.gms;

/* compiled from: R */
/* renamed from: com.google.android.gms.f */
public final class C1434f {
    public static final int cast_libraries_material_featurehighlight_pulse_base_alpha = 2131623939;
    public static final int google_play_services_version = 2131623940;
}
