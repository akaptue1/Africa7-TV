package com.google.android.gms.clearcut;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.bp;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.internal.sg;
import com.google.android.gms.playlog.internal.PlayLoggerContext;
import java.util.Arrays;

public class LogEventParcelable extends AbstractSafeParcelable {
    public static final Creator<LogEventParcelable> CREATOR = new C1342h();
    /* renamed from: a */
    public final int f6770a;
    /* renamed from: b */
    public PlayLoggerContext f6771b;
    /* renamed from: c */
    public byte[] f6772c;
    /* renamed from: d */
    public int[] f6773d;
    /* renamed from: e */
    public String[] f6774e;
    /* renamed from: f */
    public int[] f6775f;
    /* renamed from: g */
    public byte[][] f6776g;
    /* renamed from: h */
    public boolean f6777h;
    /* renamed from: i */
    public final sg f6778i;
    /* renamed from: j */
    public final C1339e f6779j;
    /* renamed from: k */
    public final C1339e f6780k;

    LogEventParcelable(int i, PlayLoggerContext playLoggerContext, byte[] bArr, int[] iArr, String[] strArr, int[] iArr2, byte[][] bArr2, boolean z) {
        this.f6770a = i;
        this.f6771b = playLoggerContext;
        this.f6772c = bArr;
        this.f6773d = iArr;
        this.f6774e = strArr;
        this.f6778i = null;
        this.f6779j = null;
        this.f6780k = null;
        this.f6775f = iArr2;
        this.f6776g = bArr2;
        this.f6777h = z;
    }

    public LogEventParcelable(PlayLoggerContext playLoggerContext, sg sgVar, C1339e c1339e, C1339e c1339e2, int[] iArr, String[] strArr, int[] iArr2, byte[][] bArr, boolean z) {
        this.f6770a = 1;
        this.f6771b = playLoggerContext;
        this.f6778i = sgVar;
        this.f6779j = c1339e;
        this.f6780k = c1339e2;
        this.f6773d = iArr;
        this.f6774e = strArr;
        this.f6775f = iArr2;
        this.f6776g = bArr;
        this.f6777h = z;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LogEventParcelable)) {
            return false;
        }
        LogEventParcelable logEventParcelable = (LogEventParcelable) obj;
        return this.f6770a == logEventParcelable.f6770a && bp.m10109a(this.f6771b, logEventParcelable.f6771b) && Arrays.equals(this.f6772c, logEventParcelable.f6772c) && Arrays.equals(this.f6773d, logEventParcelable.f6773d) && Arrays.equals(this.f6774e, logEventParcelable.f6774e) && bp.m10109a(this.f6778i, logEventParcelable.f6778i) && bp.m10109a(this.f6779j, logEventParcelable.f6779j) && bp.m10109a(this.f6780k, logEventParcelable.f6780k) && Arrays.equals(this.f6775f, logEventParcelable.f6775f) && Arrays.deepEquals(this.f6776g, logEventParcelable.f6776g) && this.f6777h == logEventParcelable.f6777h;
    }

    public int hashCode() {
        return bp.m10107a(Integer.valueOf(this.f6770a), this.f6771b, this.f6772c, this.f6773d, this.f6774e, this.f6778i, this.f6779j, this.f6780k, this.f6775f, this.f6776g, Boolean.valueOf(this.f6777h));
    }

    public String toString() {
        return "LogEventParcelable[" + this.f6770a + ", " + this.f6771b + ", " + "LogEventBytes: " + (this.f6772c == null ? null : new String(this.f6772c)) + ", " + "TestCodes: " + Arrays.toString(this.f6773d) + ", " + "MendelPackages: " + Arrays.toString(this.f6774e) + ", " + "LogEvent: " + this.f6778i + ", " + "ExtensionProducer: " + this.f6779j + ", " + "VeProducer: " + this.f6780k + ", " + "ExperimentIDs: " + Arrays.toString(this.f6775f) + ", " + "ExperimentTokens: " + Arrays.toString(this.f6776g) + ", " + "AddPhenotypeExperimentTokens: " + this.f6777h + "]";
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1342h.m9739a(this, parcel, i);
    }
}
