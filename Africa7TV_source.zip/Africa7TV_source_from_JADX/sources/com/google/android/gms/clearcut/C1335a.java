package com.google.android.gms.clearcut;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import com.google.android.gms.common.api.C1138g;
import com.google.android.gms.common.api.C1344a;
import com.google.android.gms.common.api.C1345d;
import com.google.android.gms.common.api.C1347l;
import com.google.android.gms.common.internal.C1370c;
import com.google.android.gms.common.util.C1415d;
import com.google.android.gms.common.util.C1417f;
import com.google.android.gms.internal.auz;
import com.google.android.gms.internal.avc;
import com.google.android.gms.internal.avk;
import java.util.ArrayList;
import java.util.Iterator;

/* renamed from: com.google.android.gms.clearcut.a */
public final class C1335a {
    /* renamed from: a */
    public static final C1347l<avc> f6781a = new C1347l();
    /* renamed from: b */
    public static final C1138g<avc, C1345d> f6782b = new C1336b();
    @Deprecated
    /* renamed from: c */
    public static final C1344a<C1345d> f6783c = new C1344a("ClearcutLogger.API", f6782b, f6781a);
    /* renamed from: d */
    private final String f6784d;
    /* renamed from: e */
    private final int f6785e;
    /* renamed from: f */
    private String f6786f;
    /* renamed from: g */
    private int f6787g;
    /* renamed from: h */
    private String f6788h;
    /* renamed from: i */
    private String f6789i;
    /* renamed from: j */
    private final boolean f6790j;
    /* renamed from: k */
    private int f6791k;
    /* renamed from: l */
    private final C1341g f6792l;
    /* renamed from: m */
    private final C1415d f6793m;
    /* renamed from: n */
    private C1340f f6794n;
    /* renamed from: o */
    private final C1338d f6795o;

    public C1335a(Context context, int i, String str, String str2, String str3, boolean z, C1341g c1341g, C1415d c1415d, C1340f c1340f, C1338d c1338d) {
        boolean z2 = false;
        this.f6787g = -1;
        this.f6791k = 0;
        this.f6784d = context.getPackageName();
        this.f6785e = m9708a(context);
        this.f6787g = i;
        this.f6786f = str;
        this.f6788h = str2;
        this.f6789i = str3;
        this.f6790j = z;
        this.f6792l = c1341g;
        this.f6793m = c1415d;
        if (c1340f == null) {
            c1340f = new C1340f();
        }
        this.f6794n = c1340f;
        this.f6791k = 0;
        this.f6795o = c1338d;
        if (this.f6790j) {
            if (this.f6788h == null) {
                z2 = true;
            }
            C1370c.m10121b(z2, "can't be anonymous with an upload account");
        }
    }

    public C1335a(Context context, String str, String str2) {
        this(context, -1, str, str2, null, false, auz.m12455a(context), C1417f.m10332d(), null, new avk(context));
    }

    /* renamed from: a */
    private int m9708a(Context context) {
        int i = 0;
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
            Log.wtf("ClearcutLogger", "This can't happen.");
            return i;
        }
    }

    /* renamed from: d */
    private static int[] m9716d(ArrayList<Integer> arrayList) {
        if (arrayList == null) {
            return null;
        }
        int[] iArr = new int[arrayList.size()];
        Iterator it = arrayList.iterator();
        int i = 0;
        while (it.hasNext()) {
            int i2 = i + 1;
            iArr[i] = ((Integer) it.next()).intValue();
            i = i2;
        }
        return iArr;
    }

    /* renamed from: e */
    private static String[] m9718e(ArrayList<String> arrayList) {
        return arrayList == null ? null : (String[]) arrayList.toArray(new String[0]);
    }

    /* renamed from: f */
    private static byte[][] m9720f(ArrayList<byte[]> arrayList) {
        return arrayList == null ? null : (byte[][]) arrayList.toArray(new byte[0][]);
    }

    /* renamed from: a */
    public C1337c m9727a(byte[] bArr) {
        return new C1337c(this, bArr);
    }
}
