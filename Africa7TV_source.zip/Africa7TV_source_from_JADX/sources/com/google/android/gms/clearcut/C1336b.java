package com.google.android.gms.clearcut;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.C1138g;
import com.google.android.gms.common.api.C1153k;
import com.google.android.gms.common.api.C1242s;
import com.google.android.gms.common.api.C1243t;
import com.google.android.gms.common.api.C1345d;
import com.google.android.gms.common.internal.C1393z;
import com.google.android.gms.internal.avc;

/* renamed from: com.google.android.gms.clearcut.b */
final class C1336b extends C1138g<avc, C1345d> {
    C1336b() {
    }

    /* renamed from: a */
    public /* synthetic */ C1153k mo1387a(Context context, Looper looper, C1393z c1393z, Object obj, C1242s c1242s, C1243t c1243t) {
        return m9729a(context, looper, c1393z, (C1345d) obj, c1242s, c1243t);
    }

    /* renamed from: a */
    public avc m9729a(Context context, Looper looper, C1393z c1393z, C1345d c1345d, C1242s c1242s, C1243t c1243t) {
        return new avc(context, looper, c1393z, c1242s, c1243t);
    }
}
