package com.google.android.gms.clearcut;

import com.facebook.widget.PlacePickerFragment;
import java.util.TimeZone;

/* renamed from: com.google.android.gms.clearcut.f */
public class C1340f {
    /* renamed from: a */
    public long m9737a(long j) {
        return (long) (TimeZone.getDefault().getOffset(j) / PlacePickerFragment.DEFAULT_RADIUS_IN_METERS);
    }
}
