package com.google.android.gms.clearcut;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C1384a;
import com.google.android.gms.common.internal.safeparcel.C1385b;
import com.google.android.gms.common.internal.safeparcel.C1386c;
import com.google.android.gms.playlog.internal.PlayLoggerContext;

/* renamed from: com.google.android.gms.clearcut.h */
public class C1342h implements Creator<LogEventParcelable> {
    /* renamed from: a */
    static void m9739a(LogEventParcelable logEventParcelable, Parcel parcel, int i) {
        int a = C1386c.m10193a(parcel);
        C1386c.m10198a(parcel, 1, logEventParcelable.f6770a);
        C1386c.m10202a(parcel, 2, logEventParcelable.f6771b, i, false);
        C1386c.m10210a(parcel, 3, logEventParcelable.f6772c, false);
        C1386c.m10211a(parcel, 4, logEventParcelable.f6773d, false);
        C1386c.m10214a(parcel, 5, logEventParcelable.f6774e, false);
        C1386c.m10211a(parcel, 6, logEventParcelable.f6775f, false);
        C1386c.m10215a(parcel, 7, logEventParcelable.f6776g, false);
        C1386c.m10209a(parcel, 8, logEventParcelable.f6777h);
        C1386c.m10194a(parcel, a);
    }

    /* renamed from: a */
    public LogEventParcelable m9740a(Parcel parcel) {
        byte[][] bArr = null;
        int b = C1384a.m10169b(parcel);
        int i = 0;
        boolean z = true;
        int[] iArr = null;
        String[] strArr = null;
        int[] iArr2 = null;
        byte[] bArr2 = null;
        PlayLoggerContext playLoggerContext = null;
        while (parcel.dataPosition() < b) {
            int a = C1384a.m10164a(parcel);
            switch (C1384a.m10163a(a)) {
                case 1:
                    i = C1384a.m10175e(parcel, a);
                    break;
                case 2:
                    playLoggerContext = (PlayLoggerContext) C1384a.m10166a(parcel, a, PlayLoggerContext.CREATOR);
                    break;
                case 3:
                    bArr2 = C1384a.m10186p(parcel, a);
                    break;
                case 4:
                    iArr2 = C1384a.m10188r(parcel, a);
                    break;
                case 5:
                    strArr = C1384a.m10190t(parcel, a);
                    break;
                case 6:
                    iArr = C1384a.m10188r(parcel, a);
                    break;
                case 7:
                    bArr = C1384a.m10187q(parcel, a);
                    break;
                case 8:
                    z = C1384a.m10173c(parcel, a);
                    break;
                default:
                    C1384a.m10170b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LogEventParcelable(i, playLoggerContext, bArr2, iArr2, strArr, iArr, bArr, z);
        }
        throw new C1385b("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public LogEventParcelable[] m9741a(int i) {
        return new LogEventParcelable[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m9740a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m9741a(i);
    }
}
