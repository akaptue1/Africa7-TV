package com.google.android.gms.clearcut;

import com.google.android.gms.common.api.C1192u;
import com.google.android.gms.common.api.C1352q;
import com.google.android.gms.common.api.C1355w;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.sg;
import com.google.android.gms.playlog.internal.PlayLoggerContext;
import java.util.ArrayList;

/* renamed from: com.google.android.gms.clearcut.c */
public class C1337c {
    /* renamed from: a */
    final /* synthetic */ C1335a f6796a;
    /* renamed from: b */
    private int f6797b;
    /* renamed from: c */
    private String f6798c;
    /* renamed from: d */
    private String f6799d;
    /* renamed from: e */
    private String f6800e;
    /* renamed from: f */
    private int f6801f;
    /* renamed from: g */
    private final C1339e f6802g;
    /* renamed from: h */
    private ArrayList<Integer> f6803h;
    /* renamed from: i */
    private ArrayList<String> f6804i;
    /* renamed from: j */
    private ArrayList<Integer> f6805j;
    /* renamed from: k */
    private ArrayList<byte[]> f6806k;
    /* renamed from: l */
    private boolean f6807l;
    /* renamed from: m */
    private final sg f6808m;
    /* renamed from: n */
    private boolean f6809n;

    private C1337c(C1335a c1335a, byte[] bArr) {
        this(c1335a, bArr, null);
    }

    private C1337c(C1335a c1335a, byte[] bArr, C1339e c1339e) {
        this.f6796a = c1335a;
        this.f6797b = this.f6796a.f6787g;
        this.f6798c = this.f6796a.f6786f;
        this.f6799d = this.f6796a.f6788h;
        this.f6800e = this.f6796a.f6789i;
        this.f6801f = 0;
        this.f6803h = null;
        this.f6804i = null;
        this.f6805j = null;
        this.f6806k = null;
        this.f6807l = true;
        this.f6808m = new sg();
        this.f6809n = false;
        this.f6799d = c1335a.f6788h;
        this.f6800e = c1335a.f6789i;
        this.f6808m.f10292a = c1335a.f6793m.mo1680a();
        this.f6808m.f10293b = c1335a.f6793m.mo1681b();
        this.f6808m.f10306o = c1335a.f6794n.m9737a(this.f6808m.f10292a);
        if (bArr != null) {
            this.f6808m.f10302k = bArr;
        }
        this.f6802g = c1339e;
    }

    /* renamed from: a */
    public LogEventParcelable m9730a() {
        return new LogEventParcelable(new PlayLoggerContext(this.f6796a.f6784d, this.f6796a.f6785e, this.f6797b, this.f6798c, this.f6799d, this.f6800e, this.f6796a.f6790j, this.f6801f), this.f6808m, this.f6802g, null, C1335a.m9716d(null), C1335a.m9718e(null), C1335a.m9716d(null), C1335a.m9720f(null), this.f6807l);
    }

    /* renamed from: a */
    public C1337c m9731a(int i) {
        this.f6808m.f10296e = i;
        return this;
    }

    @Deprecated
    /* renamed from: a */
    public C1192u<Status> m9732a(C1352q c1352q) {
        return m9734b();
    }

    /* renamed from: b */
    public C1337c m9733b(int i) {
        this.f6808m.f10297f = i;
        return this;
    }

    @Deprecated
    /* renamed from: b */
    public C1192u<Status> m9734b() {
        if (this.f6809n) {
            throw new IllegalStateException("do not reuse LogEventBuilder");
        }
        this.f6809n = true;
        LogEventParcelable a = m9730a();
        PlayLoggerContext playLoggerContext = a.f6771b;
        return this.f6796a.f6795o.mo1991a(playLoggerContext.f11318h, playLoggerContext.f11314d) ? this.f6796a.f6792l.mo1986a(a) : C1355w.m9831a(Status.f6824a);
    }
}
