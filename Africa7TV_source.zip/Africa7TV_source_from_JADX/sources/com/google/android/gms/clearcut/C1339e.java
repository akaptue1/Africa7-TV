package com.google.android.gms.clearcut;

/* renamed from: com.google.android.gms.clearcut.e */
public interface C1339e {
    /* renamed from: a */
    byte[] m9736a();
}
