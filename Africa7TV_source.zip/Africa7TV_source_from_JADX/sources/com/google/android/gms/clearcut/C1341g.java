package com.google.android.gms.clearcut;

import com.google.android.gms.common.api.C1192u;
import com.google.android.gms.common.api.Status;

/* renamed from: com.google.android.gms.clearcut.g */
public interface C1341g {
    /* renamed from: a */
    C1192u<Status> mo1986a(LogEventParcelable logEventParcelable);
}
