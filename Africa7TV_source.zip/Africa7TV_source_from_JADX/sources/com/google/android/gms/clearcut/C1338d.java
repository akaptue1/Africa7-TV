package com.google.android.gms.clearcut;

/* renamed from: com.google.android.gms.clearcut.d */
public interface C1338d {
    /* renamed from: a */
    boolean mo1991a(String str, int i);
}
